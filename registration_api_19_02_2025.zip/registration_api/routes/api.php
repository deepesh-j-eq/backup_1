<?php

use App\http\Controllers\API\AuthController;
use App\Http\Controllers\API\CartController;
use App\Http\Controllers\API\CategoryController;
use App\Http\Controllers\API\ColorController;
use App\Http\Controllers\API\ContactMessageController;
use App\http\Controllers\API\PostController;
use App\Http\Controllers\API\ProductController;
use App\Http\Controllers\API\RatingController;
use App\Http\Controllers\API\SizeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('signup',[AuthController::class,'signup']);
Route::post('login', [AuthController::class, 'login']);
Route::apiResource('ratings', RatingController::class);
Route::post('contact', [ContactMessageController::class, 'store']);

Route::middleware('auth:sanctum')->group(function(){
    Route::post('logout', [AuthController::class, 'logout']);
    Route::apiResource('posts', PostController::class);

    Route::apiResource('category', CategoryController::class);
    Route::apiResource('sizes', SizeController::class);
    Route::apiResource('colors', ColorController::class);
    Route::apiResource('products', ProductController::class);

    Route::get('products_with_filter', [ProductController::class, 'productsWithFilter'])->name('products.with.filter');

    Route::controller(ContactMessageController::class)->group(function(){
        Route::get('contact_messages', 'index')->name('all.contact.messages');
        Route::get('contact_messages/{id}', 'show')->name('single.contact.messages');
    });

    Route::controller(CartController::class)->group(function(){
        Route::post('cart/add', 'addToCart');
        Route::post('cart/checkout', 'checkout');
    });
});
