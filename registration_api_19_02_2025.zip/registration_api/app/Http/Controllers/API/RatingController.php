<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Rating;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class RatingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = array();

        $user = auth('sanctum')->user();
        $userId = $user ? $user->id : null;

        $ratingsQuery = Rating::with(['product', 'user']);

        if ($userId) {
            $ratingsQuery->where('user_id', $userId);
        }

        $data['ratings'] = $ratingsQuery->get();

        return response()->json([
            'staus' => true,
            'message' => 'All ratings',
            'data' => $data,
        ],200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'rating' => 'required|numeric|min:0|regex:/^\d+(\.\d{1,1})?$/',
            'review' => 'required|string',
            'product_id' => 'required|integer|exists:products,id',
            'user_id' => 'nullable|integer|exists:users,id'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }

        $user = auth('sanctum')->user();
        $userId = $user ? $user->id : null;
        
        $rating = Rating::create([
            'rating' => number_format($request->rating, 1),
            'review' => $request->review,
            'product_id' => $request->product_id,
            'user_id' => $userId
        ]);

        if (!$rating) {
            return response()->json([
                'status' => false,
                'message' => 'Rating create failed',
            ], 500);
        }

        return response()->json([
            'status' => true,
            'message' => 'Rating created successfully',
            'rating' => $rating
        ], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $data = array();

        $user = auth('sanctum')->user();
        $userId = $user ? $user->id : null;

        $ratingsQuery = Rating::with(['product', 'user']);

        if ($userId) {
            $ratingsQuery->where('user_id', $userId);
        }

        $data['ratings'] = $ratingsQuery->where('id', $id)->first();

        if ($data['ratings'] == null) {
            return response()->json([
                'status' => false,
                'message' => 'Requested rating is not available'
            ], 400);
        }

        return response()->json([
            'status' => true,
            'message' => 'Your single rating',
            'data' => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $rating = Rating::find($id);

        if (!$rating) {
            return response()->json([
                'status' => false,
                'message' => 'Requested rating is not available for update',
            ], 400);
        }

        $validate = Validator::make($request->all(), [
            'rating' => 'required|numeric|min:0|regex:/^\d+(\.\d{1,1})?$/',
            'review' => 'required|string',
            'product_id' => 'required|integer|exists:products,id',
            'user_id' => 'nullable|integer|exists:users,id'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }

        $user = auth('sanctum')->user();
        $userId = $user ? $user->id : null;

        $updateRating = Rating::where('id', $id)->update([
            'rating' => number_format($request->rating, 1),
            'review' => $request->review,
            'product_id' => $request->product_id,
            'user_id' => $userId
        ]);

        if (!$updateRating) {
            return response()->json([
                'status' => false,
                'message' => 'Rating update failed',
            ], 500);
        }

        $data = array();
        $data['rating'] = Rating::find($id);

        return response()->json([
            'status' => true,
            'message' => 'Rating updated successfully',
            'rating' => $rating
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $rating = Rating::find($id);

        if (!$rating) {
            return response()->json([
                'status' => false,
                'message' => 'Requested rating is not available for delete',
            ], 400);
        }

        $rating->delete();

        return response()->json([
            'status' => true,
            'message' => 'Rating deleted successfully',
        ], 200);
    }
}
