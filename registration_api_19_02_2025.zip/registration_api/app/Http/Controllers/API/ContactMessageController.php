<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Mail\ContactMessageMail;
use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class ContactMessageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = array();

        $data['contact_messages'] = ContactMessage::with(['user'])->get();

        $data['contact_messages']->transform(function ($contactMsg) {
            if($contactMsg->user == null) {
                $contactMsg->makeHidden(['user']);
            }            
        
            return $contactMsg;
        });

        return response()->json([
            'staus' => true,
            'message' => 'All contact messages',
            'data' => $data,
        ],200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'full_name' => 'required|string',
            'email' => 'required|email:rfc,dns',
            'message' => 'required|string|min:10'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }

        $user = auth('sanctum')->user();
        $userId = $user ? $user->id : null;

        $contact = ContactMessage::create([
            'full_name' => $request->full_name,
            'email' => $request->email,
            'message' => $request->message,
            'user_id' => $userId
        ]);

        if (!$contact) {
            return response()->json([
                'status' => false,
                'message' => 'Contact message create failed',
            ], 500);
        }

        Mail::to('test@example.com')->send(new ContactMessageMail($contact));

        return response()->json([
            'status' => true,
            'message' => 'Your message has been sent successfully!',
            'data' => $contact
        ], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $data = array();

        $data['contact_message'] = ContactMessage::with('user')
            ->select('id', 'full_name', 'email', 'message', 'user_id')
            ->where('id', $id)
            ->first();

        if ($data['contact_message'] == null) {
            return response()->json([
                'status' => false,
                'message' => 'Requested contact message is not available'
            ], 400);
        }

        return response()->json([
            'status' => true,
            'message' => 'Your single contact message',
            'data' => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
