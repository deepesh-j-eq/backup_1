<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    public function addToCart(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'product_id' => 'required|integer|exists:products,id',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $product = Product::find($request->product_id);

            if ($product->quantity < $request->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not enough stock available',
                ], 400);
            }

            $user = auth('sanctum')->user();

            $cartItem = Cart::where('user_id', $user->id)
                            ->where('product_id', $request->product_id)
                            ->first();

            if ($cartItem) {
                $cartItem->quantity += $request->quantity;
                $cartItem->save();
            } else {
                Cart::create([
                    'quantity' => $request->quantity,
                    'product_id' => $request->product_id,
                    'user_id' => $user->id
                ]);
            }

            return response()->json([
                'status' => true,
                'message' => 'Product added to cart successfully',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }
}
