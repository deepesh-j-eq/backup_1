<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
* @OA\SecurityScheme(
*     securityScheme="bearerAuth",
*     type="http",
*     scheme="bearer"
* )
*/
class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    /**
    
 * @OA\Get(
 *     path="/api/posts",
 *     summary="Get all posts",
 *     description="Fetches all post data from the database",
 *     tags={"Posts"},
 *     security={{"bearerAuth": {}}},
 *     @OA\Response(
 *         response=200,
 *         description="All post data fetched successfully",
 *         @OA\JsonContent(
 *             type="object",
 *             @OA\Property(
 *                 property="status",
 *                 type="boolean",
 *                 example=true
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="All Post Data."
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *                 @OA\Property(
 *                     property="Posts",
 *                     type="array",
 *                     @OA\Items(
 *                         type="object",
 *                         @OA\Property(property="id", type="integer", example=1),
 *                         @OA\Property(property="title", type="string", example="Post title"),
 *                         @OA\Property(property="content", type="string", example="Post content")
 *                     )
 *                 )
 *             )
 *         )
 *     ),
 *     @OA\Response(
 *         response=500,
 *         description="Internal server error"
 *     )
 * )
 */
   
    public function index()
    {
        $data['Posts'] = post::all();

        return response()->json([
            'staus'=>true,
            'message'=>'All Post Data .',
            'data' => $data,
        ],200);
    }

    
    // Store a newly created resource in storage.

/**
 * @OA\Post(
 *     path="/api/posts",  
 *     summary="Create a new post",  
 *     description="This endpoint allows users to create a new post with a title, description, and image.", 
 *     tags={"Posts"},  
 *     security={{"bearerAuth": {}}}, 
 *     
 *     @OA\RequestBody(
 *         required=true,
 *         description="Post data that needs to be created",
 *         @OA\MediaType(
 *             mediaType="multipart/form-data", 
 *             @OA\Schema(
 *                 type="object",
 *                 required={"title", "description", "image"},
 *                 @OA\Property(property="title", type="string", example="New Post Title"),
 *                 @OA\Property(property="description", type="string", example="This is the description of the post."),
 *                 @OA\Property(property="image", type="string", format="binary", example="", nullable=false)
 *             )
 *         ),
 *         @OA\MediaType(
 *             mediaType="application/json",  
 *             @OA\Schema(
 *                 type="object",
 *                 required={"title", "description", "image"},
 *                 @OA\Property(property="title", type="string", example="New Post Title"),
 *                 @OA\Property(property="description", type="string", example="This is the description of the post."),
 *                 @OA\Property(property="image", type="string", example="path/to/image.jpg")  
 *             )
 *         )
 *     ),
 *     
 *     @OA\Response(
 *         response=200,
 *         description="Post created successfully",
 *         @OA\JsonContent(
 *             type="object",
 *             @OA\Property(property="status", type="boolean", example=true),
 *             @OA\Property(property="message", type="string", example="post created successfully"),
 *             @OA\Property(property="post", type="object", 
 *                 @OA\Property(property="id", type="integer", example=1),
 *                 @OA\Property(property="title", type="string", example="New Post Title"),
 *                 @OA\Property(property="description", type="string", example="This is the description of the post."),
 *                 @OA\Property(property="image", type="string", example="uploads/1634312345.jpg")
 *             )
 *         )
 *     ),
 *     
 *     @OA\Response(
 *         response=401,
 *         description="Validation Error",
 *         @OA\JsonContent(
 *             type="object",
 *             @OA\Property(property="status", type="boolean", example=false),
 *             @OA\Property(property="message", type="string", example="validation Error"),
 *             @OA\Property(property="errors", type="object", 
 *                 @OA\Property(property="title", type="array", @OA\Items(type="string", example="The title field is required.")),
 *                 @OA\Property(property="description", type="array", @OA\Items(type="string", example="The description field is required.")),
 *                 @OA\Property(property="image", type="array", @OA\Items(type="string", example="The image field is required."))
 *             )
 *         )
 *     ),
 *     
 *     @OA\Response(
 *         response=500,
 *         description="Internal Server Error",
 *         @OA\JsonContent(
 *             type="object",
 *             @OA\Property(property="status", type="boolean", example=false),
 *             @OA\Property(property="message", type="string", example="Internal server error")
 *         )
 *     )
 * )
 */
    public function store(Request $request)
    {
            $validateUser = Validator::make(
            $request->all(), 
            [
                'title'=>'required',
                'description' => 'required ',
                'image'=>'required|image|mimes:png,jpg,jpeg,gif',
            ]);

            if ($validateUser->fails()){
                return response()->json([
                    'status'=> false,
                    'message'=>'validation Error',
                    'errors'=>$validateUser->errors()
                ],401);
            } 
            $img =$request->image;
            $ext = $img->getClientOriginalExtension();
            $imageName = time(). '.'. $ext;
            $img->move(public_path(). '/uploads',$imageName);
           
            $post = post::create([
                'title'=>$request->title,
                'description' => $request->description,
                'image'=>$imageName,
            ]);

            return response()->json([
                'status'=> true,
                'message'=>'post created successfully',
                'post'=>$post
            ],200);
    }

    /**   
    * @OA\Get(
    *     path="/api/posts/{id}",
    *     summary="Get a single post",
    *     tags={"Posts"},
    *     security={{"bearerAuth":{}}},
    *     description="Get a single post by id",
    *     operationId="getSinglePost",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Post id to show that post",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Successful response",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single post"),
    *             @OA\Property(
    *                 property="data", type="object",
    *                 @OA\Property(property="post", type="array", @OA\Items(
    *                     @OA\Property(property="id", type="integer", example=1),
    *                     @OA\Property(property="title", type="string", example="Post Title"),
    *                     @OA\Property(property="description", type="string", example="Post Description"),
    *                     @OA\Property(property="image", type="string", example="post.jpg")
    *                 ))
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested post not available",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested post not available"),
    *         )
    *     ),
    *     @OA\Response(
    *           response=401,
    *           description="Unauthenticated"
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */

    //Display the specified resource.
    public function show(string $id)
    {
        try {
            $data = array();

            $data['post'] = post::select(
                'id',
                'title',
                'description',
                'image'
            )->where('id', $id)->first();

            if ($data['post'] == null) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested post not available'
                ], 400);
            }

            return response()->json([
                'status' => true,
                'message' => 'Your single post',
                'data' => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/posts/{id}",
    *     summary="Update a post",
    *     tags={"Posts"},
    *     security={{"bearerAuth":{}}},
    *     description="Update a post by id",
    *     operationId="updatePost",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Post id to be updated",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "title", "description"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="title",
    *                       type="string",
    *                       example="Updated Post Title"
    *                   ),
    *                   @OA\Property(
    *                       property="description",
    *                       type="string",
    *                       example="Updated Post Description"
    *                   ),
    *                   @OA\Property(
    *                       property="image",
    *                       type="string",
    *                       format="binary",
    *                       example=""
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "title", "description"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="title",
    *                       type="string",
    *                       example="Updated Post Title"
    *                   ),
    *                   @OA\Property(
    *                       property="description",
    *                       type="string",
    *                       example="Updated Post Description"
    *                   ),
    *                   @OA\Property(
    *                       property="image",
    *                       type="string",
    *                       format="binary",
    *                       example="path/to/image.jpg"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Post updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Post updated successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested post not available for update",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested post not available for update"),
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Validation error"),
    *             @OA\Property(property="errors", type="object", additionalProperties=true, example={
    *                   "_method": {"The _method field is required."},
    *                   "title": {"The title field is required."},
    *                   "description": {"The description field is required."},
    *                   "image": {"The image must be a valid image."}
    *             })
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */

    // Update the specified resource in storage.
    public function update(Request $request, string $id)
    {
        try {
            $post = post::find($id);

            if ($post) {
                $rules = [
                    'title' => 'required',
                    'description' => 'required',
                ];

                if ($request->hasFile('image')) {
                    $rules['image'] = 'image|mimes:jpeg,png,jpg,gif';
                }
                
                $validate = Validator::make($request->all(), $rules);
        
                if ($validate->fails()) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Validation error',
                        'errors' => $validate->errors()
                    ], 401);
                }
        
                if ($request->hasFile('image')) {
                    $path = public_path(). '/uploads/';
        
                    if ($post->image != '' && $post->image != null) {
                        $old_image = $path . $post->image;
        
                        if (file_exists($old_image)) {
                            unlink($old_image);
                        }
                    }
        
                    $img = $request->image;
                    $ext = $img->getClientOriginalExtension();
                    $imageName = time(). '.' .$ext;
                    $img->move(public_path(). '/uploads', $imageName);
                } else {
                    $imageName = $post->image;
                }
        
                post::where('id', $id)->update([
                    'title' => $request->title,
                    'description' => $request->description,
                    'image' => $imageName,
                ]);
        
                return response()->json([
                    'status' => true,
                    'message' => 'Post updated successfully',
                ], 200);
            } else {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested post not available for update'
                ], 400);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
    * @OA\Delete(
    *     path="/api/posts/{id}",
    *     summary="Delete a post",
    *     tags={"Posts"},
    *     security={{"bearerAuth":{}}},
    *     description="Delete a post by id",
    *     operationId="deletePost",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Post id to delete",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Post deleted successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Post deleted successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested post not available for delete",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested post not available for delete"),
    *         )
    *     ),
    *     @OA\Response(
    *           response=401,
    *           description="Unauthenticated"
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */

    //Remove the specified resource from storage.
    public function destroy(string $id)
    {
        $post = post::find($id);

        if ($post) {
            if ($post->image) {
                $path = public_path(). '/uploads/';
                $imagePath = $path . $post->image;

                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
            }

            $post->delete();

            return response()->json([
                'status' => true,
                'message' => 'Post deleted successfully',
            ], 200);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'Requested post not available for delete',
            ], 400);
        }
    }
}
