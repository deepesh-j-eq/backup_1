<?php

namespace App\Http\Controllers\API;

use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

/**
* @OA\Info(
*   title="Laravel Sanctum API",
*   version="1.0.0",
*   description="Authentication related operations"
* )
*/
class AuthController extends Controller
{ 
        /**
     * @OA\Post(
     *     path="/api/signup",
     *     summary="User signup",
     *     description="Registers a new user with the provided name, email, and password.",
     *     operationId="signup",
     *     tags={"Registration"},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"name", "email", "password"},
     *             @OA\Property(property="name", type="string", example="John Doe"),
     *             @OA\Property(property="email", type="string", format="email", example="john@test.com"),
     *             @OA\Property(property="password", type="string", format="password", example="password123")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="User created successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="User created successfully"),
     *             @OA\Property(property="errors", type="object", example={})
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Validation error",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="validation Error"),
     *             @OA\Property(property="errors", type="object", additionalProperties=true, example={
     *                 "name": {"The name field is required."},
     *                "email": {"The email field is required.", "The email must be a valid email address."}
     *             })
     *         )
     *     )
     * )
     */
    public function signup(Request $request){
        $validateUser =Validator::make(
            $request->all(), 
            [
                'name'=>'required',
                'email' => 'required|email:rfc,dns|unique:users,email',
                'password'=>'required',
            ]);

            if ($validateUser->fails()){
                return response()->json([
                    'status'=> false,
                    'message'=>'validation Error',
                    'errors'=>$validateUser->errors()
                ],401);
            }
           
            $user= User::create([
                'name'=>$request->name,
                'email'=>$request->email,
                'password'=>$request->password,
            ]);

            return response()->json([
                'status'=> true,
                'message'=>'User created successfully',
                'errors'=>$user
            ],200);
    }

    /**
    * @OA\Post(
    *     path="/api/login",
    *     summary="User login",
    *     tags={"Authentication"},
    *     description="User Login API",
    *     operationId="login",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"email", "password"},
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   ),
    *                   @OA\Property(
    *                       property="password",
    *                       type="string",
    *                       example="12345"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"email", "password"},
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   ),
    *                   @OA\Property(
    *                       property="password",
    *                       type="string",
    *                       example="12345"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="User successfully logged in",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="User Logged in Successfully"),
    *             @OA\Property(property="token", type="string", example="your_api_token_here"),
    *             @OA\Property(property="token_type", type="string", example="bearer")
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Validation error"),
    *             @OA\Property(property="errors", type="object", additionalProperties=true, example={
    *                   "email": {"The email field is required.", "The email must be a valid email address."},
    *                   "password": {"The password field is required."}
    *             })
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Email and Password does not matched")
    *         )
    *     )
    * )
    */

    public function login (Request $request) {
        $validateUser = Validator::make($request->all(), [
            'email' => 'required|email:rfc,dns',
            'password' => 'required'
        ]);

        if ($validateUser->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validateUser->errors()
            ], 400);
        }   

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $authUser = Auth::user();

            return response()->json([
                'status' => true,
                'message' => 'User Logged in Successfully',
                'token' => $authUser->createToken("API Token")->plainTextToken,
                'token_type' => 'bearer'
            ], 200);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'Email and Password does not matched'
            ], 401);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/logout",
    *     summary="User logout",
    *     tags={"Authentication"},
    *     description="User Logout API",
    *     operationId="logout",
    *     security={{"bearerAuth": {}}},
    *     @OA\Response(
    *         response=200,
    *         description="User Logged out Successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="User Logged out Successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthenticated",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="User not authenticated")
    *         )
    *     )
    * )
    */
    public function logout (Request $request) {
        $authUser = Auth::user();

        if ($authUser) {
            $authUser->tokens()->delete();

            return response()->json([
                'status' => true,
                'message' => 'User Logged out Successfully'
            ], 200);
        }

        return response()->json([
            'status' => false,
            'message' => 'User not authenticated'
        ], 401);
    }
}
