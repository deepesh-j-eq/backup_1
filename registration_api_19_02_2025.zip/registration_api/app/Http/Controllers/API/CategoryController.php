<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = array();
        $data['categories'] = Category::all();

        return response()->json([
            'staus' => true,
            'message' => 'All categories',
            'data' => $data,
        ],200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'name'=>'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }
        
        $category = Category::create([
            'name' => $request->name
        ]);

        if (!$category) {
            return response()->json([
                'status' => false,
                'message' => 'Category create failed',
            ], 500);
        }

        return response()->json([
            'status' => true,
            'message' => 'Category created successfully',
            'category' => $category
        ], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $data = array();

        $data['category'] = Category::select(
            'id',
            'name'
        )->where('id', $id)->first();

        if ($data['category'] == null) {
            return response()->json([
                'status' => false,
                'message' => 'Requested category is not available'
            ], 400);
        }

        return response()->json([
            'status' => true,
            'message' => 'Your single category',
            'data' => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $category = Category::find($id);

        if (!$category) {
            return response()->json([
                'status' => false,
                'message' => 'Requested post not available for update'
            ], 400);
        }

        $validate = Validator::make($request->all(), [
            'name'=>'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }          

        $updateCategory = Category::where('id', $id)->update([
            'name' => $request->name
        ]);

        if (!$updateCategory) {
            return response()->json([
                'status' => false,
                'message' => 'Category update failed',
            ], 500);
        }

        $data = array();
        $data['category'] = Category::find($id);

        return response()->json([
            'status' => true,
            'message' => 'Category updated successfully',
            'data' => $data
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $category = Category::find($id);

        if (!$category) {
            return response()->json([
                'status' => false,
                'message' => 'Requested category not available for delete',
            ], 400);
        }

        $category->delete();

        return response()->json([
            'status' => true,
            'message' => 'Category deleted successfully',
        ], 200);
    }
}
