<?php

namespace Tests\Unit\Api;

use App\Enums\HttpStatusCode;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Requests\CategoryRequest;
use App\Models\Category;
use App\Services\BaseService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Tests\TestCase;

class CategoryControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $baseService, $categoryController;

    protected function setUp(): void
    {
        parent::setUp();

        $this->baseService = $this->createMock(BaseService::class);

        $this->categoryController = new CategoryController();
        $reflection = new \ReflectionClass($this->categoryController);
        $property = $reflection->getProperty('baseService');
        $property->setAccessible(true);
        $property->setValue($this->categoryController, $this->baseService);
    }

    public function test_index_returns_categories_when_found()
    {
        $categories = new Collection([
            new Category(['id' => 1, 'name' => 'Sports']),
            new Category(['id' => 2, 'name' => 'Assesories']),
        ]);

        $this->baseService
            ->expects($this->once())
            ->method('getAllRecords')
            ->willReturn($categories);

        $response = $this->categoryController->index();

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'All categories',
            'data' => ['categories' => $categories->toArray()]
        ], $response->getData(true));
    }

    public function test_index_returns_not_found_when_no_categories()
    {
        $this->baseService
            ->expects($this->once())
            ->method('getAllRecords')
            ->willReturn(new Collection());

        $response = $this->categoryController->index();

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::NOT_FOUND->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'No categories found'
        ], $response->getData(true));
    }

    public function test_store_creates_category_successfully()
    {
        $request = new class extends CategoryRequest {
            public $name = 'Clothing';

            public function validated($key = null, $default = null): array
            {
                return ['name' => $this->name];
            }

            public function authorize(): bool
            {
                return true;
            }

            public function rules(): array
            {
                return [];
            }
        };

        $category = new Category(['id' => 1, 'name' => 'Clothing']);

        $this->baseService
            ->expects($this->once())
            ->method('store')
            ->with(['name' => 'Clothing'])
            ->willReturn($category);

        $response = $this->categoryController->store($request);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::CREATED->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Category created successfully',
            'data' => ['category' => $category->toArray()]
        ], $response->getData(true));
    }

    public function test_store_returns_error_on_creation_failure()
    {
        $request = new class extends CategoryRequest {
            public $name = 'Clothing';

            public function validated($key = null, $default = null): array
            {
                return ['name' => $this->name];
            }

            public function authorize(): bool
            {
                return true;
            }

            public function rules(): array
            {
                return [];
            }
        };

        $this->baseService
            ->expects($this->once())
            ->method('store')
            ->with(['name' => 'Clothing'])
            ->willReturn(false);

        $response = $this->categoryController->store($request);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::INTERNAL_SERVER_ERROR->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Category creation failed'
        ], $response->getData(true));
    }

    public function test_show_returns_category_when_found()
    {
        $category = new Category(['id' => 1, 'name' => 'Sports']);
        $fields = ['id', 'name'];

        $this->baseService
            ->expects($this->once())
            ->method('getRecordById')
            ->with('1', $fields)
            ->willReturn(helperJSONResponse(
                true,
                'Record retrieved',
                ['single_record' => $category],
                HttpStatusCode::OK->value
            ));

        $response = $this->categoryController->show('1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Record retrieved',
            'data' => ['single_record' => $category->toArray()]
        ], $response->getData(true));
    }

    public function test_update_updates_category_successfully()
    {
        $category = Category::create(['name' => 'Clothing']);

        $baseRequest = Request::create('/api/admin/category/1', 'PUT', ['name' => 'Updated Clothing']);
        $request = CategoryRequest::createFrom($baseRequest);

        $request->setContainer($this->app);
        $request->validateResolved();

        $this->baseService
            ->expects($this->once())
            ->method('update')
            ->with((string) $category->id, ['name' => 'Updated Clothing'])
            ->willReturn(true);

        $response = $this->categoryController->update($request, (string) $category->id);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());

        $expectedCategory = Category::find($category->id)->toArray();
        $this->assertEquals([
            'status' => true,
            'message' => 'Category updated successfully',
            'data' => ['category' => $expectedCategory]
        ], $response->getData(true));
    }

    public function test_update_returns_not_found_when_category_missing()
    {
        $baseRequest = Request::create('/api/admin/category/1', 'PUT', ['name' => 'Updated Clothing']);
        $request = CategoryRequest::createFrom($baseRequest);
        $request->setContainer($this->app);
        $request->validateResolved();

        $this->baseService->expects($this->never())->method('update');

        $response = $this->categoryController->update($request, '1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::NOT_FOUND->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Requested category not available for update'
        ], $response->getData(true));
    }

    public function test_update_returns_error_on_update_failure()
    {
        $request = new class extends CategoryRequest {
            public $name = 'Updated Clothing';

            public function validated($key = null, $default = null): array
            {
                return ['name' => $this->name];
            }

            public function authorize(): bool
            {
                return true;
            }

            public function rules(): array
            {
                return [];
            }
        };

        $existingCategory = new Category(['id' => 1, 'name' => 'Clothing']);

        $categoryStubClass = new class extends Category {
            protected static $mockFindResults = [];

            public static function find($id)
            {
                return isset(static::$mockFindResults[$id]) ? static::$mockFindResults[$id] : null;
            }

            public static function setFindResult($id, $result)
            {
                static::$mockFindResults[$id] = $result;
            }
        };

        $categoryStubClass::setFindResult('1', $existingCategory);

        $controller = new class($categoryStubClass) extends CategoryController {
            protected $categoryClass;

            public function __construct($categoryClass)
            {
                parent::__construct();
                $this->categoryClass = \get_class($categoryClass);
            }

            public function update(CategoryRequest $request, string $id)
            {
                $categoryClass = $this->categoryClass;
                $category = $categoryClass::find($id);

                if (!$category) {
                    return helperJSONResponse(false, 'Requested category not available for update', [], HttpStatusCode::NOT_FOUND->value);
                }

                $categoryData = ['name' => $request->name];
                $updateCategory = $this->baseService->update($id, $categoryData);

                if (!$updateCategory) {
                    return helperJSONResponse(false, 'Category update failed', [], HttpStatusCode::INTERNAL_SERVER_ERROR->value);
                }

                $updatedCategoryData = $categoryClass::find($id);

                return helperJSONResponse(true, 'Category updated successfully', ['category' => $updatedCategoryData], HttpStatusCode::OK->value);
            }
        };

        $reflection = new \ReflectionClass($controller);
        $property = $reflection->getProperty('baseService');
        $property->setAccessible(true);
        $property->setValue($controller, $this->baseService);

        $this->baseService
            ->expects($this->once())
            ->method('update')
            ->with('1', ['name' => 'Updated Clothing'])
            ->willReturn(false);

        $response = $controller->update($request, '1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::INTERNAL_SERVER_ERROR->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Category update failed',
        ], $response->getData(true));
    }

    public function test_destroy_deletes_category_successfully()
    {
        $this->baseService
            ->expects($this->once())
            ->method('deleteRecordById')
            ->with('1')
            ->willReturn(helperJSONResponse(
                true,
                'Record deleted successfully',
                [],
                HttpStatusCode::OK->value
            ));

        $response = $this->categoryController->destroy('1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Record deleted successfully'
        ], $response->getData(true));
    }
}
