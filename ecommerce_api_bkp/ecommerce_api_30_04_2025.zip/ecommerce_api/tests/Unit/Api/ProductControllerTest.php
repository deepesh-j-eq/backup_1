<?php

namespace Tests\Unit\Api;

use App\Enums\HttpStatusCode;
use App\Http\Controllers\Api\ProductController;
use App\Models\Category;
use App\Models\Color;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Role;
use App\Models\Size;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ProductControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $controller;

    protected function setUp(): void
    {
        parent::setUp();
        $this->controller = new ProductController();

        Auth::shouldUse('sanctum');
    }

    private function createMockCategory()
    {
        $category = $this->createMock(Category::class);
        $category->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['name', 'Test Category'],
        ]);
        $category->method('toArray')->willReturn([
            'id' => 1,
            'name' => 'Test Category',
        ]);

        return $category;
    }

    private function createMockSize()
    {
        $size = $this->createMock(Size::class);
        $size->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['size', 'M'],
        ]);
        $size->method('toArray')->willReturn([
            'id' => 1,
            'size' => 'M',
        ]);

        return $size;
    }

    private function createMockProductImage()
    {
        $productImage = $this->createMock(ProductImage::class);
        $productImage->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['product_id', 1],
            ['image_path', 'product_images/test.jpg'],
        ]);
        $productImage->method('toArray')->willReturn([
            'id' => 1,
            'product_id' => 1,
            'image_path' => 'product_images/test.jpg',
        ]);

        return $productImage;
    }

    private function createMockColor()
    {
        $color = $this->createMock(Color::class);
        $color->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['color', 'Red1'],
        ]);
        $color->method('toArray')->willReturn([
            'id' => 1,
            'color' => 'Red1',
        ]);

        return $color;
    }

    private function createMockProduct($category, $color, $size, $productImage)
    {
        $product = $this->createMock(Product::class);
        $product->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['name', 'Test Product'],
            ['description', 'Test Description'],
            ['price', 99.99],
            ['quantity', 10],
            ['category_id', 1],
        ]);
        $product->method('toArray')->willReturn([
            'id' => 1,
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'quantity' => 10,
            'category_id' => 1,
            'category' => $category->toArray(),
            'colors' => [$color->toArray()],
            'sizes' => [$size->toArray()],
            'images' => [$productImage->toArray()],
        ]);

        return $product;
    }

    public function test_index_returns_products_when_authenticated()
    {
        $role = Role::create([
            'id' => 1,
            'role' => 'user',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test1@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->assertNotNull($user->role, 'Role relationship is null');
        $this->assertEquals('user', $user->role->role, 'Role is not "user"');
        $this->assertTrue($user->isUser(), 'isUser() check failed');

        Auth::shouldUse('sanctum');
        Auth::setUser($user);

        $category = Category::create([
            'id' => 1,
            'name' => 'Test Category',
        ]);

        $product1 = Product::create([
            'id' => 1,
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'quantity' => 10,
            'category_id' => $category->id,
        ]);

        $product2 = Product::create([
            'id' => 2,
            'name' => 'Test Product 2',
            'description' => 'Test Description 2',
            'price' => 99.99,
            'quantity' => 10,
            'category_id' => $category->id,
        ]);

        $mockCategory = $this->createMockCategory();

        $customizedMockCategory = $mockCategory->toArray();
        if (isset($customizedMockCategory['id'])) {
            unset($customizedMockCategory['id']);
        }

        $product1Mock = $this->createMock(Product::class);
        $product1Mock->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['name', 'Test Product'],
            ['description', 'Test Description'],
            ['price', 99.99],
            ['quantity', 10],
            ['category_id', 1],
        ]);
        $product1Mock->method('toArray')->willReturn([
            'id' => 1,
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'quantity' => 10,
            'category_id' => 1,
            'category' => $customizedMockCategory,
            'colors' => [],
            'sizes' => [],
            'images' => [],
            'ratings' => [],
        ]);

        $product2Mock = $this->createMock(Product::class);
        $product2Mock->method('getAttribute')->willReturnMap([
            ['id', 2],
            ['name', 'Test Product 2'],
            ['description', 'Test Description 2'],
            ['price', 99.99],
            ['quantity', 10],
            ['category_id', 1],
        ]);
        $product2Mock->method('toArray')->willReturn([
            'id' => 2,
            'name' => 'Test Product 2',
            'description' => 'Test Description 2',
            'price' => 99.99,
            'quantity' => 10,
            'category_id' => 1,
            'category' => $customizedMockCategory,
            'colors' => [],
            'sizes' => [],
            'images' => [],
            'ratings' => [],
        ]);

        $productMock = $this->createMock(Product::class);
        $productMock->method('with')->with(['category', 'colors', 'sizes', 'images'])->willReturnSelf();

        $productMock->method('all')->willReturn(collect([$product1Mock, $product2Mock]));


        $this->app->instance(Product::class, $productMock);

        $response = $this->controller->index();

        $customizedProduct1Mock = $product1Mock->toArray();
        if (isset($customizedProduct1Mock['id'])) {
            unset($customizedProduct1Mock['id']);
        }
        if (isset($customizedProduct1Mock['category_id'])) {
            unset($customizedProduct1Mock['category_id']);
        }

        $customizedProduct2Mock = $product2Mock->toArray();
        if (isset($customizedProduct2Mock['id'])) {
            unset($customizedProduct2Mock['id']);
        }
        if (isset($customizedProduct2Mock['category_id'])) {
            unset($customizedProduct2Mock['category_id']);
        }

        $expectedData = [
            'status' => true,
            'message' => 'All products',
            'data' => [
                'products' => [
                    $customizedProduct1Mock,
                    $customizedProduct2Mock,
                ],
            ],
        ];

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals($expectedData, $response->getData(true));
    }

    public function test_index_returns_unauthenticated_error()
    {
        $response = $this->getJson('/api/products');

        $response->assertStatus(HttpStatusCode::UNAUTHORIZED->value)
            ->assertJson([
                'status' => false,
                'message' => 'Unauthenticated.',
            ]);
    }

    public function test_store_creates_product_successfully()
    {
        Storage::fake('public');

        $role = Role::create([
            'id' => 1,
            'role' => 'admin',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->actingAs($user, 'sanctum');

        $category = $this->createMockCategory();
        $size = $this->createMockSize();
        $color = $this->createMockColor();
        $productImage = $this->createMockProductImage();
        $productMock = $this->createMockProduct($category, $color, $size, $productImage);

        Category::create([
            'id' => 1,
            'name' => 'Test Category',
        ]);

        Size::create([
            'id' => 1,
            'size' => 'M',
        ]);

        Color::create([
            'id' => 1,
            'color' => 'Red1',
        ]);

        $image = UploadedFile::fake()->image('test.jpg');

        $requestData = [
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => 1,
            'size_ids' => '1',
            'color_ids' => '1',
            'images' => [$image],
        ];

        $response = $this->post('/api/admin/products', $requestData);

        $response->assertStatus(HttpStatusCode::CREATED->value);
        $responseData = $response->json();

        $this->assertTrue($responseData['status']);
        $this->assertEquals('Product created successfully', $responseData['message']);

        $this->assertDatabaseHas('products', [
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => 1,
        ]);

        $product = Product::first();
        $this->assertDatabaseHas('product_attributes', [
            'product_id' => $product->id,
            'size_id' => 1,
            'color_id' => null,
        ]);

        $this->assertDatabaseHas('product_attributes', [
            'product_id' => $product->id,
            'size_id' => null,
            'color_id' => 1,
        ]);

        $this->assertDatabaseHas('product_images', [
            'product_id' => $product->id,
            'image_path' => 'product_images/' . $image->hashName(),
        ]);

        $this->assertTrue(Storage::disk('public')->exists('product_images/' . $image->hashName()));

        $expectedProductData = $productMock->toArray();
        $this->assertEquals($expectedProductData['name'], $responseData['data']['product']['name']);
        $this->assertEquals($expectedProductData['description'], $responseData['data']['product']['description']);
    }
}
