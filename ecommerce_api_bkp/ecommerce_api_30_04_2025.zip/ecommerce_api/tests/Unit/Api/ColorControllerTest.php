<?php

namespace Tests\Unit\Api;

use App\Enums\HttpStatusCode;
use App\Http\Controllers\Api\ColorController;
use App\Http\Requests\ColorAttributeRequest;
use App\Models\Color;
use App\Services\BaseService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Tests\TestCase;

class ColorControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $baseService, $colorController;

    protected function setUp(): void
    {
        parent::setUp();

        $this->baseService = $this->createMock(BaseService::class);

        $this->colorController = new ColorController();
        $reflection = new \ReflectionClass($this->colorController);
        $property = $reflection->getProperty('baseService');
        $property->setAccessible(true);
        $property->setValue($this->colorController, $this->baseService);
    }

    public function test_index_returns_colors_when_found()
    {
        $colors = new Collection([
            new Color(['id' => 1, 'color' => 'Red']),
            new Color(['id' => 2, 'color' => 'Blue']),
        ]);

        $this->baseService
            ->expects($this->once())
            ->method('getAllRecords')
            ->willReturn($colors);

        $response = $this->colorController->index();

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'All color attributes',
            'data' => ['color' => $colors->toArray()]
        ], $response->getData(true));
    }

    public function test_index_returns_not_found_when_no_colors()
    {
        $this->baseService
            ->expects($this->once())
            ->method('getAllRecords')
            ->willReturn(new Collection());

        $response = $this->colorController->index();

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::NOT_FOUND->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'No color attributes found'
        ], $response->getData(true));
    }

    public function test_store_creates_color_successfully()
    {
        $request = new class extends ColorAttributeRequest {
            public $color = 'Green';

            public function validated($key = null, $default = null): array
            {
                return ['color' => $this->color];
            }

            public function authorize(): bool
            {
                return true;
            }

            public function rules(): array
            {
                return [];
            }
        };

        $colorAttribute = new Color(['id' => 1, 'name' => 'Green']);

        $this->baseService
            ->expects($this->once())
            ->method('store')
            ->with(['color' => 'Green'])
            ->willReturn($colorAttribute);

        $response = $this->colorController->store($request);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::CREATED->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Color attribute created successfully',
            'data' => ['color' => $colorAttribute->toArray()]
        ], $response->getData(true));
    }

    public function test_store_returns_error_on_failure()
    {
        $request = new class extends ColorAttributeRequest {
            public $color = 'Green';

            public function validated($key = null, $default = null): array
            {
                return ['color' => $this->color];
            }

            public function authorize(): bool
            {
                return true;
            }

            public function rules(): array
            {
                return [];
            }
        };

        $this->baseService
            ->expects($this->once())
            ->method('store')
            ->with(['color' => 'Green'])
            ->willReturn(false);

        $response = $this->colorController->store($request);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::INTERNAL_SERVER_ERROR->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Color creation failed'
        ], $response->getData(true));
    }

    public function test_show_returns_color_when_found()
    {
        $color = new Color(['id' => 1, 'color' => 'Red']);
        $this->baseService
            ->expects($this->once())
            ->method('getRecordById')
            ->with('1', ['id', 'color'])
            ->willReturn(new JsonResponse([
                'status' => true,
                'message' => 'Record retrieved',
                'data' => ['single_record' => $color],
            ], HttpStatusCode::OK->value));

        $response = $this->colorController->show('1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Record retrieved',
            'data' => ['single_record' => $color->toArray()]
        ], $response->getData(true));
    }

    public function test_update_updates_color_successfully()
    {
        $color = Color::create(['color' => 'Red']);

        $baseRequest = Request::create('/api/admin/colors/1', 'PUT', ['color' => 'Blue']);
        $request = ColorAttributeRequest::createFrom($baseRequest);

        $request->setContainer($this->app);
        $request->validateResolved();

        $this->baseService
            ->expects($this->once())
            ->method('update')
            ->with((string) $color->id, ['color' => 'Blue'])
            ->willReturn(true);

        $response = $this->colorController->update($request, (string) $color->id);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());

        $updatedColor = Color::find($color->id)->toArray();
        $this->assertEquals([
            'status' => true,
            'message' => 'Color attribute updated successfully',
            'data' => ['color' => $updatedColor]
        ], $response->getData(true));
    }

    public function test_update_returns_not_found_when_color_does_not_exist()
    {
        $baseRequest = Request::create('/api/admin/colors/1', 'PUT', ['color' => 'Blue']);
        $request = ColorAttributeRequest::createFrom($baseRequest);

        $request->setContainer($this->app);
        $request->validateResolved();

        $this->baseService->expects($this->never())->method('update');

        $response = $this->colorController->update($request, '1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::NOT_FOUND->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Requested color attribute is not available for update'
        ], $response->getData(true));
    }

    public function test_update_returns_error_on_failure()
    {
        $color = Color::create(['color' => 'Red']);

        $baseRequest = Request::create('/api/admin/colors/1', 'PUT', ['color' => 'Blue']);
        $request = ColorAttributeRequest::createFrom($baseRequest);

        $request->setContainer($this->app);
        $request->validateResolved();

        $this->baseService
            ->expects($this->once())
            ->method('update')
            ->with((string) $color->id, ['color' => 'Blue'])
            ->willReturn(false);

        $response = $this->colorController->update($request, (string) $color->id);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::INTERNAL_SERVER_ERROR->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Color attribute update failed'
        ], $response->getData(true));
    }

    public function test_destroy_deletes_color_successfully()
    {
        $this->baseService
            ->expects($this->once())
            ->method('deleteRecordById')
            ->with('1')
            ->willReturn(new JsonResponse([
                'status' => true,
                'message' => 'Record deleted successfully'
            ], HttpStatusCode::OK->value));

        $response = $this->colorController->destroy('1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Record deleted successfully'
        ], $response->getData(true));
    }

    protected function tearDown(): void
    {
        parent::tearDown();
    }
}
