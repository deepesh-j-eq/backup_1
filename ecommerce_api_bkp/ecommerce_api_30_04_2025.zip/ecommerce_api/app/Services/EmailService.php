<?php

namespace App\Services;

use App\Mail\DynamicEmail;
use Illuminate\Support\Facades\Mail;

class EmailService
{
    public function sendEmail(array|string $recipient, string $subject, string $template, array $data = [], array $attachments = [])
    {
        $email = new DynamicEmail($subject, $template, $data, $attachments);

        Mail::to($recipient)->queue($email);
    }
}
