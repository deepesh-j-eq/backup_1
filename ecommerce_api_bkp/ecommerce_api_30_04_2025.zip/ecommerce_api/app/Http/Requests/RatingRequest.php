<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RatingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $isUpdate = $this->isMethod('put') || $this->isMethod('patch');

        return [
            'rating' => 'required|numeric|min:0.1|max:5|regex:/^\d+(\.\d{1,1})?$/',
            'review' => 'required|string|min:5|max:500',
            'product_id' => $isUpdate ? 'nullable' : 'required|exists:products,id',
        ];
    }
}
