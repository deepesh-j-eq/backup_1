<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

class CheckoutRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'first_name' => 'required|string|min:2|max:191',
            'last_name' => 'required|string|min:2|max:191',
            'address_line_1' => 'required|string|min:10|max:191',
            'apartment' => 'nullable|string|max:191',
            'address_line_2' => 'nullable|string|max:191',
            'city' => 'required|string|max:191|regex:/[a-zA-Z]+/',
            'state' => 'required|string|max:191|regex:/[a-zA-Z]+/',
            'country' => 'required|string|max:191|regex:/[a-zA-Z]+/',
            'postal_code' => 'required|regex:/^\d{6,}$/',
            'email' => 'required|email:rfc,dns',
            'payment_method' => 'required|string|in:pm_card_visa,pm_card_mastercard,pm_card_chargeDeclined,pm_card_chargeDeclinedInsufficientFunds',
            'phone' => 'required|integer|digits:10',
            'shipping_option' => 'required|string|in:2_4_days_delivery,8_12_days_delivery',
            /*'exp_month' => 'required|between:1,12',
            'exp_year' => 'required|integer|digits:4',
            'cvc' => 'required|integer|digits:3',
            'phone' => 'required|integer|regex:/^\d{10}$/',*/
        ];
    }

    public function messages(): array
    {
        return [
            'email.email' => 'Please enter a valid email address.',
            'postal_code.regex' => 'Postal code should be minimum 6 digits.'
        ];
    }

    public function withValidator(Validator $validator)
    {
        $validator->after(function ($validator) {
            $email = $this->input('email');
            $domain = substr(strrchr($email, "@"), 1);

            if (!empty($domain) && !dns_get_record($domain, DNS_MX)) {
                $validator->errors()->add('email', 'Please enter a valid email address.');
            }
        });
    }
}
