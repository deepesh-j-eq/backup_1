<?php

namespace App\Http\Controllers\Api;

use App\Enums\HttpStatusCode;
use App\Http\Controllers\Controller;
use App\Http\Requests\RatingRequest;
use App\Models\Rating;
use App\Models\User;
use App\Services\BaseService;

class RatingController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/ratings",
    *     summary="Get all product ratings",
    *     description="Fetches all product ratings from the database",
    *     tags={"Product Ratings"},
    *     operationId="get.all.ratings",
    *     @OA\Response(
    *         response=200,
    *         description="All product ratings or No product rating created",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All product ratings or No product rating created"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="product_ratings",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="rating", type="string", example="1.0"),
    *                         @OA\Property(property="review", type="string", example="Test review"),
    *                         @OA\Property(
    *                               property="product",
    *                               type="object",
    *                                   @OA\Property(property="name", type="string", example="Product 1")
    *                         ),
    *                         @OA\Property(
    *                               property="user",
    *                               type="object",
    *                                   @OA\Property(property="name", type="string", example="Test 1")
    *                         )
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="No product ratings available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="No product ratings available")
    *         )
    *     )
    * )
    */
    public function index()
    {
        $ratings = array();
        $ratings = $this->getProductRatingDetails();

        if(!$ratings) {
            return helperJSONResponse(false, 'No product ratings available', [], HttpStatusCode::NOT_FOUND->value);
        }

        return helperJSONResponse(true, 'All product ratings', ['product_ratings' => $ratings], HttpStatusCode::OK->value);
    }

    /**
     * Store a newly created resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/ratings",
    *     summary="Create product rating",
    *     description="Create product rating",
    *     tags={"Product Ratings"},
    *     security={{"bearerAuth": {}}},
    *     operationId="create.rating",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"rating", "review", "product_id"},
    *                   @OA\Property(
    *                       property="rating",
    *                       type="string",
    *                       example="2.5"
    *                   ),
    *                   @OA\Property(
    *                       property="review",
    *                       type="string",
    *                       example="Test review"
    *                   ),
    *                   @OA\Property(
    *                       property="product_id",
    *                       type="integer",
    *                       example=5
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"rating", "review", "product_id"},
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Furniture"
    *                   ),
    *                   @OA\Property(
    *                       property="review",
    *                       type="string",
    *                       example="Test review"
    *                   ),
    *                   @OA\Property(
    *                       property="product_id",
    *                       type="integer",
    *                       example=5
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=201,
    *         description="Product rating created successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product rating created successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="product_rating",
    *                     type="object",
    *                         @OA\Property(property="rating", type="string", example="1.0"),
    *                         @OA\Property(property="review", type="string", example="Test review"),
    *                         @OA\Property(
    *                             property="product",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Product 1")
    *                         )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "rating": {"The rating field is required.", "The rating field must be a number.", "The rating field format is invalid.", "The rating field must be at least 0.1.", "The rating field must not be greater than 5."},
    *                       "review": {"The review field is required.", "The name field must be at least 5 characters."},
    *                       "product_id": {"The product_id field is required.", "The selected product id is invalid."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Product rating creation failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Product rating creation failed")
    *         )
    *     )
    * )
    */
    public function store(RatingRequest $request)
    {
        $authenticatedUserId = authenticatedUserId();

        if (!is_null($authenticatedUserId)) {
            $userRating = Rating::with([
                'product:id,name',
            ])->where(['user_id' => $authenticatedUserId, 'product_id' => $request->product_id])->first();
    
            $newProductRatingCreated = false;
    
            if ($userRating) {
                $userRating->update([
                    'rating' => number_format($request->rating, 1),
                    'review' => $request->review,
                    'product_id' => $request->product_id
                ]);
            } else {
                $userRating = Rating::create([
                    'rating' => number_format($request->rating, 1),
                    'review' => $request->review,
                    'product_id' => $request->product_id,
                    'user_id' => $authenticatedUserId
                ]);
    
                $newProductRatingCreated = true;
            }
    
            if (!$userRating) {
                return helperJSONResponse(false, 'Product rating creation failed', [], HttpStatusCode::INTERNAL_SERVER_ERROR->value);
            }
    
            $userRating = $this->formatProductRatingResponse($userRating, null, $newProductRatingCreated);
    
            return helperJSONResponse(true, 'Product rating created successfully', ['product_rating' => $userRating], HttpStatusCode::CREATED->value);
        }

        return helperJSONResponse(false, 'Unauthenticated.', [], HttpStatusCode::UNAUTHORIZED->value);
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/ratings/{id}",
    *     summary="Get single product rating",
    *     description="Display single product rating",
    *     tags={"Product Ratings"},
    *     operationId="get.single.rating",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Rating id to show that product rating",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display single product rating",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single product rating"),
    *             @OA\Property(
    *                   property="data",
    *                   type="object",
    *                   nullable=true,
    *                       @OA\Property(
    *                           property="rating",
    *                           type="object",
    *                               @OA\Property(property="rating", type="string", example="1.0"),
    *                               @OA\Property(property="review", type="string", example="Test review"),
    *                               @OA\Property(
    *                                   property="product",
    *                                   type="object",
    *                                   @OA\Property(property="name", type="string", example="Product 1")
    *                               ),
    *                               @OA\Property(
    *                                   property="user",
    *                                   type="object",
    *                                   @OA\Property(property="name", type="string", example="Test 1")
    *                               )
    *                       )
    *               )
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested product rating is not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested product rating is not available")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {
        $rating = $this->getProductRatingDetails($id);

        if (!$rating) {
            return helperJSONResponse(false, 'Requested product rating is not available', [], HttpStatusCode::NOT_FOUND->value);
        }

        return helperJSONResponse(true, 'Your single product rating', ['rating' => $rating], HttpStatusCode::OK->value);
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/ratings/{id}",
    *     summary="Update product rating",
    *     description="Update product rating",
    *     tags={"Product Ratings"},
    *     security={{"bearerAuth": {}}},
    *     operationId="update.rating",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Rating id to update that product rating",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "rating", "review"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="rating",
    *                       type="string",
    *                       example="3.0"
    *                   ),
    *                   @OA\Property(
    *                       property="review",
    *                       type="string",
    *                       example="Tester review"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "rating", "review"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="rating",
    *                       type="string",
    *                       example="3.0"
    *                   ),
    *                   @OA\Property(
    *                       property="review",
    *                       type="string",
    *                       example="Tester review"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product rating updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product rating updated successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="rating",
    *                     type="object",
    *                         @OA\Property(property="rating", type="string", example="1.0"),
    *                         @OA\Property(property="review", type="string", example="Test review"),
    *                         @OA\Property(
    *                               property="product",
    *                               type="object",
    *                                   @OA\Property(property="name", type="string", example="Product 1")
    *                         ),
    *                         @OA\Property(
    *                               property="user",
    *                               type="object",
    *                                   @OA\Property(property="name", type="string", example="Test 1")
    *                         )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested product rating is not available for update",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested product rating is not available for update")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "rating": {"The rating field is required.", "The rating field must be a number.", "The rating field format is invalid.", "The rating field must be at least 0.1.", "The rating field must not be greater than 5."},
    *                       "review": {"The review field is required.", "The name field must be at least 5 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Product rating update failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Product rating update failed")
    *         )
    *     )
    * )
    */
    public function update(RatingRequest $request, string $id)
    {
        $authenticatedUserId = authenticatedUserId();

        if (!is_null($authenticatedUserId)) {
            $user = User::find($authenticatedUserId);
    
            $ratingQuery = Rating::query();
    
            if($user->isUser()) {
                $rating = $ratingQuery->where('user_id', $authenticatedUserId);
            }
    
            $rating = $ratingQuery->find($id);
    
            if (!$rating) {
                return helperJSONResponse(false, 'Requested product rating is not available for update', [], HttpStatusCode::NOT_FOUND->value);
            }
    
            $updateRating = $rating->update([
                'rating' => number_format($request->rating, 1),
                'review' => $request->review,
                'user_id' => $authenticatedUserId
            ]);
    
            if (!$updateRating) {
                return helperJSONResponse(false, 'Product rating update failed', [], HttpStatusCode::INTERNAL_SERVER_ERROR->value);
            }
    
            $updatedRatingData = array();
            $updatedRatingData = $this->getProductRatingDetails($id);
    
            return helperJSONResponse(true, 'Product rating updated successfully', ['rating' => $updatedRatingData], HttpStatusCode::OK->value);
        }

        return helperJSONResponse(false, 'Unauthenticated.', [], HttpStatusCode::UNAUTHORIZED->value);
    }

    /**
     * Remove the specified resource from storage.
     */

    /**
    * @OA\Delete(
    *     path="/api/admin/ratings/{id}",
    *     summary="Delete product rating",
    *     description="Delete product rating",
    *     tags={"Product Ratings"},
    *     security={{"bearerAuth": {}}},
    *     operationId="rating.delete",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Rating id to delete that product rating",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product rating deleted successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Record deleted successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested record not available for deletion",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested record not available for deletion"
    *             )
    *         )
    *     )
    * )
    */
    public function destroy(string $id)
    {
        $baseService = new BaseService(new Rating());
        return $baseService->deleteRecordById($id);
    }

    private function getProductRatingDetails($specificProductId = null)
    {
        $authenticatedUserId = authenticatedUserId();
        $user = !is_null($authenticatedUserId) ? User::find($authenticatedUserId) : null;

        $productRatingQuery = Rating::with([
            'product:id,name',
            'user:id,name',
        ]);

        if (!empty($specificProductId)) {
            $productRating = $productRatingQuery->find($specificProductId);
    
            if (!$productRating) {
                return false;
            }

            return $this->formatProductRatingResponse($productRating, $user);
        }

        $productRatings = $productRatingQuery->get();

        if ($productRatings->isEmpty()) {
            return false;
        }

        foreach ($productRatings as $prodRating) {
            $this->formatProductRatingResponse($prodRating, $user);
        }

        return $productRatings;
    }

    private function formatProductRatingResponse(Rating $productRating, ?User $user = null, $newProductRatingCreated = false) {
        $productRating->makeHidden(['id', 'product_id', 'user_id', 'created_at', 'updated_at']);
        $productRating->product->makeHidden(['id']);

        if ($newProductRatingCreated) {
            $productRating->product->makeHidden(['description', 'price', 'quantity', 'category_id', 'created_at', 'updated_at']);
        }

        if ($productRating->user === null) {
            unset($productRating->user);
        } else {
            $productRating->user->makeHidden(['id']);
            if ($newProductRatingCreated) {
                $productRating->user->makeHidden(['email', 'email_verified_at', 'role_id', 'created_at', 'updated_at', 'deleted_at']);
            }

            $productRating->user->makeHidden(array_keys(array_filter([
                'email' => $productRating->user->email,
                'email_verified_at' => $productRating->user->email_verified_at,
                'role_id' => $productRating->user->role_id,
                'created_at' => $productRating->user->created_at,
                'updated_at' => $productRating->user->updated_at,
                'deleted_at' => $productRating->user->deleted_at,
            ])));

            foreach (['email_verified_at', 'deleted_at'] as $field) {
                if (is_null($productRating->user->$field)) {
                    unset($productRating->user->$field);
                }
            }
        }

        if ($user !== null && $user->isUser()) {
            //$productRating->makeHidden(['some_user_specific_field']);
        }

        return $productRating;
    }
}
