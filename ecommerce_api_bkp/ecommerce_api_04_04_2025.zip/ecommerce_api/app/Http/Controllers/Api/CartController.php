<?php

namespace App\Http\Controllers\Api;

use App\Enums\HttpStatusCode;
use App\Enums\OrderStatuses;
use App\Http\Controllers\Controller;
use App\Http\Requests\CartRequest;
use App\Http\Requests\CheckoutRequest;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderAddress;
use App\Models\OrderItem;
use App\Models\Product;
use App\Services\CartService;
use Illuminate\Http\Request;

class CartController extends Controller
{
    protected $stripePaymentController;
    protected $cartService;

    public function __construct(StripePaymentController $stripePaymentController, CartService $cartService)
    {
        $this->stripePaymentController = $stripePaymentController;
        $this->cartService = $cartService;
    }

    /**
    * @OA\Get(
    *     path="/api/cart",
    *     summary="View your cart",
    *     description="Display your cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="view.cart.items",
    *     @OA\Response(
    *         response=200,
    *         description="Display your cart or No product in your cart, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your cart | No product in your cart, keep shoppping!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                           @OA\Property(
    *                             property="cart_items",
    *                             type="array",
    *                                   @OA\Items(
    *                                       type="object",
    *                                       @OA\Property(property="id", type="integer", example=3),
    *                                       @OA\Property(property="quantity", type="integer", example=2),
    *                                       @OA\Property(property="product_id", type="integer", example=1),
    *                                       @OA\Property(property="created_at", type="string", example="2025-02-24T12:36:29.000000Z"),
    *                                       @OA\Property(property="updated_at", type="string", example="2025-02-25T11:03:47.000000Z"),
    *                                       @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                           @OA\Property(
    *                                               property="product",
    *                                               type="object",
    *                                                   @OA\Property(property="name", type="string", example="Product 1"),
    *                                                   @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                                   @OA\Property(property="price", type="string", example="50.00"),
    *                                                   @OA\Property(property="discounted_price", type="string", example="25.00")
    *                                           )
    *                                   ),
    *                           ),
    *                      @OA\Property(property="total_price", type="string", example="715.00")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=204,
    *         description="No product in your cart",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="No product in your cart, keep shoppping!")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function viewCart()
    {
        $authenticatedUserId = authenticatedUserId();

        if (!is_null($authenticatedUserId)) {
            $cartItems = Cart::with(['product' => function ($query) {
                    $query->select(['id', 'name', 'description', 'price', 'discounted_price']);
                }])
                ->where('user_id', $authenticatedUserId)
                ->get()
                ->makeHidden(['user_id']);

            if ($cartItems->isEmpty()) {
                return helperJSONResponse(true, 'No product in your cart, keep shoppping!', [], HttpStatusCode::NO_CONTENT->value);
            }

            $data = array();
            $totalPrice = 0;

            foreach ($cartItems as $cartItem) {
                $cartItem->product->makeHidden(['id']);
                if (empty($cartItem->product->discounted_price)) {
                    $cartItem->product->makeHidden(['discounted_price']);
                }
    
                $cartItem->sub_total = $this->cartService->calculateSubTotal($cartItem);
                $totalPrice += $cartItem->sub_total;
            }

            $data = [
                'cart_items' => $cartItems,
                'total_price' => number_format($totalPrice, 2),
            ];

            if ($data['cart_items']->isNotEmpty()) {
                return helperJSONResponse(true, 'Your cart', ['cart' => $data], HttpStatusCode::OK->value);
            }
        }

        return helperJSONResponse(false, 'Unauthenticated.', [], HttpStatusCode::UNAUTHORIZED->value);
    }

    /**
    * @OA\Post(
    *     path="/api/cart/add",
    *     summary="Add to cart",
    *     description="Add to cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="add.to.cart",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"product_id", "quantity"},
    *                   @OA\Property(
    *                       property="product_id",
    *                       type="integer",
    *                       example=6
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=2
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"product_id", "quantity"},
    *                   @OA\Property(
    *                       property="product_id",
    *                       type="integer",
    *                       example=6
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=2
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product added to cart successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product added to cart successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                         @OA\Property(property="product_id", type="string", example="6"),
    *                         @OA\Property(property="quantity", type="string", example="2"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-04T08:20:17.000000Z"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-04T08:20:17.000000Z"),
    *                         @OA\Property(property="id", type="integer", example=13),
    *                         @OA\Property(property="sub_total", type="string", example="410.00"),
    *                         @OA\Property(
    *                             property="product",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Product 3"),
    *                             @OA\Property(property="description", type="string", example="Product 3 description"),
    *                             @OA\Property(property="price", type="string", example="205.00"),
    *                             @OA\Property(property="discounted_price", type="string", example="105.00"),
    *                             @OA\Property(property="quantity", type="integer", example=12)
    *                        )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=409,
    *         description="Not enough stock available for selected product",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Not enough stock available for selected product")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "product_id": {"The product_id field is required.", "The selected product id is invalid."},
    *                   "quantity": {"The quantity field is required.", "The quantity field must be at least 1.", "The quantity field must be an integer."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function addToCart(CartRequest $request)
    {
        $authenticatedUserId = authenticatedUserId();

        if (!is_null($authenticatedUserId)) {
            $productId = $request->product_id;
            $quantity = $request->quantity;

            $product = Product::find($productId);

            if (!$product) {
                return helperJSONResponse(false, 'Opps! Requested product is not available', [], HttpStatusCode::NOT_FOUND->value);
            }

            $cartItem = Cart::where('user_id', $authenticatedUserId)
                            ->where('product_id', $productId)
                            ->first();
    
            if ($cartItem) {
                $newQuantity = $cartItem->quantity + $quantity;
    
                if ($newQuantity > $product->quantity) {
                    return $this->cartService->handleStockError($product, $cartItem);
                }

                $cartItem->update(['quantity' => $newQuantity]);
            } else {
                if ($quantity > $product->quantity) {
                    return $this->cartService->handleStockError($product);
                }

                $cartItem = Cart::create([
                    'user_id' => $authenticatedUserId,
                    'product_id' => $productId,
                    'quantity' => $quantity
                ]);
            }

            $cartItem->sub_total = number_format($this->cartService->calculateSubTotal($cartItem), 2);
            $cartItem->product->makeHidden(['id', 'category_id', 'created_at', 'updated_at']);
            if (empty($cartItem->product->discounted_price)) {
                $cartItem->product->makeHidden(['discounted_price']);
            }
            $cartItem->makeHidden(['user_id']);

            return helperJSONResponse(true, 'Product added to cart successfully', ['cart' => $cartItem], HttpStatusCode::OK->value);
        }

        return helperJSONResponse(false, 'Unauthenticated.', [], HttpStatusCode::UNAUTHORIZED->value);
    }
    
    /**
    * @OA\Post(
    *     path="/api/cart/change-quantity/{id}",
    *     summary="Change product quantity from cart",
    *     description="Change product quantity from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="change.cart.qty",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Cart id to change product quantity",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"change_to", "quantity"},
    *                   @OA\Property(
    *                       property="change_to",
    *                       type="string",
    *                       enum={"up", "down"},
    *                       example="down",
    *                       description="Change (increase or decrease) product quantity which already added to cart"
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=1
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"change_to", "quantity"},
    *                   @OA\Property(
    *                       property="change_to",
    *                       type="string",
    *                       enum={"up", "down"},
    *                       example="down",
    *                       description="Change (increase or decrease) product quantity which already added to cart"
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=1
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product qunatity has been changed successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product qunatity has been changed successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                         @OA\Property(
    *                             property="cart_item",
    *                             type="object",
    *                                   @OA\Property(property="id", type="integer", example=12),
    *                                   @OA\Property(property="quantity", type="integer", example=2),
    *                                   @OA\Property(property="product_id", type="integer", example=6),
    *                                   @OA\Property(property="updated_at", type="string", example="2025-03-04T08:31:20.000000Z"),
    *                                   @OA\Property(property="created_at", type="string", example="2025-03-04T09:12:07.000000Z"),
    *                                   @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                   @OA\Property(
    *                                       property="product",
    *                                       type="object",
    *                                           @OA\Property(property="name", type="string", example="Product 1"),
    *                                           @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                           @OA\Property(property="price", type="string", example="50.00"),
    *                                           @OA\Property(property="discounted_price", type="string", example="25.00")
    *                                   )
    *                          )
    *                   )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Please remove correct quantity",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Please remove correct quantity")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Please choose correct cart item for update quantity",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Please choose correct cart item for update quantity"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=405,
    *         description="Not enough stock available for product <product name>",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Not enough stock available for product <product name>")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "change_to": {"The change to field is required.", "The selected change to is invalid."},
    *                   "quantity": {"The quantity field is required.", "The quantity field must be at least 1.", "The quantity field must be an integer."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function changeCartQuantity(CartRequest $request, $id)
    {
        $authenticatedUserId = authenticatedUserId();

        if (!is_null($authenticatedUserId)) {
            $cartItem = Cart::with(['product'])
                        ->where('user_id', $authenticatedUserId)
                        ->find($id);

            if (!$cartItem) {
                return helperJSONResponse(false, 'Please choose correct cart item for update quantity', [], HttpStatusCode::NOT_FOUND->value);
            }

            $changeTo = $request->change_to;
            $quantity = $request->quantity;

            if ($changeTo == 'up') {
                $newQuantity = $cartItem->quantity + $quantity;
            } else if ($changeTo == 'down') {
                $newQuantity = $cartItem->quantity - $quantity;
            }

            $stockValidationResponse = $this->cartService->validateCartQuantityChange($cartItem, $newQuantity, $changeTo);
            if ($stockValidationResponse) {
                return $stockValidationResponse;
            }

            $cartItem->update(['quantity' => $newQuantity]);

            $cart_item = Cart::with([
                'product' => function ($query) {
                    $query->select(['id', 'name', 'description', 'price', 'discounted_price']);
                }])
                ->where('user_id', $authenticatedUserId)
                ->find($id);

            $cart_item->sub_total = number_format($this->cartService->calculateSubTotal($cartItem), 2);

            $cart_item->product->makeHidden(['id']);
            if (empty($cart_item->product->discounted_price)) {
                $cart_item->product->makeHidden(['discounted_price']);
            }
            $cart_item->makeHidden(['user_id']);

            $data = array();
            $data['cart_item'] = $cart_item;

            return helperJSONResponse(true, $cart_item->product->name . ' qunatity has been changed successfully', ['cart' => $data], HttpStatusCode::OK->value);
        }

        return helperJSONResponse(false, 'Unauthenticated.LL', [], HttpStatusCode::UNAUTHORIZED->value);
    }

    /**
    * @OA\Delete(
    *     path="/api/cart/{id}",
    *     summary="Remove item from cart",
    *     description="Remove item from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="remove.cart.item",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Cart id to delete the specific cart item",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Cart item removed successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Cart item removed successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                           @OA\Property(
    *                             property="cart_items",
    *                             type="array",
    *                                   @OA\Items(
    *                                       type="object",
    *                                       @OA\Property(property="id", type="integer", example=3),
    *                                       @OA\Property(property="quantity", type="integer", example=2),
    *                                       @OA\Property(property="product_id", type="integer", example=1),
    *                                       @OA\Property(property="created_at", type="string", example="2025-02-24T12:36:29.000000Z"),
    *                                       @OA\Property(property="updated_at", type="string", example="2025-02-25T11:03:47.000000Z"),
    *                                       @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                           @OA\Property(
    *                                               property="product",
    *                                               type="object",
    *                                                   @OA\Property(property="name", type="string", example="Product 1"),
    *                                                   @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                                   @OA\Property(property="price", type="string", example="50.00"),
    *                                                   @OA\Property(property="discounted_price", type="string", example="25.00")
    *                                           )
    *                                   ),
    *                           ),
    *                      @OA\Property(property="total_price", type="string", example="715.00")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=204,
    *         description="No product in your cart",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Cart item removed successfully, No product in your cart, keep shoppping!")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested cart item not available for remove",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested cart item not available for remove"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function removeFromCart(Request $request, $id)
    {
        $authenticatedUserId = authenticatedUserId();

        if (!is_null($authenticatedUserId)) {
            $cartItem = Cart::where('user_id', $authenticatedUserId)
                            ->find($id);

            if (!$cartItem) {
                return helperJSONResponse(false, 'Requested cart item not available for remove', [], HttpStatusCode::NOT_FOUND->value);
            }

            $cartItem->delete();

            $RemainingCartItems = Cart::with(['product' => function ($query) {
                            $query->select(['id', 'name', 'description', 'price', 'discounted_price']);
                        }])
                ->where('user_id', $authenticatedUserId)
                ->get()
                ->makeHidden(['user_id']);
    
            if ($RemainingCartItems->isEmpty()) {
                return helperJSONResponse(true, 'Cart item removed successfully, No product in your cart, keep shoppping!', [], HttpStatusCode::NO_CONTENT->value);
            }

            $data = array();
            $totalPrice = 0;

            $RemainingCartItems->transform(function ($item) use (&$totalPrice) {
                $item->product->makeHidden(['id']);
                if (empty($item->product->discounted_price)) {
                    $item->product->makeHidden(['discounted_price']);
                }

                $item->sub_total = $this->cartService->calculateSubTotal($item);
                $totalPrice += $item->sub_total;

                return $item;
            });

            $data = [
                    'cart_items' => $RemainingCartItems,
                    'total_price' => number_format($totalPrice, 2)
            ];

            return helperJSONResponse(true, 'Cart item removed successfully', ['cart' => $data], HttpStatusCode::OK->value);
        }

        return helperJSONResponse(false, 'Unauthenticated.', [], HttpStatusCode::UNAUTHORIZED->value);
    }

    /**
    * @OA\Post(
    *     path="/api/cart/remove-cart",
    *     summary="Remove all items from cart",
    *     description="Remove all items from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="remove.all.cart.items",
    *     @OA\Response(
    *         response=200,
    *         description="All products are removed from cart successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All products are removed from cart successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="No cart item available for remove, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="No cart item available for remove, keep shoppping!"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function removeAllProductsFromCart(Request $request)
    {
        $authenticatedUserId = authenticatedUserId();

        if (!is_null($authenticatedUserId)) {
            $cartItems = Cart::where('user_id', $authenticatedUserId)->get();

            if ($cartItems->isEmpty()) {
                return helperJSONResponse(false, 'No cart item available for remove, keep shoppping!', [], HttpStatusCode::NOT_FOUND->value);
            }

            $cartProducts = array();

            foreach ($cartItems as $cartItem) {
                $product = Product::find($cartItem->product_id);
    
                $cartProducts[] = $product->name;
    
                $cartItem->delete();
            }

            return helperJSONResponse(true, 'All products ('.implode(", ", $cartProducts).') are removed from cart successfully', [], HttpStatusCode::OK->value);
        }

        return helperJSONResponse(false, 'Unauthenticated.', [], HttpStatusCode::UNAUTHORIZED->value);
    }

    /**
    * @OA\Post(
    *     path="/api/cart/checkout",
    *     summary="Checkout",
    *     description="Checkout",
    *     tags={"Checkout"},
    *     security={{"bearerAuth": {}}},
    *     operationId="checkout",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"first_name", "last_name", "address_line_1", "city", "state", "country", "postal_code", "email", "payment_method", "phone", "shipping_option"},
    *                   @OA\Property(
    *                       property="first_name",
    *                       type="string",
    *                       example="Test1 First Name"
    *                   ),
    *                   @OA\Property(
    *                       property="last_name",
    *                       type="string",
    *                       example="Test1 Last Name"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_1",
    *                       type="string",
    *                       example="Test1 Address Line 1"
    *                   ),
    *                   @OA\Property(
    *                       property="apartment",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Apartment"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_2",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Address Line 2"
    *                   ),
    *                   @OA\Property(
    *                       property="city",
    *                       type="string",
    *                       example="Ahmedabad"
    *                   ),
    *                   @OA\Property(
    *                       property="state",
    *                       type="string",
    *                       example="Gujarat"
    *                   ),
    *                   @OA\Property(
    *                       property="country",
    *                       type="string",
    *                       example="India"
    *                   ),
    *                   @OA\Property(
    *                       property="postal_code",
    *                       type="integer",
    *                       example=441122
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="payment_method",
    *                       type="string",
    *                       enum={"pm_card_visa", "pm_card_mastercard", "pm_card_chargeDeclined", "pm_card_chargeDeclinedInsufficientFunds"},
    *                       example="pm_card_visa",
    *                       description="pm_card_visa, pm_card_mastercard, pm_card_chargeDeclined, pm_card_chargeDeclinedInsufficientFunds"
    *                   ),
    *                   @OA\Property(
    *                       property="phone",
    *                       type="integer",
    *                       example=4411441188
    *                   ),
    *                   @OA\Property(
    *                       property="shipping_option",
    *                       type="string",
    *                       enum={"2_4_days_delivery", "8_12_days_delivery"},
    *                       example="2_4_days_delivery",
    *                       description="2_4_days_delivery, 8_12_days_delivery"
    *                   ),
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"first_name", "last_name", "address_line_1", "city", "state", "country", "postal_code", "email", "payment_method", "phone", "shipping_option"},
    *                   @OA\Property(
    *                       property="first_name",
    *                       type="string",
    *                       example="Test1 First Name"
    *                   ),
    *                   @OA\Property(
    *                       property="last_name",
    *                       type="string",
    *                       example="Test1 Last Name"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_1",
    *                       type="string",
    *                       example="Test1 Address Line 1"
    *                   ),
    *                   @OA\Property(
    *                       property="apartment",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Apartment"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_2",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Address Line 2"
    *                   ),
    *                   @OA\Property(
    *                       property="city",
    *                       type="string",
    *                       example="Ahmedabad"
    *                   ),
    *                   @OA\Property(
    *                       property="state",
    *                       type="string",
    *                       example="Gujarat"
    *                   ),
    *                   @OA\Property(
    *                       property="country",
    *                       type="string",
    *                       example="India"
    *                   ),
    *                   @OA\Property(
    *                       property="postal_code",
    *                       type="integer",
    *                       example=441122
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="payment_method",
    *                       type="string",
    *                       enum={"pm_card_visa", "pm_card_mastercard", "pm_card_chargeDeclined", "pm_card_chargeDeclinedInsufficientFunds"},
    *                       example="pm_card_visa",
    *                       description="pm_card_visa, pm_card_mastercard, pm_card_chargeDeclined, pm_card_chargeDeclinedInsufficientFunds"
    *                   ),
    *                   @OA\Property(
    *                       property="phone",
    *                       type="integer",
    *                       example=4411441188
    *                   ),
    *                   @OA\Property(
    *                       property="shipping_option",
    *                       type="string",
    *                       enum={"2_4_days_delivery", "8_12_days_delivery"},
    *                       example="2_4_days_delivery",
    *                       description="2_4_days_delivery, 8_12_days_delivery"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Order placed successfully or Your cart is empty, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Order placed successfully | Your cart is empty, keep shoppping!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="order_details",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="total_amount", type="string", example="460.00"),
    *                         @OA\Property(property="shipping_amount", type="string", example="30.00"),
    *                         @OA\Property(property="tax_amount", type="string", example="71.40"),
    *                         @OA\Property(property="order_status", type="string", example="Placed"),
    *                         @OA\Property(property="updated_by", type="string", example=null),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-04T10:40:08.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-04T10:40:08.000000Z"),
    *                         @OA\Property(
    *                             property="payment",
    *                             type="object",
    *                             @OA\Property(property="payment_gateway", type="string", example="paypal"),
    *                             @OA\Property(property="transaction_id", type="string", example="ojsMiGIkg50MrLG"),
    *                             @OA\Property(property="status", type="string", example="successful")
    *                         ),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Test 2")
    *                         ),
    *                         @OA\Property(
    *                             property="address",
    *                             type="object",
    *                             @OA\Property(property="id", type="integer", example=1),
    *                             @OA\Property(property="order_id", type="integer", example=1),
    *                             @OA\Property(property="first_name", type="string", example="Test2 First Name"),
    *                             @OA\Property(property="last_name", type="string", example="Test2 Last Name"),
    *                             @OA\Property(property="address_line_1", type="string", example="Test2 Address Line 1"),
    *                             @OA\Property(property="apartment", type="string", example="Test2 Apartment"),
    *                             @OA\Property(property="address_line_2", type="string", example="Test2 Address Line 2"),
    *                             @OA\Property(property="city", type="string", example="Ahmedabad"),
    *                             @OA\Property(property="country", type="string", example="India"),
    *                             @OA\Property(property="state", type="string", example="Gujarat"),
    *                             @OA\Property(property="postal_code", type="integer", example=441122),
    *                             @OA\Property(property="phone", type="integer", example=4411441188),
    *                             @OA\Property(property="email", type="string", example="test2@gmail.com")
    *                         ),
    *                         @OA\Property(
    *                             property="order_items",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="quantity", type="integer", example=2),
    *                                 @OA\Property(property="name", type="string", example="Product 1"),
    *                                 @OA\Property(property="price", type="string", example="205.00"),
    *                                 @OA\Property(property="discount_price", type="string", example="105.00"),
    *                                 @OA\Property(property="order_id", type="integer", example=1),
    *                                 @OA\Property(property="sub_total", type="string", example="410.00")
    *                             )
    *                         )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Something went wrong! Order not found for update",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Something went wrong! Order not found for update"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=402,
    *         description="Something went wrong while attempting stripe payment!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Something went wrong while attempting stripe payment!"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Somthing went wrong! Requested products are not available for purchase")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "first_name": {"The first_name field is required.", "The first name field must be at least 2 characters."},
    *                       "last_name": {"The last_name field is required.", "The last name field must be at least 2 characters."},
    *                       "address_line_1": {"The address_line_1 field is required.", "The address line 1 field must be at least 10 characters."},
    *                       "city": {"The city field is required.", "The city field format is invalid."},
    *                       "state": {"The state field is required.", "The state field format is invalid."},
    *                       "country": {"The country field is required.", "The country field format is invalid."},
    *                       "postal_code": {"The postal code field is required.", "Postal code should be minimum 6 digits."},
    *                       "email": {"The email field is required.", "Please enter a valid email address."},
    *                       "payment_method": {"The payment method field is required.", "The selected payment method is invalid."},
    *                       "phone": {"The phone field is required.", "The phone field must be an integer.", "The phone field must be 10 digits."},
    *                       "shipping_option": {"The shipping option field is required.", "The selected shipping option is invalid."},
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function checkout(CheckoutRequest $request)
    {
        $authenticatedUserId = authenticatedUserId();

        if (!is_null($authenticatedUserId)) {
            $cartItems = Cart::with(['product'])->where('user_id', $authenticatedUserId)->get();
    
            if ($cartItems->isEmpty()) {
                return helperJSONResponse(true, 'Your cart is empty, keep shoppping!', [], HttpStatusCode::OK->value);
            }
    
            $totalAmount = 0;
            $allNotAvailableProducts = array();
            $allAvailableProducts = array();
            $tempAllNotAvailableProducts = array();
            $tempAllAvailableProducts = array();
            $responseProductsDataArray = array();
            $responseArray = array();

            foreach ($cartItems as $item) {
                $availabilityStatus = $this->cartService->varifyProductAvailabilityOnCheckout($item);
                $allNotAvailableProducts = array_merge($allNotAvailableProducts, $availabilityStatus['not_available_product_details']);
                $allAvailableProducts = array_merge($allAvailableProducts, $availabilityStatus['available_product_details']);

                $item->sub_total = $this->cartService->calculateSubTotal($item);
                $totalAmount += $item->sub_total;
            }

            if (!empty($allNotAvailableProducts)) {
                $message = '';
                foreach ($allNotAvailableProducts as $notAvailableProd) {
                    if ($notAvailableProd['available_quantity'] > 0) {
                        $tempAllNotAvailableProducts[] = [
                            'product_name' => $notAvailableProd['product_name'],
                            'available_quantity' => $notAvailableProd['available_quantity']
                        ];
                    }
                }

                $allNotAvailableProductsProductNames = implode(', ' , array_column($allNotAvailableProducts, 'product_name'));
                $allNotAvailableProductQuantities = implode(', ' , array_column($allNotAvailableProducts, 'cart_quanity'));

                $responseArray = ['status' => false];

                if (empty($allAvailableProducts)) {
                    if (!empty($tempAllNotAvailableProducts)) {
                        $message = "Opps! Requested quantities: '{$allNotAvailableProductQuantities}' for products: '{$allNotAvailableProductsProductNames}' are not avaliaible, please change quantity of the products according to available stock";

                        $responseArray['message'] = $message;
    
                        $responseArray['data'] = ['current_product_stock' => $tempAllNotAvailableProducts];
                    } else {
                        $message = "Opps! requested products are not avaliaible";

                        $responseArray['message'] = $message;
                    }
    
                    return response()->json($responseArray, HttpStatusCode::BAD_REQUEST->value);
                } else {
                    foreach ($allAvailableProducts as $allAvailableProd) {
                        if ($allAvailableProd['available_quantity'] > 0) {
                            $tempAllAvailableProducts[] = [
                                'product_name' => $allAvailableProd['product_name'],
                                'available_quantity' => $allAvailableProd['available_quantity']
                            ];
                        }
                    }

                    if (!empty($tempAllAvailableProducts)) {
                        $tempAvailableProductNames = implode(', ' , array_column($tempAllAvailableProducts, 'product_name'));
                        $tempAvailableProductQuantities = implode(', ' , array_column($tempAllAvailableProducts, 'available_quantity'));

                        $message = "The available products: '{$tempAvailableProductNames}' with quantities: '{$tempAvailableProductQuantities}'";

                        $responseProductsDataArray = $tempAllAvailableProducts;
                    }

                    if (!empty($tempAllNotAvailableProducts)) {
                        $responseProductsDataArray = array_merge($responseProductsDataArray, $tempAllNotAvailableProducts);
                    }

                    $message .= " But requested quantities: '{$allNotAvailableProductQuantities}' for products: '{$allNotAvailableProductsProductNames}' are not avaliaible, please change quantity of the products according to available stock";

                    $responseArray['message'] = $message;

                    if (!empty($responseProductsDataArray)) {
                        $responseArray['data'] = ['current_product_stock' => $responseProductsDataArray];
                    }

                    return response()->json($responseArray, HttpStatusCode::BAD_REQUEST->value);
                }
            } else if (empty($allAvailableProducts) && empty($allNotAvailableProducts)) {
                return helperJSONResponse(false, 'Somthing went wrong! Requested products are not available for purchase', [], HttpStatusCode::NOT_FOUND->value);
            }

            $shippingEstimate = $this->cartService->shippingEstimate($request->shipping_option);
            $taxPercentage = 14;
            $taxAmount = $this->cartService->taxCalculation($totalAmount, $taxPercentage);
            $totalAmountWithTax = $totalAmount + $shippingEstimate + $taxAmount;

            $order = Order::create([
                'total_amount' => $totalAmountWithTax,
                'shipping_amount' => $shippingEstimate,
                'tax_amount' => number_format($taxAmount, 2),
                'user_id' => $authenticatedUserId
            ]);

            if (!$order) {
                return helperJSONResponse(false, 'Order creation failed', [], HttpStatusCode::INTERNAL_SERVER_ERROR->value);
            }

            OrderAddress::create([
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'address_line_1' => $request->address_line_1,
                'apartment' => $request->apartment,
                'address_line_2' => $request->address_line_2,
                'city' => $request->city,
                'state' => $request->state,
                'country' => $request->country,
                'postal_code' => $request->postal_code,
                'phone' => $request->phone,
                'email' => $request->email,
                'order_id' => $order->id
            ]);

            foreach ($cartItems as $item) {
                OrderItem::create([
                    'quantity' => $item->quantity,
                    'name' => $item->product->name,
                    'price' => $item->product->price,
                    'discounted_price' => !empty($item->product->discounted_price) ? $item->product->discounted_price : null,
                    'order_id' => $order->id,
                    'product_id' => $item->product_id
                ]);
            }

            $newRequest = $request->all();
            $newRequest['order_id'] = $order->id;
            $newRequest['total_amount_with_tax'] = $totalAmountWithTax;

            $paymentIntents = $this->stripePaymentController->processPayment($newRequest);

            if (!empty($paymentIntents)) {
                if (!array_key_exists('paymentId', $paymentIntents) && $paymentIntents['status'] = 'error') {
                    return helperJSONResponse(false, 'Order number ' . $order->id . ' has following issue: ' . $paymentIntents['message'], [], HttpStatusCode::BAD_REQUEST->value);
                }

                $orderUpdateArray = [
                    'order_status' => OrderStatuses::ORDER_STATUS_CREATED->value,
                    'payment_id' => $paymentIntents['paymentId']
                ];

                $orderForUpdate = Order::find($order->id);
    
                if (!$orderForUpdate) {
                    return helperJSONResponse(false, 'Something went wrong! Order not found for update', [], HttpStatusCode::BAD_REQUEST->value);
                }

                $orderForUpdate->update($orderUpdateArray);

                return $this->orderResponse($order, 'Order created successfully', true, HttpStatusCode::OK->value);
            }

            $orderForUpdate = Order::find($order->id);

            if (!$orderForUpdate) {
                return helperJSONResponse(false, 'Something went wrong!! Order not found for update', [], HttpStatusCode::BAD_REQUEST->value);
            }

            $orderForUpdate->update(['order_status' => OrderStatuses::ORDER_STATUS_PAYMENT_FAILED->value]);

            return helperJSONResponse(false, 'Something went wrong while attempting stripe payment!', [], HttpStatusCode::PAYMENT_REQUIRED->value);
        }

        return helperJSONResponse(false, 'Unauthenticated.', [], HttpStatusCode::UNAUTHORIZED->value);
    }

    private function orderResponse($order, $message, $status, $httpCode)
    {
        $orderDetails = Order::with([
            'payment:id,payment_gateway,transaction_id,status,payment_method',
            'user:id,name',
            'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
            'orderItems'
        ])->find($order->id);

        $orderSubTotal = 0;

        if ($orderDetails->order_status) {
            $orderDetails->order_status = ucfirst(strtolower(str_replace('_', ' ', $orderDetails->order_status)));
        }
        $orderDetails->makeHidden(['user_id']);
        if ($orderDetails->payment) {
            $orderDetails->payment->makeHidden(['id']);
        }
        $orderDetails->user->makeHidden(['id']);

        if ($orderDetails->payment_id) {
            $orderDetails->makeHidden(['payment_id']);
        }

        foreach ($orderDetails->orderItems as $orderItem) {
            $orderItem->makeHidden(['id', 'product_id', 'created_at', 'updated_at']);
            $unitPrice = (!empty($orderItem->discounted_price) && $orderItem->discounted_price > 0)
            ? (float) $orderItem->discounted_price
            : (float) $orderItem->price;
            $quantity = (int) $orderItem->quantity;

            $orderItem->sub_total = number_format($unitPrice * $quantity, 2);
            $orderSubTotal += ($unitPrice * $quantity);

            if (empty($orderItem->discounted_price)) {
                $orderItem->makeHidden(['discounted_price']);
            }
        }

        $orderDetails->order_sub_total = number_format($orderSubTotal, 2);

        return response()->json([
            'status' => $status,
            'message' => $message,
            'order_id' => $order->id,
            'data' => ['order_details' => $orderDetails]
        ], $httpCode);
    }
}
