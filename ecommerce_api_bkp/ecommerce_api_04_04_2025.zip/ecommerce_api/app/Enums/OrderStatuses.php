<?php

namespace App\Enums;

enum OrderStatuses : string
{
    case ORDER_STATUS_CREATED = 'created';
    case ORDER_STATUS_PLACED = 'placed';
    case ORDER_STATUS_IN_TRANSIST = 'in_transit';
    case ORDER_STATUS_SHIPPED = 'shipped';
    case ORDER_STATUS_CANCELED = 'canceled';
    case ORDER_STATUS_PAYMENT_FAILED = 'payment_failed';
    case ORDER_STATUS_REFUNDED = 'refunded';
    case ORDER_STATUS_COMPLETED = 'completed';
}
