<?php

namespace App\Services;

use App\Enums\HttpStatusCode;
use App\Models\Cart;
use App\Models\Product;

class CartService
{
    public function handleStockError(Product $product, ?Cart $cartItem = null)
    {
        $availableQuantity = $product ? $product->quantity : 0;

        if ($cartItem) {
            $availableQuantity -= $cartItem->quantity;
        }

        $message = 'Not enough stock available for selected product ' . ($product->name ?? '');

        if ($availableQuantity > 0) {
            $message .= ', you can add only ' . max($availableQuantity, 0) . ' more.';
        }

        return helperJSONResponse(
            false,
            $message,
            [],
            HttpStatusCode::CONFLICT->value
        );
    }

    public function validateCartQuantityChange($cartItem, $newQuantity, $changeTo)
    {
        if ($changeTo === 'down' && $newQuantity < 1) {
            return helperJSONResponse(
                false,
                'Please remove correct quantity for product ' . ($cartItem->product->name ?? '') . '. ' . $cartItem->quantity . ' in your cart.',
                [],
                HttpStatusCode::BAD_REQUEST->value
            );
        }

        if ($changeTo === 'up' && $newQuantity > $cartItem->product->quantity) {
            return helperJSONResponse(
                false,
                'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Maximum available quantity is ' . $cartItem->product->quantity,
                [],
                HttpStatusCode::BAD_REQUEST->value
            );
        }

        if ($newQuantity < 1) {
            return helperJSONResponse(false, 'Quantity must be at least 1.', [], HttpStatusCode::BAD_REQUEST->value);
        }

        return null;
    }

    public function varifyProductAvailabilityOnCheckout(Cart $cartItem)
    {
        $availableProductDetails = array();
        $notAvailableProductDetails = array();
        $productAvailabilityDetails = array();

        $productId = $cartItem->product_id;
        $productNanme = $cartItem->product->name;
        $cartItemQuantity = $cartItem->quantity;
        $productQuantity = $cartItem->product->quantity;

        if ($cartItemQuantity > $productQuantity) {
            $notAvailableProductDetails[] = [
                'product_id' => $productId,
                'product_name' => $productNanme,
                'cart_quanity' => $cartItemQuantity,
                'available_quantity' => $productQuantity
            ];
        } else {
            $availableProductDetails[] = [
                'product_id' => $productId,
                'product_name' => $productNanme,
                'cart_quanity' => $cartItemQuantity,
                'available_quantity' => $productQuantity
            ];
        }

        $productAvailabilityDetails = [
            'not_available_product_details' => $notAvailableProductDetails,
            'available_product_details' => $availableProductDetails
        ];

        return $productAvailabilityDetails;
    }

    public function calculateSubTotal($cartItem)
    {
        if (!$cartItem || !$cartItem->product) {
            return 0;
        }

        $unitPrice = (!empty($cartItem->product->discounted_price) && $cartItem->product->discounted_price > 0)
        ? $cartItem->product->discounted_price
        : $cartItem->product->price;

        $subTotal = (float) $unitPrice * (int) $cartItem->quantity;
        return $subTotal;
    }

    public function taxCalculation($totalAmount, $taxPercentage)
    {
        return (($totalAmount * $taxPercentage) / 100);
    }

    public function shippingEstimate($shippingOption)
    {
        if ($shippingOption == '2_4_days_delivery') {
            return 40;
        } else if ($shippingOption == '8_12_days_delivery') {
            return 30;
        } else {
            return 10;
        }
    }
}
