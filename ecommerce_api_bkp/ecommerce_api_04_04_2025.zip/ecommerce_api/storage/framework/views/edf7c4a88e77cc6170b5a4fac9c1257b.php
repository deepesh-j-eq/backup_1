<!DOCTYPE html>
<html>
<head>
    <title>New Contact Message</title>
</head>
<body>
    <h2>New Contact Message</h2>
    <p><strong>Name:</strong> <?php echo e($contactMessage->full_name); ?></p>
    <p><strong>Email:</strong> <?php echo e($contactMessage->email); ?></p>
    <p><strong>Message:</strong></p>
    <p><?php echo e($contactMessage->message); ?></p>
</body>
</html>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\git_repo\trainee-milestones-laravel\ecommerce_api\resources\views/emails/contact_message.blade.php ENDPATH**/ ?>