<?php

namespace App\Http\Controllers\Api;

use App\Enums\HttpStatusCode;
use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateUserProfileRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/users",
    *     summary="Get all users",
    *     description="Fetches all users data from the database",
    *     tags={"Users accessed by admin"},
    *     security={{"bearerAuth": {}}},
    *     operationId="getAllUsers",
    *     @OA\Response(
    *         response=200,
    *         description="All users data",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All users"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="users",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Test"),
    *                         @OA\Property(property="email", type="string", example="test@test.com"),
    *                         @OA\Property(property="email_verified_at", type="string", example=null),
    *                         @OA\Property(property="role_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(
    *                             property="role",
    *                             type="object",
    *                             @OA\Property(property="role", type="string", example="user")
    *                         )
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="No user registered",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="No user registered")
    *         )
    *     )
    * )
    */
    public function index()
    {
        $users = User::with([
            'role' => function ($query) {
                $query->select('id', 'role');
            }
        ])->whereHas('role', function ($query) {
            $query->where('role', 'user');
        })->get();

        if($users->isEmpty()) {
            return helperJSONResponse(false, 'No user registered', [], HttpStatusCode::NOT_FOUND->value);
        }

        $users->each(function ($user) {
            $user->role->makeHidden(['id']);
        });

        return helperJSONResponse(true, 'All users', ['users' => $users], HttpStatusCode::OK->value);
    }

    /**
    * @OA\Get(
    *     path="/api/admin/users-with-trashed",
    *     summary="Get all users including deleted",
    *     description="Fetches all users data from the database including deleted",
    *     tags={"Users accessed by admin"},
    *     security={{"bearerAuth": {}}},
    *     operationId="all.users.inclding.trashed",
    *     @OA\Response(
    *         response=200,
    *         description="All users data including deleted",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All users including deleted"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="users",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Test"),
    *                         @OA\Property(property="email", type="string", example="test@test.com"),
    *                         @OA\Property(property="email_verified_at", type="string", example=null),
    *                         @OA\Property(property="role_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(
    *                             property="role",
    *                             type="object",
    *                             @OA\Property(property="role", type="string", example="user")
    *                         )
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="No user registered",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="No user registered")
    *         )
    *     )
    * )
    */
    public function allUsersIncludingTrashed()
    {
        $users = User::with([
            'role' => function ($query) {
                $query->select('id', 'role');
            }
        ])->whereHas('role', function ($query) {
            $query->where('role', 'user');
        })->withTrashed()
        ->get();

        if($users->isEmpty()) {
            return helperJSONResponse(false, 'No user registered', [], HttpStatusCode::NOT_FOUND->value);
        }

        $users->each(function ($user) {
            $user->role->makeHidden(['id']);
        });

        return helperJSONResponse(true, 'All users', ['users' => $users], HttpStatusCode::OK->value);
    }

    /**
    * @OA\Post(
    *     path="/api/admin/users/{id}",
    *     summary="Get single user",
    *     description="Get single user",
    *     tags={"Users accessed by admin"},
    *     security={{"bearerAuth": {}}},
    *     operationId="single.user",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="User id to show that user",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"include_deleted"},
    *                   @OA\Property(
    *                       property="include_deleted",
    *                       type="string",
    *                       enum={"no", "yes"},
    *                       example="no",
    *                       description="Included trashed (deleted) user or not"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"include_deleted"},
    *                   @OA\Property(
    *                       property="include_deleted",
    *                       type="string",
    *                       enum={"no", "yes"},
    *                       example="no",
    *                       description="Included trashed (deleted) user or not"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Your single user data",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single user data"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="user",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Test"),
    *                         @OA\Property(property="email", type="string", example="test@test.com"),
    *                         @OA\Property(property="email_verified_at", type="string", example=null),
    *                         @OA\Property(property="role_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(property="deleted_at", type="string", example="2025-03-06T07:08:16.000000Z"),
    *                         @OA\Property(
    *                             property="role",
    *                             type="object",
    *                             @OA\Property(property="role", type="string", example="user")
    *                         )
    *                  )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested user is not available or set include_deleted to yes",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested user is not available or set include_deleted to yes")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function show(Request $request, string $id)
    {
        $includeDeleted = $request->has('include_deleted') ? $request->include_deleted : 'no';

        $query = User::with([
            'role' => function ($query) {
                $query->select('id', 'role');
            }
        ])->whereHas('role', function ($query) {
            $query->where('role', 'user');
        });

        if ($includeDeleted === 'yes') {
            $query->withTrashed();
        } else {
            $query->whereNull('deleted_at');
        }

        $user = $query->find($id);

        if(!$user) {
            return helperJSONResponse(false, 'Requested user is not available or set include_deleted to yes', [], HttpStatusCode::NOT_FOUND->value);
        }

        $user->role->makeHidden(['id']);

        return helperJSONResponse(true, 'Your single user data', ['user' => $user], HttpStatusCode::OK->value);
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/profile",
    *     summary="User profile",
    *     description="User profile",
    *     tags={"User"},
    *     security={{"bearerAuth": {}}},
    *     operationId="showUserProfile",
    *     @OA\Response(
    *         response=200,
    *         description="Your profile",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your profile"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="profile",
    *                     type="object",
    *                       @OA\Property(property="name", type="string", example="Test"),
    *                       @OA\Property(property="email", type="string", example="test@test.com")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Something went wrong!",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Something went wrong!")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function showUserProfile()
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $user = User::select('name', 'email')->whereNull('deleted_at')->find($authenticatedUserId);

        if(!$user) {
            return helperJSONResponse(false, 'Something went wrong!', [], HttpStatusCode::BAD_REQUEST->value);
        }

        return helperJSONResponse(true, 'Your profile', ['profile' => $user], HttpStatusCode::OK->value);
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/update-user-profile",
    *     summary="Update user profile",
    *     description="Update your profile",
    *     tags={"User"},
    *     security={{"bearerAuth": {}}},
    *     operationId="user.profile.update",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name", "email"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Test 2"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name", "email"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Test 2"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Your profile is updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your profile is updated successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="profile",
    *                     type="object",
    *                       @OA\Property(property="name", type="string", example="Test"),
    *                       @OA\Property(property="email", type="string", example="test@test.com")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested user is not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested user is not available")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "name": {"The name field is required.", "The name field must be at least 3 characters."},
    *                       "email": {"The email field is required.", "The email must be a valid email address.", "The email has already been taken."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Profile update failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Profile update failed")
    *         )
    *     )
    * )
    */
    public function updateUserProfile(UpdateUserProfileRequest $request)
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $user = User::whereNull('deleted_at')->find($authenticatedUserId);

        if (!$user) {
            return helperJSONResponse(false, 'Requested user is not available', [], HttpStatusCode::NOT_FOUND->value);
        }

        $updateUser = $user->update([
            'name' => $request->name,
            'email' => $request->email
        ]);

        if (!$updateUser) {
            return helperJSONResponse(false, 'Profile update failed', [], HttpStatusCode::INTERNAL_SERVER_ERROR->value);
        }

        $updatedUserProfile = array();
        $updatedUserProfile = User::select('name', 'email')->where('deleted_at', null)->find($authenticatedUserId);

        return helperJSONResponse(true, 'Your profile is updated successfully', ['profile' => $updatedUserProfile], HttpStatusCode::OK->value);
    }

    /**
    * @OA\Delete(
    *     path="/api/delete-user-account",
    *     summary="Delete user account",
    *     description="Delete user account",
    *     tags={"User"},
    *     security={{"bearerAuth": {}}},
    *     operationId="user.account.delete",
    *     @OA\Response(
    *         response=200,
    *         description="Your account deleted successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your account deleted successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested user account is not available for delete",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested user account is not available for delete"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function destroy()
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $user = User::whereNull('deleted_at')
                ->whereHas('role', function ($query) {
                    $query->where('role', 'user');
                })
                ->find($authenticatedUserId);

        if (!$user) {
            return helperJSONResponse(false, 'Requested user account is not available for delete', [], HttpStatusCode::NOT_FOUND->value);
        }

        $user->delete();

        return helperJSONResponse(true, 'User account deleted successfully', [], HttpStatusCode::OK->value);
    }

    /**
    * @OA\Post(
    *     path="/api/admin/restore-user",
    *     summary="Restore user account",
    *     description="Restore user account",
    *     tags={"Users accessed by admin"},
    *     security={{"bearerAuth": {}}},
    *     operationId="restore.soft.deleted.user",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"user_id"},
    *                   @OA\Property(
    *                       property="user_id",
    *                       type="integer",
    *                       example=9
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"user_id"},
    *                   @OA\Property(
    *                       property="user_id",
    *                       type="integer",
    *                       example=9
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Your single user data",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single user data"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="user",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Test"),
    *                         @OA\Property(property="email", type="string", example="test@test.com"),
    *                         @OA\Property(property="email_verified_at", type="string", example=null),
    *                         @OA\Property(property="role_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(property="deleted_at", type="string", example="2025-03-06T07:08:16.000000Z"),
    *                         @OA\Property(
    *                             property="role",
    *                             type="object",
    *                             @OA\Property(property="role", type="string", example="user")
    *                         )
    *                  )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested user not available for restore or user already active",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested user not available for restore or user already active")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "user_id": {"The user id field is required.", "The selected user id is invalid."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function restoreSoftDeletedUser(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'user_id'=>'required|exists:users,id'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), HttpStatusCode::UNPROCESSABLE_ENTITY->value);
        }

        $userId = $request->user_id;

        $user = User::onlyTrashed()->find($userId);

        if (!$user) {
            return helperJSONResponse(false, 'Requested user not available for restore or user already active', [], HttpStatusCode::NOT_FOUND->value);
        }

        $user->restore();

        $updatedUser = User::with([
                            'role' => function ($query) {
                                $query->select('id', 'role');
                            }
                        ])->whereHas('role', function ($query) {
                            $query->where('role', 'user');
                        })->find($userId);

        $updatedUser->role->makeHidden(['id']);

        return helperJSONResponse(true, 'User account restored successfully', ['user' => $updatedUser], HttpStatusCode::OK->value);
    }

    public function permanentDeleteUser(string $id)
    {
        $user = User::withTrashed()
                ->whereHas('role', function ($query) {
                    $query->where('role', 'user');
                })
                ->find($id);

        if (!$user) {
            return helperJSONResponse(false, 'Requested user is not available for permanent delete', [], HttpStatusCode::NOT_FOUND->value);
        }

        $user->forceDelete();

        return helperJSONResponse(true, 'User permanent deleted successfully', [], HttpStatusCode::OK->value);
    }
}
