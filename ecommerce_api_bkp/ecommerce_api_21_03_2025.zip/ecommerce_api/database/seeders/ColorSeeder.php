<?php

namespace Database\Seeders;

use App\Models\Color;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ColorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $colors = [
            ['color' => 'Red'],
            ['color' => 'Yellow'],
            ['color' => 'Green'],
            ['color' => 'Black'],
            ['color' => 'Blue'],
            ['color' => 'Brown'],
            ['color' => 'Gray']
        ];

        foreach ($colors as $color) {
            Color::firstOrCreate($color);
        }
    }
}
