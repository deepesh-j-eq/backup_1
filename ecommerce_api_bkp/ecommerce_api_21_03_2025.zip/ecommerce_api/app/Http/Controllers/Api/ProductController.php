<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Models\Category;
use App\Models\Color;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Size;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/products",
    *     summary="Get all products",
    *     description="Fetches all products from the database",
    *     tags={"Products"},
    *     security={{"bearerAuth": {}}},
    *     operationId="get.all.products",
    *     @OA\Response(
    *         response=200,
    *         description="All products",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All products"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="products",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Product 1"),
    *                         @OA\Property(property="description", type="string", example="Product 1 description"),
    *                         @OA\Property(property="price", type="string", example="50.00"),
    *                         @OA\Property(property="discounted_price", type="string", example="25.00"),
    *                         @OA\Property(property="quantity", type="integer", example=10),
    *                         @OA\Property(property="category_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="rating", type="string", example="2.5"),
    *                         @OA\Property(
    *                             property="category",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Men's fashion")
    *                         ),
    *                         @OA\Property(
    *                             property="colors",
    *                             type="array",
    *                             nullable=true,
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="color", type="string", example="Blue")
    *                             )
    *                         ),
    *                         @OA\Property(
    *                             property="sizes",
    *                             type="array",
    *                             nullable=true,
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="size", type="string", example="S")
    *                             )
    *                         ),
    *                         @OA\Property(
    *                             property="images",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="image_path", type="string", example="product_images/4RZWt1pw9l73uaooKwHDPEbz3mqDjszdAUbpemnN.jpg")
    *                             )
    *                         ),
    *                         @OA\Property(
    *                             property="ratings",
    *                             type="array",
    *                             nullable=true,
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="id", type="integer", example=2),
    *                                 @OA\Property(property="rating", type="string", example="2.5"),
    *                                 @OA\Property(property="review", type="string", example="Test review"),
    *                                 @OA\Property(property="user_id", type="integer", example=3),
    *                                 @OA\Property(
    *                                     property="user",
    *                                     type="object",
    *                                     @OA\Property(property="name", type="string", example="Test 2")
    *                                 )
    *                             )
    *                         )
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="No products found",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="No products found")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function index()
    {
        try {
            $products = $this->getProductDetails();

            if (!$products) {
                return helperJSONResponse(true, 'No products found', [], 404);
            }

            return helperJSONResponse(true, 'All products', ['products' => $products], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/products",
    *     summary="Create product",
    *     description="Create product",
    *     tags={"Products"},
    *     security={{"bearerAuth": {}}},
    *     operationId="store.product",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"name", "description", "price", "quantity", "category_id", "images"},
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Product 5"
    *                   ),
    *                   @OA\Property(
    *                       property="description",
    *                       type="string",
    *                       example="Product 5 description"
    *                   ),
    *                   @OA\Property(
    *                       property="discounted_price",
    *                       type="number",
    *                       format="float",
    *                       nullable=true,
    *                       example=110.00
    *                   ),
    *                   @OA\Property(
    *                       property="price",
    *                       type="number",
    *                       format="float",
    *                       example=210.00
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=10
    *                   ),
    *                   @OA\Property(
    *                       property="category_id",
    *                       type="integer",
    *                       example=2
    *                   ),
    *                   @OA\Property(
    *                       property="size_ids",
    *                       type="string",
    *                       nullable=true,
    *                       example="1,3"
    *                   ),
    *                   @OA\Property(
    *                       property="color_ids",
    *                       type="string",
    *                       nullable=true,
    *                       example="4,5"
    *                   ),
    *                   @OA\Property(
    *                       property="images",
    *                       type="array",
    *                       @OA\Items(type="string", format="binary")
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"name", "description", "price", "quantity", "category_id", "images"},
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Product 5"
    *                   ),
    *                   @OA\Property(
    *                       property="description",
    *                       type="string",
    *                       example="Product 5 description"
    *                   ),
    *                   @OA\Property(
    *                       property="price",
    *                       type="number",
    *                       format="float",
    *                       example=210.00
    *                   ),
    *                   @OA\Property(
    *                       property="discounted_price",
    *                       type="number",
    *                       format="float",
    *                       nullable=true,
    *                       example=110.00
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=10
    *                   ),
    *                   @OA\Property(
    *                       property="category_id",
    *                       type="integer",
    *                       example=2
    *                   ),
    *                   @OA\Property(
    *                       property="size_ids",
    *                       type="string",
    *                       nullable=true,
    *                       example="1,3"
    *                   ),
    *                   @OA\Property(
    *                       property="color_ids",
    *                       type="string",
    *                       nullable=true,
    *                       example="4,5"
    *                   ),
    *                   @OA\Property(
    *                       property="images",
    *                       type="array",
    *                       @OA\Items(type="string", format="uri")
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=201,
    *         description="Product created successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product created successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="product",
    *                     type="object",
    *                         @OA\Property(property="name", type="string", example="Product 5"),
    *                         @OA\Property(property="description", type="string", example="Product 5 description"),
    *                         @OA\Property(property="price", type="string", example="100"),
    *                         @OA\Property(property="discounted_price", type="string", example="50.00"),
    *                         @OA\Property(property="quantity", type="string", example="15"),
    *                         @OA\Property(property="category_id", type="string", example="4"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-04T05:10:48.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-04T05:10:48.000000Z"),
    *                         @OA\Property(property="id", type="integer", example=1)
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "name": {"The name field is required.", "The name field must be at least 3 characters."},
    *                       "description": {"The description field is required."},
    *                       "price": {"The price field is required.", "The price field must be at least 1.", "Price should be a valid number with up to two decimal places."},
    *                       "discounted_price": {"The discounted price field must be at least 0.", "Discounted price should be a valid number with up to two decimal places."},
    *                       "quantity": {"The quantity field is required.", "The quantity field must be at least 0."},
    *                       "category_id": {"The category id field is required.", "The selected category id is invalid."},
    *                       "size_ids": {"Size ID 10 does not exist in the sizes table.", "Invalid Size ID format"},
    *                       "color_ids": {"Color ID 30 does not exist in the colors table.", "Invalid Color ID format"},
    *                       "images": {"The images field is required."},
    *                       "images.0": {"The first image must be an image file."},
    *                       "images.1": {"The second image must be a file of type: jpeg, png, jpg, gif."},
    *                       "images.2": {"The third image must not be greater than 2048 kilobytes."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Product creation failed or An error occurred",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Product creation failed or An error occurred")
    *         )
    *     )
    * )
    */
    public function store(StoreProductRequest $request)
    {
        try {
            $errors = array();
            $sizeIds = $request->size_ids ? explode(',', $request->size_ids) : [];
            $colorIds = $request->color_ids ? explode(',', $request->color_ids) : [];

            foreach ($sizeIds as $sizeId) {
                if (!ctype_digit($sizeId)) {
                    $errors['size_id'][] = "Invalid Size ID format: $sizeId";
                    continue;
                }
                if (!Size::where('id', $sizeId)->exists()) {
                    $errors['size_id'][] = "Size ID $sizeId does not exist in the sizes table.";
                }
            }

            foreach ($colorIds as $colorId) {
                if (!ctype_digit($colorId)) {
                    $errors['color_id'][] = "Invalid Color ID format: $colorId";
                    continue;
                }
                if (!Color::where('id', $colorId)->exists()) {
                    $errors['color_id'][] = "Color ID $colorId does not exist in the colors table.";
                }
            }

            if (!empty($errors)) {
                return helperJSONResponse(false, 'Validation error', $errors, 422);
            }

            $product = Product::create([
                'name' => $request->name,
                'description' => $request->description,
                'price' => $request->price,
                'discounted_price' => !empty($request->discounted_price) ? $request->discounted_price : null,
                'quantity' => $request->quantity,
                'category_id' => $request->category_id
            ]);

            if (!$product) {
                return helperJSONResponse(false, 'Product create failed', [], 500);
            }

            if (!empty($sizeIds)) {
                $product->sizes()->syncWithPivotValues($sizeIds, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
            }

            if (!empty($colorIds)) {
                $product->colors()->syncWithPivotValues($colorIds, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
            }

            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $image) {
                    $path = $image->store('product_images', 'public');

                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $product->id
                    ]);
                }
            }

            return helperJSONResponse(true, 'Product creation successfully', ['product' => $product], 201);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/products/{id}",
    *     summary="Get single product",
    *     description="Display single product",
    *     tags={"Products"},
    *     security={{"bearerAuth": {}}},
    *     operationId="get.single.product",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Product id to show that category",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display single product",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single product"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="product",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Product 1"),
    *                         @OA\Property(property="description", type="string", example="Product 1 description"),
    *                         @OA\Property(property="price", type="string", example="50.00"),
    *                         @OA\Property(property="discounted_price", type="string", example="25.00"),
    *                         @OA\Property(property="quantity", type="integer", example=10),
    *                         @OA\Property(property="category_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="rating", type="string", example="1.5"),
    *                         @OA\Property(
    *                             property="category",
    *                             type="object",
    *                             @OA\Property(property="id", type="integer", example=2),
    *                             @OA\Property(property="name", type="string", example="Men's fashion")
    *                         ),
    *                         @OA\Property(
    *                             property="colors",
    *                             type="array",
    *                             nullable=true,
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="color", type="string", example="Blue")
    *                             )
    *                         ),
    *                         @OA\Property(
    *                             property="sizes",
    *                             type="array",
    *                             nullable=true,
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="size", type="string", example="S")
    *                             )
    *                         ),
    *                         @OA\Property(
    *                             property="images",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="image_path", type="string", example="product_images/4RZWt1pw9l73uaooKwHDPEbz3mqDjszdAUbpemnN.jpg")
    *                             )
    *                         ),
    *                         @OA\Property(
    *                             property="ratings",
    *                             type="array",
    *                             nullable=true,
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="id", type="integer", example=2),
    *                                 @OA\Property(property="rating", type="string", example="2.5"),
    *                                 @OA\Property(property="review", type="string", example="Test review"),
    *                                 @OA\Property(property="user_id", type="integer", example=3),
    *                                 @OA\Property(
    *                                     property="user",
    *                                     type="object",
    *                                     @OA\Property(property="name", type="string", example="Test 2")
    *                                 )
    *                             )
    *                         )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested product is not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested product is not available")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {
        try {
            $product = $this->getProductDetails($id);

            if (!$product) {
                return helperJSONResponse(false, 'Requested product is not available', [], 404);
            }

            return helperJSONResponse(true, 'Your single product', ['product' => $product], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/products/{id}",
    *     summary="Update product",
    *     description="Update product",
    *     tags={"Products"},
    *     security={{"bearerAuth": {}}},
    *     operationId="update.product",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Product id to update that product",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name", "description", "price", "quantity", "category_id"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Product 7"
    *                   ),
    *                   @OA\Property(
    *                       property="description",
    *                       type="string",
    *                       example="Product 7 description"
    *                   ),
    *                   @OA\Property(
    *                       property="price",
    *                       type="number",
    *                       format="float",
    *                       example=110.00
    *                   ),
    *                   @OA\Property(
    *                       property="discounted_price",
    *                       type="number",
    *                       format="float",
    *                       nullable=true,
    *                       example=50.00
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=15
    *                   ),
    *                   @OA\Property(
    *                       property="category_id",
    *                       type="integer",
    *                       example=3
    *                   ),
    *                   @OA\Property(
    *                       property="size_ids",
    *                       type="string",
    *                       nullable=true,
    *                       example="4,5"
    *                   ),
    *                   @OA\Property(
    *                       property="color_ids",
    *                       type="string",
    *                       nullable=true,
    *                       example="2,4"
    *                   ),
    *                   @OA\Property(
    *                       property="images",
    *                       type="array",
    *                       @OA\Items(type="string", format="binary")
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name", "description", "price", "quantity", "category_id"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Product 7"
    *                   ),
    *                   @OA\Property(
    *                       property="description",
    *                       type="string",
    *                       example="Product 7 description"
    *                   ),
    *                   @OA\Property(
    *                       property="price",
    *                       type="number",
    *                       format="float",
    *                       example=110.00
    *                   ),
    *                   @OA\Property(
    *                       property="discounted_price",
    *                       type="number",
    *                       format="float",
    *                       nullable=true,
    *                       example=50.00
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=15
    *                   ),
    *                   @OA\Property(
    *                       property="category_id",
    *                       type="integer",
    *                       example=3
    *                   ),
    *                   @OA\Property(
    *                       property="size_ids",
    *                       type="string",
    *                       nullable=true,
    *                       example="4,5"
    *                   ),
    *                   @OA\Property(
    *                       property="color_ids",
    *                       type="string",
    *                       nullable=true,
    *                       example="2,4"
    *                   ),
    *                   @OA\Property(
    *                       property="images",
    *                       type="array",
    *                       @OA\Items(type="string", format="uri")
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product updated successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="product",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Product 7"),
    *                         @OA\Property(property="description", type="string", example="Product 7 description"),
    *                         @OA\Property(property="price", type="string", example="110.00"),
    *                         @OA\Property(property="quantity", type="integer", example=15),
    *                         @OA\Property(property="category_id", type="integer", example=5),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-04T06:17:33.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-04T06:19:16.000000Z"),
    *                         @OA\Property(
    *                             property="category",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Men's fashion")
    *                         ),
    *                         @OA\Property(
    *                             property="colors",
    *                             type="array",
    *                             nullable=true,
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="color", type="string", example="Blue")
    *                             )
    *                         ),
    *                         @OA\Property(
    *                             property="sizes",
    *                             type="array",
    *                             nullable=true,
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="size", type="string", example="S")
    *                             )
    *                         ),
    *                         @OA\Property(
    *                             property="images",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="image_path", type="string", example="product_images/4RZWt1pw9l73uaooKwHDPEbz3mqDjszdAUbpemnN.jpg")
    *                             )
    *                         )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Something went wrong! Product is not available after update",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Something went wrong! Product is not available after update")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested product not available for update",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested product not available for update")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "name": {"The name field is required.", "The name field must be at least 3 characters."},
    *                       "description": {"The description field is required."},
    *                       "price": {"The price field is required.", "The price field must be at least 1.", "Price should be a valid number with up to two decimal places."},
    *                       "discounted_price": {"The discounted price field must be at least 0.", "Discounted price should be a valid number with up to two decimal places."},
    *                       "quantity": {"The quantity field is required.", "The quantity field must be at least 0."},
    *                       "category_id": {"The category id field is required.", "The selected category id is invalid."},
    *                       "size_ids": {"Size ID 10 does not exist in the sizes table.", "Invalid Size ID format"},
    *                       "color_ids": {"Color ID 30 does not exist in the colors table.", "Invalid Color ID format"},
    *                       "images": {"The images field is required."},
    *                       "images.0": {"The first image must be an image file."},
    *                       "images.1": {"The second image must be a file of type: jpeg, png, jpg, gif."},
    *                       "images.2": {"The third image must not be greater than 2048 kilobytes."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Product update failed or An error occurred",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Product update failed or An error occurred")
    *         )
    *     )
    * )
    */
    public function update(UpdateProductRequest $request, string $id)
    {
        try {
            $product = Product::find($id);

            if (!$product) {
                return helperJSONResponse(false, 'Requested product not available for update', [], 404);
            }

            $errors = array();
            $sizeIds = $request->size_ids ? explode(',', $request->size_ids) : [];
            $colorIds = $request->color_ids ? explode(',', $request->color_ids) : [];

            foreach ($sizeIds as $sizeId) {
                if (!ctype_digit($sizeId)) {
                    $errors['size_id'][] = "Invalid Size ID format: $sizeId";
                    continue;
                }
                if (!Size::where('id', $sizeId)->exists()) {
                    $errors['size_id'][] = "Size ID $sizeId does not exist in the sizes table.";
                }
            }

            foreach ($colorIds as $colorId) {
                if (!ctype_digit($colorId)) {
                    $errors['color_id'][] = "Invalid Color ID format: $colorId";
                    continue;
                }
                if (!Color::where('id', $colorId)->exists()) {
                    $errors['color_id'][] = "Color ID $colorId does not exist in the colors table.";
                }
            }

            if (!empty($errors)) {
                return helperJSONResponse(false, 'Validation error', $errors, 422);
            }

            $updateProduct = $product->update([
                'name' => $request->name,
                'description' => $request->description,
                'price' => $request->price,
                'discounted_price' => !empty($request->discounted_price) ? $request->discounted_price : null,
                'quantity' => $request->quantity,
                'category_id' => $request->category_id
            ]);

            if (!$updateProduct) {
                return helperJSONResponse(false, 'Product update failed', [], 500);
            }

            if (!empty($sizeIds)) {
                $product->sizes()->syncWithPivotValues($sizeIds, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
            } else {
                $product->sizes()->sync([]);
            }

            if (!empty($colorIds)) {
                $product->colors()->syncWithPivotValues($colorIds, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
            } else {
                $product->colors()->sync([]);
            }

            if ($request->hasFile('images')) {
                foreach ($product->images as $image) {
                    Storage::disk('public')->delete($image->image_path);
                    $image->delete();
                }

                foreach ($request->file('images') as $image) {
                    $path = $image->store('product_images', 'public');
        
                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $product->id
                    ]);
                }
            }

            $productDetails = array();
            $productDetails = Product::with([
                'category:id,name',
                'colors:id,color',
                'sizes:id,size',
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id']);
                }
            ])->find($id);

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            $updatedProductData = $this->formatProductResponse($productDetails, $user);

            if (!$updatedProductData) {
                return helperJSONResponse(false, 'Something went wrong! Product is not available after update', [], 400);
            }

            return helperJSONResponse(true, 'Product updated successfully', ['product' => $updatedProductData], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */

    /**
    * @OA\Delete(
    *     path="/api/admin/products/{id}",
    *     summary="Delete product",
    *     description="Delete product",
    *     tags={"Products"},
    *     security={{"bearerAuth": {}}},
    *     operationId="product.destroy",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Product id to delete that product",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product deleted successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product deleted successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested product not available for delete",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested product not available for delete"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function destroy(string $id)
    {
        try {
            $product = Product::find($id);

            if (!$product) {
                return helperJSONResponse(false, 'Requested product not available for delete', [], 404);
            }

            foreach ($product->images as $image) {
                Storage::disk('public')->delete($image->image_path);
                $image->delete();
            }

            $product->sizes()->detach();
            $product->colors()->detach();

            $product->delete();

            return helperJSONResponse(true, 'Product deleted successfully', [], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }


    /**
     * Display a listing of the resource after applying filters.
     */

    /**
    * @OA\Post(
    *     path="/api/products_with_filter",
    *     summary="Get products after applying filters",
    *     description="Display products after applying filters",
    *     tags={"Products"},
    *     security={{"bearerAuth": {}}},
    *     operationId="products.with.filter",
    *     @OA\RequestBody(
    *           required=false,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   @OA\Property(
    *                       property="category_id",
    *                       type="integer",
    *                       nullable=true,
    *                       example=1
    *                   ),
    *                   @OA\Property(
    *                       property="min_price",
    *                       type="integer",
    *                       nullable=true,
    *                       example=100
    *                   ),
    *                   @OA\Property(
    *                       property="max_price",
    *                       type="integer",
    *                       nullable=true,
    *                       example=500
    *                   ),
    *                   @OA\Property(
    *                       property="sort_by",
    *                       type="string",
    *                       example="price_low_high"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   @OA\Property(
    *                       property="category_id",
    *                       type="integer",
    *                       nullable=true,
    *                       example=1
    *                   ),
    *                   @OA\Property(
    *                       property="min_price",
    *                       type="integer",
    *                       nullable=true,
    *                       example=100
    *                   ),
    *                   @OA\Property(
    *                       property="max_price",
    *                       type="integer",
    *                       nullable=true,
    *                       example=500
    *                   ),
    *                   @OA\Property(
    *                       property="sort_by",
    *                       type="string",
    *                       example="price_low_high"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display products after applying filters",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Products after applying filters"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="product",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Product 1"),
    *                         @OA\Property(property="description", type="string", example="Product 1 description"),
    *                         @OA\Property(property="price", type="string", example="50.00"),
    *                         @OA\Property(property="discounted_price", type="string", example="25.00"),
    *                         @OA\Property(property="quantity", type="integer", example=10),
    *                         @OA\Property(property="category_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="rating", type="string", example="1.5"),
    *                         @OA\Property(
    *                             property="images",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="id", type="integer", example=1),
    *                                 @OA\Property(property="image_path", type="string", example="product_images/4RZWt1pw9l73uaooKwHDPEbz3mqDjszdAUbpemnN.jpg"),
    *                                 @OA\Property(property="product_id", type="integer", example=5)
    *                             )
    *                         )
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Sorry! No product available, please apply different filter",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Sorry! No product available, please apply different filter")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "category_id": {"The category_id field is required.", "The selected category id is invalid."},
    *                       "min_price": {"The min price field must be an integer."},
    *                       "max_price": {"The max price field must be an integer."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function productsWithFilter(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'category_id' => 'nullable|exists:categories,id',
                'min_price' => 'nullable|integer',
                'max_price' => 'nullable|integer',
                'sort_by' => 'nullable|string'
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 422);
            }

            $query = Product::with([
                'category:id,name',
                'ratings.user:id,name',
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id'])->limit(1);
                }
            ]);
        
            if ($request->has('category_id') && $request->category_id !== null) {
                $categoryIds = explode(',', $request->category_id);
                $validCategoryIds = Category::whereIn('id', $categoryIds)->pluck('id')->toArray();
                
                if (!empty($validCategoryIds)) {
                    $query->whereIn('category_id', $validCategoryIds);
                }
            }
        
            if ($request->has('min_price') && $request->min_price !== null) {
                $query->where(function ($q) use ($request) {
                    $q->where(function ($q) use ($request) {
                        $q->whereNotNull('discounted_price')
                          ->where('discounted_price', '>', 0)
                          ->where('discounted_price', '>=', $request->min_price);
                    })->orWhere(function ($q) use ($request) {
                        $q->where(function ($q) {
                            $q->whereNull('discounted_price')
                              ->orWhere('discounted_price', '<=', 0);
                        })
                        ->where('price', '>=', $request->min_price);
                    });
                });
            }

            if ($request->has('max_price') && $request->max_price !== null) {
                $query->where(function ($q) use ($request) {
                    $q->where(function ($q) use ($request) {
                        $q->whereNotNull('discounted_price')
                          ->where('discounted_price', '>', 0)
                          ->where('discounted_price', '<=', $request->max_price);
                    })->orWhere(function ($q) use ($request) {
                        $q->where(function ($q) {
                            $q->whereNull('discounted_price')
                              ->orWhere('discounted_price', '<=', 0);
                        })->where('price', '<=', $request->max_price);
                    });
                });
            }

            if ($request->has('sort_by') && $request->sort_by !== null) {
                switch ($request->sort_by) {
                    case 'most_popular':
                        $query->orderBy('popularity', 'desc');
                        break;
                    case 'best_rating':
                        $query->withAvg('ratings', 'rating')->orderByDesc('ratings_avg_rating');
                        //$query->orderBy('rating', 'desc');
                        break;
                    case 'newest':
                        $query->orderBy('created_at', 'desc');
                        break;
                    case 'price_low_high':
                        $query->orderBy('price', 'asc');
                        break;
                    case 'price_high_low':
                        $query->orderBy('price', 'desc');
                        break;
                    default:
                        $query->orderBy('created_at', 'desc');
                }
            }

            $products = $query->get();

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            $productDetails = $products->map(function ($product) use ($user) {
                return $this->formatProductResponse($product, $user);
            });

            if ($productDetails->isEmpty()) {
                return helperJSONResponse(false, 'Sorry! No product available, please apply different filter', [], 404);
            }

            return helperJSONResponse(true, 'Products after applying filters', ['products' => $productDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    private function getProductDetails($specificProductId = null)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            $productQuery = Product::with([
                'category:id,name',
                'colors:id,color',
                'sizes:id,size',
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id']);/*->limit(1);*/
                },
                'ratings.user:id,name'
            ]);

            if (!empty($specificProductId)) {
                $product = $productQuery->find($specificProductId);
        
                if (!$product) {
                    return false;
                }

                return $this->formatProductResponse($product, $user);
            }

            $products = $productQuery->get();

            if ($products->isEmpty()) {
                return false;
            }

            foreach ($products as $product) {
                $this->formatProductResponse($product, $user);
            }

            return $products;
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    private function formatProductResponse(Product $product, User $user) {
        $product->category->makeHidden(['id']);

        if ($product->category->created_at) {
            $product->category->makeHidden(['created_at']);
        }

        if ($product->category->updated_at) {
            $product->category->makeHidden(['updated_at']);
        }

        if (empty($product->discounted_price)) {
            $product->makeHidden(['discounted_price']);
        }

        if ($user->isUser()) {
            $product->makeHidden(['id', 'category_id', 'created_at', 'updated_at']);
        }

        if ($product->relationLoaded('colors') && $product->colors->isNotEmpty()) {
            foreach ($product->colors as $productColor) {
                $productColor->makeHidden(['id', 'pivot', 'created_at', 'updated_at']);
            }
        }

        if ($product->relationLoaded('sizes') && $product->sizes->isNotEmpty()) {
            foreach ($product->sizes as $productSize) {
                $productSize->makeHidden(['id', 'pivot', 'created_at', 'updated_at']);
            }
        }

        if ($product->relationLoaded('ratings') && $product->ratings->isNotEmpty()) {
            foreach ($product->ratings as $productRating) {
                if ($user->isUser()) {
                    $productRating->makeHidden(['id', 'user_id']);
                }

                $productRating->makeHidden(['product_id', 'created_at', 'updated_at']);

                if (!$productRating->relationLoaded('user') || !$productRating->user) {
                    unset($rating->user);
                } else {
                    $productRating->user->makeHidden(['id']);
                }
            }

            $averageRating = $product->ratings->avg('rating');
            $product->rating = number_format($averageRating, 1);
        }

        if ($product->relationLoaded('images') && $product->images->isNotEmpty()) {
            foreach ($product->images as $productImage) {
                $productImage->makeHidden(['id', 'product_id']);
            }
        }

        return $product;
    }
}
