<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $orderDetails = $this->getOrderDetails();

            if ($orderDetails->isEmpty()) {
                return helperJSONResponse(false, 'No orders. Keep shopping !', [], 400);
            }

            return helperJSONResponse(true, 'All orders', ['orders' => $orderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $orderDetails = $this->getOrderDetails($id);

            if (!$orderDetails) {
                return helperJSONResponse(false, 'Requested order is not available', [], 400);
            }

            return helperJSONResponse(true, 'Your single order', ['order_details' => $orderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $adminUser = auth('sanctum')->user();
            $adminUserId = $adminUser->id;

            $adminCheck = User::find($adminUserId);

            if(!$adminCheck->isAdmin()) {
                return helperJSONResponse(false, 'Unauthorize, admin has only access to update order', [], 403);
            }

            $validate = Validator::make($request->all(), [
                'order_status' => 'required|exists:order_statuses,status',
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $order = Order::with([
                        'orderStatus:id,status',
                        'payment:id,status',
                        'orderItems:id,product_id'
                    ])
                    ->find($id);

            if (!$order) {
                return helperJSONResponse(false, 'Requested order is not available for update', [], 400);
            }

            $allowedOrderStatuses = $this->getAllowedOrderStatuses($order->payment->status);

            if (!in_array($request->order_status, $allowedOrderStatuses)) {
                return helperJSONResponse(false, "Invalid order_status. Allowed values for order payment status '{$order->payment->status}' are: " . json_encode($allowedOrderStatuses), [], 400);
            }

            $updateOrderData = array();

            if ($request->order_status != $order->orderStatus->status) {
                $newOrderStatusId = OrderStatus::where('status', $request->order_status)->pluck('id')->first();
                $updateOrderData['order_status_id'] = $newOrderStatusId;
            }

            if (!empty($updateOrderData)) {
                $updateOrderData['updated_by'] = $adminUserId;
                $order->update($updateOrderData);
            }

            if ($order->payment->status === 'refunded' ||  ($order->payment->status === 'succeeded' && $order->order_status_id == 5)) {
                foreach ($order->orderItems as $orderItem) {
                    $product = Product::find($orderItem->product_id);

                    if ($product) {
                        // $product->quantity += $orderItem->quantity;
                        // $product->save();
                    }
                }
            }

            $updatedOrderDetails = $this->getOrderDetails($id);

            $responseMessage = empty($updateOrderData) 
                                ? "No changes in order status, try another order status" 
                                : "Order status updated successfully";

            return helperJSONResponse(true, $responseMessage, ['order_details' => $updatedOrderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    public function ordersWithFilter(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'order_status' => 'nullable|string',
                'payment_status' => 'nullable|string|in:pending,requires_payment_method,failed,succeeded,refunded',
                'city' => 'nullable|string',
                'state' => 'nullable|string',
                'country' => 'nullable|string',
                'order_total_min' => 'nullable|integer|min:0',
                'order_total_max' => 'nullable|integer|min:0',
                'user_id' => 'nullable|exists:users,id'
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $orderStatusId = '';

            if ($request->has('order_status') && $request->order_status !== null) {
                $orderStatusId = OrderStatus::where('status', $request->order_status)->pluck('id')->first();
            }

            $orderQuery = Order::query();
        
            if ($orderStatusId != '' && $orderStatusId !== null) {
                $orderQuery->where('order_status_id', $orderStatusId);
            }
        
            if ($request->has('payment_status') && $request->payment_status !== null) {
                $orderQuery->whereHas('payment', function ($query) use ($request) {
                    $query->where('status', $request->payment_status);
                });
            }

            if ($request->has('city') && $request->city !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('city', 'LIKE', "%{$request->city}%");
                });
            }

            if ($request->has('state') && $request->state !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('state', 'LIKE', "%{$request->state}%");
                });
            }

            if ($request->has('country') && $request->country !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('country', 'LIKE', "%{$request->country}%");
                });
            }

            if ($request->has('order_total_min') && $request->order_total_min !== null) {
                $orderQuery->where('total_amount', '>=', $request->order_total_min);
            }

            if ($request->has('order_total_max') && $request->order_total_max !== null) {
                $orderQuery->where('total_amount', '<=', $request->order_total_max);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            if($user->isUser()) {
                $orderQuery->where('user_id', $authenticatedUserId);
            }

            if($user->isAdmin()) {
                if ($request->has('user_id') && $request->user_id !== null) {
                    $orderQuery->where('user_id', $request->user_id);
                }
            }

            $orderDetails = $orderQuery->with([
                'orderStatus:id,status',
                'payment:id,payment_gateway,transaction_id,status,payment_method',
                'user:id,name',
                'address:id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email,order_id',
                'orderItems.product:id,name'
            ])->get();

            if ($orderDetails->isEmpty()) {
                return helperJSONResponse(true, 'Sorry! No order available, please apply different filter', [], 200);
            }

            foreach ($orderDetails as $order) {
                $this->formatOrderResponse($order, $user);
            }

            return helperJSONResponse(true, 'Orders after applying filters', ['order_details' => $orderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    private function getOrderDetails($specificOrderId = null)
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $user = User::find($authenticatedUserId);

        $ordersQuery = Order::with([
            'orderStatus:id,status',
            'payment:id,payment_gateway,transaction_id,status,payment_method',
            'user:id,name',
            'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
            'orderItems.product:id,name'
        ]);

        if ($user->isUser()) {
            $ordersQuery->where('user_id', $authenticatedUserId);
        }

        if (!empty($specificOrderId)) {
            $order = $ordersQuery->find($specificOrderId);
    
            if (!$order) {
                return helperJSONResponse(false, 'Requested order is not available', [], 400);
            }
    
            return $this->formatOrderResponse($order, $user);
        }

        $orders = $ordersQuery->get();

        if ($orders->isEmpty()) {
            return helperJSONResponse(false, 'No orders. Keep shopping!', [], 400);
        }

        foreach ($orders as $order) {
            $this->formatOrderResponse($order, $user);
        }

        return $orders;
    }

    private function formatOrderResponse(Order $order, User $user)
    {
        if ($user->isUser()) {
            $order->makeHidden(['user_id', 'order_status_id', 'payment_id', 'updated_by']);
        }

        $order->orderStatus->makeHidden(['id']);
        $order->payment->makeHidden(['id']);
        $order->user->makeHidden(['id']);
        $order->address->makeHidden(['id']);

        $orderSubTotal = 0.00;

        foreach ($order->orderItems as $orderItem) {
            $orderItem->makeHidden(['id']);

            if ($user->isUser()) {
                $orderItem->makeHidden(['product_id', 'created_at', 'updated_at']);
            }

            $price = (float) $orderItem->price;
            $quantity = (int) $orderItem->quantity;

            $subTotal = $price * $quantity;
            $orderSubTotal += $subTotal;

            $orderItem->sub_total = number_format($subTotal, 2);

            if ($orderItem->product) {
                $orderItem->product->makeHidden(['id']);
            }
        }

        $order->order_sub_total = number_format($orderSubTotal, 2);

        return $order;
    }

    private function getAllowedOrderStatuses(string $paymentStatus)
    {
        $allowedStatuses = [
            'succeeded' => ["Created", "Placed", "In Transit", "Shipped", "Completed"],
            'pending'   => ["Canceled", "Payment Failed"],
            'failed'    => ["Canceled", "Payment Failed"],
            'refunded'  => ["Refunded"]
        ];

        return $allowedStatuses[$paymentStatus] ?? [];
    }
}
