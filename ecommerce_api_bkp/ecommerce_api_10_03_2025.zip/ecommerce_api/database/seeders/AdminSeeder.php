<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $admins = [
            [
                'name' => 'Admin 1',
                'email' => 'admin1@test.com',
                'password' => '12345',
                'role_id' => 1,
            ],
            [
                'name' => 'Admin 2',
                'email' => 'admin2@test.com',
                'password' => '12345',
                'role_id' => 1,
            ]
        ];

        foreach($admins as $admin) {
            $checkEmailExist = User::where('email', $admin['email'])->first();

            if (!$checkEmailExist) {
                User::create($admin);
            }

            /* // Assign role if using spatie/laravel-permission
            if (!$user->hasRole('admin')) {
                $user->assignRole('admin');
            } */
        }
    }
}
