<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = ['transaction_id', 'currency', 'amount', 'payer_name', 'payer_email', 'payment_gateway', 'payment_method', 'status'];

    public function order()
    {
        return $this->hasOne(Order::class);
    }

    public function setMaskedCardNumberAttribute($value)
    {
        $lastFour = substr($value, -4);
        $this->attributes['masked_card_number'] = 'xxxx-xxxx-xxxx-' . $lastFour;
    }
}
