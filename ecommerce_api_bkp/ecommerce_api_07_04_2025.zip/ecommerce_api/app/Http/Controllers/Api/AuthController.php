<?php

namespace App\Http\Controllers\Api;

use App\Enums\HttpStatusCode;
use App\Http\Controllers\Controller;
use App\Http\Requests\AuthValidationRequest;
use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

/**
* @OA\Info(
*   title="Laravel Ecommerce API",
*   version="1.0.0",
*   description="Authentication related operations"
* )
* @OA\SecurityScheme(
*     securityScheme="bearerAuth",
*     type="http",
*     scheme="bearer"
* )
*/
class AuthController extends Controller
{
        /**
    * @OA\Post(
    *     path="/api/signup",
    *     summary="User registration (signup)",
    *     tags={"User Registration"},
    *     description="User registration (signup) API",
    *     operationId="signup",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"name", "email", "password", "confirm_password"},
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Test1"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   ),
    *                   @OA\Property(
    *                       property="password",
    *                       type="string",
    *                       example="12345"
    *                   ),
    *                   @OA\Property(
    *                       property="confirm_password",
    *                       type="string",
    *                       example="12345"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"name", "email", "password", "confirm_password"},
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Test1"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   ),
    *                   @OA\Property(
    *                       property="password",
    *                       type="string",
    *                       example="12345"
    *                   ),
    *                   @OA\Property(
    *                       property="confirm_password",
    *                       type="string",
    *                       example="12345"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=201,
    *         description="Successful response",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="User created successfully"),
    *             @OA\Property(
    *                 property="data", type="object",
    *                 @OA\Property(property="post", type="array", @OA\Items(
    *                     @OA\Property(property="name", type="string", example="Test1"),
    *                     @OA\Property(property="email", type="string", example="test@test.com")
    *                 ))
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Validation error"),
    *             @OA\Property(property="errors", type="object", additionalProperties=true, example={
    *                   "name": {"The name field is required.", "The name field must be at least 3 characters."},
    *                   "email": {"The email field is required.", "The email must be a valid email address.", "The email has already been taken."},
    *                   "password": {"The password field is required.", "The password field must be at least 5 characters.", "The password field must match confirm password."}
    *             })
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function signup(AuthValidationRequest $request) {
        $userRoleId = Role::where('role', 'user')->pluck('id')->first();
        
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password,
            'role_id' => $userRoleId
        ]);

        $user->makeHidden(['id', 'role_id']);
        
        return helperJSONResponse(true, 'User created successfully', ['user' => $user], HttpStatusCode::CREATED->value);
    }

    /**
    * @OA\Post(
    *     path="/api/login",
    *     summary="User or Admin login",
    *     tags={"Authentication"},
    *     description="User or Admin Login API",
    *     operationId="login",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"email", "password"},
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   ),
    *                   @OA\Property(
    *                       property="password",
    *                       type="string",
    *                       example="12345"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"email", "password"},
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   ),
    *                   @OA\Property(
    *                       property="password",
    *                       type="string",
    *                       example="12345"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Logged in successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="user Logged in successfully"),
    *             @OA\Property(property="token", type="string", example="your_api_token_here"),
    *             @OA\Property(property="token_type", type="string", example="bearer"),
    *             @OA\Property(property="user_type", type="string", example="user")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Email and Password do not match")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="User account is deleted (inactive)",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="User account is deleted (inactive)")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Validation error"),
    *             @OA\Property(property="errors", type="object", additionalProperties=true, example={
    *                   "email": {"The email field is required.", "The email must be a valid email address."},
    *                   "password": {"The password field is required."}
    *             })
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function login(AuthValidationRequest $request) {
        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $authUser = Auth::user();
            $user_id = $authUser->id;

            $user = User::with('role')->whereNull('deleted_at')->find($user_id);

            if (!$user) {
                return helperJSONResponse(false, 'User account is deleted (inactive)', [], HttpStatusCode::FORBIDDEN->value);
            }

            $userRole = $user->role->role ?? null;

            return response()->json([
                'status' => true,
                'message' => $userRole . ' Logged in successfully',
                'token' => $authUser->createToken("API Token")->plainTextToken,
                'token_type' => 'bearer',
                'user_type' => $userRole
            ], HttpStatusCode::OK->value);
        } else {
            return helperJSONResponse(false, 'Email and Password do not match', [], HttpStatusCode::UNAUTHORIZED->value);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/logout",
    *     summary="User or Admin logout",
    *     tags={"Authentication"},
    *     description="User or Admin Logout API",
    *     operationId="logout",
    *     security={{"bearerAuth": {}}},
    *     @OA\Response(
    *         response=200,
    *         description="Logged out Successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Logged out Successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthenticated",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Not authenticated")
    *         )
    *     )
    * )
    */
    public function logout() {
        $authUser = Auth::user();

        if ($authUser) {
            $authUser->tokens()->delete();

            return helperJSONResponse(true, 'Logged out successfully', [], HttpStatusCode::OK->value);
        }

        return helperJSONResponse(false, 'Not authenticated', [], HttpStatusCode::UNAUTHORIZED->value);
    }
}
