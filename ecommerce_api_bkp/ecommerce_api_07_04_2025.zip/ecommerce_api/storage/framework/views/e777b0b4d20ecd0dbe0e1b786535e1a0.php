<!DOCTYPE html>
<html>
<head>
    <title>Your Order</title>
</head>
<body style="margin: 0; padding: 20px; background-color: #f4f4f4; font-family: Arial, sans-serif; color: #333;">
    <div style="max-width: 900px; margin: 0 auto; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        <div style="background: #007bff; color: #fff; text-align: center; padding: 20px; font-size: 22px; font-weight: bold;">
            Your Order Confirmation
        </div>
        <div style="padding: 20px;">
            <h2 style="margin-top: 0;">Hello, <?php echo e($shippingAddress->first_name); ?> <?php echo e($shippingAddress->last_name); ?></h2>

            <p>Your order (Order No: <strong><?php echo e($order->id); ?></strong>) has been <strong><?php echo e($statusMessage); ?></strong>.</p>

            <h3 style="border-bottom: 1px solid #eee; padding-bottom: 10px;">Order Summary:</h3>
            <?php $subTotal = 0; ?>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead>
                    <tr style="background: #f1f1f1; text-align: left;">
                        <th style="padding:10px;">Sr. No.</th>
                        <th style="padding:10px;">Product Name</th>
                        <th style="padding:10px;">Product Quantity</th>
                        <th style="padding:10px;">Product Price</th>
                        <th style="padding:10px;">Sub Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($orderItems) && $orderItems->isNotEmpty()): ?>
                        <?php $unitPrice = ''; ?>
                        <?php $ik = 1; ?>
                        <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!empty($item->discounted_price) && $item->discounted_price > 0): ?>
                                <?php $unitPrice = (float) $item->discounted_price; ?>
                            <?php else: ?>
                                <?php $unitPrice = (float) $item->price; ?>
                            <?php endif; ?>
                            <tr>
                                <td style="padding:10px;"><?php echo e($ik); ?></td>
                                <td style="padding:10px;"><?php echo e($item->name); ?></td>
                                <td style="padding:10px;"><?php echo e($item->quantity); ?></td>
                                <td style="padding:10px;">$<?php echo e(number_format($unitPrice, 2)); ?></td>
                                <td style="padding:10px;">$<?php echo e(number_format($unitPrice * $item->quantity, 2)); ?></td>
                            </tr>
                            <?php $subTotal = $subTotal + ($unitPrice * $item->quantity); ?>
                            <?php $ik++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5" style="text-align: right; padding: 10px 80px 10px 10px; border-top: 1px solid #eee; border-bottom: 1px solid #eee">
                                <strong>Order Subtotal:</strong> $<?php echo e(number_format($subTotal, 2)); ?><br>
                                <strong>Tax Estimate:</strong> $<?php echo e(number_format($order->tax_amount, 2)); ?><br>
                                <strong>Shipping Estimate:</strong> $<?php echo e(number_format($order->shipping_amount, 2)); ?><br>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5" style="text-align: right; padding: 10px 80px 10px 10px;">
                                <strong>Total Order Value:</strong> $<?php echo e(number_format($order->total_amount, 2)); ?>

                            </td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 10px;">Your order does not have any product, keep shopping !</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <h3 style="border-bottom: 1px solid #eee; padding-bottom: 10px;">Payment Details:</h3>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead>
                    <tr style="background: #f1f1f1; text-align: left;">
                        <th style="padding:10px;">Transaction ID</th>
                        <th style="padding:10px;">Date</th>
                        <th style="padding:10px;">Status</th>
                        <th style="padding:10px;">Gateway</th>
                        <th style="padding:10px;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($payment)): ?>
                        <td style="padding:10px;"><?php echo e($payment->transaction_id); ?></td>
                        <td style="padding:10px;"><?php echo e($payment->created_at->format('d M Y, H:i A')); ?></td>
                        <td style="padding:10px;"><?php echo e(ucfirst($payment->status)); ?></td>
                        <td style="padding:10px;"><?php echo e($payment->payment_gateway); ?></td>
                        <td style="padding:10px;">$<?php echo e(number_format($payment->amount, 2)); ?></td>
                    <?php else: ?>
                        <td colspan="5" style="text-align: center; padding: 10px;">No payment details available.</td>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if($shippingAddress): ?>
                <h3 style="border-bottom: 1px solid #eee; padding-bottom: 10px;">Shipping Address:</h3>
                <div style="font-size: 14px; color: #555; padding: 15px;">
                    <p style="margin: 0;">
                        <?php echo e($shippingAddress->address_line_1); ?><br>
                        <?php echo e($shippingAddress->apartment ? $shippingAddress->apartment . ', ' : ''); ?>

                        <?php echo e($shippingAddress->address_line_2 ? $shippingAddress->address_line_2 . ', ' : ''); ?><br>
                        <?php echo e($shippingAddress->city); ?>, <?php echo e($shippingAddress->state); ?><br>
                        <?php echo e($shippingAddress->country); ?> - <?php echo e($shippingAddress->postal_code); ?><br>
                        <strong>Phone:</strong> <?php echo e($shippingAddress->phone); ?>

                    </p>
                </div>
            <?php endif; ?>

            <div style="text-align: center; font-size: 14px; color: #888; padding: 15px; border-top: 1px solid #ddd;">
                <p style="margin: 0;">Thank you for shopping with us!</p>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\git_repo\trainee-milestones-laravel\ecommerce_api\resources\views/emails/orders/order.blade.php ENDPATH**/ ?>