<!DOCTYPE html>
<html>
<head>
    <title>New Contact Message</title>
</head>
    <body style="margin: 0; padding: 20px; background-color: #f4f4f4; color: #333; font-family: Arial, sans-serif;">
        <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);">
            <div style="background: #007bff; color: #ffffff; text-align: center; padding: 15px; font-size: 20px;">
                New Contact Message
            </div>

            <div style="padding:20px;">
                <p><strong>Name:</strong> {{ $contactMessage->full_name }}</p>
                <p><strong>Email:</strong> {{ $contactMessage->email }}</p>
                <p><strong>Message:</strong></p>
                <p>{{ $contactMessage->message }}</p>
            </div>
        </div>
    </body>
</html>
