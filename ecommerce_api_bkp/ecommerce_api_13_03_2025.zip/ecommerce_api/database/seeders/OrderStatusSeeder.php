<?php

namespace Database\Seeders;

use App\Models\OrderStatus;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class OrderStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $orderStatuses = [
            ['status' => 'Created'],
            ['status' => 'Placed'],
            ['status' => 'In Transit'],
            ['status' => 'Shipped'],
            ['status' => 'Canceled'],
            ['status' => 'Payment Failed'],
            ['status' => 'Refunded'],
            ['status' => 'Completed']
        ];

        foreach ($orderStatuses as $orderStatus) {
            OrderStatus::firstOrCreate($orderStatus);
        }
    }
}
