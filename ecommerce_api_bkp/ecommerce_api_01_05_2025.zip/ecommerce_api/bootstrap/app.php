<?php

use App\Http\Middleware\RoleMiddleware;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Exception\RouteNotFoundException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'role' => RoleMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $exceptions->render(function (Throwable $e, Request $request) {
            if ($request->is('api/*')) {
                return match (true) {
                    $e instanceof ThrottleRequestsException => response()->json([
                        'status' => false,
                        'message' => 'Too many requests. Please try again later.',
                        'retry_after' => $e->getHeaders()['Retry-After'] ?? 60
                    ], Response::HTTP_TOO_MANY_REQUESTS),

                    $e instanceof AuthenticationException => response()->json([
                        'status' => false,
                        'message' => $e->getMessage()
                    ], Response::HTTP_UNAUTHORIZED),

                    $e instanceof ValidationException => response()->json([
                        'status' => false,
                        'message' => 'Validation error',
                        'errors' => $e->errors(),
                    ], Response::HTTP_UNPROCESSABLE_ENTITY),

                    $e instanceof NotFoundHttpException => response()->json([
                        'success' => false,
                        'message' => 'Resource not found',
                    ], Response::HTTP_NOT_FOUND),

                    $e instanceof HttpException => response()->json([
                        'success' => false,
                        'message' => $e->getMessage(),
                    ], $e->getStatusCode()),

                    $e instanceof RouteNotFoundException => response()->json([
                        'status' => false,
                        'message' => 'Route not found',
                    ], Response::HTTP_NOT_FOUND),

                    default => response()->json([
                        'status' => false,
                        'message' => $e->getMessage()
                    ], Response::HTTP_INTERNAL_SERVER_ERROR)
                };
            }

            //return parent::render($request, $e);
        });
    })->create();
