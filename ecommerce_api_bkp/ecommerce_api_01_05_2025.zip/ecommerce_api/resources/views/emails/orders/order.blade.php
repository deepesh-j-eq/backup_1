<!DOCTYPE html>
<html>
<head>
    <title>Your Order</title>
</head>
<body style="margin: 0; padding: 20px; background-color: #f4f4f4; font-family: Arial, sans-serif; color: #333;">
    <div style="max-width: 900px; margin: 0 auto; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        <div style="background: #007bff; color: #fff; text-align: center; padding: 20px; font-size: 22px; font-weight: bold;">
            Your Order Confirmation
        </div>
        <div style="padding: 20px;">
            <h2 style="margin-top: 0;">Hello, {{ $shippingAddress->first_name }} {{ $shippingAddress->last_name }}</h2>

            <p>Your order (Order No: <strong>{{ $order->id }}</strong>) has been <strong>{{ $statusMessage }}</strong>.</p>

            <h3 style="border-bottom: 1px solid #eee; padding-bottom: 10px;">Order Summary:</h3>
            @php $subTotal = 0; @endphp
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead>
                    <tr style="background: #f1f1f1; text-align: left;">
                        <th style="padding:10px;">Sr. No.</th>
                        <th style="padding:10px;">Product Name</th>
                        <th style="padding:10px;">Product Quantity</th>
                        <th style="padding:10px;">Product Price</th>
                        <th style="padding:10px;">Sub Total</th>
                    </tr>
                </thead>
                <tbody>
                    @if(isset($orderItems) && $orderItems->isNotEmpty())
                        @php $unitPrice = ''; @endphp
                        @php $ik = 1; @endphp
                        @foreach($orderItems as $item)
                            @if (!empty($item->discounted_price) && $item->discounted_price > 0)
                                @php $unitPrice = (float) $item->discounted_price; @endphp
                            @else
                                @php $unitPrice = (float) $item->price; @endphp
                            @endif
                            <tr>
                                <td style="padding:10px;">{{ $ik }}</td>
                                <td style="padding:10px;">{{ $item->name }}</td>
                                <td style="padding:10px;">{{ $item->quantity }}</td>
                                <td style="padding:10px;">${{ number_format($unitPrice, 2) }}</td>
                                <td style="padding:10px;">${{ number_format($unitPrice * $item->quantity, 2) }}</td>
                            </tr>
                            @php $subTotal = $subTotal + ($unitPrice * $item->quantity); @endphp
                            @php $ik++; @endphp
                        @endforeach
                        <tr>
                            <td colspan="5" style="text-align: right; padding: 10px 80px 10px 10px; border-top: 1px solid #eee; border-bottom: 1px solid #eee">
                                <strong>Order Subtotal:</strong> ${{ number_format($subTotal, 2) }}<br>
                                <strong>Tax Estimate:</strong> ${{ number_format($order->tax_amount, 2) }}<br>
                                <strong>Shipping Estimate:</strong> ${{ number_format($order->shipping_amount, 2) }}<br>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5" style="text-align: right; padding: 10px 80px 10px 10px;">
                                <strong>Total Order Value:</strong> ${{ number_format($order->total_amount, 2) }}
                            </td>
                        </tr>
                    @else
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 10px;">Your order does not have any product, keep shopping !</td>
                        </tr>
                    @endif
                </tbody>
            </table>

            <h3 style="border-bottom: 1px solid #eee; padding-bottom: 10px;">Payment Details:</h3>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead>
                    <tr style="background: #f1f1f1; text-align: left;">
                        <th style="padding:10px;">Transaction ID</th>
                        <th style="padding:10px;">Date</th>
                        <th style="padding:10px;">Status</th>
                        <th style="padding:10px;">Gateway</th>
                        <th style="padding:10px;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    @if(isset($payment))
                        <td style="padding:10px;">{{ $payment->transaction_id }}</td>
                        <td style="padding:10px;">{{ $payment->created_at->format('d M Y, H:i A') }}</td>
                        <td style="padding:10px;">{{ ucfirst($payment->status) }}</td>
                        <td style="padding:10px;">{{ $payment->payment_gateway }}</td>
                        <td style="padding:10px;">${{ number_format($payment->amount, 2) }}</td>
                    @else
                        <td colspan="5" style="text-align: center; padding: 10px;">No payment details available.</td>
                    @endif
                </tbody>
            </table>

            @if ($shippingAddress)
                <h3 style="border-bottom: 1px solid #eee; padding-bottom: 10px;">Shipping Address:</h3>
                <div style="font-size: 14px; color: #555; padding: 15px;">
                    <p style="margin: 0;">
                        {{ $shippingAddress->address_line_1 }}<br>
                        {{ $shippingAddress->apartment ? $shippingAddress->apartment . ', ' : '' }}
                        {{ $shippingAddress->address_line_2 ? $shippingAddress->address_line_2 . ', ' : '' }}<br>
                        {{ $shippingAddress->city }}, {{ $shippingAddress->state }}<br>
                        {{ $shippingAddress->country }} - {{ $shippingAddress->postal_code }}<br>
                        <strong>Phone:</strong> {{ $shippingAddress->phone }}
                    </p>
                </div>
            @endif

            <div style="text-align: center; font-size: 14px; color: #888; padding: 15px; border-top: 1px solid #ddd;">
                <p style="margin: 0;">Thank you for shopping with us!</p>
            </div>
        </div>
    </div>
</body>
</html>
