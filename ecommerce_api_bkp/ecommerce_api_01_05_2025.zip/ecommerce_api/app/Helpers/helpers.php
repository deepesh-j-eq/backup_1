<?php

if (! function_exists('helperJSONResponse')) {
    function helperJSONResponse($status, $message, $data = [], $statusCode = 200)
    {
        $response = [
            'status' => $status,
            'message' => $message
        ];

        if (!empty($data)) {
            $response[$status ? 'data' : 'errors'] = is_array($data) && isset($data['errors']) ? $data['errors'] : $data;
        }

        return response()->json($response, $statusCode);
    }
}

if (!function_exists('authenticatedUserId')) {
    function authenticatedUserId()
    {
        if (!app()->has('auth')) {
            return null;
        }

        $userId = auth('sanctum')->id();

        return !empty($userId) ? $userId : null;
    }
}
