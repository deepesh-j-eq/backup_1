<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class OrdersWithFilterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'order_status' => 'nullable|string',
            'payment_status' => 'nullable|string|in:pending,requires_payment_method,failed,succeeded,refunded',
            'city' => 'nullable|string|max:191|regex:/[a-zA-Z]+/',
            'state' => 'nullable|string|max:191|regex:/[a-zA-Z]+/',
            'country' => 'nullable|string|max:191|regex:/[a-zA-Z]+/',
            'order_total_min' => 'nullable|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
            'order_total_max' => 'nullable|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
            'user_id' => 'nullable|exists:users,id'
        ];
    }
}
