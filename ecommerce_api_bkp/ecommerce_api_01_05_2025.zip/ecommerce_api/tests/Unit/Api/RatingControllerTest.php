<?php

namespace Tests\Unit\Api;

use Tests\TestCase;

class RatingControllerTest extends TestCase
{
    protected $ratingController, $user, $product, $rating;

    protected function setUp(): void
    {
        parent::setUp();

        
    }
}
