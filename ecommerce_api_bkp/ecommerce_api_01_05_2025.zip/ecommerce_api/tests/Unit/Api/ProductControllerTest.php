<?php

namespace Tests\Unit\Api;

use App\Enums\HttpStatusCode;
use App\Http\Controllers\Api\ProductController;
use App\Models\Category;
use App\Models\Color;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Role;
use App\Models\Size;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ProductControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $controller;

    protected function setUp(): void
    {
        parent::setUp();
        $this->controller = new ProductController();

        Auth::shouldUse('sanctum');
    }

    private function createMockCategory()
    {
        $category = $this->createMock(Category::class);
        $category->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['name', 'Test Category'],
        ]);
        $category->method('toArray')->willReturn([
            'id' => 1,
            'name' => 'Test Category',
        ]);

        return $category;
    }

    private function createMockSize()
    {
        $size = $this->createMock(Size::class);
        $size->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['size', 'M'],
        ]);
        $size->method('toArray')->willReturn([
            'id' => 1,
            'size' => 'M',
        ]);

        return $size;
    }

    private function createMockProductImage()
    {
        $productImage = $this->createMock(ProductImage::class);
        $productImage->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['product_id', 1],
            ['image_path', 'product_images/test.jpg'],
        ]);
        $productImage->method('toArray')->willReturn([
            'id' => 1,
            'product_id' => 1,
            'image_path' => 'product_images/test.jpg',
        ]);

        return $productImage;
    }

    private function createMockColor()
    {
        $color = $this->createMock(Color::class);
        $color->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['color', 'Red'],
        ]);
        $color->method('toArray')->willReturn([
            'id' => 1,
            'color' => 'Red',
        ]);

        return $color;
    }

    private function createMockProduct($category, $color, $size, $productImage)
    {
        $product = $this->createMock(Product::class);
        $product->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['name', 'Test Product'],
            ['description', 'Test Description'],
            ['price', 99.99],
            ['quantity', 10],
            ['category_id', 1],
        ]);
        $product->method('toArray')->willReturn([
            'id' => 1,
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'quantity' => 10,
            'category_id' => 1,
            'category' => $category->toArray(),
            'colors' => [$color->toArray()],
            'sizes' => [$size->toArray()],
            'images' => [$productImage->toArray()],
        ]);

        return $product;
    }

    public function test_index_returns_products_when_authenticated()
    {
        $role = Role::create([
            'id' => 1,
            'role' => 'user',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test1@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->assertNotNull($user->role, 'Role relationship is null');
        $this->assertEquals('user', $user->role->role, 'Role is not "user"');

        Auth::shouldUse('sanctum');
        Auth::setUser($user);

        $category = Category::create([
            'id' => 1,
            'name' => 'Test Category',
        ]);

        $product1 = Product::create([
            'id' => 1,
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $category->id,
        ]);

        $product2 = Product::create([
            'id' => 2,
            'name' => 'Test Product 2',
            'description' => 'Test Description 2',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $category->id,
        ]);

        $mockCategory = $this->createMockCategory();

        $customizedMockCategory = $mockCategory->toArray();
        if (isset($customizedMockCategory['id'])) {
            unset($customizedMockCategory['id']);
        }

        $product1Mock = $this->createMock(Product::class);
        $product1Mock->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['name', 'Test Product'],
            ['description', 'Test Description'],
            ['price', 99.99],
            ['discounted_price', 89.99],
            ['quantity', 10],
            ['category_id', 1],
        ]);
        $product1Mock->method('toArray')->willReturn([
            'id' => 1,
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => 1,
            'category' => $customizedMockCategory,
            'colors' => [],
            'sizes' => [],
            'images' => [],
            'ratings' => [],
        ]);

        $product2Mock = $this->createMock(Product::class);
        $product2Mock->method('getAttribute')->willReturnMap([
            ['id', 2],
            ['name', 'Test Product 2'],
            ['description', 'Test Description 2'],
            ['price', 99.99],
            ['discounted_price', 89.99],
            ['quantity', 10],
            ['category_id', 1],
        ]);
        $product2Mock->method('toArray')->willReturn([
            'id' => 2,
            'name' => 'Test Product 2',
            'description' => 'Test Description 2',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => 1,
            'category' => $customizedMockCategory,
            'colors' => [],
            'sizes' => [],
            'images' => [],
            'ratings' => [],
        ]);

        $productMock = $this->createMock(Product::class);
        $productMock->method('with')->with(['category', 'colors', 'sizes', 'images'])->willReturnSelf();

        $productMock->method('all')->willReturn(collect([$product1Mock, $product2Mock]));


        $this->app->instance(Product::class, $productMock);

        $response = $this->controller->index();

        $customizedProduct1Mock = $product1Mock->toArray();
        if (isset($customizedProduct1Mock['id'])) {
            unset($customizedProduct1Mock['id']);
        }
        if (isset($customizedProduct1Mock['category_id'])) {
            unset($customizedProduct1Mock['category_id']);
        }

        $customizedProduct2Mock = $product2Mock->toArray();
        if (isset($customizedProduct2Mock['id'])) {
            unset($customizedProduct2Mock['id']);
        }
        if (isset($customizedProduct2Mock['category_id'])) {
            unset($customizedProduct2Mock['category_id']);
        }

        $expectedData = [
            'status' => true,
            'message' => 'All products',
            'data' => [
                'products' => [
                    $customizedProduct1Mock,
                    $customizedProduct2Mock,
                ],
            ],
        ];

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals($expectedData, $response->getData(true));
    }

    public function test_index_returns_unauthenticated_error()
    {
        $response = $this->getJson('/api/products');

        $response->assertStatus(HttpStatusCode::UNAUTHORIZED->value)
            ->assertJson([
                'status' => false,
                'message' => 'Unauthenticated.',
            ]);
    }

    public function test_store_creates_product_successfully()
    {
        Storage::fake('public');

        $role = Role::create([
            'id' => 1,
            'role' => 'admin',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->actingAs($user, 'sanctum');

        $category = $this->createMockCategory();
        $size = $this->createMockSize();
        $color = $this->createMockColor();
        $productImage = $this->createMockProductImage();
        $productMock = $this->createMockProduct($category, $color, $size, $productImage);

        $createdCategory = Category::create([
            'name' => 'Test Category',
        ]);

        $createdSize = Size::create([
            'size' => 'M',
        ]);

        $createdColor = Color::create([
            'color' => 'Red',
        ]);

        $image = UploadedFile::fake()->image('test.jpg');

        $requestData = [
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $createdCategory->id,
            'size_ids' => (string) $createdSize->id,
            'color_ids' => (string) $createdColor->id,
            'images' => [$image],
        ];

        $response = $this->post('/api/admin/products', $requestData);

        $response->assertStatus(HttpStatusCode::CREATED->value);
        $responseData = $response->json();

        $this->assertTrue($responseData['status']);
        $this->assertEquals('Product created successfully', $responseData['message']);

        $this->assertDatabaseHas('products', [
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $createdCategory->id,
        ]);

        $product = Product::first();
        $this->assertDatabaseHas('product_attributes', [
            'product_id' => $product->id,
            'size_id' => $createdSize->id,
            'color_id' => null,
        ]);

        $this->assertDatabaseHas('product_attributes', [
            'product_id' => $product->id,
            'size_id' => null,
            'color_id' => $createdColor->id,
        ]);

        $this->assertDatabaseHas('product_images', [
            'product_id' => $product->id,
            'image_path' => 'product_images/' . $image->hashName(),
        ]);

        $this->assertTrue(Storage::disk('public')->exists('product_images/' . $image->hashName()));

        $expectedProductData = $productMock->toArray();

        $this->assertEquals($expectedProductData['name'], $responseData['data']['product']['name']);
        $this->assertEquals($expectedProductData['description'], $responseData['data']['product']['description']);
    }

    /* public function test_show_returns_single_product()
    {
        $role = Role::create([
            'id' => 1,
            'role' => 'admin',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->assertNotNull($user->role, 'Role relationship is null');
        $this->assertEquals('admin', $user->role->role, 'Role is not "admin"');

        Auth::shouldUse('sanctum');
        Auth::setUser($user);

        $category = Category::create([
            'id' => 1,
            'name' => 'Test Category',
        ]);

        $product = Product::create([
            'id' => 1,
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $category->id
        ]);

        $this->assertDatabaseHas('products', [
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => 1,
        ]);

        $mockCategory = $this->createMockCategory();

        $customizedMockCategory = $mockCategory->toArray();
        if (isset($customizedMockCategory['id'])) {
            unset($customizedMockCategory['id']);
        }

        $productMock = $this->createMock(Product::class);
        $productMock->method('getAttribute')->willReturnMap([
            ['id', 1],
            ['name', 'Test Product'],
            ['description', 'Test Description'],
            ['price', 99.99],
            ['quantity', 10],
            ['category_id', 1],
        ]);
        $productMock->method('toArray')->willReturn([
            'id' => 1,
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => 1,
            'created_at' => $product->created_at->toJSON(),
            'updated_at' => $product->updated_at->toJSON(),
            'category' => $customizedMockCategory,
            'colors' => [],
            'sizes' => [],
            'images' => [],
            'ratings' => [],
        ]);

        $productQueryMock = $this->createMock(Product::class);
        $productQueryMock->method('with')->with(['category', 'colors', 'sizes', 'images'])->willReturnSelf();
        $productMock->method('all')->willReturn(collect([$productMock]));

        $this->app->instance(Product::class, $productQueryMock);

        $response = $this->controller->show(1);

        $customizedProductMock = $productMock->toArray();

        $expectedData = [
            'status' => true,
            'message' => 'Your single product',
            'data' => [
                'product' => $customizedProductMock,
            ],
        ];

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals($expectedData, $response->getData(true));
    } */

    public function test_show_returns_single_product()
    {
        $this->withoutExceptionHandling();

        $role = Role::create([
            'role' => 'admin',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->assertNotNull($user->role, 'Role relationship is null');
        $this->assertEquals('admin', $user->role->role, 'Role is not "admin"');

        $this->actingAs($user, 'sanctum');

        $category = Category::create([
            'name' => 'Test Category',
        ]);

        $product = Product::create([
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $category->id,
        ]);

        $this->assertDatabaseHas('products', [
            'name' => 'Test Product',
            'description' => 'Test Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $category->id,
        ]);

        $response = $this->get("/api/products/{$product->id}");

        $response->assertStatus(HttpStatusCode::OK->value);
        $responseData = $response->json();

        $this->assertTrue($responseData['status']);
        $this->assertEquals('Your single product', $responseData['message']);

        $this->assertEquals('Test Product', $responseData['data']['product']['name']);
        $this->assertEquals('Test Description', $responseData['data']['product']['description']);
    }

    public function test_show_returns_not_found_for_nonexistent_product()
    {
        $role = Role::create([
            'id' => 1,
            'role' => 'user',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test1@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->assertNotNull($user->role, 'Role relationship is null');
        $this->assertEquals('user', $user->role->role, 'Role is not "user"');

        Auth::shouldUse('sanctum');
        Auth::setUser($user);

        $response = $this->controller->show(1);

        $expectedData = [
            'status' => false,
            'message' => 'Requested product is not available',
        ];

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::NOT_FOUND->value, $response->getStatusCode());
        $this->assertEquals($expectedData, $response->getData(true));
    }

    public function test_show_returns_unauthorized_for_unauthenticated_user()
    {
        $role = Role::create([
            'id' => 1,
            'role' => 'user',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test1@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->assertNotNull($user->role, 'Role relationship is null');
        $this->assertEquals('user', $user->role->role, 'Role is not "user"');

        $response = $this->controller->show('1');
        $responseArray = $response->getData(true);

        if (isset($responseArray['data']['product']['original'])) {
            $customizedResponse = $responseArray['data']['product']['original'];

            $expectedData = [
                'status' => false,
                'message' => 'Unauthenticated.',
            ];

            $this->assertInstanceOf(JsonResponse::class, $response);
            $this->assertEquals(HttpStatusCode::UNAUTHORIZED->value, 401);
            $this->assertEquals($expectedData, $customizedResponse);
        } else {
            $response = $this->getJson('/api/products/1');

            $response->assertStatus(HttpStatusCode::UNAUTHORIZED->value)
                ->assertJson([
                'status' => false,
                'message' => 'Unauthenticated.',
            ]);
        }
    }

    public function test_update_modifies_product_successfully()
    {
        Storage::fake('public');

        $role = Role::create(['role' => 'admin']);
        $user = User::create([
            'name' => 'Test User',
            'email' => 'test@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->assertNotNull($user->role, 'Role relationship is null');
        $this->assertEquals('admin', $user->role->role, 'Role is not "admin"');

        $this->actingAs($user, 'sanctum');

        $category = Category::firstOrCreate(['name' => 'Test Category']);
        $size = Size::create(['size' => 'M']);
        $color = Color::create(['color' => 'Red']);

        $product = Product::create([
            'name' => 'Original Product',
            'description' => 'Original Description',
            'price' => 50.00,
            'quantity' => 5,
            'category_id' => $category->id,
        ]);

        $this->assertDatabaseHas('products', [
            'id' => $product->id,
            'name' => 'Original Product',
        ]);

        $image = UploadedFile::fake()->image('new_test.jpg');

        $requestData = [
            'name' => 'Updated Product',
            'description' => 'Updated Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $category->id,
            'size_ids' => (string) $size->id,
            'color_ids' => (string) $color->id,
            'images' => [$image],
        ];

        $response = $this->put("/api/admin/products/{$product->id}", $requestData);

        $response->assertStatus(HttpStatusCode::OK->value);
        $responseData = $response->json();

        $this->assertTrue($responseData['status']);
        $this->assertEquals('Product updated successfully', $responseData['message']);

        $this->assertDatabaseHas('products', [
            'id' => $product->id,
            'name' => 'Updated Product',
            'description' => 'Updated Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $category->id,
        ]);

        $this->assertDatabaseHas('product_attributes', [
            'product_id' => $product->id,
            'size_id' => $size->id,
            'color_id' => null,
        ]);

        $this->assertDatabaseHas('product_attributes', [
            'product_id' => $product->id,
            'size_id' => null,
            'color_id' => $color->id,
        ]);

        $this->assertDatabaseHas('product_images', [
            'product_id' => $product->id,
            'image_path' => 'product_images/' . $image->hashName(),
        ]);

        $this->assertTrue(Storage::disk('public')->exists('product_images/' . $image->hashName()));

        $this->assertEquals('Updated Product', $responseData['data']['product']['name']);
        $this->assertEquals('Updated Description', $responseData['data']['product']['description']);
    }

    public function test_update_fails_for_nonexistent_product()
    {
        Storage::fake('public');

        $role = Role::create([
            'id' => 1,
            'role' => 'admin',
        ]);

        $user = User::create([
            'name' => 'Test User',
            'email' => 'test@test.com',
            'password' => '12345',
            'role_id' => $role->id,
        ]);

        $this->actingAs($user, 'sanctum');

        $createdCategory = Category::create([
            'name' => 'Test Category',
        ]);

        $createdSize = Size::create([
            'size' => 'M',
        ]);

        $createdColor = Color::create([
            'color' => 'Red',
        ]);

        $image = UploadedFile::fake()->image('test.jpg');

        $requestData = [
            'name' => 'Updated Product',
            'description' => 'Updated Description',
            'price' => 99.99,
            'discounted_price' => 89.99,
            'quantity' => 10,
            'category_id' => $createdCategory->id,
            'size_ids' => (string) $createdSize->id,
            'color_ids' => (string) $createdColor->id,
            'images' => [$image],
        ];

        $response = $this->put('/api/admin/products/999', $requestData);

        $response->assertStatus(HttpStatusCode::NOT_FOUND->value);
        $responseData = $response->json();

        $this->assertFalse($responseData['status']);
        $this->assertEquals('Requested product not available for update', $responseData['message']);
    }
}
