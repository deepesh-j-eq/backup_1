<?php

namespace Tests\Unit\Api;

use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\User;
use App\Models\Role;
use Tests\TestCase;

class UserControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $admin, $user, $roleUser, $roleAdmin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->roleUser = Role::create(['role' => 'user']);
        $this->roleAdmin = Role::create(['role' => 'admin']);

        $this->admin = User::factory()->create(['role_id' => $this->roleAdmin->id]);
        $this->user = User::factory()->create(['role_id' => $this->roleUser->id]);
    }

    public function test_index_returns_users_for_admin()
    {
        $user2 = User::factory()->create(['role_id' => $this->roleUser->id]);

        $response = $this->actingAs($this->admin, 'sanctum')
            ->getJson('/api/admin/users');

        $response->assertStatus(200);

        $partialDataArray = [
            [
                'id' => $this->user->id,
                'name' => $this->user->name,
                'email' => $this->user->email,
                'role' => ['role' => 'user'],
                'created_at' => $this->user->created_at->toJSON(),
                'deleted_at' => is_null($this->user->deleted_at) ? null : $this->user->email_verified_at->toJSON(),
                'email_verified_at' => is_null($this->user->email_verified_at) ? null : $this->user->email_verified_at->toJSON(),
                'role_id' => $this->roleUser->id,
                'updated_at' => $this->user->updated_at->toJSON()
            ],
            [
                'id' => $user2->id,
                'name' => $user2->name,
                'email' => $user2->email,
                'role' => ['role' => 'user'],
                'created_at' => $user2->created_at->toJSON(),
                'deleted_at' => is_null($user2->deleted_at) ? null : $user2->email_verified_at->toJSON(),
                'email_verified_at' => is_null($user2->email_verified_at) ? null : $user2->email_verified_at->toJSON(),
                'role_id' => $this->roleUser->id,
                'updated_at' => $user2->updated_at->toJSON()
            ]
        ];

        $dataArray = [
            'data' => [
                'users' => $partialDataArray,
            ],
        ];

        $response->assertJsonFragment(
            $dataArray
        );

        $response->assertJsonFragment([
            'status' => true,
            'message' => 'All users',
        ]);
    }

    public function test_index_returns_not_found_when_no_users()
    {
        User::where('role_id', $this->roleUser->id)->delete();

        $response = $this->actingAs($this->admin, 'sanctum')
            ->getJson('/api/admin/users');

        $response->assertStatus(404)
            ->assertJsonFragment([
                'status' => false,
                'message' => 'No user registered'
            ]);
    }

    public function test_all_users_including_trashed()
    {
        $deletedUser = User::factory()->create(['role_id' => $this->roleUser->id]);
        $deletedUser->delete();

        $response = $this->actingAs($this->admin, 'sanctum')
            ->getJson('/api/admin/users-with-trashed');

        $response->assertStatus(200);

        $partialDataArray = [
            [
                'id' => $deletedUser->id,
                'name' => $deletedUser->name,
                'email' => $deletedUser->email,
                'role' => ['role' => 'user'],
                'created_at' => $deletedUser->created_at->toJSON(),
                'deleted_at' => is_null($deletedUser->deleted_at) ? null : $deletedUser->deleted_at->toJSON(),
                'email_verified_at' => is_null($deletedUser->email_verified_at) ? null : $deletedUser->email_verified_at->toJSON(),
                'role_id' => $this->roleUser->id,
                'updated_at' => $deletedUser->updated_at->toJSON()
            ],
            [
                'id' => $this->user->id,
                'name' => $this->user->name,
                'email' => $this->user->email,
                'role' => ['role' => 'user'],
                'created_at' => $this->user->created_at->toJSON(),
                'deleted_at' => is_null($this->user->deleted_at) ? null : $this->user->deleted_at->toJSON(),
                'email_verified_at' => is_null($this->user->email_verified_at) ? null : $this->user->email_verified_at->toJSON(),
                'role_id' => $this->roleUser->id,
                'updated_at' => $this->user->updated_at->toJSON()
            ]
        ];

        $dataArray = [
            'data' => [
                'users' => $partialDataArray,
            ],
        ];

        $response->assertJsonFragment(
            $dataArray
        );

        $response->assertJsonFragment([
            'status' => true,
            'message' => 'All users',
        ]);
    }

    public function test_show_user()
    {
        $response = $this->actingAs($this->admin, 'sanctum')
            ->postJson('/api/admin/users/' . $this->user->id);

        $response->assertStatus(200);

        $response->assertJsonFragment([
            'data' => [
                'user' => [
                    'id' => $this->user->id,
                    'name' => $this->user->name,
                    'email' => $this->user->email,
                    'role' => ['role' => 'user'],
                    'created_at' => $this->user->created_at->toJSON(),
                    'deleted_at' => is_null($this->user->deleted_at) ? null : $this->user->email_verified_at->toJSON(),
                    'email_verified_at' => is_null($this->user->email_verified_at) ? null : $this->user->email_verified_at->toJSON(),
                    'role_id' => $this->roleUser->id,
                    'updated_at' => $this->user->updated_at->toJSON()
                ]
            ]
        ]);

        $response->assertJsonFragment([
            'status' => true,
            'message' => 'Your single user data',
        ]);
    }

    public function test_show_user_with_trashed()
    {
        $deletedUser = User::factory()->create(['role_id' => $this->roleUser->id]);
        $deletedUser->delete();

        $response = $this->actingAs($this->admin, 'sanctum')
            ->postJson('/api/admin/users/' . $deletedUser->id, ['include_deleted' => 'yes']);

        $response->assertStatus(200);

        $response->assertJsonFragment([
            'data' => [
                'user' => [
                    'id' => $deletedUser->id,
                    'name' => $deletedUser->name,
                    'email' => $deletedUser->email,
                    'role' => ['role' => 'user'],
                    'created_at' => $deletedUser->created_at->toJSON(),
                    'deleted_at' => is_null($deletedUser->deleted_at) ? null : $deletedUser->deleted_at->toJSON(),
                    'email_verified_at' => is_null($deletedUser->email_verified_at) ? null : $deletedUser->email_verified_at->toJSON(),
                    'role_id' => $this->roleUser->id,
                    'updated_at' => $deletedUser->updated_at->toJSON()
                ]
            ]
        ]);

        $response->assertJsonFragment([
            'status' => true,
            'message' => 'Your single user data',
        ]);
    }

    public function test_show_user_not_found()
    {
        $response = $this->actingAs($this->admin, 'sanctum')
            ->postJson('/api/admin/users/999');

        $response->assertStatus(404)
            ->assertJsonFragment([
                'status' => false,
                'message' => 'Requested user is not available or set include_deleted to yes'
            ]);
    }

    public function test_restore_soft_deleted_user()
    {
        $deletedUser = User::factory()->create(['role_id' => $this->roleUser->id]);
        $deletedUser->delete();

        $response = $this->actingAs($this->admin, 'sanctum')
            ->postJson('/api/admin/restore-user', ['user_id' => $deletedUser->id]);

        $response->assertStatus(200)
            ->assertJsonFragment([
                'status' => true,
                'message' => 'User account restored successfully',
                'data' => [
                    'user' => [
                        'id' => $deletedUser->id,
                        'name' => $deletedUser->name,
                        'email' => $deletedUser->email,
                        'role' => ['role' => 'user'],
                        'created_at' => $deletedUser->created_at->toJSON(),
                        'deleted_at' => null,
                        'email_verified_at' => is_null($deletedUser->email_verified_at) ? null : $deletedUser->email_verified_at->toJSON(),
                        'role_id' => $this->roleUser->id,
                        'updated_at' => $this->user->updated_at->toJSON()
                    ]
                ]
            ]);
    }

    public function test_restore_soft_deleted_user_validation_error()
    {
        $response = $this->actingAs($this->admin, 'sanctum')
            ->postJson('/api/admin/restore-user', ['user_id' => null]);

        $response->assertStatus(422)
            ->assertJsonFragment([
                'status' => false,
                'message' => 'Validation error'
            ]);
    }

    public function test_show_user_profile()
    {
        $response = $this->actingAs($this->user, 'sanctum')
            ->getJson('/api/profile');

        $response->assertStatus(200)
            ->assertJsonFragment([
                'status' => true,
                'message' => 'Your profile',
                'data' => [
                    'profile' => [
                        'name' => $this->user->name,
                        'email' => $this->user->email
                    ]
                ]
            ]);
    }

    public function test_show_user_profile_unauthenticated()
    {
        $response = $this->getJson('/api/profile');

        $response->assertStatus(401)
            ->assertJsonFragment([
                'status' => false,
                'message' => 'Unauthenticated.'
            ]);
    }

    public function test_update_user_profile()
    {
        $newData = [
            'name' => 'Updated Name',
            'email' => 'test1@test.com'
        ];

        $response = $this->actingAs($this->user, 'sanctum')
            ->putJson('/api/update-user-profile', $newData);

        $response->assertStatus(200)
            ->assertJsonFragment([
                'status' => true,
                'message' => 'Your profile is updated successfully',
                'data' => [
                    'profile' => [
                        'name' => 'Updated Name',
                        'email' => 'test1@test.com'
                    ]
                ]
            ]);
    }

    public function test_update_user_profile_unauthenticated()
    {
        $response = $this->putJson('/api/update-user-profile', [
            'name' => 'Test',
            'email' => 'test@example.com'
        ]);

        $response->assertStatus(401)
            ->assertJsonFragment([
                'status' => false,
                'message' => 'Unauthenticated.'
            ]);
    }

    public function test_destroy_user_account()
    {
        $response = $this->actingAs($this->user, 'sanctum')
            ->deleteJson('/api/delete-user-account');

        $response->assertStatus(200)
            ->assertJsonFragment([
                'status' => true,
                'message' => 'User account deleted successfully'
            ]);
    }

    public function test_destroy_user_account_unauthenticated()
    {
        $response = $this->deleteJson('/api/delete-user-account');

        $response->assertStatus(401)
            ->assertJsonFragment([
                'status' => false,
                'message' => 'Unauthenticated.'
            ]);
    }
}
