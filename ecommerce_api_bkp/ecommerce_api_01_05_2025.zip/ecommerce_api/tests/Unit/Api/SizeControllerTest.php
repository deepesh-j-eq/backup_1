<?php

namespace Tests\Unit\Api;

use App\Enums\HttpStatusCode;
use App\Http\Controllers\Api\SizeController;
use App\Http\Requests\SizeAttributeRequest;
use App\Models\Size;
use App\Services\BaseService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Tests\TestCase;

class SizeControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $baseService, $sizeController;

    protected function setUp(): void
    {
        parent::setUp();

        $this->baseService = $this->createMock(BaseService::class);

        $this->sizeController = new SizeController();
        $reflection = new \ReflectionClass($this->sizeController);
        $property = $reflection->getProperty('baseService');
        $property->setAccessible(true);
        $property->setValue($this->sizeController, $this->baseService);
    }

    public function test_index_returns_sizes_when_found()
    {
        $sizes = new Collection([
            new Size(['id' => 1, 'size' => 'S']),
            new Size(['id' => 2, 'size' => 'M'])
        ]);

        $this->baseService
            ->expects($this->once())
            ->method('getAllRecords')
            ->willReturn($sizes);

        $response = $this->sizeController->index();

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'All size attributes',
            'data' => ['size' => $sizes->toArray()]
        ], $response->getData(true));
    }

    public function test_index_returns_not_found_when_no_sizes()
    {
        $this->baseService
            ->expects($this->once())
            ->method('getAllRecords')
            ->willReturn(new Collection());

        $response = $this->sizeController->index();

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::NOT_FOUND->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'No size attributes found',
        ], $response->getData(true));
    }

    public function test_store_creates_size_successfully()
    {
        $request = new class extends SizeAttributeRequest {
            public $size = 'L';

            public function validated($key = null, $default = null): array
            {
                return ['size' => $this->size];
            }

            public function authorize(): bool
            {
                return true;
            }

            public function rules(): array
            {
                return [];
            }
        };

        $sizeAttribute = new Size(['id' => 1, 'size' => 'L']);

        $this->baseService
            ->expects($this->once())
            ->method('store')
            ->with(['size' => 'L'])
            ->willReturn($sizeAttribute);

        $response = $this->sizeController->store($request);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::CREATED->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Size attribute created successfully',
            'data' => ['size' => $sizeAttribute->toArray()]
        ], $response->getData(true));
    }

    public function test_store_fails_when_creation_fails()
    {
        $request = new class extends SizeAttributeRequest {
            public $size = 'L';

            public function validated($key = null, $default = null): array
            {
                return ['size' => $this->size];
            }

            public function authorize(): bool
            {
                return true;
            }

            public function rules(): array
            {
                return [];
            }
        };

        $this->baseService
            ->expects($this->once())
            ->method('store')
            ->with(['size' => 'L'])
            ->willReturn(false);

        $response = $this->sizeController->store($request);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::INTERNAL_SERVER_ERROR->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Size creation failed'
        ], $response->getData(true));
    }

    public function test_show_retrieves_size_by_id()
    {
        $size = new Size(['id' => 1, 'size' => 'S']);
        $this->baseService
            ->expects($this->once())
            ->method('getRecordById')
            ->with('1', ['id', 'size'])
            ->willReturn(new JsonResponse([
                'status' => true,
                'message' => 'Record retrieved',
                'data' => ['single_record' => $size],
            ], HttpStatusCode::OK->value));

        $response = $this->sizeController->show('1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Record retrieved',
            'data' => ['single_record' => $size->toArray()]
        ], $response->getData(true));
    }

    public function test_update_modifies_size_successfully()
    {
        $size = Size::create(['size' => 'M']);

        $baseRequest = Request::create('/api/admin/sizes/1', 'PUT', ['size' => 'L']);
        $request = SizeAttributeRequest::createFrom($baseRequest);

        $request->setContainer($this->app);
        $request->validateResolved();

        $this->baseService
            ->expects($this->once())
            ->method('update')
            ->with((string) $size->id, ['size' => 'L'])
            ->willReturn(true);

        $response = $this->sizeController->update($request, (string) $size->id);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());

        $updatedSize = Size::find($size->id)->toArray();

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Size attribute updated successfully',
            'data' => ['size' => $updatedSize]
        ], $response->getData(true));
    }

    public function test_update_fails_when_size_not_found()
    {
        $baseRequest = Request::create('/api/admin/sizes/1', 'PUT', ['size' => 'S']);
        $request = SizeAttributeRequest::createFrom($baseRequest);

        $request->setContainer($this->app);
        $request->validateResolved();

        $this->baseService->expects($this->never())->method('update');

        $response = $this->sizeController->update($request, '1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::NOT_FOUND->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Requested size attribute is not available for update'
        ], $response->getData(true));
    }

    public function test_update_fails_when_update_operation_fails()
    {
        $size = Size::create(['size' => 'M']);

        $baseRequest = Request::create('/api/admin/sizes/1', 'PUT', ['size' => 'S']);
        $request = SizeAttributeRequest::createFrom($baseRequest);

        $request->setContainer($this->app);
        $request->validateResolved();

        $this->baseService
            ->expects($this->once())
            ->method('update')
            ->with((string) $size->id, ['size' => 'S'])
            ->willReturn(false);

        $response = $this->sizeController->update($request, (string) $size->id);

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::INTERNAL_SERVER_ERROR->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => false,
            'message' => 'Size update failed'
        ], $response->getData(true));
    }

    public function test_destroy_deletes_size_successfully()
    {
        $this->baseService
            ->expects($this->once())
            ->method('deleteRecordById')
            ->with('1')
            ->willReturn(new JsonResponse([
                'status' => true,
                'message' => 'Record deleted successfully'
            ], HttpStatusCode::OK->value));

        $response = $this->sizeController->destroy('1');

        $this->assertInstanceOf(JsonResponse::class, $response);
        $this->assertEquals(HttpStatusCode::OK->value, $response->getStatusCode());
        $this->assertEquals([
            'status' => true,
            'message' => 'Record deleted successfully'
        ], $response->getData(true));
    }
}
