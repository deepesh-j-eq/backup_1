<?php

use App\Http\Controllers\StripePaymentController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('testPayment', function () {
    return view('prdouct_detail');
})->name('testPayment');

/* Route::post('paypal', [PayPalController::class, 'payment'])->name('paypal');
Route::get('paypal/cancel', [PayPalController::class, 'paymentCancel'])->name('cancel.payment');
Route::get('paypal/success', [PayPalController::class, 'paymentSuccess'])->name('success.payment'); */

Route::post('stripe', [StripePaymentController::class, 'payment'])->name('stripe');
Route::get('cancel', [StripePaymentController::class, 'paymentCancel'])->name('cancel.payment');
Route::get('success', [StripePaymentController::class, 'paymentSuccess'])->name('success.payment');