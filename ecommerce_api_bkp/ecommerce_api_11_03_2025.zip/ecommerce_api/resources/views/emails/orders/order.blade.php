<!DOCTYPE html>
<html>
<head>
    <title>Your Order</title>
</head>
<body>
    <h2>Hello, {{ $shippingAddress->first_name }} {{ $shippingAddress->last_name }}</h2>
    
    <p>Your order (Order No: <strong>{{ $order->id }}</strong>) has been <strong>{{ $statusMessage }}</strong>.</p>

    <h3>Order Summary:</h3>
    @php $subTotal = 0; @endphp
    @if(isset($orderItems) && $orderItems->isNotEmpty())
        <ul>
            @foreach($orderItems as $item)
                <li>
                    <strong>Product:</strong> {{ $item->product->name }}<br>
                    <strong>Quantity:</strong> {{ $item->quantity }}<br>
                    <strong>Price:</strong> ${{ number_format($item->price, 2) }}<br>
                    <strong>Item Subtotal:</strong> ${{ number_format($item->price * $item->quantity, 2) }}
                </li>
                @php $subTotal = $subTotal + ($item->price * $item->quantity); @endphp
            @endforeach
        </ul>
    @else
        <p>No items found in the order.</p>
    @endif

    <p>
        <strong>Order Subtotal:</strong> ${{ number_format($subTotal, 2) }}<br>
        <strong>Tax Estimate:</strong> ${{ number_format($order->tax_amount, 2) }}<br>
        <strong>Shipping Estimate:</strong> ${{ number_format($order->shipping_amount, 2) }}<br>
    </p>
    <p><strong>Total Order Value:</strong> ${{ number_format($order->total_amount, 2) }}</p>

    <h3>Payment Details:</h3>
    @if(isset($payment))
        <p>
            <strong>Status:</strong> {{ ucfirst($payment->status) }}<br>
            <strong>Gateway:</strong> {{ $payment->payment_gateway }}<br>
            <strong>Transaction ID:</strong> {{ $payment->transaction_id }}<br>
            <strong>Date:</strong> {{ $payment->created_at->format('d M Y, H:i A') }}<br>
            <strong>Amount:</strong> ${{ number_format($payment->amount, 2) }}
        </p>
    @else
        <p>No payment details available.</p>
    @endif

    <h3>Shipping Address:</h3>
    <p>
        {{ $shippingAddress->address_line_1 }}<br>
        {{ $shippingAddress->apartment ? $shippingAddress->apartment . ', ' : '' }}
        {{ $shippingAddress->address_line_2 ? $shippingAddress->address_line_2 . ', ' : '' }}
        {{ $shippingAddress->city }}, {{ $shippingAddress->state }}<br>
        {{ $shippingAddress->country }} - {{ $shippingAddress->postal_code }}<br>
        <strong>Phone:</strong> {{ $shippingAddress->phone }}
    </p>

    <p>Thank you for shopping with us!</p>
</body>
</html>
