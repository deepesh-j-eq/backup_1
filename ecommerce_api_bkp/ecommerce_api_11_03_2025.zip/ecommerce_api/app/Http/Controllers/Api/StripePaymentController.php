<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\OrderMail;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use League\CommonMark\Node\Query\OrExpr;
use Stripe\Exception\ApiErrorException;
use Stripe\StripeClient;

class StripePaymentController extends Controller
{
    protected $stripe;

    public function __construct(StripeClient $stripe)
    {
        $this->stripe = new StripeClient(config('stripe.stripe_sk'));
    }

    public function processPayment($newRequest)
    {
        try {
            if (!$newRequest || !is_array($newRequest) || empty($newRequest)) {
                return [
                    'status' => 'error',
                    'message' => 'Invalid request data.'
                ];
            }
    
            if (!isset($newRequest['order_id']) || $newRequest['order_id'] == '') {
                return [
                    'status' => 'error',
                    'message' => 'No order created, something went wrong!'
                ];
            }

            $orderData = Order::with([
                            'orderItems:id,order_id,product_id,quantity,price',
                            'orderItems.product:id,name'
                        ])->find($newRequest['order_id']);

            if (!$orderData) {
                return [
                    'status' => 'error',
                    'message' => 'No order available for process payment, something went wrong!'
                ];
            }

            $orderItems = $orderData->orderItems;
            $lineItems = [];
            $totalAmount = 0;

            foreach ($orderItems as $item) {
                $lineItems[] = [
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => ['name' => $item->product->name],
                        'unit_amount' => $item->price * 100
                    ],
                    'quantity' => $item->quantity,
                ];
                $totalAmount += $item->price * $item->quantity;
            }

            if (isset($newRequest['total_amount_with_tax']) || $newRequest['total_amount_with_tax'] != '') {
                $totalAmount = $newRequest['total_amount_with_tax'];
            }

            $customer = $this->stripe->customers->create([
                'name' => $newRequest['first_name'],
                'email' => $newRequest['email']
            ]);

            $paymentIntent = $this->stripe->paymentIntents->create([
                'amount' => $totalAmount * 100,
                'currency' => 'usd',
                'payment_method' => $newRequest['payment_method'],
                'confirm' => true,
                'customer' => $customer->id,
                'automatic_payment_methods' => [
                    'enabled' => true,
                    'allow_redirects' => 'never'
                ]
            ]);

            $customerDetails = $this->stripe->customers->retrieve($paymentIntent->customer);

            $payerName = !empty($customerDetails->name) ? $customerDetails->name : $newRequest['first_name'];
            $payerEmail = !empty($customerDetails->email) ? $customerDetails->email : $newRequest['email'];

            $payment = Payment::create([
                'transaction_id' => $paymentIntent->id,
                'currency' => $paymentIntent->currency,
                'amount' => $paymentIntent->amount / 100,
                'payer_name' => $payerName,
                'payer_email' => $payerEmail,
                'payment_gateway' => 'Stripe',
                'payment_method' => $paymentIntent->payment_method ?? $newRequest['payment_method']
            ]);

            $orderData->update(['payment_id' => $payment->id]);

            return [
                'status' => 'created',
                'paymentId' => $payment->id
            ];
        } catch (ApiErrorException $e) {
            $errorResponse = $e->getJsonBody();
            $errorData = $errorResponse['error'] ?? [];

            $paymentIntentIdOnFail = $errorData['payment_intent']['id'] ?? null;
            $paymentStatusOnFail = $errorData['payment_intent']['decline_code'] ?? 'failed';
            $currencyOnFail = $errorData['payment_intent']['currency'] ?? 'usd';
            $amountOnFail = isset($errorData['payment_intent']['amount']) ? ($errorData['payment_intent']['amount'] / 100) : 0;

            $payment = Payment::create([
                'transaction_id' => $paymentIntentIdOnFail,
                'currency' => $currencyOnFail,
                'amount' => $amountOnFail,
                'payer_name' => $newRequest['first_name'],
                'payer_email' => $newRequest['email'],
                'payment_gateway' => 'Stripe',
                'payment_method' => $newRequest['payment_method'],
                'status' => $paymentStatusOnFail
            ]);

            $orderData->update(['payment_id' => $payment->id]);

            return [
                'status' => 'error',
                'paymentId' => $payment->id,
                'message' => 'Payment failed: ' . $e->getMessage()
            ];
        }
    }

    public function handleWebhook(Request $request)
    {
        try {
            $payload = $request->getContent();
            $event = json_decode($payload, true);
            $sigHeader = $request->header('Stripe-Signature');

            //Log::info('Stripe Webhook Payload:', ['payload' => $payload]);
            //Log::info('Stripe Webhook Event:', ['event' => $event]);
            //Log::info('Stripe Webhook Signature:', ['signature' => $sigHeader]);

            if (!isset($event['type']) || !isset($event['data']['object'])) {
                return [
                    'status' => 'error',
                    'message' => 'Invalid webhook event'
                ];
            }

            $paymentIntent = $event['data']['object'];
            $customerDetails = null;

            if (!empty($paymentIntent['customer'])) {
                try {
                    $customerDetails = $this->stripe->customers->retrieve($paymentIntent['customer']);
                } catch (\Exception $e) {
                    Log::error('Failed to retrieve customer details: ' . $e->getMessage());
                }
            }

            $paymentDetails = Payment::where('transaction_id', $paymentIntent['id'])->first();

            $order = Order::with([
                        'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                        'orderItems:id,order_id,product_id,quantity,price',
                        'orderItems.product:id,name,quantity'
                    ])
                    ->where('payment_id', $paymentDetails['id'])->first();

            Log::error('order: ' . $order);

            if (!$order) {
                return [
                    'status' => 'error',
                    'message' => 'Order not found'
                ];
            }

            switch ($event['type'] ?? null) {
                /* case 'payment_intent.created':
                    Log::info('payment_intent.created');

                    if (!$paymentDetails) {
                        return [
                            'status' => 'success',
                            'message' => 'Payment intent created but payment details not found for update'
                        ];
                    }

                    $paymentDetails->update(['status' => 'Payment intent created']);
                    //break;

                case 'payment_intent.canceled':
                    Log::info('payment_intent.canceled');

                    if (!$paymentDetails) {
                        return [
                            'status' => 'error',
                            'message' => 'Payment intent cancled but payment details not found for update'
                        ];
                    }

                    $paymentDetails->update(['status' => 'Payment intent cancled']);
                    //break; */

                case 'payment_intent.succeeded':
                    if (!$paymentDetails) {
                        return [
                            'status' => 'success',
                            'message' => 'Payment successful but payment details not found for update'
                        ];
                    }

                    $paymentDetails->update(['status' => $paymentIntent['status']]);

                    $placedStatusId = OrderStatus::where('status', 'Placed')->pluck('id')->first();
                    $order->update(['order_status_id' => $placedStatusId]);

                    foreach ($order->orderItems as $item) {
                        Cart::where([
                            'user_id' => $order->user_id,
                            'product_id' => $item->product_id
                        ])->delete();
                    
                        if ($item->product) {
                            if ($item->product->quantity > $item->quantity) {
                                $item->product->update([
                                    'quantity' => ($item->product->quantity - $item->quantity)
                                ]);
                            } else {
                                Log::info('There is issue in product quantity decrement');
                                Log::info('Payment succeeded: item->product->quantity = ' . $item->product->quantity . ' And item->quantity = ' . $item->quantity);
                            }
                        }
                    }

                    $order->address->email = "deepesh.jain-t@equestsolutions.net";
                    Mail::to($order->address->email)->queue(new OrderMail($order, $paymentDetails, $order->orderItems, $order->address, 'Order Placed Successfully'));

                    Log::info('Payment succeeded and order updated');
                    break;

                case 'payment_intent.payment_failed':
                    if (!$paymentDetails) {
                        return [
                            'status' => 'success',
                            'message' => 'Payment failed but payment details not found for update'
                        ];
                    }

                    $paymentDetails->update(['status' => 'failed']);

                    $failedStatusId = OrderStatus::where('status', 'Payment Failed')->pluck('id')->first();
                    $order->update(['order_status_id' => $failedStatusId]);

                    $order->address->email = "deepesh.jain-t@equestsolutions.net";
                    Mail::to($order->address->email)->queue(new OrderMail($order, $paymentDetails, $order->orderItems, $order->address, 'Payment Failed'));

                    Log::error('Payment failed and order updated');
                    break;

                default:
                    Log::error('Invalid webhook event');
                    return [
                        'status' => 'error',
                        'message' => 'Invalid webhook event'
                    ];
            }
        } catch (ApiErrorException $e) {
            return [
                'status' => 'error',
                'message' => 'Payment processing error: ' . $e->getMessage()
            ];
        }
    }
}
