<!DOCTYPE html>
<html>
<head>
    <title>Your Order</title>
</head>
<body>
    <h2>Hello, <?php echo e($shippingAddress->first_name); ?> <?php echo e($shippingAddress->last_name); ?></h2>
    
    <p>Your order (Order No: <strong><?php echo e($order->id); ?></strong>) has been <strong><?php echo e($statusMessage); ?></strong>.</p>

    <h3>Order Summary:</h3>
    <?php $subTotal = 0; ?>
    <?php if(isset($orderItems) && $orderItems->isNotEmpty()): ?>
        <ul>
            <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <strong>Product:</strong> <?php echo e($item->product->name); ?><br>
                    <strong>Quantity:</strong> <?php echo e($item->quantity); ?><br>
                    <strong>Price:</strong> $<?php echo e(number_format($item->price, 2)); ?><br>
                    <strong>Item Subtotal:</strong> $<?php echo e(number_format($item->price * $item->quantity, 2)); ?>

                </li>
                <?php $subTotal = $subTotal + ($item->price * $item->quantity); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <p>No items found in the order.</p>
    <?php endif; ?>

    <p><strong>Order Subtotal:</strong> $<?php echo e(number_format($subTotal, 2)); ?></p>
    <p><strong>Tax Estimate:</strong> $<?php echo e(number_format($order->tax_amount, 2)); ?></p>
    <p><strong>Shipping Estimate:</strong> $<?php echo e(number_format($order->shipping_amount, 2)); ?></p>
    <p><strong>Total Order Value:</strong> $<?php echo e(number_format($order->total_amount, 2)); ?></p>

    <h3>Payment Details:</h3>
    <?php if(isset($payment)): ?>
        <p>
            <strong>Status:</strong> <?php echo e(ucfirst($payment->status)); ?><br>
            <strong>Gateway:</strong> <?php echo e($payment->payment_gateway); ?><br>
            <strong>Transaction ID:</strong> <?php echo e($payment->transaction_id); ?><br>
            <strong>Date:</strong> <?php echo e($payment->created_at->format('d M Y, H:i A')); ?><br>
            <strong>Amount:</strong> $<?php echo e(number_format($payment->amount, 2)); ?>

        </p>
    <?php else: ?>
        <p>No payment details available.</p>
    <?php endif; ?>

    <h3>Shipping Address:</h3>
    <p>
        <?php echo e($shippingAddress->address_line_1); ?><br>
        <?php echo e($shippingAddress->apartment ? $shippingAddress->apartment . ', ' : ''); ?>

        <?php echo e($shippingAddress->address_line_2 ? $shippingAddress->address_line_2 . ', ' : ''); ?>

        <?php echo e($shippingAddress->city); ?>, <?php echo e($shippingAddress->state); ?><br>
        <?php echo e($shippingAddress->country); ?> - <?php echo e($shippingAddress->postal_code); ?><br>
        <strong>Phone:</strong> <?php echo e($shippingAddress->phone); ?>

    </p>

    <p>Thank you for shopping with us!</p>
</body>
</html>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\git_repo\trainee-milestones-laravel\ecommerce_api\resources\views/emails/orders/order.blade.php ENDPATH**/ ?>