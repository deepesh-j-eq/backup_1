<?php

namespace App\Http\Controllers\Api;

use App\Enums\OrderStatuses;
use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Payment;
use App\Services\EmailService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Stripe\Exception\ApiErrorException;
use Stripe\StripeClient;

class StripePaymentController extends Controller
{
    protected $stripe, $emailService;

    public function __construct(StripeClient $stripe, EmailService $emailService)
    {
        $this->stripe = new StripeClient(config('stripe.stripe_sk'));
        $this->emailService = $emailService;
    }

    public function processPayment($newRequest)
    {
        try {
            if (!$newRequest || !is_array($newRequest) || empty($newRequest)) {
                return [
                    'status' => 'error',
                    'message' => 'Invalid request data for processing payment.'
                ];
            }

            if (!isset($newRequest['order_id']) || $newRequest['order_id'] == '') {
                return [
                    'status' => 'error',
                    'message' => 'Invalid order data, something went wrong!'
                ];
            }

            $orderData = Order::with([
                            'orderItems:id,order_id,product_id,quantity,price,name,discounted_price'
                        ])->find($newRequest['order_id']);

            if (!$orderData) {
                return [
                    'status' => 'error',
                    'message' => 'Invalid order for processing payment, something went wrong!'
                ];
            }

            $orderItems = $orderData->orderItems;
            $lineItems = [];
            $totalAmount = 0;

            foreach ($orderItems as $item) {
                $unitPrice = (!empty($item->discounted_price) && $item->discounted_price > 0)
                ? (float) $item->discounted_price
                : (float) $item->price;
                $lineItems[] = [
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => ['name' => $item->name],
                        'unit_amount' => $unitPrice * 100
                    ],
                    'quantity' => $item->quantity,
                ];
                $totalAmount += $unitPrice * $item->quantity;
            }

            if (isset($newRequest['total_amount_with_tax']) || $newRequest['total_amount_with_tax'] != '') {
                $totalAmount = $newRequest['total_amount_with_tax'];
            }

            $customer = $this->stripe->customers->create([
                'name' => $newRequest['first_name'],
                'email' => $newRequest['email']
            ]);

            $paymentIntent = $this->stripe->paymentIntents->create([
                'amount' => (int) (number_format($totalAmount, 2, '.', '') * 100),
                'currency' => 'usd',
                'payment_method' => $newRequest['payment_method'],
                'confirm' => true,
                'customer' => $customer->id,
                'automatic_payment_methods' => [
                    'enabled' => true,
                    'allow_redirects' => 'never'
                ]
            ]);

            $customerDetails = $this->stripe->customers->retrieve($paymentIntent->customer);

            $payerName = !empty($customerDetails->name) ? $customerDetails->name : $newRequest['first_name'];
            $payerEmail = !empty($customerDetails->email) ? $customerDetails->email : $newRequest['email'];

            $payment = Payment::create([
                'transaction_id' => $paymentIntent->id,
                'currency' => $paymentIntent->currency,
                'amount' => $paymentIntent->amount / 100,
                'payer_name' => $payerName,
                'payer_email' => $payerEmail,
                'payment_gateway' => 'Stripe',
                'payment_method' => $paymentIntent->payment_method ?? $newRequest['payment_method']
            ]);

            $orderData->update(['payment_id' => $payment->id]);

            return [
                'status' => 'created',
                'paymentId' => $payment->id
            ];
        } catch (ApiErrorException $e) {
            $errorResponse = $e->getJsonBody();
            $errorData = $errorResponse['error'] ?? [];

            $paymentIntentIdOnFail = $errorData['payment_intent']['id'] ?? null;
            $paymentStatusOnFail = $errorData['decline_code'] ?? 'failed';
            $currencyOnFail = $errorData['payment_intent']['currency'] ?? 'usd';
            $amountOnFail = isset($errorData['payment_intent']['amount']) ? ($errorData['payment_intent']['amount'] / 100) : 0;

            $payment = Payment::create([
                'transaction_id' => $paymentIntentIdOnFail,
                'currency' => $currencyOnFail,
                'amount' => $amountOnFail,
                'payer_name' => $newRequest['first_name'],
                'payer_email' => $newRequest['email'],
                'payment_gateway' => 'Stripe',
                'payment_method' => $newRequest['payment_method'],
                'status' => $paymentStatusOnFail
            ]);

            $orderData->update(['payment_id' => $payment->id]);

            return [
                'status' => 'error',
                'paymentId' => $payment->id,
                'message' => 'Payment failed: ' . $e->getMessage()
            ];
        }
    }

    public function handleWebhook(Request $request)
    {
        try {
            $payload = $request->getContent();
            $event = json_decode($payload, true);
            $sigHeader = $request->header('Stripe-Signature');

            if (!isset($event['type']) || !isset($event['data']['object'])) {
                return [
                    'status' => 'error',
                    'message' => 'Invalid webhook event'
                ];
            }

            $paymentIntent = $event['data']['object'];
            $customerDetails = null;

            if (!empty($paymentIntent['customer'])) {
                try {
                    $customerDetails = $this->stripe->customers->retrieve($paymentIntent['customer']);
                } catch (\Exception $e) {
                    Log::error('handleWebhook: Failed to retrieve customer details: ' . $e->getMessage());
                }
            }

            $paymentDetails = Payment::where('transaction_id', $paymentIntent['id'])->first();

            if (!$paymentDetails) {
                Log::info('handleWebhook: Payment (transaction) details not found!');
                return [
                    'status' => 'error',
                    'message' => 'Payment (transaction) details not found!'
                ];
            }

            $order = Order::with([
                        'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                        'orderItems:id,order_id,name,product_id,quantity,price,discounted_price',
                        'orderItems.product:id,quantity'
                    ])
                    ->where('payment_id', $paymentDetails['id'])->first();

            if (!$order) {
                Log::info('handleWebhook: Order not found!');
                return [
                    'status' => 'error',
                    'message' => 'Order not found!'
                ];
            }

            try{
                $orderEmailData = [
                    'order' => $order,
                    'payment' => $paymentDetails,
                    'orderItems' => $order->orderItems,
                    'shippingAddress' => $order->address
                ];

                $validStatuses = array_column(OrderStatuses::cases(), 'value');

                switch ($event['type'] ?? null) {
                    case 'payment_intent.succeeded':
                        $paymentDetails->update(['status' => $paymentIntent['status']]);

                        if (in_array('placed', $validStatuses, true)) {
                            $order->update(['order_status' => OrderStatuses::ORDER_STATUS_PLACED->value]);
                        }

                        foreach ($order->orderItems as $item) {
                            $cartItem = Cart::where([
                                'user_id' => $order->user_id,
                                'product_id' => $item->product_id
                            ])->first();

                            if ($cartItem) {
                                $cartItem->delete();
                            }

                            if ($item->product) {
                                if ($item->product->quantity > $item->quantity) {
                                    $item->product->update([
                                        'quantity' => ($item->product->quantity - $item->quantity)
                                    ]);
                                } else {
                                    Log::info('There is issue in product quantity decrement');
                                    Log::info('Payment succeeded: item->product->quantity = ' . $item->product->quantity . ' And item->quantity = ' . $item->quantity);
                                }
                            }
                        }

                        $orderEmailData['statusMessage'] = 'Order Placed Successfully';

                        $this->emailService->sendEmail($order->address->email, "Your Order #{$order->id} - Order Placed Successfully", 'emails.orders.order', $orderEmailData);
                        break;

                    case 'payment_intent.payment_failed':
                        $paymentDetails->update(['status' => 'failed']);

                        if (in_array('payment_failed', $validStatuses, true)) {
                            $order->update(['order_status' => OrderStatuses::ORDER_STATUS_PAYMENT_FAILED->value]);
                        }

                        $orderEmailData['statusMessage'] = 'Payment Failed';

                        $this->emailService->sendEmail($order->address->email, "Your Order #{$order->id} - Payment Failed", 'emails.orders.order', $orderEmailData);
                        break;

                    default:
                        Log::error('Invalid webhook event');
                        return [
                            'status' => 'error',
                            'message' => 'Invalid webhook event'
                        ];
                }
            } catch (\Exception $e) {
                Log::error('handleWebhook: something went wrong! while payment_intent succeeded or payment_failed event : ' . $e->getMessage());
            }
        } catch (ApiErrorException $e) {
            return [
                'status' => 'error',
                'message' => 'Payment processing error: ' . $e->getMessage()
            ];
        }
    }
}
