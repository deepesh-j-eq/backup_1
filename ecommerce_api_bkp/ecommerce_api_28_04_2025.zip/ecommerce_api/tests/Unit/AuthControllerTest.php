<?php

namespace Tests\Unit;

use App\Models\User;
use App\Models\Role;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthControllerTest extends TestCase
{
    use RefreshDatabase;

    public function test_signup_valid_data()
    {
        $data = [
            'name' => 'Test User 1',
            'email' => 'test1@test.com',
            'password' => '12345',
            'confirm_password' => '12345'
        ];

        $response = $this->postJson(route('signup'), $data);

        $response->assertStatus(201);
        $response->assertJsonFragment(['message' => 'User created successfully']);
        $this->assertDatabaseHas('users', [
            'email' => 'test1@test.com',
        ]);
    }

    public function test_signup_missing_data()
    {
        $data = [
            'name' => 'Test User 1',
            'email' => '',
            'password' => '12345',
            'confirm_password' => '12345'
        ];

        $response = $this->postJson(route('signup'), $data);

        $response->assertStatus(422);
        $response->assertJsonValidationErrors(['email']);
    }

    public function test_login_success()
    {
        $role = Role::firstOrCreate(['role' => 'user']);
        $user = User::factory()->create([
            'email' => 'test1@test.com',
            'password' => Hash::make('12345'),
            'role_id' => $role->id,
        ]);

        $data = [
            'email' => 'test1@test.com',
            'password' => '12345',
        ];

        $response = $this->postJson(route('login'), $data);

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'status', 'message', 'token', 'token_type', 'user_type'
        ]);
    }

    public function test_login_invalid_credentials()
    {
        $data = [
            'email' => 'test22@test.com',
            'password' => 'wrongpassword',
        ];

        $response = $this->postJson(route('login'), $data);

        $response->assertStatus(401);
        $response->assertJsonFragment(['message' => 'Email and Password do not match']);
    }

    public function test_login_deleted_user()
    {
        $role = Role::firstOrCreate(['role' => 'user']);
        $user = User::factory()->create([
            'email' => 'test1@test.com',
            'password' => Hash::make('12345'),
            'role_id' => $role->id,
        ]);
        $user->delete();

        $data = [
            'email' => 'test1@test.com',
            'password' => '12345',
        ];

        $response = $this->postJson(route('login'), $data); 

        $response->assertStatus(403);
        $response->assertJsonFragment(['message' => 'User account is deleted (inactive)']);
    }

    public function test_logout_success()
    {
        $user = User::factory()->create();
        $this->actingAs($user, 'sanctum');

        $response = $this->postJson(route('logout'));

        $response->assertStatus(200);
        $response->assertJsonFragment(['message' => 'Logged out successfully']);
        $this->assertCount(0, $user->tokens);
    }

    public function test_logout_not_authenticated()
    {
        $response = $this->postJson(route('logout'));

        $response->assertStatus(401);
        $response->assertJsonFragment(['message' => 'Unauthenticated.']);
    }
}
