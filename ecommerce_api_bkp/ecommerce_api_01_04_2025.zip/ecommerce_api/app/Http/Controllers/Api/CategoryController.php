<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Services\BaseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    protected $baseService;

    public function __construct()
    {
        $this->baseService = new BaseService(new Category());
    }

    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/category",
    *     summary="Get all category",
    *     description="Fetches all categories from the database",
    *     tags={"Category"},
    *     security={{"bearerAuth": {}}},
    *     operationId="category.index",
    *     @OA\Response(
    *         response=200,
    *         description="All categories",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All categories"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="categories",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Men's fashion"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T08:19:36.000000Z")
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="No categories found",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="No categories found")
    *         )
    *     )
    * )
    */
    public function index()
    {
        $categories = array();
        $categories = $this->baseService->getAllRecords();

        if($categories->isEmpty()) {
            return helperJSONResponse(false, 'No categories found', [], 404);
        }

        return helperJSONResponse(true, 'All categories', ['categories' => $categories], 200);
    }

    /**
     * Store a newly created resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/category",
    *     summary="Create category",
    *     description="Create category",
    *     tags={"Category"},
    *     security={{"bearerAuth": {}}},
    *     operationId="category.store",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"name"},
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Furniture"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"name"},
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Furniture"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=201,
    *         description="Category created successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Category created successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="category",
    *                     type="object",
    *                         @OA\Property(property="name", type="string", example="Furniture"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T08:16:10.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T08:16:10.000000Z"),
    *                         @OA\Property(property="id", type="integer", example=1)
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "name": {"The name field is required.", "The name field must be at least 3 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Category creation failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Category creation failed")
    *         )
    *     )
    * )
    */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'name' => 'required|string|min:3|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 422);
        }

        $categoryData = array('name' => $request->name);
        $category = $this->baseService->store($categoryData);

        if (!$category) {
            return helperJSONResponse(false, 'Category creation failed', [], 500);
        }

        return helperJSONResponse(true, 'Category created successfully', ['category' => $category], 201);
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/category/{id}",
    *     summary="Get single category",
    *     description="Display single category",
    *     tags={"Category"},
    *     security={{"bearerAuth": {}}},
    *     operationId="categorys.show",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Category id to show that category",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display single category",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Record retrieved"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="single_record",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Furniture")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested record not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested record not available")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {
        $fields = array('id', 'name');
        return $this->baseService->getRecordById($id, $fields);
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/category/{id}",
    *     summary="Update category",
    *     description="Update category",
    *     tags={"Category"},
    *     security={{"bearerAuth": {}}},
    *     operationId="category.update",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Category id to update that category",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Furniture"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Furniture"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Category updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Category updated successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="category",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="category", type="string", example="Furniture"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-27T09:38:00.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-27T09:40:00.000000Z"),
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested category not available for update",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested category not available for update")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "name": {"The name field is required.", "The name field must be at least 3 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Category update failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Category update failed")
    *         )
    *     )
    * )
    */
    public function update(Request $request, string $id)
    {
        $category = Category::find($id);

        if (!$category) {
            return helperJSONResponse(false, 'Requested category not available for update', [], 404);
        }

        $validate = Validator::make($request->all(), [
            'name' => 'required|string|min:3|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 422);
        }

        $categoryData = array('name' => $request->name);
        $updateCategory = $this->baseService->update($id, $categoryData);

        if (!$updateCategory) {
            return helperJSONResponse(false, 'Category update failed', [], 500);
        }

        $updatedCategoryData = array();
        $updatedCategoryData = Category::find($id);

        return helperJSONResponse(true, 'Category updated successfully', ['category' => $updatedCategoryData], 200);
    }

    /**
     * Remove the specified resource from storage.
     */

    /**
    * @OA\Delete(
    *     path="/api/admin/category/{id}",
    *     summary="Delete category",
    *     description="Delete category",
    *     tags={"Category"},
    *     security={{"bearerAuth": {}}},
    *     operationId="category.destroy",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Category id to delete that category",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Category deleted successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Record deleted successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested record not available for deletion",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested record not available for deletion"
    *             )
    *         )
    *     )
    * )
    */
    public function destroy(string $id)
    {
        return $this->baseService->deleteRecordById($id);
    }
}
