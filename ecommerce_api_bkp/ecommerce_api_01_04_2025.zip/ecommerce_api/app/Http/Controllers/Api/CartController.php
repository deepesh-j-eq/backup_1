<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\CheckoutRequest;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderAddress;
use App\Models\OrderItem;
use App\Models\OrderStatus;
use App\Models\Product;
use App\Services\BaseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    protected $stripePaymentController;

    public function __construct(StripePaymentController $stripePaymentController)
    {
        $this->stripePaymentController = $stripePaymentController;
    }

    /**
    * @OA\Get(
    *     path="/api/cart",
    *     summary="View your cart",
    *     description="Display your cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="view.cart.items",
    *     @OA\Response(
    *         response=200,
    *         description="Display your cart or No product in your cart, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your cart | No product in your cart, keep shoppping!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                           @OA\Property(
    *                             property="cart_items",
    *                             type="array",
    *                                   @OA\Items(
    *                                       type="object",
    *                                       @OA\Property(property="id", type="integer", example=3),
    *                                       @OA\Property(property="quantity", type="integer", example=2),
    *                                       @OA\Property(property="product_id", type="integer", example=1),
    *                                       @OA\Property(property="created_at", type="string", example="2025-02-24T12:36:29.000000Z"),
    *                                       @OA\Property(property="updated_at", type="string", example="2025-02-25T11:03:47.000000Z"),
    *                                       @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                           @OA\Property(
    *                                               property="product",
    *                                               type="object",
    *                                                   @OA\Property(property="name", type="string", example="Product 1"),
    *                                                   @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                                   @OA\Property(property="price", type="string", example="50.00"),
    *                                                   @OA\Property(property="discounted_price", type="string", example="25.00")
    *                                           )
    *                                   ),
    *                           ),
    *                      @OA\Property(property="total_price", type="string", example="715.00")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=204,
    *         description="No product in your cart",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="No product in your cart, keep shoppping!")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function viewCart(Request $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItems = Cart::with(['product' => function ($query) {
                    $query->select(['id', 'name', 'description', 'price', 'discounted_price']);
                }])
                ->where('user_id', $authenticatedUserId)
                ->get()
                ->makeHidden(['user_id']);

            if ($cartItems->isEmpty()) {
                return helperJSONResponse(true, 'No product in your cart, keep shoppping!', [], 204);
            }

            $data = array();
            $totalPrice = 0;

            foreach ($cartItems as $cartItem) {
                $cartItem->product->makeHidden(['id']);
                if (empty($cartItem->product->discounted_price)) {
                    $cartItem->product->makeHidden(['discounted_price']);
                }

                $cartItem->sub_total = $this->calculateSubTotal($cartItem);
                $totalPrice += $cartItem->sub_total;
            }

            $data = [
                'cart_items' => $cartItems,
                'total_price' => number_format($totalPrice, 2),
            ];

            if ($data['cart_items']->isNotEmpty()) {
                return helperJSONResponse(true, 'Your cart', ['cart' => $data], 200);
            }
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/cart/add",
    *     summary="Add to cart",
    *     description="Add to cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="add.to.cart",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"product_id", "quantity"},
    *                   @OA\Property(
    *                       property="product_id",
    *                       type="integer",
    *                       example=6
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=2
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"product_id", "quantity"},
    *                   @OA\Property(
    *                       property="product_id",
    *                       type="integer",
    *                       example=6
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=2
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product added to cart successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product added to cart successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                         @OA\Property(property="product_id", type="string", example="6"),
    *                         @OA\Property(property="quantity", type="string", example="2"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-04T08:20:17.000000Z"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-04T08:20:17.000000Z"),
    *                         @OA\Property(property="id", type="integer", example=13),
    *                         @OA\Property(property="sub_total", type="string", example="410.00"),
    *                         @OA\Property(
    *                             property="product",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Product 3"),
    *                             @OA\Property(property="description", type="string", example="Product 3 description"),
    *                             @OA\Property(property="price", type="string", example="205.00"),
    *                             @OA\Property(property="discounted_price", type="string", example="105.00"),
    *                             @OA\Property(property="quantity", type="integer", example=12)
    *                        )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=409,
    *         description="Not enough stock available for selected product",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Not enough stock available for selected product")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "product_id": {"The product_id field is required.", "The selected product id is invalid."},
    *                   "quantity": {"The quantity field is required.", "The quantity field must be at least 1.", "The quantity field must be an integer."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function addToCart(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'product_id' => 'required|exists:products,id',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 422);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;
            $productId = $request->product_id;
            $quantity = $request->quantity;

            $product = Product::find($productId);

            if (!$product || $quantity > $product->quantity) {
                return $this->handleStockError($product);
            }

            $cartItem = Cart::where('user_id', $authenticatedUserId)
                            ->where('product_id', $productId)
                            ->first();

            if ($cartItem) {
                $newQuantity = $cartItem->quantity + $quantity;

                if ($newQuantity > $product->quantity) {
                    return $this->handleStockError($product, $cartItem);
                }

                $cartItem->update(['quantity' => $newQuantity]);
            } else {
                $cartItem = Cart::create([
                    'user_id' => $authenticatedUserId,
                    'product_id' => $productId,
                    'quantity' => $quantity
                ]);
            }

            $cartItem->sub_total = $this->calculateSubTotal($cartItem);
            $cartItem->product->makeHidden(['id', 'category_id', 'created_at', 'updated_at']);
            if (empty($cartItem->product->discounted_price)) {
                $cartItem->product->makeHidden(['discounted_price']);
            }
            $cartItem->makeHidden(['user_id']);

            return helperJSONResponse(true, 'Product added to cart successfully', ['cart' => $cartItem], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }
    
    /**
    * @OA\Post(
    *     path="/api/cart/change-quantity/{id}",
    *     summary="Change product quantity from cart",
    *     description="Change product quantity from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="change.cart.qty",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Cart id to change product quantity",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"change_to", "quantity"},
    *                   @OA\Property(
    *                       property="change_to",
    *                       type="string",
    *                       enum={"up", "down"},
    *                       example="down",
    *                       description="Change (increase or decrease) product quantity which already added to cart"
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=1
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"change_to", "quantity"},
    *                   @OA\Property(
    *                       property="change_to",
    *                       type="string",
    *                       enum={"up", "down"},
    *                       example="down",
    *                       description="Change (increase or decrease) product quantity which already added to cart"
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=1
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product qunatity has been changed successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product qunatity has been changed successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                         @OA\Property(
    *                             property="cart_item",
    *                             type="object",
    *                                   @OA\Property(property="id", type="integer", example=12),
    *                                   @OA\Property(property="quantity", type="integer", example=2),
    *                                   @OA\Property(property="product_id", type="integer", example=6),
    *                                   @OA\Property(property="updated_at", type="string", example="2025-03-04T08:31:20.000000Z"),
    *                                   @OA\Property(property="created_at", type="string", example="2025-03-04T09:12:07.000000Z"),
    *                                   @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                   @OA\Property(
    *                                       property="product",
    *                                       type="object",
    *                                           @OA\Property(property="name", type="string", example="Product 1"),
    *                                           @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                           @OA\Property(property="price", type="string", example="50.00"),
    *                                           @OA\Property(property="discounted_price", type="string", example="25.00")
    *                                   )
    *                          )
    *                   )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Please remove correct quantity",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Please remove correct quantity")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Please choose correct cart item for update quantity",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Please choose correct cart item for update quantity"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=405,
    *         description="Not enough stock available for product <product name>",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Not enough stock available for product <product name>")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "change_to": {"The change to field is required.", "The selected change to is invalid."},
    *                   "quantity": {"The quantity field is required.", "The quantity field must be at least 1.", "The quantity field must be an integer."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function changeCartQuantity(Request $request, $id)
    {
        try {
            $validate = Validator::make($request->all(), [
                'change_to' => 'required|string|in:up,down',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 422);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItem = Cart::with(['product'])
                        ->where('user_id', $authenticatedUserId)
                        ->find($id);

            if (!$cartItem) {
                return helperJSONResponse(false, 'Please choose correct cart item for update quantity', [], 404);
            }

            $changeTo = $request->change_to;
            $quantity = $request->quantity;
            
            if ($changeTo == 'up') {
                $newQuantity = $cartItem->quantity + $quantity;
            } else if ($changeTo == 'down') {
                $newQuantity = $cartItem->quantity - $quantity;
            }

            $stockValidationResponse = $this->validateCartQuantityChange($cartItem, $newQuantity, $changeTo);
            if ($stockValidationResponse) {
                return $stockValidationResponse;
            }

            $cartItem->update(['quantity' => $newQuantity]);

            $cart_item = Cart::with([
                'product' => function ($query) {
                    $query->select(['id', 'name', 'description', 'price', 'discounted_price']);
                }])
                ->where('user_id', $authenticatedUserId)
                ->find($id);

            $cart_item->sub_total = $this->calculateSubTotal($cartItem);

            $cart_item->product->makeHidden(['id']);
            if (empty($cart_item->product->discounted_price)) {
                $cart_item->product->makeHidden(['discounted_price']);
            }
            $cart_item->makeHidden(['user_id']);

            $data = array();
            $data['cart_item'] = $cart_item;

            return helperJSONResponse(true, $cart_item->product->name . ' qunatity has been changed successfully', ['cart' => $data], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Delete(
    *     path="/api/cart/{id}",
    *     summary="Remove item from cart",
    *     description="Remove item from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="remove.cart.item",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Cart id to delete the specific cart item",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Cart item removed successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Cart item removed successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                           @OA\Property(
    *                             property="cart_items",
    *                             type="array",
    *                                   @OA\Items(
    *                                       type="object",
    *                                       @OA\Property(property="id", type="integer", example=3),
    *                                       @OA\Property(property="quantity", type="integer", example=2),
    *                                       @OA\Property(property="product_id", type="integer", example=1),
    *                                       @OA\Property(property="created_at", type="string", example="2025-02-24T12:36:29.000000Z"),
    *                                       @OA\Property(property="updated_at", type="string", example="2025-02-25T11:03:47.000000Z"),
    *                                       @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                           @OA\Property(
    *                                               property="product",
    *                                               type="object",
    *                                                   @OA\Property(property="name", type="string", example="Product 1"),
    *                                                   @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                                   @OA\Property(property="price", type="string", example="50.00"),
    *                                                   @OA\Property(property="discounted_price", type="string", example="25.00")
    *                                           )
    *                                   ),
    *                           ),
    *                      @OA\Property(property="total_price", type="string", example="715.00")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=204,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Cart item removed successfully, No product in your cart, keep shoppping!")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested cart item not available for remove",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested cart item not available for remove"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function removeFromCart(Request $request, $id)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItem = Cart::where('user_id', $authenticatedUserId)
                            ->find($id);

            if (!$cartItem) {
                return helperJSONResponse(false, 'Requested cart item not available for remove', [], 404);
            }

            $cartItem->delete();

            $RemainingCartItems = Cart::with(['product' => function ($query) {
                            $query->select(['id', 'name', 'description', 'price', 'discounted_price']);
                        }])
                ->where('user_id', $authenticatedUserId)
                ->get()
                ->makeHidden(['user_id']);

            if ($RemainingCartItems->isEmpty()) {
                return helperJSONResponse(true, 'Cart item removed successfully, No product in your cart, keep shoppping!', [], 204);
            }

            $data = array();
            $totalPrice = 0;

            $RemainingCartItems->transform(function ($item) use (&$totalPrice) {
                $item->product->makeHidden(['id']);
                if (empty($item->product->discounted_price)) {
                    $item->product->makeHidden(['discounted_price']);
                }

                $item->sub_total = $this->calculateSubTotal($item);
                $totalPrice += $item->sub_total;

                return $item;
            });

            $data = [
                    'cart_items' => $RemainingCartItems,
                    'total_price' => number_format($totalPrice, 2)
            ];

            return helperJSONResponse(true, 'Cart item removed successfully', ['cart' => $data], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/cart/remove-cart",
    *     summary="Remove all items from cart",
    *     description="Remove all items from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="remove.all.cart.items",
    *     @OA\Response(
    *         response=200,
    *         description="All products are removed from cart successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All products are removed from cart successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="No cart item available for remove, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="No cart item available for remove, keep shoppping!"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function removeAllProductsFromCart(Request $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItems = Cart::where('user_id', $authenticatedUserId)->get();

            if ($cartItems->isEmpty()) {
                return helperJSONResponse(false, 'No cart item available for remove, keep shoppping!', [], 404);
            }

            $cartProducts = array();

            foreach ($cartItems as $cartItem) {
                $product = Product::find($cartItem->product_id);

                $cartProducts[] = $product->name;

                $cartItem->delete();
            }

            return helperJSONResponse(true, 'All products ('.implode(", ", $cartProducts).') are removed from cart successfully', [], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/cart/checkout",
    *     summary="Checkout",
    *     description="Checkout",
    *     tags={"Checkout"},
    *     security={{"bearerAuth": {}}},
    *     operationId="checkout",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"first_name", "last_name", "address_line_1", "city", "state", "country", "postal_code", "email", "payment_method", "phone", "shipping_option"},
    *                   @OA\Property(
    *                       property="first_name",
    *                       type="string",
    *                       example="Test1 First Name"
    *                   ),
    *                   @OA\Property(
    *                       property="last_name",
    *                       type="string",
    *                       example="Test1 Last Name"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_1",
    *                       type="string",
    *                       example="Test1 Address Line 1"
    *                   ),
    *                   @OA\Property(
    *                       property="apartment",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Apartment"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_2",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Address Line 2"
    *                   ),
    *                   @OA\Property(
    *                       property="city",
    *                       type="string",
    *                       example="Ahmedabad"
    *                   ),
    *                   @OA\Property(
    *                       property="state",
    *                       type="string",
    *                       example="Gujarat"
    *                   ),
    *                   @OA\Property(
    *                       property="country",
    *                       type="string",
    *                       example="India"
    *                   ),
    *                   @OA\Property(
    *                       property="postal_code",
    *                       type="integer",
    *                       example=441122
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="payment_method",
    *                       type="string",
    *                       enum={"pm_card_visa", "pm_card_mastercard", "pm_card_chargeDeclined", "pm_card_chargeDeclinedInsufficientFunds"},
    *                       example="pm_card_visa",
    *                       description="pm_card_visa, pm_card_mastercard, pm_card_chargeDeclined, pm_card_chargeDeclinedInsufficientFunds"
    *                   ),
    *                   @OA\Property(
    *                       property="phone",
    *                       type="integer",
    *                       example=4411441188
    *                   ),
    *                   @OA\Property(
    *                       property="shipping_option",
    *                       type="string",
    *                       enum={"2_4_days_delivery", "8_12_days_delivery"},
    *                       example="2_4_days_delivery",
    *                       description="2_4_days_delivery, 8_12_days_delivery"
    *                   ),
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"first_name", "last_name", "address_line_1", "city", "state", "country", "postal_code", "email", "payment_method", "phone", "shipping_option"},
    *                   @OA\Property(
    *                       property="first_name",
    *                       type="string",
    *                       example="Test1 First Name"
    *                   ),
    *                   @OA\Property(
    *                       property="last_name",
    *                       type="string",
    *                       example="Test1 Last Name"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_1",
    *                       type="string",
    *                       example="Test1 Address Line 1"
    *                   ),
    *                   @OA\Property(
    *                       property="apartment",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Apartment"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_2",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Address Line 2"
    *                   ),
    *                   @OA\Property(
    *                       property="city",
    *                       type="string",
    *                       example="Ahmedabad"
    *                   ),
    *                   @OA\Property(
    *                       property="state",
    *                       type="string",
    *                       example="Gujarat"
    *                   ),
    *                   @OA\Property(
    *                       property="country",
    *                       type="string",
    *                       example="India"
    *                   ),
    *                   @OA\Property(
    *                       property="postal_code",
    *                       type="integer",
    *                       example=441122
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="payment_method",
    *                       type="string",
    *                       enum={"pm_card_visa", "pm_card_mastercard", "pm_card_chargeDeclined", "pm_card_chargeDeclinedInsufficientFunds"},
    *                       example="pm_card_visa",
    *                       description="pm_card_visa, pm_card_mastercard, pm_card_chargeDeclined, pm_card_chargeDeclinedInsufficientFunds"
    *                   ),
    *                   @OA\Property(
    *                       property="phone",
    *                       type="integer",
    *                       example=4411441188
    *                   ),
    *                   @OA\Property(
    *                       property="shipping_option",
    *                       type="string",
    *                       enum={"2_4_days_delivery", "8_12_days_delivery"},
    *                       example="2_4_days_delivery",
    *                       description="2_4_days_delivery, 8_12_days_delivery"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Order placed successfully or Your cart is empty, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Order placed successfully | Your cart is empty, keep shoppping!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="order_details",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="total_amount", type="string", example="460.00"),
    *                         @OA\Property(property="order_status_id", type="integer", example=1),
    *                         @OA\Property(property="updated_by", type="string", example=null),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-04T10:40:08.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-04T10:40:08.000000Z"),
    *                         @OA\Property(
    *                             property="order_status",
    *                             type="object",
    *                             @OA\Property(property="status", type="string", example="Placed")
    *                         ),
    *                         @OA\Property(
    *                             property="payment",
    *                             type="object",
    *                             @OA\Property(property="payment_gateway", type="string", example="paypal"),
    *                             @OA\Property(property="transaction_id", type="string", example="ojsMiGIkg50MrLG"),
    *                             @OA\Property(property="status", type="string", example="successful")
    *                         ),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Test 2")
    *                         ),
    *                         @OA\Property(
    *                             property="address",
    *                             type="object",
    *                             @OA\Property(property="id", type="integer", example=1),
    *                             @OA\Property(property="order_id", type="integer", example=1),
    *                             @OA\Property(property="first_name", type="string", example="Test2 First Name"),
    *                             @OA\Property(property="last_name", type="string", example="Test2 Last Name"),
    *                             @OA\Property(property="address_line_1", type="string", example="Test2 Address Line 1"),
    *                             @OA\Property(property="apartment", type="string", example="Test2 Apartment"),
    *                             @OA\Property(property="address_line_2", type="string", example="Test2 Address Line 2"),
    *                             @OA\Property(property="city", type="string", example="Ahmedabad"),
    *                             @OA\Property(property="country", type="string", example="India"),
    *                             @OA\Property(property="state", type="string", example="Gujarat"),
    *                             @OA\Property(property="postal_code", type="integer", example=441122),
    *                             @OA\Property(property="phone", type="integer", example=4411441188),
    *                             @OA\Property(property="email", type="string", example="test2@gmail.com")
    *                         ),
    *                         @OA\Property(
    *                             property="order_items",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="quantity", type="integer", example=2),
    *                                 @OA\Property(property="name", type="string", example="Product 1"),
    *                                 @OA\Property(property="price", type="string", example="205.00"),
    *                                 @OA\Property(property="discount_price", type="string", example="105.00"),
    *                                 @OA\Property(property="order_id", type="integer", example=1),
    *                                 @OA\Property(property="sub_total", type="string", example="410.00")
    *                             )
    *                         )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Something went wrong! Order not found for update",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Something went wrong! Order not found for update"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=402,
    *         description="Something went wrong while attempting stripe payment!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Something went wrong while attempting stripe payment!"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "first_name": {"The first_name field is required.", "The first name field must be at least 2 characters."},
    *                       "last_name": {"The last_name field is required.", "The last name field must be at least 2 characters."},
    *                       "address_line_1": {"The address_line_1 field is required.", "The address line 1 field must be at least 10 characters."},
    *                       "city": {"The city field is required.", "The city field format is invalid."},
    *                       "state": {"The state field is required.", "The state field format is invalid."},
    *                       "country": {"The country field is required.", "The country field format is invalid."},
    *                       "postal_code": {"The postal code field is required.", "Postal code should be minimum 6 digits."},
    *                       "email": {"The email field is required.", "Please enter a valid email address."},
    *                       "payment_method": {"The payment method field is required.", "The selected payment method is invalid."},
    *                       "phone": {"The phone field is required.", "The phone field must be an integer.", "The phone field must be 10 digits."},
    *                       "shipping_option": {"The shipping option field is required.", "The selected shipping option is invalid."},
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function checkout(CheckoutRequest $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItems = Cart::with(['product'])->where('user_id', $authenticatedUserId)->get();

            if ($cartItems->isEmpty()) {
                return helperJSONResponse(true, 'Your cart is empty, keep shoppping!', [], 200);
            }

            $totalAmount = 0;

            foreach ($cartItems as $item) {
                $item->sub_total = $this->calculateSubTotal($item);
                $totalAmount += $item->sub_total;
            }

            $shippingEstimate = $this->shippingEstimate($request->shipping_option);
            $taxPercentage = 14;
            $taxAmount = $this->taxCalculation($totalAmount, $taxPercentage);
            $totalAmountWithTax = $totalAmount + $shippingEstimate + $taxAmount;

            $order = Order::create([
                'total_amount' => $totalAmountWithTax,
                'shipping_amount' => $shippingEstimate,
                'tax_amount' => $taxAmount,
                'user_id' => $authenticatedUserId
            ]);

            if (!$order) {
                return helperJSONResponse(false, 'Order creation failed', [], 500);
            }

            OrderAddress::create([
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'address_line_1' => $request->address_line_1,
                'apartment' => $request->apartment,
                'address_line_2' => $request->address_line_2,
                'city' => $request->city,
                'state' => $request->state,
                'country' => $request->country,
                'postal_code' => $request->postal_code,
                'phone' => $request->phone,
                'email' => $request->email,
                'order_id' => $order->id
            ]);

            foreach ($cartItems as $item) {
                OrderItem::create([
                    'quantity' => $item->quantity,
                    'name' => $item->product->name,
                    'price' => $item->product->price,
                    'discounted_price' => !empty($item->product->discounted_price) ? $item->product->discounted_price : null,
                    'order_id' => $order->id,
                    'product_id' => $item->product_id
                ]);
            }

            $newRequest = $request->all();
            $newRequest['order_id'] = $order->id;
            $newRequest['total_amount_with_tax'] = $totalAmountWithTax;

            $paymentIntents = $this->stripePaymentController->processPayment($newRequest);
            $baseService = new BaseService(new OrderStatus());

            if (!empty($paymentIntents)) {
                if (!array_key_exists('paymentId', $paymentIntents) && $paymentIntents['status'] = 'error') {
                    return helperJSONResponse(false, 'Order number ' . $order->id . ' has following issue: ' . $paymentIntents['message'], [], 400);
                }

                $createdStatusId = $baseService->getOrderStatusId('Created');

                $orderUpdateArray = [
                    'order_status_id' => ($createdStatusId) ? $createdStatusId : null,
                    'payment_id' => $paymentIntents['paymentId']
                ];

                $orderForUpdate = Order::find($order->id);

                if (!$orderForUpdate) {
                    return helperJSONResponse(false, 'Something went wrong! Order not found for update', [], 400);
                }

                $orderForUpdate->update($orderUpdateArray);

                return $this->orderResponse($order, 'Order created successfully', true, 200);
            }

            $failedStatusId = $baseService->getOrderStatusId('Payment Failed');
            $orderForUpdate = Order::find($order->id);

            if (!$orderForUpdate) {
                return helperJSONResponse(false, 'Something went wrong!! Order not found for update', [], 400);
            }

            $orderForUpdate->update(['order_status_id' => $failedStatusId]);

            return helperJSONResponse(false, 'Something went wrong while attempting stripe payment!', [], 402);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    private function orderResponse($order, $message, $status, $httpCode)
    {
        $orderDetails = Order::with([
            'orderStatus:id,status',
            'payment:id,payment_gateway,transaction_id,status,payment_method',
            'user:id,name',
            'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
            'orderItems'
        ])->find($order->id);

        $orderSubTotal = 0;

        $orderDetails->makeHidden(['user_id']);
        if ($orderDetails->orderStatus) {
            $orderDetails->orderStatus->makeHidden(['id']);
        }
        if ($orderDetails->payment) {
            $orderDetails->payment->makeHidden(['id']);
        }
        $orderDetails->user->makeHidden(['id']);

        if ($orderDetails->payment_id) {
            $orderDetails->makeHidden(['payment_id']);
        }

        foreach ($orderDetails->orderItems as $orderItem) {
            $orderItem->makeHidden(['id', 'product_id', 'created_at', 'updated_at']);
            $unitPrice = (!empty($orderItem->discounted_price) && $orderItem->discounted_price > 0)
            ? (float) $orderItem->discounted_price
            : (float) $orderItem->price;
            $quantity = (int) $orderItem->quantity;

            $orderItem->sub_total = number_format($unitPrice * $quantity, 2);
            $orderSubTotal += ($unitPrice * $quantity);

            if (empty($orderItem->discounted_price)) {
                $orderItem->makeHidden(['discounted_price']);
            }
        }

        $orderDetails->order_sub_total = number_format($orderSubTotal, 2);

        return response()->json([
            'status' => $status,
            'message' => $message,
            'order_id' => $order->id,
            'data' => ['order_details' => $orderDetails]
        ], $httpCode);
    }

    private function calculateSubTotal($cartItem)
    {
        if (!$cartItem || !$cartItem->product) {
            return 0;
        }

        $unitPrice = (!empty($cartItem->product->discounted_price) && $cartItem->product->discounted_price > 0)
        ? $cartItem->product->discounted_price
        : $cartItem->product->price;

        $subTotal = (float) $unitPrice * (int) $cartItem->quantity;
        return number_format($subTotal, 2);
    }

    private function shippingEstimate($shippingOption)
    {
        if ($shippingOption == '2_4_days_delivery') {
            return 40;
        } else if ($shippingOption == '8_12_days_delivery') {
            return 30;
        } else {
            return 10;
        }
    }

    private function taxCalculation($totalAmount, $taxPercentage)
    {
        return number_format((($totalAmount * $taxPercentage) / 100), 2);
    }

    private function handleStockError($product, $cartItem = null)
    {
        $availableQuantity = $product ? $product->quantity : 0;

        if ($cartItem) {
            $availableQuantity -= $cartItem->quantity;
        }

        return helperJSONResponse(
            false,
            'Not enough stock available for selected product ' . ($product->name ?? '') . '. You can add only ' . max($availableQuantity, 0) . ' more.',
            [],
            409
        );
    }

    private function validateCartQuantityChange($cartItem, $newQuantity, $changeTo)
    {
        if ($changeTo === 'down' && $newQuantity < 1) {
            return helperJSONResponse(
                false,
                'Please remove correct quantity for product ' . ($cartItem->product->name ?? '') . '. ' . $cartItem->quantity . ' in your cart.',
                [],
                400
            );
        }

        if ($changeTo === 'up' && $newQuantity > $cartItem->product->quantity) {
            return helperJSONResponse(
                false,
                'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Maximum available quantity is ' . $cartItem->product->quantity,
                [],
                400
            );
        }

        if ($newQuantity < 1) {
            return helperJSONResponse(false, 'Quantity must be at least 1.', [], 400);
        }

        return null;
    }
}
