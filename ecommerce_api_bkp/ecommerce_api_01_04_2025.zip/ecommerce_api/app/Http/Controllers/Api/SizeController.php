<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Size;
use App\Services\BaseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SizeController extends Controller
{
    protected $baseService;

    public function __construct()
    {
        $this->baseService = new BaseService(new Size());
    }

    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/sizes",
    *     summary="Get all size attributes",
    *     description="Fetches all sizes attributes from the database",
    *     tags={"Size Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="sizes.index",
    *     @OA\Response(
    *         response=200,
    *         description="All size attributes",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All size attributes"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="size",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="size", type="string", example="3XL"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T08:18:08.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T08:18:08.000000Z")
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="No size attributes found",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="No size attributes found")
    *         )
    *     )
    * )
    */
    public function index()
    {
        $size_attributes = array();
        $size_attributes = $this->baseService->getAllRecords();

        if($size_attributes->isEmpty()) {
            return helperJSONResponse(false, 'No size attributes found', [], 404);
        }

        return helperJSONResponse(true, 'All size attributes', ['size' => $size_attributes], 200);
    }

    /**
     * Store a newly created resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/sizes",
    *     summary="Create size attribute",
    *     description="Create size attribute",
    *     tags={"Size Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="sizes.store",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"size"},
    *                   @OA\Property(
    *                       property="size",
    *                       type="string",
    *                       example="3XL"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"size"},
    *                   @OA\Property(
    *                       property="size",
    *                       type="string",
    *                       example="3XL"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=201,
    *         description="Size attribute created successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Size attribute created successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="size",
    *                     type="object",
    *                         @OA\Property(property="size", type="string", example="3XL"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-27T08:21:37.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-27T08:21:37.000000Z"),
    *                         @OA\Property(property="id", type="integer", example=1)
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "size": {"The size field is required."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Size attribute creation failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Size creation failed")
    *         )
    *     )
    * )
    */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'size' => 'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 422);
        }

        $sizeData = array('size' => $request->size);
        $sizeAttribute = $this->baseService->store($sizeData);

        if (!$sizeAttribute) {
            return helperJSONResponse(false, 'Size creation failed', [], 500);
        }

        return helperJSONResponse(true, 'Size attribute created successfully', ['size' => $sizeAttribute], 201);
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/sizes/{id}",
    *     summary="Get single size attribute",
    *     description="Display single size attribute",
    *     tags={"Size Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="sizes.show",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Size attribute id to show that size",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display single size attribute",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Record retrieved"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="single_record",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="size", type="string", example="3XL")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested record not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested record not available")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {
        $fields = array('id', 'size');
        return $this->baseService->getRecordById($id, $fields);
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/sizes/{id}",
    *     summary="Update size attribute",
    *     description="Update size attribute",
    *     tags={"Size Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="sizes.update",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Size attribute id to update that size",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "size"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="size",
    *                       type="string",
    *                       example="3XL"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "size"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="size",
    *                       type="string",
    *                       example="3XL"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Size attribute updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Size attribute updated successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="size",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="size", type="string", example="3XL"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-28T13:07:56.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-28T13:16:41.000000Z"),
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested size attribute is not available for update",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested size attribute is not available for update")
    *         )
    *     ),
    *     @OA\Response(
    *         response=422,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "size": {"The size field is required."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Size attribute update failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Size attribute update failed")
    *         )
    *     )
    * )
    */
    public function update(Request $request, string $id)
    {
        $sizeAttribute = Size::find($id);

        if (!$sizeAttribute) {
            return helperJSONResponse(false, 'Requested size attribute is not available for update', [], 404);
        }

        $validate = Validator::make($request->all(), [
            'size' => 'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 422);
        }          

        $sizeData = array('size' => $request->size);
        $updateSize = $this->baseService->update($id, $sizeData);

        if (!$updateSize) {
            return helperJSONResponse(false, 'Size update failed', [], 500);
        }

        $updatedSizeAttribute = array();
        $updatedSizeAttribute = Size::find($id);

        return helperJSONResponse(true, 'Size attribute updated successfully', ['size' => $updatedSizeAttribute], 200);
    }

    /**
     * Remove the specified resource from storage.
     */

    /**
    * @OA\Delete(
    *     path="/api/admin/sizes/{id}",
    *     summary="Delete size attribute",
    *     description="Delete size attribute",
    *     tags={"Size Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="sizes.destroy",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Size attribute id to delete that size",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Size attribute deleted successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Record deleted successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=404,
    *         description="Requested record not available for deletion",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested record not available for deletion"
    *             )
    *         )
    *     )
    * )
    */
    public function destroy(string $id)
    {
        return $this->baseService->deleteRecordById($id);
    }
}
