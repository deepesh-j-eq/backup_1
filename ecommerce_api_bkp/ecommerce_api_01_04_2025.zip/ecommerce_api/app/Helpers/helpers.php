<?php

if (! function_exists('helperJSONResponse')) {
    function helperJSONResponse($status, $message, $data = [], $statusCode = 200)
    {
        $response = [
            'status' => $status,
            'message' => $message
        ];

        if (!empty($data)) {
            $response[$status ? 'data' : 'errors'] = is_array($data) && isset($data['errors']) ? $data['errors'] : $data;
        }
    
        return response()->json($response, $statusCode);
    }
}
