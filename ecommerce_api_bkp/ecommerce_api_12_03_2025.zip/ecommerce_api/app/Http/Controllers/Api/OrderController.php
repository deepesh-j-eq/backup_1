<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use App\Services\BaseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/orders",
    *     summary="Get all orders",
    *     description="Fetches all orders from the database",
    *     tags={"Orders"},
    *     security={{"bearerAuth": {}}},
    *     operationId="view.user.all.orders",
    *     @OA\Response(
    *         response=200,
    *         description="All orders or No orders. Keep shopping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All orders or No orders. Keep shopping!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="orders",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="total_amount", type="string", example="581.40"),
    *                         @OA\Property(property="shipping_amount", type="string", example="30.00"),
    *                         @OA\Property(property="tax_amount", type="string", example="71.40"),
    *                         @OA\Property(property="order_status_id", type="integer", example=6),
    *                         @OA\Property(property="user_id", type="integer", example=3),
    *                         @OA\Property(property="payment_id", type="integer", example=8),
    *                         @OA\Property(property="updated_by", type="string", example="null"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-10T06:15:24.000000Z"),
    *                         @OA\Property(property="order_sub_total", type="string", example="510.00"),
    *                         @OA\Property(
    *                             property="order_status",
    *                             type="object",
    *                             @OA\Property(property="status", type="string", example="failed")
    *                         ),
    *                         @OA\Property(
    *                             property="payment",
    *                             type="object",
    *                             @OA\Property(property="payment_gateway", type="string", example="Stripe"),
    *                             @OA\Property(property="transaction_id", type="string", example="pi_3R10YK2MdIz6RgJE1FuQqZVP"),
    *                             @OA\Property(property="status", type="string", example="failed"),
    *                             @OA\Property(property="payment_method", type="string", example="pm_card_chargeDeclined"),
    *                             @OA\Property(property="amount", type="string", example="581.40")
    *                         ),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Test 2")
    *                         ),
    *                         @OA\Property(
    *                             property="address",
    *                             type="object",
    *                             @OA\Property(property="order_id", type="integer", example=7),
    *                             @OA\Property(property="first_name", type="string", example="test1_first_name"),
    *                             @OA\Property(property="last_name", type="string", example="test1_last_name"),
    *                             @OA\Property(property="address_line_1", type="string", example="Test 2 Address Line 1"),
    *                             @OA\Property(property="apartment", type="string", example="Test 2 Apartment"),
    *                             @OA\Property(property="address_line_2", type="string", example="Test 2 Address Line 2"),
    *                             @OA\Property(property="city", type="string", example="Vadodara"),
    *                             @OA\Property(property="country", type="string", example="India"),
    *                             @OA\Property(property="state", type="string", example="Gujarat"),
    *                             @OA\Property(property="postal_code", type="integer", example=898963),
    *                             @OA\Property(property="phone", type="integer", example=7744112255),
    *                             @OA\Property(property="email", type="string", example="test2@gmail.com")
    *                         ),
    *                         @OA\Property(
    *                             property="order_items",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="quantity", type="integer", example=1),
    *                                 @OA\Property(property="price", type="string", example="100.00"),
    *                                 @OA\Property(property="product_id", type="integer", example=1),
    *                                 @OA\Property(property="order_id", type="integer", example=1),
    *                                 @OA\Property(property="created_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                                 @OA\Property(property="updated_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                                 @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                 @OA\Property(
    *                                     property="product",
    *                                     type="object",
    *                                     @OA\Property(property="name", type="string", example="Product 1")
    *                                 )
    *                             )
    *                         )
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function index()
    {
        try {
            $orderDetails = $this->getOrderDetails();

            if (!$orderDetails) {
                return helperJSONResponse(true, 'No orders. Keep shopping!', [], 200);
            }

            return helperJSONResponse(true, 'All orders', ['orders' => $orderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/order/{id}",
    *     summary="Get single order",
    *     description="Display single order",
    *     tags={"Orders"},
    *     security={{"bearerAuth": {}}},
    *     operationId="view.user.single.order",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Order id to show that order",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display single order",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single order"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="order_details",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=4),
    *                         @OA\Property(property="total_amount", type="string", example="621.40"),
    *                         @OA\Property(property="shipping_amount", type="string", example="40.00"),
    *                         @OA\Property(property="tax_amount", type="string", example="71.40"),
    *                         @OA\Property(property="order_status_id", type="integer", example=1),
    *                         @OA\Property(property="user_id", type="integer", example=3),
    *                         @OA\Property(property="payment_id", type="integer", example=11),
    *                         @OA\Property(property="updated_by", type="string", example="null"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-10T07:02:28.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-10T07:02:30.000000Z"),
    *                         @OA\Property(property="order_sub_total", type="string", example="510.00"),
    *                         @OA\Property(
    *                             property="order_status",
    *                             type="object",
    *                             @OA\Property(property="status", type="string", example="Created")
    *                         ),
    *                         @OA\Property(
    *                             property="payment",
    *                             type="object",
    *                             @OA\Property(property="payment_gateway", type="string", example="Stripe"),
    *                             @OA\Property(property="transaction_id", type="string", example="pi_3R10LS2MdIz6RgJE0SUXHuSs"),
    *                             @OA\Property(property="status", type="string", example="failed"),
    *                             @OA\Property(property="payment_method", type="string", example="pm_card_chargeDeclined"),
    *                             @OA\Property(property="amount", type="string", example="621.40"),
    *                         ),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Test 2")
    *                         ),
    *                         @OA\Property(
    *                             property="address",
    *                             type="object",
    *                             @OA\Property(property="order_id", type="integer", example=4),
    *                             @OA\Property(property="first_name", type="string", example="test1_first_name"),
    *                             @OA\Property(property="last_name", type="string", example="test1_last_name"),
    *                             @OA\Property(property="address_line_1", type="string", example="Test 2 Address Line 1"),
    *                             @OA\Property(property="apartment", type="string", example="Test 2 Apartment"),
    *                             @OA\Property(property="address_line_2", type="string", example="Test 2 Address Line 2"),
    *                             @OA\Property(property="city", type="string", example="Vadodara"),
    *                             @OA\Property(property="country", type="string", example="India"),
    *                             @OA\Property(property="state", type="string", example="Gujarat"),
    *                             @OA\Property(property="postal_code", type="integer", example=898963),
    *                             @OA\Property(property="phone", type="integer", example=7744112255),
    *                             @OA\Property(property="email", type="string", example="test2@gmail.com")
    *                         ),
    *                         @OA\Property(
    *                             property="order_items",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="quantity", type="integer", example=1),
    *                                 @OA\Property(property="price", type="string", example="100.00"),
    *                                 @OA\Property(property="product_id", type="integer", example=1),
    *                                 @OA\Property(property="order_id", type="integer", example=1),
    *                                 @OA\Property(property="created_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                                 @OA\Property(property="updated_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                                 @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                 @OA\Property(
    *                                     property="product",
    *                                     type="object",
    *                                     @OA\Property(property="name", type="string", example="Product 1")
    *                                 )
    *                             )
    *                        )
    *                  )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested order is not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested order is not available")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {
        try {
            $orderDetails = $this->getOrderDetails($id);

            if (!$orderDetails) {
                return helperJSONResponse(false, 'Requested order is not available', [], 400);
            }

            return helperJSONResponse(true, 'Your single order', ['order_details' => $orderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/order/{id}",
    *     summary="Update order status",
    *     description="Update order status",
    *     tags={"Orders Manage By Admin"},
    *     security={{"bearerAuth": {}}},
    *     operationId="update.order.status",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Order id to update that order status",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "order_status"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="order_status",
    *                       type="string",
    *                       enum={"Created", "Placed", "In Transit", "Shipped", "Canceled", "Payment Failed", "Refunded"},
    *                       example="Created",
    *                       description="Created, Placed, In Transit, Shipped, Canceled, Payment Failed, Refunded"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "order_status"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="order_status",
    *                       type="string",
    *                       nullable=true,
    *                       enum={"Created", "Placed", "In Transit", "Shipped", "Canceled", "Payment Failed", "Refunded"},
    *                       example="Created",
    *                       description="Created, Placed, In Transit, Shipped, Canceled, Payment Failed, Refunded"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Order status updated successfully or No changes in order status, try another order status",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Order status updated successfully or No changes in order status, try another order status"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="order_details",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=5),
    *                         @OA\Property(property="total_amount", type="string", example="427.60"),
    *                         @OA\Property(property="shipping_amount", type="string", example="40.00"),
    *                         @OA\Property(property="tax_amount", type="string", example="47.60"),
    *                         @OA\Property(property="order_status_id", type="integer", example=6),
    *                         @OA\Property(property="user_id", type="integer", example=2),
    *                         @OA\Property(property="payment_id", type="integer", example=10),
    *                         @OA\Property(property="updated_by", type="string", example="null"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-10T07:02:28.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-10T07:02:30.000000Z"),
    *                         @OA\Property(property="order_sub_total", type="string", example="340.00"),
    *                         @OA\Property(
    *                             property="order_status",
    *                             type="object",
    *                             @OA\Property(property="status", type="string", example="Payment Failed")
    *                         ),
    *                         @OA\Property(
    *                             property="payment",
    *                             type="object",
    *                             @OA\Property(property="payment_gateway", type="string", example="Stripe"),
    *                             @OA\Property(property="transaction_id", type="string", example="pi_3R10LS2MdIz6RgJE0SUXHuSs"),
    *                             @OA\Property(property="status", type="string", example="failed"),
    *                             @OA\Property(property="payment_method", type="string", example="pm_card_chargeDeclined"),
    *                             @OA\Property(property="amount", type="string", example="621.40"),
    *                         ),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Test 2")
    *                         ),
    *                         @OA\Property(
    *                             property="address",
    *                             type="object",
    *                             @OA\Property(property="order_id", type="integer", example=4),
    *                             @OA\Property(property="first_name", type="string", example="test1_first_name"),
    *                             @OA\Property(property="last_name", type="string", example="test1_last_name"),
    *                             @OA\Property(property="address_line_1", type="string", example="Test 2 Address Line 1"),
    *                             @OA\Property(property="apartment", type="string", example="Test 2 Apartment"),
    *                             @OA\Property(property="address_line_2", type="string", example="Test 2 Address Line 2"),
    *                             @OA\Property(property="city", type="string", example="Vadodara"),
    *                             @OA\Property(property="country", type="string", example="India"),
    *                             @OA\Property(property="state", type="string", example="Gujarat"),
    *                             @OA\Property(property="postal_code", type="integer", example=898963),
    *                             @OA\Property(property="phone", type="integer", example=7744112255),
    *                             @OA\Property(property="email", type="string", example="test2@gmail.com")
    *                         ),
    *                         @OA\Property(
    *                             property="order_items",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="quantity", type="integer", example=1),
    *                                 @OA\Property(property="price", type="string", example="100.00"),
    *                                 @OA\Property(property="product_id", type="integer", example=1),
    *                                 @OA\Property(property="order_id", type="integer", example=1),
    *                                 @OA\Property(property="created_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                                 @OA\Property(property="updated_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                                 @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                 @OA\Property(
    *                                     property="product",
    *                                     type="object",
    *                                     @OA\Property(property="name", type="string", example="Product 1")
    *                                 )
    *                             )
    *                        )
    *                  )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error or Requested order is not available for update or Invalid order_status.",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error | Requested order is not available for update | Invalid order_status. Allowed values for order payment status 'failed' are: ['Canceled','Payment Failed']"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "order_status": {"The order status field is required.", "The selected order status is invalid."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions. or Unauthorize, admin has only access to update order")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function update(Request $request, string $id)
    {
        try {
            $adminUser = auth('sanctum')->user();
            $adminUserId = $adminUser->id;

            $adminCheck = User::find($adminUserId);

            if(!$adminCheck->isAdmin()) {
                return helperJSONResponse(false, 'Unauthorize, admin has only access to update order', [], 403);
            }

            $validate = Validator::make($request->all(), [
                'order_status' => 'required|string|in:Created,Placed,In Transit,Shipped,Canceled,Payment Failed,Refunded',
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $order = Order::with([
                        'orderStatus:id,status',
                        'payment:id,status',
                        'orderItems:id,product_id'
                    ])
                    ->find($id);

            if (!$order) {
                return helperJSONResponse(false, 'Requested order is not available for update', [], 400);
            }

            $allowedOrderStatuses = $this->getAllowedOrderStatuses($order->payment->status);

            if (!in_array($request->order_status, $allowedOrderStatuses)) {
                return helperJSONResponse(false, "Invalid order_status. Allowed values for order payment status '{$order->payment->status}' are: " . json_encode($allowedOrderStatuses), [], 400);
            }

            $updateOrderData = array();

            if ($request->order_status != $order->orderStatus->status) {
                $newOrderStatusId = OrderStatus::where('status', $request->order_status)->pluck('id')->first();
                $updateOrderData['order_status_id'] = $newOrderStatusId;
            }

            if (!empty($updateOrderData)) {
                $updateOrderData['updated_by'] = $adminUserId;
                $order->update($updateOrderData);
            }

            if ($order->payment->status === 'refunded' ||  ($order->payment->status === 'succeeded' && $order->order_status_id == 5)) {
                foreach ($order->orderItems as $orderItem) {
                    $product = Product::find($orderItem->product_id);

                    if ($product) {
                        // $product->quantity += $orderItem->quantity;
                        // $product->save();
                    }
                }
            }

            $updatedOrderDetails = $this->getOrderDetails($id);

            if (!$updatedOrderDetails) {
                return helperJSONResponse(false, 'Something went wrong! Order detail is not available after update', [], 400);
            }

            $responseMessage = empty($updateOrderData) 
                                ? "No changes in order status, try another order status" 
                                : "Order status updated successfully";

            return helperJSONResponse(true, $responseMessage, ['order_details' => $updatedOrderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/orders_with_filter",
    *     summary="Get orders after applying filter",
    *     description="Display orders after applying filter",
    *     tags={"Orders"},
    *     security={{"bearerAuth": {}}},
    *     operationId="orders.with.filter",
    *     @OA\RequestBody(
    *           required=false,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   @OA\Property(
    *                       property="order_status",
    *                       type="string",
    *                       nullable=true,
    *                       enum={"Created", "Placed", "In Transit", "Shipped", "Canceled", "Payment Failed", "Refunded"},
    *                       example="Created",
    *                       description="Created, Placed, In Transit, Shipped, Canceled, Payment Failed, Refunded"
    *                   ),
    *                   @OA\Property(
    *                       property="payment_status",
    *                       type="string",
    *                       nullable=true,
    *                       enum={"pending", "requires_payment_method", "failed", "succeeded", "refunded"},
    *                       example="succeeded",
    *                       description="pending, requires_payment_method, failed, succeeded, refunded"
    *                   ),
    *                   @OA\Property(
    *                       property="city",
    *                       type="string",
    *                       nullable=true,
    *                       example="Vadodara"
    *                   ),
    *                   @OA\Property(
    *                       property="state",
    *                       type="string",
    *                       nullable=true,
    *                       example="Gujarat"
    *                   ),
    *                   @OA\Property(
    *                       property="country",
    *                       type="string",
    *                       nullable=true,
    *                       example="India"
    *                   ),
    *                   @OA\Property(
    *                       property="order_total_min",
    *                       type="number",
    *                       format="double",
    *                       nullable=true,
    *                       example=100.00
    *                   ),
    *                   @OA\Property(
    *                       property="order_total_max",
    *                       type="number",
    *                       format="double",
    *                       nullable=true,
    *                       example=999.00
    *                   ),
    *                   @OA\Property(
    *                       property="user_id",
    *                       type="integer",
    *                       nullable=true,
    *                       example=3
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   @OA\Property(
    *                       property="order_status",
    *                       type="string",
    *                       nullable=true,
    *                       enum={"Created", "Placed", "In Transit", "Shipped", "Canceled", "Payment Failed", "Refunded"},
    *                       example="Created",
    *                       description="Created, Placed, In Transit, Shipped, Canceled, Payment Failed, Refunded"
    *                   ),
    *                   @OA\Property(
    *                       property="payment_status",
    *                       type="string",
    *                       nullable=true,
    *                       enum={"pending", "requires_payment_method", "failed", "succeeded", "refunded"},
    *                       example="succeeded",
    *                       description="pending, requires_payment_method, failed, succeeded, refunded"
    *                   ),
    *                   @OA\Property(
    *                       property="city",
    *                       type="string",
    *                       nullable=true,
    *                       example="Vadodara"
    *                   ),
    *                   @OA\Property(
    *                       property="state",
    *                       type="string",
    *                       nullable=true,
    *                       example="Gujarat"
    *                   ),
    *                   @OA\Property(
    *                       property="country",
    *                       type="string",
    *                       nullable=true,
    *                       example="India"
    *                   ),
    *                   @OA\Property(
    *                       property="order_total_min",
    *                       type="number",
    *                       format="double",
    *                       nullable=true,
    *                       example=100.00
    *                   ),
    *                   @OA\Property(
    *                       property="order_total_max",
    *                       type="number",
    *                       format="double",
    *                       nullable=true,
    *                       example=999.00
    *                   ),
    *                   @OA\Property(
    *                       property="user_id",
    *                       type="integer",
    *                       nullable=true,
    *                       example=3
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Orders after applying filter",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single order"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="order_details",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=4),
    *                         @OA\Property(property="total_amount", type="string", example="621.40"),
    *                         @OA\Property(property="shipping_amount", type="string", example="40.00"),
    *                         @OA\Property(property="tax_amount", type="string", example="71.40"),
    *                         @OA\Property(property="order_status_id", type="integer", example=1),
    *                         @OA\Property(property="user_id", type="integer", example=3),
    *                         @OA\Property(property="payment_id", type="integer", example=11),
    *                         @OA\Property(property="updated_by", type="string", example="null"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-10T07:02:28.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-10T07:02:30.000000Z"),
    *                         @OA\Property(property="order_sub_total", type="string", example="510.00"),
    *                         @OA\Property(
    *                             property="order_status",
    *                             type="object",
    *                             @OA\Property(property="status", type="string", example="Created")
    *                         ),
    *                         @OA\Property(
    *                             property="payment",
    *                             type="object",
    *                             @OA\Property(property="payment_gateway", type="string", example="Stripe"),
    *                             @OA\Property(property="transaction_id", type="string", example="pi_3R10LS2MdIz6RgJE0SUXHuSs"),
    *                             @OA\Property(property="status", type="string", example="failed"),
    *                             @OA\Property(property="payment_method", type="string", example="pm_card_chargeDeclined"),
    *                             @OA\Property(property="amount", type="string", example="621.40"),
    *                         ),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Test 2")
    *                         ),
    *                         @OA\Property(
    *                             property="address",
    *                             type="object",
    *                             @OA\Property(property="order_id", type="integer", example=4),
    *                             @OA\Property(property="first_name", type="string", example="test1_first_name"),
    *                             @OA\Property(property="last_name", type="string", example="test1_last_name"),
    *                             @OA\Property(property="address_line_1", type="string", example="Test 2 Address Line 1"),
    *                             @OA\Property(property="apartment", type="string", example="Test 2 Apartment"),
    *                             @OA\Property(property="address_line_2", type="string", example="Test 2 Address Line 2"),
    *                             @OA\Property(property="city", type="string", example="Vadodara"),
    *                             @OA\Property(property="country", type="string", example="India"),
    *                             @OA\Property(property="state", type="string", example="Gujarat"),
    *                             @OA\Property(property="postal_code", type="integer", example=898963),
    *                             @OA\Property(property="phone", type="integer", example=7744112255),
    *                             @OA\Property(property="email", type="string", example="test2@gmail.com")
    *                         ),
    *                         @OA\Property(
    *                             property="order_items",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="quantity", type="integer", example=1),
    *                                 @OA\Property(property="price", type="string", example="100.00"),
    *                                 @OA\Property(property="product_id", type="integer", example=1),
    *                                 @OA\Property(property="order_id", type="integer", example=1),
    *                                 @OA\Property(property="created_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                                 @OA\Property(property="updated_at", type="string", example="2025-03-10T06:15:19.000000Z"),
    *                                 @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                 @OA\Property(
    *                                     property="product",
    *                                     type="object",
    *                                     @OA\Property(property="name", type="string", example="Product 1")
    *                                 )
    *                             )
    *                        )
    *                  )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "payment_status": {"The selected payment status is invalid."},
    *                       "order_total_min": {"The order total min field must be at least 0.", "The order total min field format is invalid."},
    *                       "city": {"The city field format is invalid."},
    *                       "state": {"The state field format is invalid."},
    *                       "country": {"The country field format is invalid."},
    *                       "user_id": {"The selected user id is invalid."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function ordersWithFilter(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'order_status' => 'nullable|string',
                'payment_status' => 'nullable|string|in:pending,requires_payment_method,failed,succeeded,refunded',
                'city' => 'nullable|string|max:191|regex:/[a-zA-Z]+/',
                'state' => 'nullable|string|max:191|regex:/[a-zA-Z]+/',
                'country' => 'nullable|string|max:191|regex:/[a-zA-Z]+/',
                'order_total_min' => 'nullable|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
                'order_total_max' => 'nullable|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
                'user_id' => 'nullable|exists:users,id'
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $orderStatusId = '';

            if ($request->has('order_status') && $request->order_status !== null) {
                $orderStatusId = OrderStatus::where('status', $request->order_status)->pluck('id')->first();
            }

            $orderQuery = Order::query();
        
            if ($orderStatusId != '' && $orderStatusId !== null) {
                $orderQuery->where('order_status_id', $orderStatusId);
            }
        
            if ($request->has('payment_status') && $request->payment_status !== null) {
                $orderQuery->whereHas('payment', function ($query) use ($request) {
                    $query->where('status', $request->payment_status);
                });
            }

            if ($request->has('city') && $request->city !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('city', 'LIKE', "%{$request->city}%");
                });
            }

            if ($request->has('state') && $request->state !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('state', 'LIKE', "%{$request->state}%");
                });
            }

            if ($request->has('country') && $request->country !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('country', 'LIKE', "%{$request->country}%");
                });
            }

            if ($request->has('order_total_min') && $request->order_total_min !== null) {
                $orderQuery->where('total_amount', '>=', $request->order_total_min);
            }

            if ($request->has('order_total_max') && $request->order_total_max !== null) {
                $orderQuery->where('total_amount', '<=', $request->order_total_max);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            if($user->isUser()) {
                $orderQuery->where('user_id', $authenticatedUserId);
            }

            if($user->isAdmin()) {
                if ($request->has('user_id') && $request->user_id !== null) {
                    $orderQuery->where('user_id', $request->user_id);
                }
            }

            $orderDetails = $orderQuery->with([
                'orderStatus:id,status',
                'payment:id,payment_gateway,transaction_id,status,payment_method,amount',
                'user:id,name',
                'address:id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email,order_id',
                'orderItems.product:id,name'
            ])->get();

            if ($orderDetails->isEmpty()) {
                return helperJSONResponse(true, 'Sorry! No order available, please apply different filter', [], 200);
            }

            foreach ($orderDetails as $order) {
                $this->formatOrderResponse($order, $user);
            }

            return helperJSONResponse(true, 'Orders after applying filters', ['order_details' => $orderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $baseService = new BaseService(new Order());
        return $baseService->deleteRecordById($id);
    }

    private function getOrderDetails($specificOrderId = null)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            $ordersQuery = Order::with([
                'orderStatus:id,status',
                'payment:id,payment_gateway,transaction_id,status,payment_method,amount',
                'user:id,name',
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderItems.product:id,name'
            ]);

            if ($user->isUser()) {
                $ordersQuery->where('user_id', $authenticatedUserId);
            }

            if (!empty($specificOrderId)) {
                $order = $ordersQuery->find($specificOrderId);
        
                if (!$order) {
                    return false;
                }

                return $this->formatOrderResponse($order, $user);
            }

            $orders = $ordersQuery->get();

            if ($orders->isEmpty()) {
                return false;
            }

            foreach ($orders as $order) {
                $this->formatOrderResponse($order, $user);
            }

            return $orders;
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    private function formatOrderResponse(Order $order, User $user)
    {
        try {
            if ($user->isUser()) {
                $order->makeHidden(['user_id', 'order_status_id', 'payment_id', 'updated_by']);
            }

            $order->orderStatus->makeHidden(['id']);
            $order->payment->makeHidden(['id']);
            $order->user->makeHidden(['id']);
            $order->address->makeHidden(['id']);

            $orderSubTotal = 0.00;

            foreach ($order->orderItems as $orderItem) {
                $orderItem->makeHidden(['id']);

                if ($user->isUser()) {
                    $orderItem->makeHidden(['product_id', 'created_at', 'updated_at']);
                }

                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;

                $subTotal = $price * $quantity;
                $orderSubTotal += $subTotal;

                $orderItem->sub_total = number_format($subTotal, 2);

                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            }

            $order->order_sub_total = number_format($orderSubTotal, 2);

            return $order;
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    private function getAllowedOrderStatuses(string $paymentStatus)
    {
        $allowedStatuses = [
            'succeeded' => ["Created", "Placed", "In Transit", "Shipped", "Completed"],
            'pending'   => ["Canceled", "Payment Failed"],
            'failed'    => ["Canceled", "Payment Failed"],
            'refunded'  => ["Refunded"]
        ];

        return $allowedStatuses[$paymentStatus] ?? [];
    }
}
