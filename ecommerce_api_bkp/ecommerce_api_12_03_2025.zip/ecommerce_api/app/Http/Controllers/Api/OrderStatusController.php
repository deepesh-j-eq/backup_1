<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\OrderStatus;
use App\Services\BaseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderStatusController extends Controller
{
    protected $baseService;

    public function __construct()
    {
        $this->baseService = new BaseService(new OrderStatus());
    }

    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/orderStatus",
    *     summary="Get all order statuses",
    *     description="Fetches all order status from the database",
    *     tags={"Order Status"},
    *     security={{"bearerAuth": {}}},
    *     operationId="orderStatus.index",
    *     @OA\Response(
    *         response=200,
    *         description="All order statuses or No order status created",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All order statuses or No order status created"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="order_statuses",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="status", type="string", example="Placed"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-24T05:01:12.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-24T05:01:12.000000Z")
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function index()
    {
        $orderStatuses = array();
        $orderStatuses = $this->baseService->getAllRecords();

        if($orderStatuses->isEmpty()) {
            return helperJSONResponse(true, 'No order status created', [], 200);
        }

        return helperJSONResponse(true, 'All order status', ['order_statuses' => $orderStatuses], 200);
    }

    /**
     * Store a newly created resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/orderStatus",
    *     summary="Create order status",
    *     description="Create order status",
    *     tags={"Order Status"},
    *     security={{"bearerAuth": {}}},
    *     operationId="orderStatus.store",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"status"},
    *                   @OA\Property(
    *                       property="status",
    *                       type="string",
    *                       example="Under process"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"status"},
    *                   @OA\Property(
    *                       property="status",
    *                       type="string",
    *                       example="Under process"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Order status created successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Order status created successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="order_status",
    *                     type="object",
    *                         @OA\Property(property="status", type="string", example="Under process"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-03T06:18:42.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-03T06:18:42.000000Z"),
    *                         @OA\Property(property="id", type="integer", example=1)
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "status": {"The status field is required.", "The status field must be at least 3 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Order status create failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Order status create failed")
    *         )
    *     )
    * )
    */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'status' => 'required|string|min:3|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
        }

        $orderStatusData = array('status' => $request->status);
        $orderStatus = $this->baseService->store($orderStatusData);

        if (!$orderStatus) {
            return helperJSONResponse(false, 'Order status create failed', [], 500);
        }

        return helperJSONResponse(true, 'Order status created successfully', ['order_status' => $orderStatus], 200);
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/orderStatus/{id}",
    *     summary="Get single order status",
    *     description="Display single order status",
    *     tags={"Order Status"},
    *     security={{"bearerAuth": {}}},
    *     operationId="orderStatus.show",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Order status id to show that order status",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display single order status",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Record retrieved"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="single_record",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="status", type="string", example="Under process")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested record not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested record not available")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {
        $fields = array('id', 'status');
        return $this->baseService->getRecordById($id, $fields);
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/orderStatus/{id}",
    *     summary="Update order status",
    *     description="Update order status",
    *     tags={"Order Status"},
    *     security={{"bearerAuth": {}}},
    *     operationId="orderStatus.update",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Order status to update that order status",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "status"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="status",
    *                       type="string",
    *                       example="Partial order"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="status",
    *                       type="string",
    *                       example="Partial order"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Order status updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Order status updated successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="order_status",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="status", type="string", example="Partial order"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-03T06:18:42.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-03T06:20:42.000000Z"),
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error or Requested order status is not available for update",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error | Requested order status is not available for update"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "status": {"The status field is required.", "The status field must be at least 3 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Order status updatation failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Order status updatation failed")
    *         )
    *     )
    * )
    */
    public function update(Request $request, string $id)
    {
        $orderStatus = OrderStatus::find($id);

        if (!$orderStatus) {
            return helperJSONResponse(false, 'Requested order status is not available for update', [], 400);
        }

        $validate = Validator::make($request->all(), [
            'status' => 'required|string|min:3|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
        }

        $orderStatusData = array('status' => $request->status);
        $updateOrderStatus = $this->baseService->update($id, $orderStatusData);

        if (!$updateOrderStatus) {
            return helperJSONResponse(false, 'Order status updatation failed', [], 500);
        }

        $updatedOrderStatusData = array();
        $updatedOrderStatusData = OrderStatus::find($id);

        return helperJSONResponse(true, 'Order status updated successfully', ['order_status' => $updatedOrderStatusData], 200);
    }

    /**
     * Remove the specified resource from storage.
     */

    /**
    * @OA\Delete(
    *     path="/api/admin/orderStatus/{id}",
    *     summary="Delete order status",
    *     description="Delete order status",
    *     tags={"Order Status"},
    *     security={{"bearerAuth": {}}},
    *     operationId="orderStatus.destroy",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Order status id to delete that order status",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Order status deleted successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Record deleted successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested record not available for deletion",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested record not available for deletion"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function destroy(string $id)
    {
        return $this->baseService->deleteRecordById($id);
    }
}
