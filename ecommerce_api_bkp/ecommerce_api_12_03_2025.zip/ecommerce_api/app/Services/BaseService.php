<?php

namespace App\Services;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Collection;

class BaseService
{
    protected $model;

    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    public function getAllRecords()
    {
        return $this->model->all();
    }

    public function store(array $data)
    {
        $record = $this->model->firstOrCreate($data);

        if (!$record) {
            return false;
        }

        return $record;
    }

    public function getRecordById(string $id, array $columns = ['*'])
    {
        $record = $this->model->select($columns)->where('id', $id)->first();

        if (!$record) {
            return helperJSONResponse(false, 'Requested record not available', [], 400);
        }

        return helperJSONResponse(true, 'Record retrieved', ['single_record' => $record], 200);
    }

    public function update(string $id, array $data)
    {
        $record = $this->model->find($id);
        if (!$record) {
            return false;
        }

        $updateSuccess = $record->update($data);
        if (!$updateSuccess) {
            return false;
        }

        return true;
    }

    public function deleteRecordById(string $id)
    {
        $record = $this->model->find($id);

        if (!$record) {
            return helperJSONResponse(false, 'Requested record not available for deletion', [], 400);
        }

        $record->delete();

        return helperJSONResponse(true, 'Record deleted successfully', [], 200);
    }

    public function storeWithoutFirst(array $data)
    {
        $record = $this->model->create($data);

        if (!$record) {
            return false;
        }

        return $record;
    }
}
