<?php

namespace App\Services;

use App\Enums\HttpStatusCode;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Collection;

class BaseService
{
    protected $model;

    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    public function getAllRecords()
    {
        return $this->model->all();
    }

    public function store(array $data)
    {
        $record = $this->model->firstOrCreate($data);

        if (!$record) {
            return false;
        }

        return $record;
    }

    public function getRecordById(string $id, array $columns = ['*'])
    {
        $record = $this->model->select($columns)->where('id', $id)->first();

        if (!$record) {
            return helperJSONResponse(false, 'Requested record not available', [], HttpStatusCode::NOT_FOUND->value);
        }

        return helperJSONResponse(true, 'Record retrieved', ['single_record' => $record], HttpStatusCode::OK->value);
    }

    public function update(string $id, array $data)
    {
        $record = $this->model->find($id);
        if (!$record) {
            return false;
        }

        $updateSuccess = $record->update($data);
        if (!$updateSuccess) {
            return false;
        }

        return true;
    }

    public function deleteRecordById(string $id)
    {
        $record = $this->model->find($id);

        if (!$record) {
            return helperJSONResponse(false, 'Requested record not available for deletion', [], HttpStatusCode::NOT_FOUND->value);
        }

        $record->delete();

        return helperJSONResponse(true, 'Record deleted successfully', [], HttpStatusCode::OK->value);
    }

    public function storeWithoutFirst(array $data)
    {
        $record = $this->model->create($data);

        if (!$record) {
            return false;
        }

        return $record;
    }

    public function getOrderStatusId(string $status)
    {
        $orderStatus = $this->model->where('status', $status)->first();

        if ($orderStatus) {
            return $orderStatus->id;
        } else {
            return false;
        }
    }
}
