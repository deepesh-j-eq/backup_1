<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\ColorController;
use App\Http\Controllers\Api\ContactMessageController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\OrderStatusController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\RatingController;
use App\Http\Controllers\Api\SizeController;
use App\Http\Controllers\Api\StripePaymentController;
use App\Http\Controllers\Api\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::controller(AuthController::class)->group(function() {
    Route::post('signup', 'signup')->name('signup');
    Route::post('login', 'login')->name('login');
});

//Route::middleware('throttle:10,1')->controller(RatingController::class)->group(function() {
Route::middleware(['throttle:public'])->group(function() {
    Route::controller(RatingController::class)
        ->prefix('ratings')
        ->name('get.')
        ->group(function() {
            Route::get('/', 'index')->name('all.ratings');
            Route::get('{id}', 'show')->name('single.rating');
    });

    Route::post('contact', [ContactMessageController::class, 'store'])->name('create.contact.message');
});

Route::post('stripe-webhook', [StripePaymentController::class, 'handleWebhook'])->name('handle.webhook');

Route::middleware('auth:sanctum')->group(function() {
    Route::post('logout', [AuthController::class, 'logout'])->name('logout');

    Route::controller(ProductController::class)->group(function() {
        Route::prefix('products')->name('get.')->group(function() {
            Route::get('/', 'index')->name('all.products');
            Route::get('{id}', 'show')->name('single.product');
        });

        Route::post('products-with-filter', 'productsWithFilter')->name('products.with.filter');
    });

    Route::match(['PUT', 'PATCH'], 'ratings/{id}', [RatingController::class, 'update'])->name('update.rating');

    Route::controller(OrderController::class)->group(function() {
        Route::name('view.')->group(function() {
            Route::get('orders', 'index')->name('all.orders');
            Route::get('order/{id}', 'show')->name('single.order');
        });

        Route::post('orders-with-filter', 'ordersWithFilter')->name('orders.with.filter');
    });

    Route::middleware('role:admin')->prefix('admin')->group(function() {
        Route::apiResource('category', CategoryController::class);
        Route::apiResource('sizes', SizeController::class);
        Route::apiResource('colors', ColorController::class);
        Route::apiResource('orderStatus', OrderStatusController::class);

        Route::controller(ProductController::class)
            ->prefix('products')
            ->name('product.')
            ->group(function() {
                Route::post('/', 'store')->name('store');
                Route::match(['PUT', 'PATCH'], '{id}', 'update')->name('update');
                Route::delete('{id}', 'destroy')->name('delete');
        });

        Route::delete('ratings/{id}', [RatingController::class, 'destroy'])->name('rating.delete');

        Route::controller(OrderController::class)
            ->prefix('order')
            ->group(function() {
                Route::match(['PUT', 'PATCH'], '{id}', 'update')->name('update.order.status');
                Route::delete('{id}', 'destroy')->name('order.delete');
        });

        Route::controller(ContactMessageController::class)
            ->prefix('contact-messages')
            ->group(function() {
                Route::get('/', 'index')->name('all.contact.messages');
                Route::get('{id}', 'show')->name('single.contact.message');
        });

        Route::controller(UserController::class)->group(function() {
            Route::prefix('users')->group(function() {
                Route::get('/', 'index')->name('all.users');
                Route::post('{id}', 'show')->name('single.user');
            });

            Route::get('users-with-trashed', 'allUsersIncludingTrashed')->name('all.users.inclding.trashed');
            Route::post('restore-user', 'restoreSoftDeletedUser')->name('restore.soft.deleted.user');
        });
    });

    Route::middleware('role:user')->group(function() {
        Route::controller(CartController::class)
            ->prefix('cart')
            ->group(function() {
                Route::get('/', 'viewCart')->name('view.cart.items');
                Route::post('add', 'addToCart')->name('add.to.cart');
                Route::post('change-quantity/{id}', 'changeCartQuantity')->name('change.cart.qty');
                Route::delete('{id}', 'removeFromCart')->name('remove.cart.item');
                Route::post('remove-cart', 'removeAllProductsFromCart')->name('remove.all.cart.items');
                Route::post('checkout', 'checkout')->name('checkout');
        });

        Route::post('ratings', [RatingController::class, 'store'])->name('create.rating');

        Route::post('contact/authUser', [ContactMessageController::class, 'store'])->name('create.contact.message.auth.user');

        Route::controller(UserController::class)
            ->name('user.')
            ->group(function() {
                Route::get('profile', 'showUserProfile')->name('profile');
                Route::match(['PUT', 'PATCH'], 'update-user-profile', 'updateUserProfile')->name('profile.update');
                Route::delete('delete-user-account', 'destroy')->name('account.delete');
        });
    });
});
