<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Color;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ColorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = array();
        $data['color_attribute'] = Color::all();

        return response()->json([
            'staus' => true,
            'message' => 'All color attributes',
            'data' => $data,
        ],200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'color'=>'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }
        
        $colorAttribute = Color::create([
            'color' => $request->color
        ]);

        if (!$colorAttribute) {
            return response()->json([
                'status' => false,
                'message' => 'Color create failed',
            ], 500);
        }

        return response()->json([
            'status' => true,
            'message' => 'Color attribute created successfully',
            'color' => $colorAttribute
        ], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $data = array();

        $data['color_attribute'] = Color::select(
            'id',
            'color'
        )->where('id', $id)->first();

        if ($data['color_attribute'] == null) {
            return response()->json([
                'status' => false,
                'message' => 'Requested color attribute is not available'
            ], 400);
        }

        return response()->json([
            'status' => true,
            'message' => 'Your single color attribute',
            'data' => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $colorAttribute = Color::find($id);

        if (!$colorAttribute) {
            return response()->json([
                'status' => false,
                'message' => 'Requested color attribute is not available for update'
            ], 400);
        }

        $validate = Validator::make($request->all(), [
            'color'=>'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }

        $updateColor = Color::where('id', $id)->update([
            'color' => $request->color
        ]);

        if (!$updateColor) {
            return response()->json([
                'status' => false,
                'message' => 'Color update failed',
            ], 500);
        }

        $data = array();
        $data['color_attribute'] = Color::find($id);

        return response()->json([
            'status' => true,
            'message' => 'Color attribute updated successfully',
            'color' => $data
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $color = Color::find($id);

        if (!$color) {
            return response()->json([
                'status' => false,
                'message' => 'Requested color attribute is not available for delete',
            ], 400);
        }

        $color->delete();

        return response()->json([
            'status' => true,
            'message' => 'Color attribute deleted successfully',
        ], 200);
    }
}
