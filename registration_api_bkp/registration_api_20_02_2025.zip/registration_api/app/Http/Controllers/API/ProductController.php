<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Color;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Rating;
use App\Models\Size;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $products = Product::with([
                'category', 
                'ratings', 
                'images' => function ($query) {
                    $query->limit(1);
                },
                'colors', 
                'sizes'
            ])->get();
            
            $products->transform(function ($product) {
                $averageRating = $product->ratings->avg('rating');
                $product->average_rating = number_format($averageRating, 1);

                $product->colors = $product->colors->makeHidden(['created_at', 'updated_at']);
                $product->sizes = $product->sizes->makeHidden(['created_at', 'updated_at']);

                return $product;
            });
            
            $data['products'] = $products;
            
            return response()->json([
                'status' => true,
                'message' => 'All products',
                'data' => $data,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'name' => 'required|string|max:191',
                'description' => 'required|string|max:255',
                'price' => 'required|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
                'quantity' => 'required|integer|min:0',
                'category_id' => 'required|integer|exists:categories,id',
                'size_ids' => 'nullable|string',
                'color_ids' => 'nullable|string',
                'images' => 'required|array',
                'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
            ]);
            

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $errors = array();
            $sizeIds = array();
            $colorIds = array();

            if ($request->size_ids != null) {
                $sizeIds = explode(',', $request->size_ids);
                foreach ($sizeIds as $sizeId) {
                    if (!Size::where('id', $sizeId)->exists()) {
                        $errors['size_id'][] = "Size ID $sizeId does not exist in the sizes table.";
                    }
                }
            }

            if ($request->color_ids != null) {
                $colorIds = explode(',', $request->color_ids);
                foreach ($colorIds as $colorId) {
                    if (!Color::where('id', $colorId)->exists()) {
                        $errors['color_id'][] = "Color ID $colorId does not exist in the colors table.";
                    }
                }
            }

            if (!empty($errors)) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $errors
                ], 400);
            }

            $product = Product::create([
                'name' => $request->name,
                'description' => $request->description,
                'price' => $request->price,
                'quantity' => $request->quantity,
                'category_id' => $request->category_id
            ]);

            if (!empty($sizeIds)) {
                $product->sizes()->syncWithPivotValues($sizeIds, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
            }

            if (!empty($colorIds)) {
                $product->colors()->syncWithPivotValues($colorIds, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
            }

            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $image) {
                    $path = $image->store('product_images', 'public');

                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $product->id
                    ]);
                }
            }

            return response()->json([
                'staus' => true,
                'message' => 'Product created successfully',
                'product' => $product,
            ],200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $data = array();

            $product = Product::with([
                'category', 
                'ratings', 
                'images' => function ($query) {
                    $query->limit(1);
                },
                'colors',
                'sizes'
            ])->find($id);

            if ($product == null) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested product is not available'
                ], 400);
            }

            $product->colors = $product->colors->makeHidden(['created_at', 'updated_at']);
            $product->sizes = $product->sizes->makeHidden(['created_at', 'updated_at']);

            $product->rating = number_format($product->ratings->avg('rating'), 1);
            
            $data['product'] = $product;
            
            return response()->json([
                'status' => true,
                'message' => 'Your single product',
                'data' => $data,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $product = Product::find($id);

            if (!$product) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested product not available for update'
                ], 404);
            }

            $validate = Validator::make($request->all(), [
                'name' => 'required|string|max:191',
                'description' => 'required|string|max:255',
                'price' => 'required|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
                'quantity' => 'required|integer|min:0',
                'category_id' => 'required|integer|exists:categories,id',
                'size_ids' => 'nullable|string',
                'color_ids' => 'nullable|string',
                'images' => 'nullable|array',
                'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $errors = array();
            $sizeIds = array();
            $colorIds = array();

            if ($request->size_ids != null) {
                $sizeIds = explode(',', $request->size_ids);
                foreach ($sizeIds as $sizeId) {
                    if (!Size::where('id', $sizeId)->exists()) {
                        $errors['size_id'][] = "Size ID $sizeId does not exist in the sizes table.";
                    }
                }
            }

            if ($request->color_ids != null) {
                $colorIds = explode(',', $request->color_ids);
                foreach ($colorIds as $colorId) {
                    if (!Color::where('id', $colorId)->exists()) {
                        $errors['color_id'][] = "Color ID $colorId does not exist in the colors table.";
                    }
                }
            }

            if (!empty($errors)) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $errors
                ], 400);
            }

            $product->update([
                'name' => $request->name,
                'description' => $request->description,
                'price' => $request->price,
                'quantity' => $request->quantity,
                'category_id' => $request->category_id
            ]);

            if (!empty($sizeIds)) {
                $product->sizes()->syncWithPivotValues($sizeIds, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
            }

            if (!empty($colorIds)) {
                $product->colors()->syncWithPivotValues($colorIds, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
            }

            if ($request->hasFile('images')) {
                foreach ($product->images as $image) {
                    Storage::disk('public')->delete($image->image_path);
                    $image->delete();
                }

                foreach ($request->file('images') as $image) {
                    $path = $image->store('product_images', 'public');
        
                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $product->id
                    ]);
                }
            }

            return response()->json([
                'status' => true,
                'message' => 'Product updated successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $product = Product::find($id);

            if (!$product) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested product not available for delete',
                ], 400);
            }

            foreach ($product->images as $image) {
                Storage::disk('public')->delete($image->image_path);
                $image->delete();
            }

            $product->sizes()->detach();
            $product->colors()->detach();

            $product->delete();

            return response()->json([
                'status' => true,
                'message' => 'Product deleted successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }


    /**
     * Display a listing of the resource after applying filters.
     */
    public function productsWithFilter(Request $request)
    {
        try {
            $query = Product::query();
        
            if ($request->has('category_id') && $request->category_id !== null) {
                $categoryIds = explode(',', $request->category_id);
                $validCategoryIds = Category::whereIn('id', $categoryIds)->pluck('id')->toArray();
                
                if (!empty($validCategoryIds)) {
                    $query->whereIn('category_id', $validCategoryIds);
                }
            }
        
            if ($request->has('min_price') && $request->min_price !== null) {
                $query->where('price', '>=', $request->min_price);
            }

            if ($request->has('max_price') && $request->max_price !== null) {
                $query->where('price', '<=', $request->max_price);
            }

            if ($request->has('sort_by') && $request->sort_by !== null) {
                switch ($request->sort_by) {
                    case 'most_popular':
                        $query->orderBy('popularity', 'desc');
                        break;
                    case 'best_rating':
                        $query->withAvg('ratings', 'rating')->orderByDesc('ratings_avg_rating');
                        //$query->orderBy('rating', 'desc');
                        break;
                    case 'newest':
                        $query->orderBy('created_at', 'desc');
                        break;
                    case 'price_low_high':
                        $query->orderBy('price', 'asc');
                        break;
                    case 'price_high_low':
                        $query->orderBy('price', 'desc');
                        break;
                    default:
                        $query->orderBy('created_at', 'desc');
                }
            }

            //\Illuminate\Support\Facades\DB::enableQueryLog();

            $products = $query->with([
                'images' => function ($query) {
                    $query->limit(1);
                }
            ])->get();

            //dd(\Illuminate\Support\Facades\DB::getQueryLog());

            /* array:2 [ // app\Http\Controllers\API\ProductController.php:387
                0 => array:3 [
                "query" => "select `products`.*, (select avg(`ratings`.`rating`) from `ratings` where `products`.`id` = `ratings`.`product_id`) as `ratings_avg_rating` from `products` where `category_id` in (?, ?) order by `ratings_avg_rating` desc"
                "bindings" => array:2 [
                    0 => 1
                    1 => 2
                ]
                "time" => 0.84
                ]
                1 => array:3 [
                "query" => "select * from (select *, row_number() over (partition by `product_images`.`product_id`) as `laravel_row` from `product_images` where `product_images`.`product_id` in (1, 5, 6)) as `laravel_table` where `laravel_row` <= 1 order by `laravel_row`"
                "bindings" => []
                "time" => 0.53
                ]
            ] */

            $products->transform(function ($product) {
                $averageRating = $product->ratings->avg('rating');
                $product->average_rating = number_format($averageRating, 1);

                $product->makeHidden(['ratings']);
            
                return $product;
            });

            if ($products->isNotEmpty()) {
                return response()->json([
                    'status' => true,
                    'message' => 'Products after applying filters',
                    'products' => $products,
                ], 200);
            }

            return response()->json([
                'status' => true,
                'message' => 'Sorry! No product available, please apply different filter'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }
}
