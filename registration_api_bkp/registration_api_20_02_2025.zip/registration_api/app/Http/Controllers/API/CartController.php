<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    public function viewCart(Request $request)
    {
        try {
            $user = auth('sanctum')->user();
            $data = array();

            $data['cart_items'] = Cart::with(['product' => function ($query) {
                                    $query->select(['id', 'name', 'description', 'price']);
                                }])
                            ->where('user_id', $user->id)
                            ->get()
                            ->makeHidden(['user_id']);

            if ($data['cart_items']->isNotEmpty()) {
                return response()->json([
                    'status' => true,
                    'message' => 'Your cart',
                    'cart' => $data
                ], 200);
            }

            return response()->json([
                'status' => true,
                'message' => 'No product added to cart, keep shoppping!'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function addToCart(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'product_id' => 'required|integer|exists:products,id',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $user = auth('sanctum')->user();
            $productId = $request->product_id;
            $quantity = $request->quantity;

            $product = Product::find($productId);
            if (!$product || $quantity > $product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not enough stock available for product ' . ($product->name ?? '')
                ], 400);
            }

            $cartItem = Cart::with(['product'])
                            ->where('user_id', $user->id)
                            ->where('product_id', $productId)
                            ->first();

            if ($cartItem) {
                $newQuantity = $cartItem->quantity + $quantity;

                if ($newQuantity > $product->quantity) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Not enough stock available for product ' . ($product->name ?? '') . '. You have already added avalaible ' . $cartItem->product->quantity . ' quantity'
                    ], 400);
                }
    
                $cartItem->update(['quantity' => $newQuantity]);
            } else {
                $cartItem = Cart::create([
                    'user_id' => $user->id,
                    'product_id' => $productId,
                    'quantity' => $quantity,
                ]);
            }

            $cartItem->makeHidden(['user_id']);

            return response()->json([
                'status' => true,
                'message' => 'Product added to cart successfully',
                'cart' => $cartItem
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function changeCartQuantity(Request $request, $id)
    {
        try {
            $validate = Validator::make($request->all(), [
                'change_to' => 'required|string|in:up,down',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $user = auth('sanctum')->user();
            $data = array();

            $cartItem = Cart::with(['product'])
                        ->where('user_id', $user->id)
                        ->find($id);

            if (!$cartItem) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please choose correct product for update quantity'
                ], 400);
            }

            //dd($cartItem->product->id . "__" . $cartItem->product->quantity);

            $changeTo = $request->change_to;
            $quantity = $request->quantity;
            if ($changeTo == 'up') {
                $newQuantity = $cartItem->quantity + $quantity;
            } else if ($changeTo == 'down') {
                $newQuantity = $cartItem->quantity - $quantity;
            }

            //dd("changeTo " . $changeTo ." request qty " . $request->quantity . " cart qty " . $cartItem->quantity . " product qty " . $cartItem->product->quantity . " new quantity " . $newQuantity);

            if ($newQuantity < 1) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please add correct qunatity of product, its not more than or eqal to ' . $cartItem->quantity
                ], 400);
            }

            if ($changeTo == 'up' && $cartItem->quantity == $cartItem->product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. You have already added avalaible ' . $cartItem->product->quantity . ' quantity'
                ], 400);
            }

            if ($newQuantity > $cartItem->product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please add correct qunatity of product, its not more than ' . ($cartItem->product->quantity - $cartItem->quantity)
                ], 400);
            }

            $cartItem->update(['quantity' => $newQuantity]);

            $data['cart_items'] = Cart::with(['product' => function ($query) {
                                            $query->select(['id', 'name', 'description', 'price']);
                                        }])
                                    ->find($id)
                                    ->makeHidden(['user_id']);

            return response()->json([
                'status' => true,
                'message' => 'Product qunatity has been changed successfully',
                'cart' => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function removeFromCart(Request $request, $id)
    {
        try {
            $user = auth('sanctum')->user();

            $cartItem = Cart::where('user_id', $user->id)
                ->find($id);

            if (!$cartItem) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested cart item not available for remove'
                ], 400);
            }

            $cartItem->delete();

            return response()->json([
                'status' => true,
                'message' => 'Cart item removed successfully',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }
}
