<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\GoogleController;
use App\Livewire\Admin\Dashboard as AdminDashboard;
use App\Livewire\User\Dashboard as UserDashboard;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::controller(AuthController::class)->group(Function() {
    Route::get('login', 'showLoginForm')->name('login');
    Route::post('login', 'login')->name('login.authentication');

    Route::get('register', 'showRegisterForm')->name('register');
    Route::post('register', 'register')->name('register.authentication');
});

Route::controller(GoogleController::class)
    ->prefix('auth/google')
    ->group(Function() {
        Route::get('/', 'redirectToGoogle')->name('auth.google');
        Route::get('/callback', 'handleGoogleCallback')->name('handle.google.callback');
});

Route::middleware('auth')->group(function() {
    Route::post('logout', [AuthController::class, 'logout'])->name('logout');

    Route::middleware('role:admin')->prefix('admin')->group(function () {
            Route::get('dashboard', AdminDashboard::class)->name('admin.dashboard');

            Route::get('google-login-details', [GoogleController::class, 'googleLoginDetails'])->name('admin.google.login.details');
    });

    Route::middleware('role:user')->group(function () {
        Route::get('dashboard', UserDashboard::class)->name('user.dashboard');
    });
});