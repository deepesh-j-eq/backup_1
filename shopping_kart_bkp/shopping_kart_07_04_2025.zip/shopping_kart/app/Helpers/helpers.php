<?php

use Illuminate\Support\Facades\Auth;

if (!function_exists('userRole')) {
    function userRole()
    {
        return Auth::check() ? Auth::user()->role->role ?? null : null;
    }
}

if (!function_exists('loggedinUserDetail')) {
    function loggedinUserDetail()
    {
        if (Auth::check() && Auth::user()) {
            return Auth::user();
        }

        return [];
    }
}
