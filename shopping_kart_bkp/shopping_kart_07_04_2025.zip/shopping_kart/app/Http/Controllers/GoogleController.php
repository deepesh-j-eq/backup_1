<?php

namespace App\Http\Controllers;

use App\Models\GoogleLogin;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

class GoogleController extends Controller
{
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    public function handleGoogleCallback()
    {
        try {
            if (request()->has('error')) {
                return redirect()->route('login.view')->with('error', 'Google login was canceled.');
            }

            Socialite::driver('google')->setHttpClient(
                new \GuzzleHttp\Client(['verify' => false])
            );

            $googleUser = Socialite::driver('google')->stateless()->user();

            $user = User::updateOrCreate([
                'email' => $googleUser->getEmail(),
            ], [
                'name' => $googleUser->getName(),
                'password' => '12345',
                'image' => '',
                'role_id' => 2
            ]);

            Auth::login($user);

            GoogleLogin::create([
                'google_id' => $googleUser->getId(),
                'email'     => $googleUser->getEmail(),
                'name'      => $googleUser->getName(),
                'ip_address'=> request()->ip(),
                'user_agent'=> request()->header('User-Agent'),
                'user_id'   => $user->id
            ]);

            return redirect()->route('admin.dashboard');
        } catch (\Exception $e) {
            dd($e->getMessage());
        }
    }

    public function googleLoginDetails()
    {
        $googleLoginDetails = GoogleLogin::with(['user'])->get();
        
        return view('admin.google_login_details', compact('googleLoginDetails'));
    }
}
