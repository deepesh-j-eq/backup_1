@section('title', 'Categories')

        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Categories</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="card-body p-4">
                        <button class="btn btn-primary mb-3 add_category_button" wire:click="showCreateModal">Add Category</button>
                        <input type="text" class="form-control" wire:model.live.debounce.300ms="searchTerm" placeholder="Search categories...">
                        <h5 class="card-title">Categories</h5>
                        <hr />

                        @if (session()->has('message'))
                            <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        @if (session()->has('error_message'))
                            <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('error_message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        <div class="table-responsive">
                            <table id="category_table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if ($categoryDetails->isNotEmpty())
                                        @foreach ($categoryDetails as $categoy)
                                            <tr>
                                                <td>{{ $categoy->id }}</td>
                                                <td>{{ $categoy->name }}</td>
                                                <td>
                                                    <button class="btn btn-warning btn-sm" wire:click="showEditModal({{ $categoy->id }})">Edit</button>
                                                    <button class="btn btn-danger btn-sm" wire:click="confirmDelete({{ $categoy->id }})">Delete</button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="8" class="text-center">No category details or no category created</td>
                                        </tr>
                                    @endif
                                </tfoot>
                            </table>
                        </div>
                        
                        @if ($modalFormVisible)
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">{{ $categoryId ? 'Edit' : 'Create' }} Category</h5>
                                            <button type="button" class="close" wire:click="$set('modalFormVisible', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form wire:submit.prevent="{{ $categoryId ? 'update' : 'store' }}">
                                                <div class="form-group">
                                                    <label for="inputCategoryName" class="form-label">Category Name</label>
                                                    <input type="text" class="form-control @error('name') is-invalid @enderror" id="inputCategoryName" placeholder="Enter category name" wire:model="name">
                                                    @error('name') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" wire:click="$set('modalFormVisible', false)">Close</button>
                                                    <button type="submit" class="btn btn-primary">{{ $categoryId ? 'Update' : 'Create' }}</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if ($deleteConfirmation)
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Delete Category</h5>
                                            <button type="button" class="close" wire:click="$set('deleteConfirmation', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete this category?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" wire:click="$set('deleteConfirmation', false)">Cancel</button>
                                            <button class="btn btn-danger" wire:click="delete">Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        <div wire:ignore.self>
                            {{ $categoryDetails->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->

        @push('scripts')
            <script>
                $(document).ready(function () {
                    $('.add_category_button').on('click', function(){
                        if ($('.invalid-feedback').length > 0) {
                            $('.invalid-feedback').remove();
                            $('.form-control').removeClass('is-invalid');
                        }
                    });
                });

                function showAlert(message) {
                    setTimeout(hideAlert, 5000);
                }

                function hideAlert() {
                    let alertBox = document.getElementById('sessionAlert');
                    if (alertBox) {
                        alertBox.style.display = 'none';
                    }
                }

                Livewire.on('showAlert', (message) => {
                    showAlert(message);
                });

                document.addEventListener("DOMContentLoaded", function () {
                    if (typeof Livewire !== "undefined") {
                        document.addEventListener("keydown", function (event) {
                            if (event.key === "Escape") {
                                Livewire.first().call('closeModal');
                            }
                        });
                    } else {
                        console.error("Livewire is not loaded. Ensure livewireScripts is included in your layout.");
                    }
                });
            </script>
        @endpush
