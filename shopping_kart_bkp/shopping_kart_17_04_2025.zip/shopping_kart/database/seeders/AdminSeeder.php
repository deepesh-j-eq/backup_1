<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        try {
            $admins = [
                [
                    'name' => 'Admin 1',
                    'email' => 'admin1@test.com',
                    'password' => '12345',
                    'role_id' => 1
                ],
                [
                    'name' => 'Admin 2',
                    'email' => 'admin2@test.com',
                    'password' => '12345',
                    'role_id' => 1
                ]
            ];
    
            foreach($admins as $admin) {
                $checkEmailExist = User::where('email', $admin['email'])->first();
    
                if (!$checkEmailExist) {
                    $tempImage = file_get_contents('https://picsum.photos/640/480');
                    $tempPath = tempnam(sys_get_temp_dir(), 'img');
                    file_put_contents($tempPath, $tempImage);
    
                    $path = Storage::disk('public')->putFile('user_images', new File($tempPath));
    
                    $admin['image'] = $path;
    
                    User::create($admin);
    
                    unlink($tempPath);
                }
            }
        } catch (\Exception $e) {
            Log::error('Admin seeder error: ' . $e->getMessage());
        }
    }
}
