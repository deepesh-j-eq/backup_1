<?php

namespace App\Livewire;

use App\Models\Product;
use Livewire\Component;

class ProductDetail extends Component
{
    public $productDetail, $productId;

    public function mount($productId)
    {
        try {
            $this->productDetail = '';
            
            $this->productDetail = Product::with([
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id'])->limit(4);
                },
                'category',
                'attributeOptions',
                'attributeOptions.productAttribute:id,attribute_name'
            ])
            ->find($this->productId);
        
            if (!$this->productDetail) {
                session()->flash('error_message', 'Something went wrong while fetching the product detail page.');
                return redirect()->route('all.products');
            }
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching product detail page. Error : ' . $e->getMessage());
        }
    }

    public function render()
    {
        try {
            return view('livewire.product-detail', [
                'productDetail' => $this->productDetail
            ]);
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching product detail page. Error : ' . $e->getMessage());
        }
    }
}
