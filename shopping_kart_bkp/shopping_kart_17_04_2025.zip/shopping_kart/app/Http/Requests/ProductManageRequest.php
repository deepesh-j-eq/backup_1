<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductManageRequest extends FormRequest
{
    protected $productPrice;

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules($actionName, $productPrice): array
    {
        $this->productPrice = $productPrice;

        return [
            'name' => 'required|string|min:3|max:255',
            'description' => 'required|string|max:255',
            'price' => 'required|numeric|min:1|regex:/^\d+(\.\d{1,2})?$/',
            'discounted_price' => [
                'nullable',
                'numeric',
                'min:0',
                'regex:/^\d+(\.\d{1,2})?$/',
                function ($attribute, $value, $fail) {
                    if ($value !== null && $value >= $this->productPrice) {
                        $fail('The discounted price must be less than the original price.');
                    }
                }
            ],
            'quantity' => 'required|integer|min:0',
            'category_id' => 'required|exists:categories,id',
            'images' => ($actionName == 'store') ? 'required' : 'nullable',
            'images.*' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'selectedProductAttributes' => 'nullable|array',
            'selectedProductAttributes.*' => 'exists:product_attributes,id',
            'selectedProductAttributeOptions' => 'nullable|array',
            'selectedProductAttributeOptions.*' => 'exists:product_attribute_options,id'
        ];
    }

    public function messages(): array
    {
        return [
            'category_id.required' => 'Please select category.',
            'category_id.exists' => 'Selected category is invalid.'
        ];
    }
}
