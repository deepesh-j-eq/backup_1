<?php

namespace App\Livewire;

use App\Http\Requests\AddToCartRequest;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Support\Str;
use Livewire\Component;

class ProductDetail extends Component
{
    public $productDetail, $productId;

    public $quantity = 1;

    public $selectedOptions = [];

    public function mount($productId)
    {
        try {
            $this->productDetail = '';
            
            $this->productDetail = Product::with([
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id'])->limit(4);
                },
                'category',
                'attributeOptions',
                'attributeOptions.productAttribute:id,attribute_name'
            ])
            ->find($this->productId);
        
            if (!$this->productDetail) {
                session()->flash('error_message', 'Something went wrong while fetching the product detail page.');
                return redirect()->route('all.products');
            }
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching product detail page. Error : ' . $e->getMessage());
        }
    }

    public function resetFields()
    {
        $this->productDetail = '';
        $this->quantity = '';
        $this->productId = '';
        $this->selectedOptions = [];
    }

    public function render()
    {
        try {
            return view('livewire.product-detail', [
                'productDetail' => $this->productDetail
            ]);
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching product detail page. Error : ' . $e->getMessage());
        }
    }

    public function addToCart()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            $product = $this->productDetail;

            if (!$product) {
                session()->flash('error_message', 'Product not found.');
                return;
            }

            $request = new AddToCartRequest();
            $rules = $request->rules($product->id, $this->quantity, !empty($this->selectedOptions) ? $this->selectedOptions : '');
            $this->validate($rules);

            try {
                //dd($this->quantity, $product->quantity, $this->selectedOptions);

                if ($this->quantity > $product->quantity) {
                    if (!empty($this->selectedOptions)) {
                        return $this->handleStockError($product, $this->selectedOptions);
                    }
                    return $this->handleStockError($product);
                    /* session()->flash('error_message', 'Not enough stock available.');
                    return; */
                }

                if (!$product->relationLoaded('attributeOptions')) {
                    $product->load('attributeOptions.productAttribute');
                }

                $formattedOptions = [];

                $this->selectedOptions = array("1"=>"2");

                //dd($this->selectedOptions);

                if (!empty($this->selectedOptions) && $product->relationLoaded('attributeOptions')) {
                    $attributeMap = $product->attributeOptions->mapWithKeys(function ($option) {
                        $attributeName = optional($option->productAttribute)->attribute_name;
                        $attributeSnakeCasedName = Str::snake($attributeName);
                        return [$option->product_attribute_id => $attributeSnakeCasedName];
                    });

                    foreach ($this->selectedOptions as $attributeId => $optionId) {
                        if (isset($attributeMap[$attributeId])) {
                            $formattedOptions[$attributeMap[$attributeId]] = $optionId;
                        }
                    }

                    //dd($formattedOptions);

                    $attributeOptionsJson = !empty($formattedOptions)
                    ? json_encode($formattedOptions, JSON_UNESCAPED_UNICODE)
                    : null;

                    //dd($attributeOptionsJson);

                    $cartItemQuery = Cart::where('user_id', $user->id)
                                    ->where('product_id', $product->id);

                    if ($attributeOptionsJson) {
                        $cartItemQuery->whereRaw('JSON_CONTAINS(product_attribute_option_id, ?)', [$attributeOptionsJson])
                                    ->whereRaw('JSON_CONTAINS(?, product_attribute_option_id)', [$attributeOptionsJson]);
                    }

                    $cartItem = $cartItemQuery->first();

                    if ($cartItem) {
                        dd('test11');
                        //dd($cartItem);
                        $newQuantity = $cartItem->quantity + $this->quantity;
                        if ($newQuantity > $product->quantity) {
                            return $this->handleStockError($product);
                        }

                        $cartItem->update(['quantity' => $newQuantity]);
                    } else {
                        dd('test22');
                        $cartItem = Cart::create([
                            'quantity' => $this->quantity,
                            'product_id' => $product->id,
                            'product_attribute_option_id' => $attributeOptionsJson,
                            'user_id' => $user->id
                        ]);

                        if (!$cartItem) {
                            session()->flash('error_message', 'Something went wrong! Product add to cart failed');
                            return;
                        }
                    }
                } else {
                    $cartItem = Cart::where('user_id', $user->id)
                                ->where('product_id', $product->id)
                                ->first();

                    dd('test33');

                    if ($cartItem) {
                        $newQuantity = $cartItem->quantity + $this->quantity;
                        if ($newQuantity > $product->quantity) {
                            return $this->handleStockError($product);
                        }

                        $cartItem->update(['quantity' => $newQuantity]);
                    } else {
                        dd('test44');
                        $cartItem = Cart::create([
                            'quantity' => $this->quantity,
                            'product_id' => $product->id,
                            'product_attribute_option_id' => null,
                            'user_id' => $user->id
                        ]);

                        if (!$cartItem) {
                            session()->flash('error_message', 'Something went wrong! Product add to cart failed');
                            return;
                        }
                    }
                }

                //dd($formattedOptions);

                dd('test54');

                session()->flash('message', 'Product added to cart successfully.');
                $this->dispatch('showAlert', session('message'));

                $this->dispatch('cart-icon-quantity-update');                
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while product add to cart. Error : ' . $e->getMessage());
            }
        } else {
            $this->resetFields();
            session()->flash('error_message', 'User not logged in, Something went wrong while add to cart');
            return;
        }
    }

    protected function handleStockError(Product $product, $selectedAttributeOptions = [], ?Cart $cartItem = null)
    {
        $availableQuantity = $product ? $product->quantity : 0;

        if ($cartItem) {
            $availableQuantity -= $cartItem->quantity;
        }

        $message = 'Not enough stock available for selected product ' . ($product->name ?? '');

        if ($availableQuantity > 0) {
            $message .= ', you can add only ' . max($availableQuantity, 0) . ' more.';
        }

        return response()->json([
            'status' => false,
            'custom_error' => true,
            'message' => $message
        ], 409);
    }

}
