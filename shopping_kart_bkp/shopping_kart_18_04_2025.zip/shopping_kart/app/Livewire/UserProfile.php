<?php

namespace App\Livewire;

use App\Models\User;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class UserProfile extends Component
{
    use WithFileUploads;

    public $loggedinUserDetail, $name, $email, $existingImage, $profileImage, $userId;

    public function mount()
    {
        $this->resetFields();

        $this->loggedinUserDetail = loggedinUserDetail();

        if ($this->loggedinUserDetail) {
            $this->userId = $this->loggedinUserDetail->id;
            $this->name = $this->loggedinUserDetail->name;
            $this->email = $this->loggedinUserDetail->email;
            $this->existingImage = $this->loggedinUserDetail->image ?? '';
        }
    }

    public function resetFields()
    {
        $this->loggedinUserDetail = (object)[];
        $this->name = '';
        $this->email = '';
        $this->profileImage = '';
        $this->userId = '';
    }

    public function render()
    {
        try {    
            if (empty($this->loggedinUserDetail)) {
                session()->flash('error_message', 'User details not found.');
                redirect()->back()->send();
            }

            return view('livewire.user-profile', ['userInformation' => $this->loggedinUserDetail]);
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching user profile. Error : ' . $e->getMessage());
        }
    }

    public function updateProfile()
    {
        if (!isset($this->userId) || $this->userId == '' || is_null($this->userId)) {
            $this->resetFields();
            session()->flash('message', 'Somthing went wrong! your profile not fount for update.');
            $this->dispatch('showAlert', session('message'));
            return;
        }

        //$this->validate((new UserProfileRequest())->rules());

        $this->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|max:255|email:rfc,dns|unique:users,email,' . $this->userId,
            'profileImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        try {
            $userDetails = User::where('id', $this->userId)->first();

            if (!$userDetails) {
                $this->resetFields();
                session()->flash('message', 'Somthing went wrong! user profile not fount for update.');
                $this->dispatch('showAlert', session('message'));
                return;
            }

            $userProfileNewData = [
                'name' => $this->name,
                'email' => $this->email,
            ];

            if (empty($this->profileImage)) {
                if ($userDetails->image) {
                    $path = $userDetails->image;
                } else {
                    $tempImage = file_get_contents('https://picsum.photos/640/480');
                    $tempPath = tempnam(sys_get_temp_dir(), 'img');
                    file_put_contents($tempPath, $tempImage);

                    $path = Storage::disk('public')->putFile('user_images', new File($tempPath));
                }
            } else {
                if ($userDetails->image) {
                    Storage::disk('public')->delete($userDetails->image);
                }
                $path = $this->profileImage->store('user_images', 'public');
            }

            if ($path && $path != '') {
                $userProfileNewData['image'] = $path;
            }

            $userDetails->update($userProfileNewData);

            $this->name = $userProfileNewData['name'];
            $this->email = $userProfileNewData['email'];
            $this->existingImage = $userProfileNewData['image'] ?? '';

            session()->flash('message', 'Your profile updated successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while updating user profile. Error : ' . $e->getMessage());
        }
    }
}
