<?php

namespace App\Livewire\Admin;

use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Dashboard extends Component
{
    public $userName;

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->userName = '';
    }

    public function render()
    {
        try {
            if (Auth::check() && Auth::user()->name) {
                $this->userName = Auth::user()->name;
            }
    
            session()->flash('message', ($this->userName != '') ? 'Hello ' . $this->userName . ' loggedin successfully' : 'Loggedin successfully');
            $this->dispatch('showAlert', session('message'));
            return view('livewire.admin.dashboard');
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching admin dashboard. Error : ' . $e->getMessage());
        }
    }
}
