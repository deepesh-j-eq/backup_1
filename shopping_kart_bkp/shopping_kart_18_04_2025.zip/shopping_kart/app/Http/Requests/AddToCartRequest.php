<?php

namespace App\Http\Requests;

use App\Models\Cart;
use App\Models\Product;
use App\Models\ProductAttributeOption;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;

class AddToCartRequest extends FormRequest
{
    protected $productId, $quantity, $selectedOptions;

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules($productId, $quantity, $selectedOptions = []): array
    {
        //dd($productId, $quantity, $selectedOptions);

        $this->productId = $productId;
        $this->quantity = $quantity;
        $this->selectedOptions = $selectedOptions;

        //dd($this->productId, $this->quantity, $this->selectedOptions);

        $rules = [
            'productId' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1'
        ];

        $product_attributes_detail = [];
        $validProductAttributeOptions = [];

        //dd($this->productId, $this->quantity, $this->selectedOptions);

        if (!empty($this->selectedOptions) && $this->productId && $this->productId != '') {
            $product_attributes_detail = array_keys($this->selectedOptions);

            $validOptions = ProductAttributeOption::with(['productAttribute'])
                ->whereIn('product_attribute_id', $product_attributes_detail)
                ->whereHas('products', function ($query) {
                    $query->where('products.id', $this->productId);
                })->get();

            //dd($validOptions);
            $validOptionsGroupBy = $validOptions->groupBy('product_attribute_id');

            //dd($validOptionsGroupBy);

            if (!empty($validOptionsGroupBy)) {
                foreach ($validOptionsGroupBy as $attributeId => $attributeOptions) {
                    //dd($attributeOptions);
                    foreach ($attributeOptions as $attOption) {
                        $productAttributeName = $attOption->productAttribute->attribute_name;
                        $attributeSnakeCasedName = Str::snake($productAttributeName);
                        $validProductAttributeOptions[$attributeId][$attributeSnakeCasedName][$attOption->id] = $attOption->option;
                        //dd($attOption->productAttribute->attribute_name);
                    }
                }
                //dd($validProductAttributeOptions);

                if (!empty($validProductAttributeOptions)) {
                    foreach ($validProductAttributeOptions as $attributeId => $attributesDetails) {
                        $key = 'selectedOptions.' . $attributeId;
                        $rules[$key] = [
                            'nullable',
                            'integer',
                            function ($attribute, $value, $fail) use ($validProductAttributeOptions, $attributesDetails) {
                                //dd($attributesDetails);
                                foreach ($attributesDetails as $attrN => $attrOpt) {
                                    // dd($value, (array_key_exists($value, $attrOpt)), "\n");
                                    // dd($value, (!array_key_exists($value, $attrOpt)), "\n");
                                    if (array_key_exists($value, $attrOpt)) {
                                        //dd($attribute);
                                        $formattedAttribute = str_replace('selectedOptions.', '', $attribute);
                                        //dd($formattedAttribute);
                                        //dd(array_keys($validProductAttributeOptions[$formattedAttribute]));
                                        $fail("The selected {$formattedAttribute} is invalid.");
                                    }
                                }
                                if (!array_key_exists($value, $attributesDetails)) {
                                    //dd($attribute);
                                    $formattedAttribute = str_replace('selectedOptions.', '', $attribute);
                                    //dd($formattedAttribute);
                                    //dd($validProductAttributeOptions[$formattedAttribute]);
                                    $fail("The selected {$formattedAttribute} is invalid.");
                                }
                            }
                        ];
                    }
                }
            }

            /* $validOptionIds = ProductAttributeOption::whereIn('product_attribute_id', $product_attributes_detail)
                ->whereHas('products', function ($query) {
                    $query->where('products.id', $this->productId);
                })
                ->pluck('id')
                ->toArray();
                
            foreach ($this->all() as $key => $value) {
                if (str_ends_with($key, '_attribute_option')) {
                    $rules[$key] = [
                        'nullable',
                        'integer',
                        function ($attribute, $value, $fail) use ($validOptionIds) {
                            if (!in_array($value, $validOptionIds)) {
                                $formattedAttribute = str_replace('_', ' ', $attribute);
                                $fail("The selected {$formattedAttribute} is invalid.");
                            }
                        }
                    ];
                }
            } */

            //dd($validOptionIds);
            //dd($this->selectedOptions);

            foreach ($this->selectedOptions as $key => $value) {
            }
        }

        if (!isset($rules['quantity']) || !is_array($rules['quantity'])) {
            $rules['quantity'] = ['required', 'integer', 'min:1'];
        }

        /* $rules['quantity'][] = function ($attribute, $value, $fail) {
            $productAttributeOptions = json_decode(json_encode([]));
            $productQuantityInfo = [];

            foreach ($this->all() as $key => $optionId) {
                if (str_ends_with($key, '_attribute_option') && $this->product_id && $this->product_id != '') {
                    $productAttributeOptions = ProductAttributeOption::with([
                            'products:id,quantity',
                            'productAttribute:id,attribute_name'
                        ])
                        ->where('id', $optionId)
                        ->whereHas('products', function ($query) {
                            $query->where('products.id', $this->product_id);
                        })
                        ->get();

                    if ($productAttributeOptions->isNotEmpty()) {
                        foreach ($productAttributeOptions as $attrbuteOption) {
                            $attributeName = $attrbuteOption->productAttribute->attribute_name;
                            $optionName = $attrbuteOption->option;
                            foreach ($attrbuteOption->products as $produc) {
                                $productQuantityInfo[$attributeName] = [
                                    'product_attribute_option' => $optionName,
                                    'product_quantity' => $produc->quantity,
                                ];
                            }
                        }
                    }

                    if (!empty($productQuantityInfo)) {
                        foreach ($productQuantityInfo as $prodAttrName => $info) {
                            if ($value > $info['product_quantity']) {
                                //$fail("The requested quantity for '{$prodAttrName}' Option '{$info['product_attribute_option']}' is not available for sale.");
                            }
                        }
                    }
                }
            } */

            /* $user = loggedinUserDetail();

            if ($this->product_id && $this->product_id != '') {
                $product = Product::select('id','name','quantity')->find($this->product_id);

                if ($product) {
                    if ($user !== null) {
                        $prodId = $product->id;
                        $prodName = $product->name;
                        $prodQuantity = $product->quantity;
                        $cartDetails = Cart::where([
                            'product_id' => $prodId,
                            'user_id' => $user->id
                        ])->get();
    
                        //dd($cartDetails);
    
                        if ($cartDetails->isNotEmpty()) {
                            $cartItemQuantity = 0;
                            $availableQuantity = 0;
                            $getHandleStockMessage = [];
                            foreach ($cartDetails as $cartDetail) {
                                $cartItemQuantity = $cartItemQuantity + $cartDetail->quantity;

                                if ($cartItemQuantity && $cartItemQuantity > 0) {
                                    $availableQuantity = $prodQuantity - $cartItemQuantity;
                                }

                                if (isset($cartDetail->product_attribute_option_id) && !is_null($cartDetail->product_attribute_option_id)) {
                                    //dd('product is in cart with attribute options', "value ".$value, "cartItemQuantity ".$cartItemQuantity, "prodId ".$prodId, "prodQuantity ".$prodQuantity, "cartDetail->product_attribute_option_id ".$cartDetail->product_attribute_option_id);
                                    $selectedProductAttributeOption = $cartDetail->product_attribute_option_id;

                                    $getHandleStockMessage = $this->getHandleStockMessage($cartDetail, $user);
                                }
                            }
                            //dd($productQuantityForAttributeOptions);
                            //dd('product is in cart with attribute options', "value ".$value, "cartItemQuantity ".$cartItemQuantity, "availableQuantity ".$availableQuantity, "prodId ".$prodId, "prodQuantity ".$prodQuantity);

                            $validatedCartItemsMessage = '';
                            if ($value > $availableQuantity) {
                                if (!empty($getHandleStockMessage)) {
                                    if (isset($getHandleStockMessage['validated_cart_items_message'])){
                                        $validatedCartItemsMessage = $getHandleStockMessage['validated_cart_items_message'];

                                        if ($availableQuantity <= 0) {
                                            $fail("Not enough stock available for product '{$prodName}'. {$cartItemQuantity} already in your cart. <br>{$validatedCartItemsMessage}");
                                        } else {
                                            $fail("Not enough stock available for product '{$prodName}'. Available quantity is {$availableQuantity}. <br>{$validatedCartItemsMessage}");
                                        }
                                    } else {
                                        if ($availableQuantity <= 0) {
                                            $fail("Not enough stock available for product '{$prodName}'. {$cartItemQuantity} already in your cart.");
                                        } else {
                                            $fail("Not enough stock available for product '{$prodName}'. Available quantity is {$availableQuantity}.");
                                        }
                                    }
                                } else {
                                    if ($availableQuantity <= 0) {
                                        $fail("The requested quantity for '{$prodName}' is not available for sale.");
                                    } else {
                                        $fail("The requested quantity for '{$prodName}' is not available for sale. The Available quantity is {$availableQuantity}");
                                    }
                                }
                            }
                        } else {
                            //dd('product not in cart', "value ".$value, "prodQuantity ".$prodQuantity);
                            if ($value > $prodQuantity) {
                                $fail("The requested quantity for '{$prodName}' is not available for sale. Maximum available quantity is $prodQuantity");
                            }
                        }
                    } else {
                        dd('user is null');
                        if ($value > $prodQuantity) {
                            $fail("The requested quantity for '{$prodName}' is not available for sale. Maximum available quantity is '{$prodQuantity}'");
                        }
                    }
                }

                // if ($value > $prodQuantity) {
                //     $fail("The requested quantity for '{$prodName}' is not available for sale. Maximum available quantity is '{}'");
                // }
            }
        }; */

        return $rules;
    }

    protected function getHandleStockMessage($cartItem, $user)
    {
        /* try {
            $cartItemsWithProdAttrOpt = Cart::with([
                'product.attributeOptions',
                'product.attributeOptions.productAttribute'
            ])
            ->where([
                'product_id' => $cartItem->product_id,
                'user_id' => $user->id
            ])->get();

            //dd($cartItemsWithProdAttrOpt);

            $cartItemHasAttributeOptions = [];
            $productHasAttributes = [];
            $productHasAttributeOptions = [];
            $attributeOptionsMap = [];
            $transformCartItemHasAttributeOptions = [];

            if ($cartItemsWithProdAttrOpt->isNotEmpty()) {
                foreach ($cartItemsWithProdAttrOpt as $itemDetails) {
                    $cartItemHasAttributeOptions[$itemDetails->id] = [
                        "cart_attribute_options" => $itemDetails->product_attribute_option_id,
                        "cart_quantity" => $itemDetails->quantity
                    ];

                    if ($itemDetails->product->attributeOptions) {
                        foreach ($itemDetails->product->attributeOptions as $itemAttributeOption) {
                            $productAttrName = $itemAttributeOption->productAttribute->attribute_name ?? '';
                            $optionId = $itemAttributeOption->id;
                            $optionValue = $itemAttributeOption->option;

                            if (!in_array($productAttrName, $productHasAttributes)) {
                                $productHasAttributes[] = $productAttrName;
                            }

                            $attributeOptionsMap[strtolower($productAttrName)][$optionId] = $optionValue;
                        }
                    }
                }

                $productHasAttributeOptions = [];
                if (!empty($attributeOptionsMap)) {
                    foreach ($attributeOptionsMap as $attrName => $attrOptions) {
                        $productHasAttributeOptions[] = [$attrName => $attrOptions];
                    }
                }

                if (!empty($cartItemHasAttributeOptions)) {
                    foreach ($cartItemHasAttributeOptions as $key => $item) {
                        $decodedOptions = json_decode($item['cart_attribute_options'], true);
                        $final = [];

                        foreach ($decodedOptions as $attributeKey => $value) {
                            $cleanKey = str_replace('_attribute_option', '', $attributeKey);
                            $final[$cleanKey] = (int) $value;
                        }

                        $final['cart_quantity'] = (int) $item['cart_quantity'];
                        $transformCartItemHasAttributeOptions[$key] = $final;
                    }
                }

                $validatedCartItems = [];
                $nonValidatedCartItems = [];

                if (!empty($transformCartItemHasAttributeOptions)) {
                    foreach ($transformCartItemHasAttributeOptions as $index => $attributes) {
                        $isCorrectAttributeOption = true;
                        $transformedProductAttributeOpts = [];

                        foreach ($attributes as $attributeKey => $optionId) {
                            if ($attributeKey === 'cart_quantity') {
                                $transformedProductAttributeOpts['cart_quantity'] = $optionId;
                                continue;
                            }

                            $found = false;

                            foreach ($productHasAttributeOptions as $attributeGroup) {
                                if (isset($attributeGroup[$attributeKey]) && isset($attributeGroup[$attributeKey][$optionId])) {
                                    $transformedProductAttributeOpts[$attributeKey] = $attributeGroup[$attributeKey][$optionId];
                                    $found = true;
                                }
                            }

                            if (!$found) {
                                $transformedProductAttributeOpts[$attributeKey] = $optionId;
                                $isCorrectAttributeOption = false;
                            }
                        }

                        if ($isCorrectAttributeOption) {
                            $validatedCartItems[$index] = $transformedProductAttributeOpts;
                        } else {
                            $nonValidatedCartItems[$index] = $transformedProductAttributeOpts;
                        }
                    }
                }

                $currentCartQuantityProductAttributeWise = '';
                $validatedCartItemsMessage = '';

                if (!empty($validatedCartItems)) {
                    $currentCartQuantityProductAttributeWise = 0;

                    $ik = 1;
                    foreach ($validatedCartItems as $cartIdKey => $cartQuantityDetails) {
                        if ($ik == 1) {
                            $validatedCartItemsMessage .= 'You have added ' . $cartQuantityDetails['cart_quantity'] . ' for attribute ';
                        } else {
                            $validatedCartItemsMessage .= 'and ' . $cartQuantityDetails['cart_quantity'] . ' for attribute ';
                        }

                        foreach ($cartQuantityDetails as $attribute_name => $attribute_option) {
                            if ($attribute_name == 'cart_quantity') {
                                continue;
                            }

                            $validatedCartItemsMessage .= '"' . (ucfirst(str_replace('_', ' ', $attribute_name))) . '"' . ' => ' . $attribute_option . ' ';
                        }

                        if (isset($cartQuantityDetails['cart_quantity'])) {
                            $currentCartQuantityProductAttributeWise = $currentCartQuantityProductAttributeWise + $cartQuantityDetails['cart_quantity'];
                        }
                        $ik++;
                    }
                }

                if (isset($currentCartQuantityProductAttributeWise) && $currentCartQuantityProductAttributeWise !== '') {
                    $currentCartQuantity = $currentCartQuantityProductAttributeWise;
                } else {
                    $currentCartQuantity = '';
                }

                return [
                    'current_cart_quantity' => $currentCartQuantity,
                    'validated_cart_items_message' => $validatedCartItemsMessage
                ];
            }
        } catch (\Exception $e) {
            session()->flash('error_message', 'Error occured while get handle stock message. Error : ' . $e->getMessage());
        } */
    }
}
