<?php

namespace App\Http\Controllers;

use App\Models\GoogleLogin;
use App\Models\User;
use Illuminate\Http\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Laravel\Socialite\Facades\Socialite;

class GoogleController extends Controller
{
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    public function handleGoogleCallback()
    {
        try {
            if (request()->has('error')) {
                return redirect()->route('login.view')->with('error', 'Google login was canceled.');
            }

            Socialite::driver('google')->setHttpClient(
                new \GuzzleHttp\Client(['verify' => false])
            );

            $googleUser = Socialite::driver('google')->stateless()->user();

            if ($googleUser->getEmail()) {
                $userExist = User::where('email', $googleUser->getEmail())->first();
            }

            if ($userExist) {
                $userDetailsForUpdate = array();

                if (!$userExist->name || $userExist->name == '') {
                    $userDetailsForUpdate['name'] = $googleUser->getName();
                } else if (strcmp($userExist->name, $googleUser->getName()) != 0) {
                    $userDetailsForUpdate['name'] = $googleUser->getName();
                }

                if (!$userExist->image || $userExist->image == '') {
                    $path = $this->createUserProfileImage();
                    $userDetailsForUpdate['image'] = $path ?? '';
                }

                if (!empty($userDetailsForUpdate)) {
                    $userExist->update($userDetailsForUpdate);
                }

                $user = $userExist;
            } else {
                $path = $this->createUserProfileImage();
                $user = User::create([
                    'email' => $googleUser->getEmail(),
                    'name' => $googleUser->getName(),
                    'password' => '12345',
                    'image' => $path ?? '',
                    'role_id' => 2
                ]);
            }

            Auth::login($user);

            GoogleLogin::create([
                'google_id' => $googleUser->getId(),
                'email'     => $googleUser->getEmail(),
                'name'      => $googleUser->getName(),
                'ip_address'=> request()->ip(),
                'user_agent'=> request()->header('User-Agent'),
                'user_id'   => $user->id
            ]);

            return redirect()->route('user.dashboard');
        } catch (\Exception $e) {
            dd($e->getMessage());
        }
    }

    public function googleLoginDetails()
    {
        $googleLoginDetails = GoogleLogin::with(['user.role'])->get();
        
        return view('admin.google-login-details', compact('googleLoginDetails'));
    }

    private function createUserProfileImage()
    {
        $tempImage = file_get_contents('https://picsum.photos/640/480');
        $tempPath = tempnam(sys_get_temp_dir(), 'img');
        file_put_contents($tempPath, $tempImage);

        return Storage::disk('public')->putFile('user_images', new File($tempPath));
    }
}
