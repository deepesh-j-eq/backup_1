@section('title', 'Checkout')
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i class="bx bx-home-alt"></i></a></li>
                                <li class="breadcrumb-item"><a href="{{ route('view.cart') }}">Cart</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="d-flex align-items-center justify-content-center my-3 my-lg-0">
                        <div class="row">
                            <div id="general-error"></div>
                        </div>
                    </div>
                    <div class="container-fluid my-4">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h4 class="card-title">Checkout</h4>
                                    <hr />

                                    @if (session()->has('message'))
                                        <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                            {{ session('message') }}
                                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                        </div>
                                    @endif

                                    @if (session()->has('error_message'))
                                        <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                            {{ session('error_message') }}
                                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                        </div>
                                    @endif

                                    <form
                                        x-data="{   contactInfo: { email: @entangle('contactInfo.email'), phone: @entangle('contactInfo.phone') },
                                                    shippingAddress: {
                                                        first_name: @entangle('shippingAddress.first_name'),
                                                        last_name: @entangle('shippingAddress.last_name'),
                                                        address_1: @entangle('shippingAddress.address_1'),
                                                        address_2: @entangle('shippingAddress.address_2'),
                                                        city: @entangle('shippingAddress.city'),
                                                        country: @entangle('shippingAddress.country'),
                                                        postal_code: @entangle('shippingAddress.postal_code'),
                                                    },
                                                    shippingMethod: @entangle('shippingMethod'),
                                                    paymentInfo : {
                                                        card_number: @entangle('paymentInfo.card_number'),
                                                        name_on_card: @entangle('paymentInfo.name_on_card'),
                                                        expiry_date: @entangle('paymentInfo.expiry_date'),
                                                        cvc: @entangle('paymentInfo.cvc'),
                                                    }
                                                    errors: {
                                                        contactInfo: { email: '', phone: '' },
                                                        shippingAddress: { first_name: '', last_name: '', address_1: '', address_2: '', city: '', country: '', postal_code: '' },
                                                        shippingMethod: '',
                                                        paymentInfo: { card_number: '', name_on_card: '', expiry_date: '', cvc: '' }
                                                    }
                                                }"
                                        x-on:submit.prevent="if (validateCheckoutForm($el, $data, $wire)) { $wire.call('placeOrder'); }"
                                    >
                                        <!-- Contact Info -->
                                        <div class="mb-4">
                                            <h5>Contact Info</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="contactInfo.email">Email Address</label>
                                                        <input type="email"
                                                            class="form-control @error('contactInfo.email') is-invalid @enderror"
                                                            wire:model="contactInfo.email"
                                                            placeholder="test1@gmail.com"
                                                            x-model="contactInfo.email">
                                                        @error('contactInfo.email')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.contactInfo.email" class="text-danger mt-1" x-text="errors.contactInfo.email"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="contactInfo.phone">Phone Number</label>
                                                        <input type="text"
                                                            class="form-control @error('contactInfo.phone') is-invalid @enderror"
                                                            wire:model="contactInfo.phone"
                                                            placeholder="5412352356"
                                                            x-model="contactInfo.phone">
                                                        @error('contactInfo.phone')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.contactInfo.phone" class="text-danger mt-1" x-text="errors.contactInfo.phone"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Shipping Address -->
                                        <div class="mb-4">
                                            <h5>Shipping Address</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.first_name">First Name</label>
                                                        <input type="text"
                                                            class="form-control @error('shippingAddress.first_name') is-invalid @enderror"
                                                            wire:model="shippingAddress.first_name"
                                                            placeholder="John"
                                                            x-model="shippingAddress.first_name">
                                                        @error('shippingAddress.first_name')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.shippingAddress.first_name" class="text-danger mt-1" x-text="errors.shippingAddress.first_name"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.last_name">Last Name</label>
                                                        <input type="text"
                                                            class="form-control @error('shippingAddress.last_name') is-invalid @enderror"
                                                            wire:model="shippingAddress.last_name"
                                                            placeholder="Cristen"
                                                            x-model="shippingAddress.last_name">
                                                        @error('shippingAddress.last_name')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.shippingAddress.last_name" class="text-danger mt-1" x-text="errors.shippingAddress.last_name"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.address_1">Address Line 1</label>
                                                        <input type="text"
                                                            class="form-control @error('shippingAddress.address_1') is-invalid @enderror"
                                                            wire:model="shippingAddress.address_1"
                                                            placeholder="5112 N"
                                                            x-model="shippingAddress.address_1">
                                                        @error('shippingAddress.address_1')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.shippingAddress.address_1" class="text-danger mt-1" x-text="errors.shippingAddress.address_1"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.address_2">Address Line 2</label>
                                                        <input type="text"
                                                            class="form-control @error('shippingAddress.address_2') is-invalid @enderror"
                                                            wire:model="shippingAddress.address_2"
                                                            placeholder="Tongass Hwy"
                                                            x-model="shippingAddress.address_2">
                                                        @error('shippingAddress.address_2')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.shippingAddress.address_2" class="text-danger mt-1" x-text="errors.shippingAddress.address_2"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.city">City</label>
                                                        <input type="text"
                                                            class="form-control @error('shippingAddress.city') is-invalid @enderror"
                                                            wire:model="shippingAddress.city"
                                                            placeholder="Ketchikan"
                                                            x-model="shippingAddress.city">
                                                        @error('shippingAddress.city')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.shippingAddress.city" class="text-danger mt-1" x-text="errors.shippingAddress.city"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.country">Country</label>
                                                        <input type="text"
                                                            class="form-control @error('shippingAddress.country') is-invalid @enderror"
                                                            wire:model="shippingAddress.country"
                                                            placeholder="United States"
                                                            x-model="shippingAddress.country">
                                                        @error('shippingAddress.country')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.shippingAddress.country" class="text-danger mt-1" x-text="errors.shippingAddress.country"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.postal_code">Postal Code</label>
                                                        <input type="text"
                                                            class="form-control @error('shippingAddress.postal_code') is-invalid @enderror"
                                                            wire:model="shippingAddress.postal_code"
                                                            placeholder="99901"
                                                            x-model="shippingAddress.postal_code">
                                                        @error('shippingAddress.postal_code')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.shippingAddress.postal_code" class="text-danger mt-1" x-text="errors.shippingAddress.postal_code"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Shipping Method -->
                                        <div class="mb-4">
                                            <h5>Shipping Method</h5>
                                            <div class="form-check">
                                                <input class="form-check-input"
                                                    type="radio"
                                                    name="shippingMethod"
                                                    id="standardShipping"
                                                    value="standard"
                                                    wire:model.live="shippingMethod"
                                                    x-model="shippingMethod">
                                                <label class="form-check-label" for="standardShipping">
                                                    Standard - 4 days delivery for $10
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input"
                                                    type="radio"
                                                    name="shippingMethod"
                                                    id="expressShipping"
                                                    value="express"
                                                    wire:model.live="shippingMethod"
                                                    x-model="shippingMethod">
                                                <label class="form-check-label" for="expressShipping">
                                                    Express - 2 days delivery for $20
                                                </label>
                                            </div>
                                            <span x-show="errors.shippingMethod" class="text-danger mt-1" x-text="errors.shippingMethod"></span>
                                        </div>

                                        <!-- Payment Info -->
                                        <div class="mb-4">
                                            <h5>Payment</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.card_number">Card Number</label>
                                                        <input type="text"
                                                            class="form-control @error('paymentInfo.card_number') is-invalid @enderror"
                                                            wire:model="paymentInfo.card_number"
                                                            maxlength="16"
                                                            placeholder="5555 5555 5555 4444"
                                                            x-model="paymentInfo.card_number">
                                                        @error('paymentInfo.card_number')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.paymentInfo.card_number" class="text-danger mt-1" x-text="errors.paymentInfo.card_number"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.name_on_card">Name on Card</label>
                                                        <input type="text"
                                                            class="form-control @error('paymentInfo.name_on_card') is-invalid @enderror"
                                                            wire:model="paymentInfo.name_on_card"
                                                            placeholder="John Cristen"
                                                            x-model="paymentInfo.name_on_card">
                                                        @error('paymentInfo.name_on_card')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.paymentInfo.name_on_card" class="text-danger mt-1" x-text="errors.paymentInfo.name_on_card"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.expiry_date">Expiry Date (MM/YY)</label>
                                                        <input type="text"
                                                            class="form-control @error('paymentInfo.expiry_date') is-invalid @enderror"
                                                            wire:model="paymentInfo.expiry_date"
                                                            placeholder="MM/YY"
                                                            x-model="paymentInfo.expiry_date">
                                                        @error('paymentInfo.expiry_date')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.paymentInfo.expiry_date" class="text-danger mt-1" x-text="errors.paymentInfo.expiry_date"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.cvc">CVC</label>
                                                        <input type="text"
                                                            class="form-control @error('paymentInfo.cvc') is-invalid @enderror"
                                                            wire:model="paymentInfo.cvc"
                                                            maxlength="3"
                                                            placeholder="789"
                                                            x-model="paymentInfo.cvc">
                                                        @error('paymentInfo.cvc')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                        <span x-show="errors.paymentInfo.cvc" class="text-danger mt-1" x-text="errors.paymentInfo.cvc"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-primary">Confirm Order</button>
                                    </form>
                                </div>
                            </div>

                            <!-- Order Summary -->
                            <div class="col-md-4">
                                <div class="card-body">
                                    <h5>Order Summary</h5>
                                    @if ($cartItems->isNotEmpty())
                                        @foreach ($cartItems as $item)
                                            <div class="d-flex align-items-center mb-3">
                                                <img src="{{ asset('storage/' . $item->product->images->first()->image_path) }}" alt="{{ $item->product->name }}" style="width: 50px; height: 50px; object-fit: contain;">
                                                <div class="ms-3">
                                                    <p class="mb-0">{{ $item->product->name }}</p>
                                                    <small>Quantity: {{ $item->quantity }}</small>
                                                </div>
                                                <div class="ms-auto">
                                                    <p class="mb-0">${{ number_format($item->sub_total, 2) }}</p>
                                                </div>
                                            </div>
                                        @endforeach
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <p>Subtotal</p>
                                            <p>${{ number_format($subTotal, 2) }}</p>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <p>Shipping Estimate</p>
                                            <p>${{ number_format($shippingCost, 2) }}</p>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <p>Tax Estimate</p>
                                            <p>${{ number_format($tax, 2) }}</p>
                                        </div>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <h6>Order Total</h6>
                                            <h6>${{ number_format($cartTotal, 2) }}</h6>
                                        </div>
                                    @else
                                        <p>Your cart is empty.</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->

@push('clientSideValidationScript')
    <script>
        function validateCheckoutForm(form, data, wire) {
            let isValid = true;
            data.errors = {
                contactInfo: { email: '', phone: '' },
                shippingAddress: { first_name: '', last_name: '', address_1: '', address_2: '', city: '', country: '', postal_code: '' },
                shippingMethod: '',
                paymentInfo: { card_number: '', name_on_card: '', expiry_date: '', cvc: '' }
            };

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!data.contactInfo.email) {
                data.errors.contactInfo.email = 'Email address is required.';
                isValid = false;
            } else if (!emailRegex.test(data.contactInfo.email)) {
                data.errors.contactInfo.email = 'Please enter a valid email address.';
                isValid = false;
            } else {
                const domain = data.contactInfo.email.split('@')[1];
                if (!domain.includes('.')) {
                    data.errors.contactInfo.email = 'Please enter a valid email address.';
                    isValid = false;
                }
            }

            const phoneRegex = /^\d{10}$/;
            if (!data.contactInfo.phone) {
                data.errors.contactInfo.phone = 'Phone number is required.';
                isValid = false;
            } else if (!phoneRegex.test(data.contactInfo.phone)) {
                data.errors.contactInfo.phone = 'Phone number must be exactly 10 digits.';
                isValid = false;
            }

            if (!data.shippingAddress.first_name) {
                data.errors.shippingAddress.first_name = 'First name is required.';
                isValid = false;
            } else if (data.shippingAddress.first_name.length < 2 || data.shippingAddress.first_name.length > 191) {
                data.errors.shippingAddress.first_name = 'First name must be between 2 and 191 characters.';
                isValid = false;
            }

            if (!data.shippingAddress.last_name) {
                data.errors.shippingAddress.last_name = 'Last name is required.';
                isValid = false;
            } else if (data.shippingAddress.last_name.length < 2 || data.shippingAddress.last_name.length > 191) {
                data.errors.shippingAddress.last_name = 'Last name must be between 2 and 191 characters.';
                isValid = false;
            }

            if (!data.shippingAddress.address_1) {
                data.errors.shippingAddress.address_1 = 'Address line 1 is required.';
                isValid = false;
            } else if (data.shippingAddress.address_1.length < 10 || data.shippingAddress.address_1.length > 191) {
                data.errors.shippingAddress.address_1 = 'Address line 1 must be between 10 and 191 characters.';
                isValid = false;
            }

            if (data.shippingAddress.address_2 && data.shippingAddress.address_2.length > 191) {
                data.errors.shippingAddress.address_2 = 'Address line 2 must not exceed 191 characters.';
                isValid = false;
            }

            const alphaRegex = /^[a-zA-Z]+$/;
            if (!data.shippingAddress.city) {
                data.errors.shippingAddress.city = 'City is required.';
                isValid = false;
            } else if (data.shippingAddress.city.length > 191 || !alphaRegex.test(data.shippingAddress.city)) {
                data.errors.shippingAddress.city = 'City must contain only letters and not exceed 191 characters.';
                isValid = false;
            }

            if (!data.shippingAddress.country) {
                data.errors.shippingAddress.country = 'Country is required.';
                isValid = false;
            } else if (data.shippingAddress.country.length > 191 || !alphaRegex.test(data.shippingAddress.country)) {
                data.errors.shippingAddress.country = 'Country must contain only letters and not exceed 191 characters.';
                isValid = false;
            }

            const postalRegex = /^\d{6,}$/;
            if (!data.shippingAddress.postal_code) {
                data.errors.shippingAddress.postal_code = 'Postal code is required.';
                isValid = false;
            } else if (!postalRegex.test(data.shippingAddress.postal_code)) {
                data.errors.shippingAddress.postal_code = 'Postal code should be minimum 6 digits.';
                isValid = false;
            }

            if (!data.shippingMethod || !['standard', 'express'].includes(data.shippingMethod)) {
                data.errors.shippingMethod = 'Please select a valid shipping method.';
                isValid = false;
            }

            const cardRegex = /^\d{16}$/;
            if (!data.paymentInfo.card_number) {
                data.errors.paymentInfo.card_number = 'Card number is required.';
                isValid = false;
            } else if (!cardRegex.test(data.paymentInfo.card_number)) {
                data.errors.paymentInfo.card_number = 'Card number must be exactly 16 digits.';
                isValid = false;
            }

            if (!data.paymentInfo.name_on_card) {
                data.errors.paymentInfo.name_on_card = 'Name on card is required.';
                isValid = false;
            } else if (data.paymentInfo.name_on_card.length < 2 || data.paymentInfo.name_on_card.length > 191) {
                data.errors.paymentInfo.name_on_card = 'Name on card must be between 2 and 191 characters.';
                isValid = false;
            }

            const expiryRegex = /^(0[1-9]|1[0-2])\/[0-9]{2}$/;
            if (!data.paymentInfo.expiry_date) {
                data.errors.paymentInfo.expiry_date = 'Expiry date is required.';
                isValid = false;
            } else if (!expiryRegex.test(data.paymentInfo.expiry_date)) {
                data.errors.paymentInfo.expiry_date = 'Expiry date must be in MM/YY format.';
                isValid = false;
            } else {
                const [month, year] = data.paymentInfo.expiry_date.split('/');
                const currentYear = new Date().getFullYear() % 100;
                const currentMonth = new Date().getMonth() + 1;
                if (parseInt(month) < 1 || parseInt(month) > 12) {
                    data.errors.paymentInfo.expiry_date = 'Month must be between 01 and 12.';
                    isValid = false;
                } else if (parseInt(year) < currentYear || (parseInt(year) === currentYear && parseInt(month) < currentMonth)) {
                    data.errors.paymentInfo.expiry_date = 'Card has expired.';
                    isValid = false;
                }
            }

            const cvcRegex = /^\d{3}$/;
            if (!data.paymentInfo.cvc) {
                data.errors.paymentInfo.cvc = 'CVC is required.';
                isValid = false;
            } else if (!cvcRegex.test(data.paymentInfo.cvc)) {
                data.errors.paymentInfo.cvc = 'CVC must be exactly 3 digits.';
                isValid = false;
            }

            return isValid;
        }

        async function checkProductAvailability(wire, data) {
            try {
                await wire.call('checkProductAvailability');
                wire.call('placeOrder');
            } catch (error) {
                const generalError = document.getElementById('general-error');
                generalError.innerHTML = '<div class="alert alert-danger alert-dismissible fade show" role="alert">' +
                    'Some products are not available in the requested quantity. Please check your cart.' +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
                setTimeout(() => {
                    generalError.innerHTML = '';
                }, 5000);
            }
        }
    </script>
@endpush

@push('scripts')
    <script>
        function showAlert(message) {
            setTimeout(hideAlert, 5000);
        }

        function hideAlert() {
            let alertBox = document.getElementById('sessionAlert');
            if (alertBox) {
                alertBox.style.display = 'none';
            }
        }

        Livewire.on('showAlert', (message) => {
            showAlert(message);
        });
    </script>
@endpush
