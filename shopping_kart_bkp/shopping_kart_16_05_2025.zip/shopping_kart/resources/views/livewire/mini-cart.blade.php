<div>
    <div class="mini-cart-items-container">
        @forelse ($cartItems as $cartItem)
            @php
                $porductPrice = $cartItem->discounted_price > 0 ? $cartItem->discounted_price : $cartItem->price;
                $cartSubTotal = $porductPrice * $cartItem->cart_quantity;
            @endphp
            <div class="dropdown-item border-bottom py-2">
                <div class="d-flex align-items-center">
                    <div class="me-2">
                        @if (!empty($cartItem->image_paths))
                            <img src="{{ asset('storage/'.$cartItem->image_paths[0]) }}" alt="{{ $cartItem->name }}" class="msg-avatar" style="width: 50px; height: 50px; object-fit: cover;">
                         @endif
                        <?php /* @else
                            <img src="{{ asset('assets/images/default-product.png') }}" alt="No image" class="msg-avatar" style="width: 50px; height: 50px; object-fit: cover;">
                        @endif */ ?>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="msg-name">
                            {{ $cartItem->name }}
                        </h6>
                        @if (!empty($cartItem->attributes))
                            <div class="mb-1">
                                <strong>Attributes:</strong>
                                <ul class="list-unstyled mb-0 mini-cart-attributes">
                                    @foreach ($cartItem->attributes as $attribute)
                                        <li class="text-truncate">
                                            {{ $attribute['attribute_name'] }}: {{ $attribute['attribute_option'] }}
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                        <p class="msg-info mb-1">Qty: {{ $cartItem->cart_quantity }}</p>
                        <p class="msg-info mb-1">
                            Price: ${{ number_format($porductPrice, 2) }}
                        </p>
                        <p class="msg-info mb-0">Subtotal: ${{ number_format($cartSubTotal, 2) }}</p>
                    </div>
                </div>
            </div>
        @empty
            <div class="dropdown-item py-2">
                <p class="msg-info">Your cart is empty.</p>
            </div>
        @endforelse

        @if ($cartItemsCount > 5)
            <a href="{{ route('view.cart') }}">
                <div class="text-center msg-footer py-2">View All Cart Items</div>
            </a>
        @endif
    </div>
</div>
