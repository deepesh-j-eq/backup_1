<?php $__env->startPush('additional_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/mini-cart.css')); ?>">
<?php $__env->stopPush(); ?>

<div class="dropdown-menu dropdown-menu-end" style="width: 300px;">
    <!--[if BLOCK]><![endif]--><?php if($cartItems): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $displayImagePath = $cartItem->image_paths[0] ?? '';
                $discountPrice = $cartItem->discounted_price > 0 ? $cartItem->discounted_price : '';
                $cartSubTotal = $discountPrice ? $discountPrice * $cartItem->cart_quantity : $cartItem->price * $cartItem->cart_quantity;
            ?>
            <div class="dropdown-item border-bottom py-2">
                <div class="d-flex align-items-center">
                    <div class="me-2">
                        <img src="<?php echo e($displayImagePath ? asset('storage/' . $displayImagePath) : asset('assets/images/default-product.png')); ?>"
                             class="msg-avatar"
                             style="width: 50px; height: 50px; object-fit: cover;"
                             alt="product image">
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="msg-name">
                            <?php echo e($cartItem->name); ?>

                            <span class="msg-time float-end">
                                <a href="javascript:;" wire:click="confirmDelete(<?php echo e($cartItem->cart_id); ?>)" class="text-danger">
                                    <i class='bx bx-x'></i>
                                </a>
                            </span>
                        </h6>
                        <!--[if BLOCK]><![endif]--><?php if(!empty($cartItem->attributes)): ?>
                            <p class="msg-info mb-1">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cartItem->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($attribute['name']); ?> - <?php echo e($attribute['option']); ?><?php echo e($loop->last ? '' : ', '); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <p class="msg-info mb-1">Qty: <?php echo e($cartItem->cart_quantity); ?></p>
                        <p class="msg-info mb-1">
                            Price: $<?php echo e(number_format($discountPrice ?: $cartItem->price, 2)); ?>

                        </p>
                        <p class="msg-info">Subtotal: $<?php echo e(number_format($cartSubTotal, 2)); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    <?php else: ?>
        <div class="dropdown-item text-center">
            <p class="msg-info">Your cart is empty</p>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($cartItemsCount > 5): ?>
        <a href="<?php echo e(route('view.cart')); ?>">
            <div class="text-center msg-footer py-2">View All Cart Items</div>
        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($specificCartItemRemoveConfirmation): ?>
        <div class="modal" style="display: block; background: rgba(0,0,0,0.5); position: fixed; top: 0; left: 0; right: 0; bottom: 0;">
            <div class="modal-dialog" style="margin: 100px auto;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Confirm Removal</h5>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to remove this item from your cart?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click="$set('specificCartItemRemoveConfirmation', false)">Cancel</button>
                        <button type="button" class="btn btn-danger" wire:click="removeSpecificCartItem">Remove</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>

<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\shopping_kart\resources\views/livewire/mini-cart.blade.php ENDPATH**/ ?>