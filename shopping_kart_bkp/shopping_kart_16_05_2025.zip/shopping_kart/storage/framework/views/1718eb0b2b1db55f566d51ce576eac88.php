<?php $__env->startSection('title', 'Checkout'); ?>
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="bx bx-home-alt"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('view.cart')); ?>">Cart</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="d-flex align-items-center justify-content-center my-3 my-lg-0">
                        <div class="row">
                            <div id="general-error"></div>
                        </div>
                    </div>
                    <div class="container-fluid my-4">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h4 class="card-title">Checkout</h4>
                                    <hr />

                                    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                                        <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                            <?php echo e(session('message')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <?php if(session()->has('error_message')): ?>
                                        <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                            <?php echo e(session('error_message')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <form
                                        x-data="{   contactInfo.email: <?php if ((object) ('contactInfo.email') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('contactInfo.email'->value()); ?>')<?php echo e('contactInfo.email'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('contactInfo.email'); ?>')<?php endif; ?>,
                                                    contactInfo.phone: <?php if ((object) ('contactInfo.phone') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('contactInfo.phone'->value()); ?>')<?php echo e('contactInfo.phone'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('contactInfo.phone'); ?>')<?php endif; ?>,
                                                    shippingAddress.first_name: <?php if ((object) ('shippingAddress.first_name') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('shippingAddress.first_name'->value()); ?>')<?php echo e('shippingAddress.first_name'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('shippingAddress.first_name'); ?>')<?php endif; ?>,
                                                    errors: { contactInfo.email: '', contactInfo.phone: '', shippingAddress.first_name: '' }
                                                }"
                                        x-on:submit.prevent="if (validateCheckoutForm($el, $data, $wire)) { $wire.call('placeOrder'); }"
                                    >
                                        <!-- Contact Info -->
                                        <div class="mb-4">
                                            <h5>Contact Info</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="contactInfo.email">Email Address</label>
                                                        <input type="email"
                                                            class="form-control <?php $__errorArgs = ['contactInfo.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="contactInfo.email"
                                                            placeholder="test1@gmail.com"
                                                            x-model="contactInfo.email">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['contactInfo.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.contactInfo.email" class="text-danger mt-1" x-text="errors.contactInfo.email"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="contactInfo.phone">Phone Number</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['contactInfo.phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="contactInfo.phone"
                                                            placeholder="5412352356"
                                                            x-model="contactInfo.phone">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['contactInfo.phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.contactInfo.phone" class="text-danger mt-1" x-text="errors.contactInfo.phone"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Shipping Address -->
                                        <div class="mb-4">
                                            <h5>Shipping Address</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.first_name">First Name</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['shippingAddress.first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="shippingAddress.first_name"
                                                            placeholder="John"
                                                            x-model="shippingAddress.first_name">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['shippingAddress.first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.shippingAddress.first_name" class="text-danger mt-1" x-text="errors.shippingAddress.first_name"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.last_name">Last Name</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['shippingAddress.last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="shippingAddress.last_name"
                                                            placeholder="Cristen"
                                                            x-model="shippingAddress.last_name">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['shippingAddress.last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.shippingAddress.last_name" class="text-danger mt-1" x-text="errors.shippingAddress.last_name"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.address_1">Address Line 1</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['shippingAddress.address_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="shippingAddress.address_1"
                                                            placeholder="5112 N"
                                                            x-model="shippingAddress.address_1">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['shippingAddress.address_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.shippingAddress.address_1" class="text-danger mt-1" x-text="errors.shippingAddress.address_1"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.address_2">Address Line 2</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['shippingAddress.address_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="shippingAddress.address_2"
                                                            placeholder="Tongass Hwy"
                                                            x-model="shippingAddress.address_2">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['shippingAddress.address_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.shippingAddress.address_2" class="text-danger mt-1" x-text="errors.shippingAddress.address_2"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.city">City</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['shippingAddress.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="shippingAddress.city"
                                                            placeholder="Ketchikan"
                                                            x-model="shippingAddress.city">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['shippingAddress.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.shippingAddress.city" class="text-danger mt-1" x-text="errors.shippingAddress.city"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.country">Country</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['shippingAddress.country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="shippingAddress.country"
                                                            placeholder="United States"
                                                            x-model="shippingAddress.country">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['shippingAddress.country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.shippingAddress.country" class="text-danger mt-1" x-text="errors.shippingAddress.country"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.postal_code">Postal Code</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['shippingAddress.postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="shippingAddress.postal_code"
                                                            placeholder="99901"
                                                            x-model="shippingAddress.postal_code">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['shippingAddress.postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.shippingAddress.postal_code" class="text-danger mt-1" x-text="errors.shippingAddress.postal_code"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Shipping Method -->
                                        <div class="mb-4">
                                            <h5>Shipping Method</h5>
                                            <div class="form-check">
                                                <input class="form-check-input"
                                                    type="radio"
                                                    name="shippingMethod"
                                                    id="standardShipping"
                                                    value="standard"
                                                    wire:model.live="shippingMethod"
                                                    x-model="shippingMethod">
                                                <label class="form-check-label" for="standardShipping">
                                                    Standard - 4 days delivery for $10
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input"
                                                    type="radio"
                                                    name="shippingMethod"
                                                    id="expressShipping"
                                                    value="express"
                                                    wire:model.live="shippingMethod"
                                                    x-model="shippingMethod">
                                                <label class="form-check-label" for="expressShipping">
                                                    Express - 2 days delivery for $20
                                                </label>
                                            </div>
                                            <span x-show="errors.shippingMethod" class="text-danger mt-1" x-text="errors.shippingMethod"></span>
                                        </div>

                                        <!-- Payment Info -->
                                        <div class="mb-4">
                                            <h5>Payment</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.card_number">Card Number</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['paymentInfo.card_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="paymentInfo.card_number"
                                                            maxlength="16"
                                                            placeholder="5555 5555 5555 4444"
                                                            x-model="paymentInfo.card_number">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['paymentInfo.card_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.paymentInfo.card_number" class="text-danger mt-1" x-text="errors.paymentInfo.card_number"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.name_on_card">Card Number</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['paymentInfo.name_on_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="paymentInfo.name_on_card"
                                                            placeholder="John Cristen"
                                                            x-model="paymentInfo.name_on_card">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['paymentInfo.name_on_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.paymentInfo.name_on_card" class="text-danger mt-1" x-text="errors.paymentInfo.name_on_card"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.expiry_date">Expiry Date (MM/YY)</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['paymentInfo.expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="paymentInfo.expiry_date"
                                                            placeholder="MM/YY"
                                                            x-model="paymentInfo.expiry_date">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['paymentInfo.expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.paymentInfo.expiry_date" class="text-danger mt-1" x-text="errors.paymentInfo.expiry_date"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.cvc">CVC</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['paymentInfo.cvc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            wire:model="paymentInfo.cvc"
                                                            maxlength="3"
                                                            placeholder="789"
                                                            x-model="paymentInfo.cvc">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['paymentInfo.cvc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span x-show="errors.paymentInfo.cvc" class="text-danger mt-1" x-text="errors.paymentInfo.cvc"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-primary">Confirm Order</button>
                                    </form>
                                </div>
                            </div>

                            <!-- Order Summary -->
                            <div class="col-md-4">
                                <div class="card-body">
                                    <h5>Order Summary</h5>
                                    <!--[if BLOCK]><![endif]--><?php if($cartItems->isNotEmpty()): ?>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex align-items-center mb-3">
                                                <img src="<?php echo e(asset('storage/' . $item->product->images->first()->image_path)); ?>" alt="<?php echo e($item->product->name); ?>" style="width: 50px; height: 50px; object-fit: contain;">
                                                <div class="ms-3">
                                                    <p class="mb-0"><?php echo e($item->product->name); ?></p>
                                                    <small>Quantity: <?php echo e($item->quantity); ?></small>
                                                </div>
                                                <div class="ms-auto">
                                                    <p class="mb-0">$<?php echo e(number_format($item->sub_total, 2)); ?></p>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <p>Subtotal</p>
                                            <p>$<?php echo e(number_format($subTotal, 2)); ?></p>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <p>Shipping Estimate</p>
                                            <p>$<?php echo e(number_format($shippingCost, 2)); ?></p>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <p>Tax Estimate</p>
                                            <p>$<?php echo e(number_format($tax, 2)); ?></p>
                                        </div>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <h6>Order Total</h6>
                                            <h6>$<?php echo e(number_format($cartTotal, 2)); ?></h6>
                                        </div>
                                    <?php else: ?>
                                        <p>Your cart is empty.</p>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->

<?php $__env->startPush('clientSideValidationScript'); ?>
    <script>
        $(document).ready(function() {
            // Card number validation
            $('input[wire\\:model="paymentInfo.card_number"]').on('input', function() {
                let sanitized = $(this).val().replace(/[^0-9]/g, '');
                if (sanitized.length > 16) {
                    sanitized = sanitized.substring(0, 16);
                }
                $(this).val(sanitized);
            });

            // Expiry date validation
            $('input[wire\\:model="paymentInfo.expiry_date"]').on('input', function() {
                let sanitized = $(this).val().replace(/[^0-9\/]/g, '');
                if (sanitized.length === 2 && !sanitized.includes('/')) {
                    sanitized += '/';
                }
                if (sanitized.length > 5) {
                    sanitized = sanitized.substring(0, 5);
                }
                $(this).val(sanitized);
            });

            // CVC validation
            $('input[wire\\:model="paymentInfo.cvc"]').on('input', function() {
                let sanitized = $(this).val().replace(/[^0-9]/g, '');
                if (sanitized.length > 3) {
                    sanitized = sanitized.substring(0, 3);
                }
                $(this).val(sanitized);
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json'
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function showAlert(message) {
            setTimeout(hideAlert, 5000);
        }

        function hideAlert() {
            let alertBox = document.getElementById('sessionAlert');
            if (alertBox) {
                alertBox.style.display = 'none';
            }
        }

        Livewire.on('showAlert', (message) => {
            showAlert(message);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\git_repo\trainee-milestones-laravel\shopping_kart\resources\views/livewire/checkout.blade.php ENDPATH**/ ?>