<div>
    <div class="mini-cart-items-container">
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $porductPrice = $cartItem->discounted_price > 0 ? $cartItem->discounted_price : $cartItem->price;
                $cartSubTotal = $porductPrice * $cartItem->cart_quantity;
            ?>
            <div class="dropdown-item border-bottom py-2">
                <div class="d-flex align-items-center">
                    <div class="me-2">
                        <!--[if BLOCK]><![endif]--><?php if(!empty($cartItem->image_paths)): ?>
                            <img src="<?php echo e(asset('storage/'.$cartItem->image_paths[0])); ?>" alt="<?php echo e($cartItem->name); ?>" class="msg-avatar" style="width: 50px; height: 50px; object-fit: cover;">
                         <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php /* @else
                            <img src="{{ asset('assets/images/default-product.png') }}" alt="No image" class="msg-avatar" style="width: 50px; height: 50px; object-fit: cover;">
                        @endif<!--[if ENDBLOCK]><![endif]--> */ ?>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="msg-name">
                            <?php echo e($cartItem->name); ?>

                        </h6>
                        <!--[if BLOCK]><![endif]--><?php if(!empty($cartItem->attributes)): ?>
                            <div class="mb-1">
                                <strong>Attributes:</strong>
                                <ul class="list-unstyled mb-0 mini-cart-attributes">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cartItem->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-truncate">
                                            <?php echo e($attribute['attribute_name']); ?>: <?php echo e($attribute['attribute_option']); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <p class="msg-info mb-1">Qty: <?php echo e($cartItem->cart_quantity); ?></p>
                        <p class="msg-info mb-1">
                            Price: $<?php echo e(number_format($porductPrice, 2)); ?>

                        </p>
                        <p class="msg-info mb-0">Subtotal: $<?php echo e(number_format($cartSubTotal, 2)); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="dropdown-item py-2">
                <p class="msg-info">Your cart is empty.</p>
            </div>
        <?php endif; ?>

        <!--[if BLOCK]><![endif]--><?php if($cartItemsCount > 5): ?>
            <a href="<?php echo e(route('view.cart')); ?>">
                <div class="text-center msg-footer py-2">View All Cart Items</div>
            </a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\git_repo\trainee-milestones-laravel\shopping_kart\resources\views/livewire/mini-cart.blade.php ENDPATH**/ ?>