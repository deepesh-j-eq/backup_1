<?php

namespace App\Services;

use App\Models\Cart;
use App\Models\Product;

class CartService
{
    public function handleStockError(Product $product, $selectedAttributeOptions = [], ?Cart $cartItem = null)
    {
        $availableQuantity = $product ? $product->quantity : 0;

        if ($cartItem) {
            $availableQuantity -= $cartItem->quantity;
        }

        $message = 'Not enough stock available for selected product ' . ($product->name ?? '');

        if ($availableQuantity > 0) {
            $message .= ', you can add only ' . max($availableQuantity, 0) . ' more.';
        }

        return [
            'status' => false,
            'custom_error' => true,
            'message' => $message
        ];
    }

    public function calculateSubTotal(Cart $cartItem)
    {
        if (!$cartItem->product) {
            return 0;
        }

        $unitPrice = (!empty($cartItem->product->discounted_price) && $cartItem->product->discounted_price > 0)
            ? $cartItem->product->discounted_price
            : $cartItem->product->price;

        return (float) $unitPrice * (int) $cartItem->quantity;
    }

    public function shippingEstimate($shippingOption)
    {
        if ($shippingOption == 'standard') {
            return 40;
        } else if ($shippingOption == 'express') {
            return 30;
        } else {
            return 10;
        }
    }
}
