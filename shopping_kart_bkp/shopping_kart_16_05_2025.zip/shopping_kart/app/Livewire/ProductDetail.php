<?php

namespace App\Livewire;

use App\Http\Requests\AddToCartRequest;
use App\Models\Cart;
use App\Models\Product;
use App\Models\ProductAttributeOption;
use Illuminate\Support\Str;
use Livewire\Component;

class ProductDetail extends Component
{
    public $productDetail, $productId;

    public $quantity = 1;

    public $selectedOptions = [];

    protected $listeners = ['validateAttributeOption'];

    public function mount($productId)
    {
        try {
            $this->productDetail = '';
            
            $this->productDetail = Product::with([
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id'])->limit(4);
                },
                'category',
                'attributeOptions',
                'attributeOptions.productAttribute:id,attribute_name'
            ])
            ->find($this->productId);
        
            if (!$this->productDetail) {
                session()->flash('error_message', 'Something went wrong while fetching the product detail page.');
                return redirect()->route('all.products');
            }
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching product detail page. Error : ' . $e->getMessage());
        }
    }

    public function resetFields()
    {
        $this->productDetail = '';
        $this->quantity = '';
        $this->productId = '';
        $this->selectedOptions = [];
    }

    public function updatedQuantity($value)
    {
        $sanitized = preg_replace('/[^0-9]/', '', $value);
        $this->quantity = $sanitized !== '' ? max(1, min($sanitized, 214748360)) : 1;
    }

    public function incrementQuantity()
    {
        $this->quantity = min($this->quantity + 1, 214748360);
    }

    public function decrementQuantity()
    {
        $this->quantity = max($this->quantity - 1, 1);
    }

    /* public function updatedSelectedOptions($value, $key)
    {
        $product = $this->productDetail;

        $request = new AddToCartRequest();
        $rules = $request->rules($product->id, $this->quantity, $this->selectedOptions);

        if (array_key_exists($key, $rules)) {
            $this->validateOnly($key, $rules);
        }
    } */

    /* public function validateAttributeOption($attributeId, $value)
    {
        $this->selectedOptions[$attributeId] = $value;

        $product = $this->productDetail;
        $request = new AddToCartRequest();
        $rules = $request->rules($product->id, $this->quantity, $this->selectedOptions);

        $key = "selectedOptions.$attributeId";
        if (array_key_exists($key, $rules)) {
            $this->validateOnly($key, $rules);
        }
    } */

    public function render()
    {
        try {
            return view('livewire.product-detail', [
                'productDetail' => $this->productDetail
            ]);
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching product detail page. Error : ' . $e->getMessage());
        }
    }

    public function addToCart()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            $product = $this->productDetail;

            if (!$product) {
                session()->flash('error_message', 'Product not found.');
                $this->dispatch('scrollToMessage');
                return;
            }

            $request = new AddToCartRequest();
            $rules = $request->rules($product->id, $this->quantity, !empty($this->selectedOptions) ? $this->selectedOptions : '');
            $this->validate($rules);

            try {
                if ($this->quantity > $product->quantity) {
                    if (!empty($this->selectedOptions)) {
                        $handleStockErrorMessageArray = $this->handleStockError($product, $this->selectedOptions);
                    }
                    $handleStockErrorMessageArray = $this->handleStockError($product, $this->selectedOptions);

                    if (!empty($handleStockErrorMessageArray)) {
                        if ($handleStockErrorMessageArray['stock_error'] && isset($handleStockErrorMessageArray['message'])) {
                            session()->flash('error_message', $handleStockErrorMessageArray['message']);
                            $this->dispatch('scrollToMessage');
                            return;
                        }
                    }
                }

                if (!$product->relationLoaded('attributeOptions')) {
                    $product->load('attributeOptions.productAttribute');
                }

                $addToCartPAOValidation = $this->addToCartProductAttributeOptionsValidation($product);

                if (!empty($addToCartPAOValidation)) {
                    session()->flash('error_message', implode(',', $addToCartPAOValidation));
                    $this->dispatch('scrollToMessage');
                    return;
                }

                $formattedOptions = [];

                if (!empty($this->selectedOptions) && $product->relationLoaded('attributeOptions')) {
                    $attributeMap = $product->attributeOptions->mapWithKeys(function ($option) {
                        $attributeName = optional($option->productAttribute)->attribute_name;
                        $attributeSnakeCasedName = Str::snake($attributeName);
                        return [$option->product_attribute_id => $attributeSnakeCasedName];
                    });

                    foreach ($this->selectedOptions as $attributeId => $optionId) {
                        if (isset($attributeMap[$attributeId])) {
                            $formattedOptions[$attributeMap[$attributeId]] = $optionId;
                        }
                    }

                    $attributeOptionsJson = !empty($formattedOptions)
                    ? json_encode($formattedOptions, JSON_UNESCAPED_UNICODE)
                    : null;

                    $cartItemQuery = Cart::where('user_id', $user->id)
                                    ->where('product_id', $product->id);

                    if ($attributeOptionsJson) {
                        $cartItemQuery->whereRaw('JSON_CONTAINS(product_attribute_option_id, ?)', [$attributeOptionsJson])
                                    ->whereRaw('JSON_CONTAINS(?, product_attribute_option_id)', [$attributeOptionsJson]);
                    }

                    $cartItem = $cartItemQuery->first();

                    if ($cartItem) {
                        //dd('test11');
                        $newQuantity = $cartItem->quantity + $this->quantity;
                        if ($newQuantity > $product->quantity) {
                            $handleStockErrorMessageArray = $this->handleStockError($product);

                            if (!empty($handleStockErrorMessageArray)) {
                                if ($handleStockErrorMessageArray['stock_error'] && isset($handleStockErrorMessageArray['message'])) {
                                    session()->flash('error_message', $handleStockErrorMessageArray['message']);
                                    $this->dispatch('scrollToMessage');
                                    return;
                                }
                            }
                        }

                        $cartItem->update(['quantity' => $newQuantity]);
                    } else {
                        //dd('test22');
                        $cartItem = Cart::create([
                            'quantity' => $this->quantity,
                            'product_id' => $product->id,
                            'product_attribute_option_id' => $attributeOptionsJson,
                            'user_id' => $user->id
                        ]);

                        if (!$cartItem) {
                            session()->flash('error_message', 'Something went wrong! Product add to cart failed');
                            $this->dispatch('scrollToMessage');
                            return;
                        }
                    }
                } else {
                    $cartItem = Cart::where('user_id', $user->id)
                                ->where('product_id', $product->id)
                                ->first();

                    if ($cartItem) {
                        //dd('test33');

                        $newQuantity = $cartItem->quantity + $this->quantity;
                        if ($newQuantity > $product->quantity) {
                            $handleStockErrorMessageArray = $this->handleStockError($product);
                            session()->flash('error_message', $handleStockErrorMessageArray['message']);
                            $this->dispatch('scrollToMessage');
                            return;
                        }

                        $cartItem->update(['quantity' => $newQuantity]);
                    } else {
                        //dd('test44');
                        $cartItem = Cart::create([
                            'quantity' => $this->quantity,
                            'product_id' => $product->id,
                            'product_attribute_option_id' => null,
                            'user_id' => $user->id
                        ]);

                        if (!$cartItem) {
                            session()->flash('error_message', 'Something went wrong! Product add to cart failed');
                            $this->dispatch('scrollToMessage');
                            return;
                        }
                    }
                }

                //dd('test54');

                session()->flash('message', 'Product added to cart successfully.');
                $this->dispatch('showAlert', session('message'));
                $this->dispatch('scrollToMessage');

                $this->dispatch('cart-icon-quantity-update');
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while product add to cart. Error : ' . $e->getMessage());
                $this->dispatch('scrollToMessage');
            }
        } else {
            $this->resetFields();
            session()->flash('error_message', 'User not logged in, Something went wrong while add to cart');
            $this->dispatch('scrollToMessage');
            return;
        }
    }

    protected function handleStockError(Product $product, $selectedAttributeOptions = [], ?Cart $cartItem = null)
    {
        $availableQuantity = $product ? $product->quantity : 0;

        if ($cartItem) {
            $availableQuantity -= $cartItem->quantity;
        }

        $message = 'Not enough stock available for selected product ' . ($product->name ?? '');

        if ($availableQuantity > 0) {
            $message .= ', you can add only ' . max($availableQuantity, 0) . '.';
        }

        return [
            'stock_error' => true,
            'message' => $message
        ];
    }

    protected function addToCartProductAttributeOptionsValidation(Product $product)
    {
        $product_has_attributes = [];
        $product_has_attributes_options = [];
        $ProductAttributeValidationResponse = [];

        if ($product->attributeOptions->isNotEmpty()) {
            $productHasAtrributeOptionsGroupBy = $product->attributeOptions->groupBy('product_attribute_id');

            if (!empty($productHasAtrributeOptionsGroupBy)) {
                foreach ($productHasAtrributeOptionsGroupBy as $productAttributeId => $productHasAttributeDetails) {
                    foreach ($productHasAttributeDetails as $productAttributeOptions) {
                        $productAttributeName = Str::snake($productAttributeOptions->productAttribute->attribute_name ?? '');
                        if (!array_key_exists($productAttributeId, $product_has_attributes)) {
                            $product_has_attributes[$productAttributeId] = $productAttributeName;
                        }

                        $product_has_attributes_options[$productAttributeId][$productAttributeName][] = $productAttributeOptions->id;
                    }
                }

                if (!empty($product_has_attributes)) {
                    if (empty($this->selectedOptions)) {
                        $tempAttributeName = [];
                        foreach ($product_has_attributes as $productAttributeId => $productAttributeOption) {
                            $tempAttributeName[] = (ucfirst(str_replace('_', ' ', $productAttributeOption)));
                        }

                        if (!empty($tempAttributeName)) {
                            $attributeNameData = implode(',', $tempAttributeName);
                            if (count($tempAttributeName) == 1) {
                                $attributeErrorMessage = "The {$attributeNameData} field is required.";
                            } else {
                                $attributeErrorMessage = "The {$attributeNameData} fields are required.";
                            }

                            $ProductAttributeValidationResponse[] = $attributeErrorMessage;
                        }
                    } else if (!empty($this->selectedOptions) && !empty($product_has_attributes_options)) {
                        $missingAttributes = [];
                        $unmatchedAttributes = [];
                        $tempAttributeName = [];

                        foreach ($product_has_attributes as $productAttributeId => $productAttributeOption) {
                            if (!array_key_exists($productAttributeId, $this->selectedOptions)) {
                                $tempAttributeName[] = ucfirst(str_replace('_', ' ', $productAttributeOption));

                                if (!empty($tempAttributeName)) {
                                    $attributeNameData = implode(',', $tempAttributeName);
                                    if (count($tempAttributeName) == 1) {
                                        $attributeErrorMessage = "The {$attributeNameData} field is required.";
                                    } else {
                                        $attributeErrorMessage = "The {$attributeNameData} fields are required.";
                                    }
        
                                    $ProductAttributeValidationResponse[] = $attributeErrorMessage;
                                }
                            }
                        }

                        foreach ($product_has_attributes_options as $productAttributeId => $productAttributeGroup) {
                            $key = 'selectedOptions.' . $productAttributeId;
                            foreach($productAttributeGroup as $prodAttrName => $productAttrOptIds) {
                                $isValueMissing = !isset($this->selectedOptions[$productAttributeId]) || trim($this->selectedOptions[$productAttributeId]) === '';
                                if ($isValueMissing) {
                                    $formattedProdAttrName = ucfirst(str_replace('_', ' ', $prodAttrName));
                                    $missingAttributes[$key] = $formattedProdAttrName;
                                }
    
                                if (isset($this->selectedOptions[$productAttributeId]) && trim($this->selectedOptions[$productAttributeId]) !== '') {
                                    $selectedValue = (int) $this->selectedOptions[$productAttributeId];
    
                                    if (!in_array($selectedValue, $productAttrOptIds, true)) {
                                        $formattedProdAttrName = ucfirst(str_replace('_', ' ', $prodAttrName));
                                        $unmatchedAttributes[$key] = $formattedProdAttrName;
                                    }
                                }
                            }
                        }
                    }
                }

                if (!empty($missingAttributes)) {
                    $tempMissingAttributeName = [];
                    foreach ($missingAttributes as $missingAttr) {
                        $tempMissingAttributeName[] = $missingAttr;
                    }
                    if (!empty($tempMissingAttributeName)) {
                        $attributeNameData = implode(',', $tempMissingAttributeName);
                        if (count($tempMissingAttributeName) == 1) {
                            $attributeErrorMessage = "The {$attributeNameData} field is required.";
                        } else {
                            $attributeErrorMessage = "The {$attributeNameData} fields are required.";
                        }

                        $ProductAttributeValidationResponse[] = $attributeErrorMessage;
                    }
                }

                $product_attributes_detail = array_keys($this->selectedOptions);

                $validOptions = ProductAttributeOption::with([
                        'productAttribute'
                    ])
                    ->whereIn('product_attribute_id', $product_attributes_detail)
                    ->whereHas('products', function ($query) {
                        $query->where('products.id', $this->productId);
                    })->get();

                $validOptionsGroupBy = $validOptions->groupBy('product_attribute_id');

                if (!empty($validOptionsGroupBy)) {
                    foreach ($validOptionsGroupBy as $attributeId => $attributeOptions) {
                        foreach ($attributeOptions as $attOption) {
                            $productAttributeName = $attOption->productAttribute->attribute_name;
                            $attributeSnakeCasedName = Str::snake($productAttributeName);
                            $validProductAttributeOptions[$attributeId][$attributeSnakeCasedName][$attOption->id] = $attOption->option;
                        }
                    }
    
                    if (!empty($validProductAttributeOptions)) {
                        $selectedInvalidAttributeOption = [];
                        foreach ($validProductAttributeOptions as $attributeId => $attributesDetails) {
                            if (array_key_exists($attributeId, $this->selectedOptions)) {
                                foreach ($attributesDetails as $attrN => $attrOpt) {
                                    if (isset($this->selectedOptions[$attributeId]) && $this->selectedOptions[$attributeId] != '') {
                                        $formattedProdAttrName = (ucfirst(str_replace('_', ' ', $attrN)));
                                        if (!array_key_exists($this->selectedOptions[$attributeId], $attrOpt)) {
                                            $selectedInvalidAttributeOption[$formattedProdAttrName][] = $this->selectedOptions[$attributeId];
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!empty($selectedInvalidAttributeOption)) {
                        foreach ($selectedInvalidAttributeOption as $attrN => $attrOpt) {
                            $formattedProdAttrName = (ucfirst(str_replace('_', ' ', $attrN)));
                            $invalidOptionData = implode(',', $attrOpt);

                            $attributeErrorMessage = "The invalid option {$invalidOptionData} for the attribute {$formattedProdAttrName} is selected.";

                            $ProductAttributeValidationResponse[] = $attributeErrorMessage;
                        }
                    }
                }
            }
        }

        return $ProductAttributeValidationResponse;
    }
}
