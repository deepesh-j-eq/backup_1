<?php

namespace App\Livewire;

use App\Models\Cart;
use App\Services\CartService;
use Livewire\Component;

class Checkout extends Component
{
    /**
     * @var Collection|array
     */
    public $cartItems = [];

    public $cartTotal = 0;
    public $subTotal = 0;
    public $shippingCost = 0;
    public $tax = 0;

    /**
     * @var array<string, string>
     */
    public $contactInfo = [
        'email' => '',
        'phone' => ''
    ];

    /**
     * @var array<string, string>
     */
    public $shippingAddress = [
        'first_name' => '',
        'last_name' => '',
        'address_1' => '',
        'address_2' => '',
        'city' => '',
        'country' => '',
        'postal_code' => ''
    ];

    /**
     * @var array<string, string>
     */
    public $paymentInfo = [
        'card_number' => '',
        'name_on_card' => '',
        'expiry_date' => '',
        'cvc' => ''
    ];

    public $shippingMethod = 'standard';

    protected $cartService;

    public function mount()
    {
        $this->cartService = new CartService;

        $user = loggedinUserDetail();
        if ($user && !empty($user)) {
            $this->contactInfo['email'] = $user->email ?? '';
            $this->shippingAddress['first_name'] = $user->name ?? '';
        }

        $this->loadCartItems();
    }

    public function loadCartItems()
    {
        $user = loggedinUserDetail();

        if ($user && !empty($user)) {
            try {
                $this->cartItems = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->get();

                $this->cartItems = $this->cartItems->filter(function ($item) {
                    return !is_null($item->product);
                });

                $this->calculateTotals();
            } catch (\Exception $e) {
                session()->flash('error_message', 'Error occurred while fetching your cart. Error: ' . $e->getMessage());
            }
        } else {
            session()->flash('error_message', 'User not logged in. Something went wrong while fetching the cart.');
        }
    }

    public function calculateTotals()
    {
        $this->subTotal = 0;

        if (is_null($this->cartService)) {
            $this->cartService = new CartService;
        }

        foreach ($this->cartItems as $item) {
            if (is_null($item->product)) {
                continue;
            }

            $item->sub_total = $this->cartService->calculateSubTotal($item);
            $this->subTotal += $item->sub_total;
        }

        $this->shippingCost = $this->cartService->shippingEstimate($this->shippingMethod);
        $this->tax = $this->cartService->taxCalculation($this->subTotal, 14);
        $this->cartTotal = $this->subTotal + $this->shippingCost + $this->tax;
    }

    public function updatedShippingMethod()
    {
        $this->calculateTotals();
    }

    public function checkProductAvailability()
    {
        if (is_null($this->cartService)) {
            $this->cartService = new CartService;
        }

        foreach ($this->cartItems as $item) {
            $availability = $this->cartService->varifyProductAvailabilityOnCheckout($item);
            if (!empty($availability['not_available_product_details'])) {
                $product = $availability['not_available_product_details'][0];
                throw new \Exception("Not enough stock for {$product['product_name']}. Requested: {$product['cart_quanity']}, Available: {$product['available_quantity']}");
            }
        }
    }

    public function placeOrder()
    {
        $user = loggedinUserDetail();

        if ($user && !empty($user)) {
            try {
                $this->validate([
                    'contactInfo.email' => 'required|email',
                    'contactInfo.phone' => 'required|numeric|digits:10',
                    'shippingAddress.first_name' => 'required|string|min:2|max:255',
                    'shippingAddress.last_name' => 'required|string|min:2|max:255',
                    'shippingAddress.address_1' => 'required|string|min:10|max:255',
                    'shippingAddress.address_2' => 'nullable|string|max:255',
                    'shippingAddress.city' => 'required|string|max:255|regex:/[a-zA-Z]+/',
                    'shippingAddress.country' => 'required|string|max:255|regex:/[a-zA-Z]+/',
                    'shippingAddress.postal_code' => 'required|regex:/^\d{6,}$/',
                    'paymentInfo.card_number' => 'required|numeric|digits:16',
                    'paymentInfo.name_on_card' => 'required|string|min:2|max:255',
                    'paymentInfo.expiry_date' => 'required|regex:/^(0[1-9]|1[0-2])\/[0-9]{2}$/',
                    'paymentInfo.cvc' => 'required|numeric|digits:3'
                ]);

                session()->flash('message', 'Order placed successfully!');
                $this->dispatch('showAlert', session('message'));

                Cart::where('user_id', $user->id)->delete();
                $this->cartItems = collect([]);
                $this->calculateTotals();
            } catch (\Exception $e) {
                session()->flash('error_message', 'Error occurred while placing the order. Error: ' . $e->getMessage());
            }
        } else {
            session()->flash('error_message', 'User not logged in. Something went wrong while placing the order.');
        }
    }

    public function render()
    {
        return view('livewire.checkout', [
            'cartItems' => $this->cartItems,
            'cartTotal' => $this->cartTotal,
            'subTotal' => $this->subTotal,
            'shippingCost' => $this->shippingCost,
            'tax' => $this->tax
        ]);
    }
}
