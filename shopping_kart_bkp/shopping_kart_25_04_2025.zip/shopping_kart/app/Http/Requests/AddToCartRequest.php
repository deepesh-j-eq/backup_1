<?php

namespace App\Http\Requests;

use App\Models\Cart;
use App\Models\Product;
use App\Models\ProductAttributeOption;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class AddToCartRequest extends FormRequest
{
    protected $productId, $quantity, $selectedOptions, $prdouctHasAttributeOptions;

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules($productId, $quantity, $selectedOptions = []): array
    {
        //dd($productId, $quantity, $selectedOptions);

        $this->productId = $productId;
        $this->quantity = (int) $quantity;
        $this->selectedOptions = $selectedOptions;

        //dd($this->productId, $this->quantity, $this->selectedOptions);

        $rules = [
            'productId' => 'required|exists:products,id',
            'quantity' => 'required|min:1'
        ];

        if (empty($this->productId)) {
            return $rules;
        }

        if (!isset($rules['quantity']) || !is_array($rules['quantity'])) {
            $rules['quantity'] = ['required', 'min:1'];
        }

        $productData = Product::with([
            'attributeOptions',
            'attributeOptions.productAttribute:id,attribute_name'
        ])
        ->find($this->productId);

        if (!$productData) {
            return $rules;
        }

        $product_has_attributes = [];
        $product_has_attributes_options = [];
        $product_attributes_detail = [];
        $validProductAttributeOptions = [];

        $productQuantityInfo = [];

        if ($productData->attributeOptions->isNotEmpty()) {
            $productHasAtrributeOptionsGroupBy = $productData->attributeOptions->groupBy('product_attribute_id');

            if (!empty($productHasAtrributeOptionsGroupBy)) {
                foreach ($productHasAtrributeOptionsGroupBy as $productAttributeId => $productHasAttributeDetails) {
                    foreach ($productHasAttributeDetails as $productAttributeOptions) {
                        $productAttributeName = Str::snake($productAttributeOptions->productAttribute->attribute_name ?? '');
                        if (!array_key_exists($productAttributeId, $product_has_attributes)) {
                            $product_has_attributes[$productAttributeId] = $productAttributeName;
                        }

                        $product_has_attributes_options[$productAttributeId][$productAttributeName][] = $productAttributeOptions->id;
                    }
                }
            }

            if (!empty($product_has_attributes)) {
                if (empty($this->selectedOptions)) {
                    foreach ($product_has_attributes as $productAttributeId => $productAttributeOption) {
                        $key = 'selectedOptions.' . $productAttributeId;
                        $rules[$key] = [
                            'required',
                            'integer',
                            function ($attribute, $value, $fail) use ($productAttributeOption) {
                                $name = ucfirst($productAttributeOption);
                                $fail("The {$name} field is required.###");
                            }
                        ];
                    }
                } else if (!empty($this->selectedOptions) && !empty($product_has_attributes_options)) {
                    //dd('product_has_attributes ', $product_has_attributes, 'product_has_attributes_options', $product_has_attributes_options, '$this->selectedOptions ', $this->selectedOptions);
                    $missingAttributes = [];
                    $unmatchedAttributes = [];
                    foreach ($product_has_attributes as $productAttributeId => $productAttributeOption) {
                        if (!array_key_exists($productAttributeId, $this->selectedOptions)) {
                            $key = 'selectedOptions.' . $productAttributeId;
                            $rules[$key] = [
                                'required',
                                'integer',
                                function ($attribute, $value, $fail) use ($productAttributeOption) {
                                    $name = ucfirst($productAttributeOption);
                                    $fail("The {$name} field is required.");
                                }
                            ];
                        }
                    }

                    foreach ($product_has_attributes_options as $productAttributeId => $productAttributeGroup) {
                        $key = 'selectedOptions.' . $productAttributeId;
                        foreach($productAttributeGroup as $prodAttrName => $productAttrOptIds) {
                            $isValueMissing = !isset($this->selectedOptions[$productAttributeId]) || trim($this->selectedOptions[$productAttributeId]) === '';
                            if ($isValueMissing) {
                                $formatedProdAttrName = (ucfirst(str_replace('_', ' ', $prodAttrName)));
                                $missingAttributes[$key] = $formatedProdAttrName;
                            }

                            if (isset($this->selectedOptions[$productAttributeId]) && trim($this->selectedOptions[$productAttributeId]) !== '') {
                                $selectedValue = (int) $this->selectedOptions[$productAttributeId];

                                if (!in_array($selectedValue, $productAttrOptIds, true)) {
                                    $formatedProdAttrName = (ucfirst(str_replace('_', ' ', $prodAttrName)));
                                    $unmatchedAttributes[$key] = $formatedProdAttrName;
                                }
                            }
                        }
                    }

                    //dd($missingAttributes, $unmatchedAttributes);

                    if (!empty($missingAttributes)) {
                        foreach ($missingAttributes as $errorKey => $missingAttr) {
                            $rules[$errorKey] = [
                                'required',
                                'integer',
                                function ($attribute, $value, $fail) use ($missingAttr) {
                                    if (is_null($value) || trim($value) === '') {
                                        $fail("The {$missingAttr} field is required.");
                                    }
                                }
                            ];
                        }
                    }

                    $product_attributes_detail = array_keys($this->selectedOptions);

                    $validOptions = ProductAttributeOption::with([
                            'productAttribute'
                        ])
                        ->whereIn('product_attribute_id', $product_attributes_detail)
                        ->whereHas('products', function ($query) {
                            $query->where('products.id', $this->productId);
                        })->get();

                    $validOptionsGroupBy = $validOptions->groupBy('product_attribute_id');

                    if (!empty($validOptionsGroupBy)) {
                        foreach ($validOptionsGroupBy as $attributeId => $attributeOptions) {
                            foreach ($attributeOptions as $attOption) {
                                $productAttributeName = $attOption->productAttribute->attribute_name;
                                $attributeSnakeCasedName = Str::snake($productAttributeName);
                                $validProductAttributeOptions[$attributeId][$attributeSnakeCasedName][$attOption->id] = $attOption->option;
                            }
                        }
                        //dd($validProductAttributeOptions);
        
                        if (!empty($validProductAttributeOptions)) {
                            foreach ($validProductAttributeOptions as $attributeId => $attributesDetails) {
                                $key = 'selectedOptions.' . $attributeId;
                                //dd('key ', $key, 'attributesDetails ', $attributesDetails);
                                $rules[$key] = [
                                    'nullable',
                                    'integer',
                                    function ($attribute, $value, $fail) use ($validProductAttributeOptions, $attributesDetails) {
                                        foreach ($attributesDetails as $attrN => $attrOpt) {
                                            if (!array_key_exists($value, $attrOpt)) {
                                                $productAttributeNumber = str_replace('selectedOptions.', '', $attribute);
                                                if ($productAttributeNumber != '') {
                                                    $creatingProductAttributeName = array_keys($validProductAttributeOptions[$productAttributeNumber]);
                                                    if (!empty($creatingProductAttributeName)) {
                                                        $fail("The selected {$creatingProductAttributeName[0]} is invalid.");
                                                    } else {
                                                        $fail("The selected {$productAttributeNumber} is invalid.");
                                                    }
                                                } else {
                                                    $fail("The selected {$productAttributeNumber} is invalid.");
                                                }
                                            }
                                        }
                                    }
                                ];
                            }
                        }
                    }

                    foreach($this->selectedOptions as $attributeId => $attributeOptionId) {
                        $productAttributeOptionsDetail = ProductAttributeOption::with([
                            'products:id,quantity',
                            'productAttribute:id,attribute_name'
                        ])
                        ->where('id', $attributeOptionId)
                        ->whereHas('products', function ($query) {
                            $query->where('products.id', $this->productId);
                        })
                        ->whereHas('productAttribute', function ($query) use ($attributeId) {
                            $query->where('id', $attributeId);
                        })
                        ->get();

                        //dd($productAttributeOptionsDetail);

                        if ($productAttributeOptionsDetail->isNotEmpty()) {
                            foreach ($productAttributeOptionsDetail as $attrbuteOption) {
                                $attributeName = $attrbuteOption->productAttribute->attribute_name;
                                $optionName = $attrbuteOption->option;
                                foreach ($attrbuteOption->products as $produc) {
                                    $productQuantityInfo[$attributeName] = [
                                        'product_attribute_option' => $optionName,
                                        'product_quantity' => $produc->quantity,
                                    ];
                                }
                            }
                        }
                    }

                    $rules['quantity'][] = function ($attribute, $value, $fail) use ($productQuantityInfo) {
                        $messages = [];

                        if (!empty($productQuantityInfo)) {
                            foreach ($productQuantityInfo as $prodAttrName => $info) {
                                if ($value > $info['product_quantity']) {
                                    if (count($productQuantityInfo) > 1) {
                                        $messages[] = "The requested quantity for '{$prodAttrName}' Option '{$info['product_attribute_option']}' and  ";
                                    } else {
                                        $messages[] = "The requested quantity for '{$prodAttrName}' Option '{$info['product_attribute_option']}' ";
                                    }
                                }
                            }

                            if (!empty($messages)) {
                                $messages = array_merge($messages, array('is not available for sale.'));
                                //$fail(implode(' ', $messages));
                            }
                        }
                    };
                }
            }
        } else {
            //code for product which does not have attribute options
            if ($productData) {
                $rules['quantity'][] = function ($attribute, $value, $fail) use ($productData) {
                    //dd(var_dump($value), var_dump($productData->quantity));
                    if ((int) $value > (int) $productData->quantity) {
                        $fail("The requested quantity for '{$productData->name}' is not available for sale.");
                    }
                };
            }
        }

        $user = loggedinUserDetail();

        if ($productData) {
            //dd($this->quantity, $productData->quantity, $user->name);
            $rules['quantity'][] = function ($attribute, $value, $fail) use ($productData, $user) {
                if (!is_null($user)) {
                    $prodId = $productData->id;
                    $prodName = $productData->name;
                    $prodQuantity = $productData->quantity;

                    $cartDetails = Cart::where([
                        'product_id' => $prodId,
                        'user_id' => $user->id
                    ])->get();

                    //dd($cartDetails);

                    if ($cartDetails->isNotEmpty()) {
                        $cartItemQuantity = 0;
                        $availableQuantity = 0;
                        $getHandleStockMessage = [];

                        foreach ($cartDetails as $cartDetail) {
                            $cartItemQuantity = $cartItemQuantity + $cartDetail->quantity;

                            if ($cartItemQuantity && $cartItemQuantity > 0) {
                                $availableQuantity = $prodQuantity - $cartItemQuantity;
                            }

                            if (isset($cartDetail->product_attribute_option_id) && !is_null($cartDetail->product_attribute_option_id)) {
                                //dd('product is in cart with attribute options', "value ".$value, "cartItemQuantity ".$cartItemQuantity, "prodId ".$prodId, "prodQuantity ".$prodQuantity, "cartDetail->product_attribute_option_id ".$cartDetail->product_attribute_option_id);
                                $selectedProductAttributeOption = $cartDetail->product_attribute_option_id;

                                $getHandleStockMessage = $this->getHandleStockMessage($cartDetail, $user);

                                //dd($getHandleStockMessage);
                            }
                        }

                        $validatedCartItemsMessage = '';

                        if ((int) $value > (int) $availableQuantity) {
                            if (!empty($getHandleStockMessage)) {
                                if (isset($getHandleStockMessage['validated_cart_items_message'])){
                                    $validatedCartItemsMessage = $getHandleStockMessage['validated_cart_items_message'];

                                    if ($availableQuantity <= 0) {
                                        $fail("Not enough stock available for product '{$prodName}'. {$cartItemQuantity} already in your cart. {$validatedCartItemsMessage}");
                                    } else {
                                        $fail("Not enough stock available for product '{$prodName}'. Available quantity is {$availableQuantity}. {$validatedCartItemsMessage}");
                                    }
                                } else {
                                    if ($availableQuantity <= 0) {
                                        $fail("Not enough stock available for product '{$prodName}'. {$cartItemQuantity} already in your cart.");
                                    } else {
                                        $fail("Not enough stock available for product '{$prodName}'. Available quantity is {$availableQuantity}.");
                                    }
                                }
                            } else {
                                if ($availableQuantity <= 0) {
                                    $fail("The requested quantity for '{$prodName}' is not available for sale.");
                                } else {
                                    $fail("The requested quantity for '{$prodName}' is not available for sale. The Available quantity is {$availableQuantity}");
                                }
                            }
                        }
                    } else {
                        //dd('product not in cart', "value ".$value, "prodQuantity ".$prodQuantity);
                        if ($value > $prodQuantity) {
                            $fail("The requested quantity for '{$prodName}' is not available for sale. Maximum available quantity is $prodQuantity");
                        }
                    }
                } else {
                    //dd('user is null');
                    if ($this->quantity > (int) $productData->quantity) {
                        $fail("The requested quantity for '{$productData->name}' is not available for sale. Maximum available quantity is '{$productData->quantity}'");
                    }
                }
            };
        }

        return $rules;
    }

    public function messages(): array
    {
        return [
            'selectedOptions.*.required' => 'Please select product attribute.'
        ];
    }

    protected function getHandleStockMessage($cartItem, $user)
    {
        try {
            $cartItemsWithProdAttrOpt = Cart::with([
                'product.attributeOptions',
                'product.attributeOptions.productAttribute'
            ])
            ->where([
                'product_id' => $cartItem->product_id,
                'user_id' => $user->id
            ])->get();

            //dd($cartItemsWithProdAttrOpt);

            if ($cartItemsWithProdAttrOpt->isEmpty()) {
                return [
                    'current_cart_quantity' => '',
                    'validated_cart_items_message' => ''
                ];
            }

            $cartItemHasAttributeOptions = [];
            $productHasAttributes = [];
            $productHasAttributeOptions = [];
            $attributeOptionsMap = [];
            $transformCartItemHasAttributeOptions = [];

            if ($cartItemsWithProdAttrOpt->isNotEmpty()) {
                foreach ($cartItemsWithProdAttrOpt as $itemDetails) {
                    $cartItemHasAttributeOptions[$itemDetails->id] = [
                        "cart_attribute_options" => $itemDetails->product_attribute_option_id,
                        "cart_quantity" => $itemDetails->quantity
                    ];

                    if ($itemDetails->product && $itemDetails->product->attributeOptions) {
                        foreach ($itemDetails->product->attributeOptions as $itemAttributeOption) {
                            $productAttrName = $itemAttributeOption->productAttribute ? $itemAttributeOption->productAttribute->attribute_name : '';
                            $optionId = $itemAttributeOption->id;
                            $optionValue = $itemAttributeOption->option;

                            if (!in_array($productAttrName, $productHasAttributes)) {
                                $productHasAttributes[] = $productAttrName;
                            }

                            $key = strtolower($productAttrName);

                            if (!isset($attributeOptionsMap[$key])) {
                                $attributeOptionsMap[$key] = array();
                            }

                            $attributeOptionsMap[$key][$optionId] = $optionValue;
                        }
                    }
                }

                $productHasAttributeOptions = [];
                if (!empty($attributeOptionsMap)) {
                    foreach ($attributeOptionsMap as $attrName => $attrOptions) {
                        $productHasAttributeOptions[] = [$attrName => $attrOptions];
                    }
                }

                //dd($productHasAttributeOptions);

                if (!empty($cartItemHasAttributeOptions)) {
                    foreach ($cartItemHasAttributeOptions as $cartId => $itemData) {
                        $decodedOptions = json_decode($itemData['cart_attribute_options'], true);
                        $transformed = [];

                        foreach ($decodedOptions as $attributeKey => $attributeValue) {
                            $cleanKey = str_replace('_', ' ', $attributeKey);
                            $transformed[$cleanKey] = (int) $attributeValue;
                        }

                        $transformed['cart_quantity'] = (int) $itemData['cart_quantity'];
                        $transformCartItemHasAttributeOptions[$cartId] = $transformed;
                    }
                }

                $validatedCartItems = [];
                $nonValidatedCartItems = [];

                if (!empty($transformCartItemHasAttributeOptions)) {
                    foreach ($transformCartItemHasAttributeOptions as $cartId => $attributes) {
                        $isValidAttributeOption = true;
                        $transformedProductAttributeOpts = [];

                        foreach ($attributes as $attributeKey => $optionId) {
                            if ($attributeKey === 'cart_quantity') {
                                $transformedProductAttributeOpts['cart_quantity'] = $optionId;
                                continue;
                            }

                            $found = false;

                            foreach ($productHasAttributeOptions as $attributeGroup) {
                                if (isset($attributeGroup[$attributeKey]) && isset($attributeGroup[$attributeKey][$optionId])) {
                                    $transformedProductAttributeOpts[$attributeKey] = $attributeGroup[$attributeKey][$optionId];
                                    $found = true;
                                }
                            }

                            if (!$found) {
                                $transformedProductAttributeOpts[$attributeKey] = $optionId;
                                $isValidAttributeOption = false;
                            }
                        }

                        if ($isValidAttributeOption) {
                            $validatedCartItems[$cartId] = $transformedProductAttributeOpts;
                        } else {
                            $nonValidatedCartItems[$cartId] = $transformedProductAttributeOpts;
                        }
                    }
                }

                $currentCartQuantityProductAttributeWise = '';
                $validatedCartItemsMessage = '';

                //dd($validatedCartItems);

                if (!empty($validatedCartItems)) {
                    $currentCartQuantityProductAttributeWise = 0;

                    $ik = 1;
                    foreach ($validatedCartItems as $cartQuantityDetails) {
                        if ($ik == 1) {
                            $validatedCartItemsMessage .= '<ul>You have added';
                            $validatedCartItemsMessage .= '<li>' . $cartQuantityDetails['cart_quantity'] . ' quantity for attribute </li>';
                        } else {
                            $validatedCartItemsMessage .= '<li>' . $cartQuantityDetails['cart_quantity'] . ' quantity for attribute</li>';
                        }

                        foreach ($cartQuantityDetails as $attribute_name => $attribute_option) {
                            if ($attribute_name == 'cart_quantity') {
                                continue;
                            }

                            $validatedCartItemsMessage .= '"' . (ucfirst(str_replace('_', ' ', $attribute_name))) . '"' . ' => ' . $attribute_option . ' ';
                        }

                        if (isset($cartQuantityDetails['cart_quantity'])) {
                            $currentCartQuantityProductAttributeWise = $currentCartQuantityProductAttributeWise + $cartQuantityDetails['cart_quantity'];
                        }
                        if ($ik == count($validatedCartItems)) {
                            $validatedCartItemsMessage .= '</ul>';
                        }
                        $ik++;
                    }
                }

                if (isset($currentCartQuantityProductAttributeWise) && $currentCartQuantityProductAttributeWise !== '') {
                    $currentCartQuantity = $currentCartQuantityProductAttributeWise;
                } else {
                    $currentCartQuantity = '';
                }

                return [
                    'current_cart_quantity' => $currentCartQuantity,
                    'validated_cart_items_message' => $validatedCartItemsMessage
                ];
            }
        } catch (\Exception $e) {
            session()->flash('error_message', 'Error occured while get handle stock message. Error : ' . $e->getMessage());
        }
    }
}
