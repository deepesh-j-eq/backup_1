@push('additional_css')
    <style>
        #priceValueDisplay {
            display: inline-block;
            background-color: #f1f5f9;
            color: #0f172a;
            padding: 8px 16px;
            border-radius: 999px;
            font-weight: 600;
            margin-top: 10px;
        }
    </style>
@endpush
@section('title', 'Products')
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    @if (userRole() && userRole() == 'admin')
                                        <div class="col-lg-3 col-xl-2 ms-5">
                                            <a href="{{ route('admin.products') }}" class="btn btn-primary mb-3 mb-lg-0"><i class='bx bxs-plus-square'></i>New Product</a>
                                        </div>
                                    @endif

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="card p-4 mb-4 shadow-sm">
                                                <form>
                                                    <div class="row g-3 mb-4">
                                                        <!-- Search -->
                                                        <div class="col-lg-6 col-md-12">
                                                            <div class="position-relative">
                                                                <input type="text" class="form-control ps-5" wire:model.live.debounce.300ms="searchTerm" placeholder="Search Product...">
                                                                <span class="position-absolute top-50 product-show translate-middle-y"><i class="bx bx-search"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-md-12"></div>
                                                    </div>
                                                    
                                                    <div class="row g-3 mb-4">
                                                        <h4 class="mb-3">Filters</h4>
                                                        <div class="row g-3">
                                                            <div class="mb-3">
                                                                <button class="btn btn-danger" wire:click="clearFilters">Clear All Filters</button>
                                                            </div>

                                                            <!-- Category Filter -->
                                                            <div class="col-lg-2 col-md-3">
                                                                <div class="dropdown">
                                                                    <button class="btn {{ !empty($selectedCategories) ? 'btn-primary' : 'btn-white' }} dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                                        Categories
                                                                    </button>
                                                                    <ul class="dropdown-menu p-3">
                                                                        @foreach ($categories as $category)
                                                                            <li>
                                                                                <div class="form-check">
                                                                                    <input class="form-check-input" type="checkbox" wire:model.live="selectedCategories" value="{{ $category->id }}" id="category-{{ $category->id }}">
                                                                                    <label class="form-check-label" for="category-{{ $category->id }}">
                                                                                        {{ $category->name }}
                                                                                    </label>
                                                                                </div>
                                                                            </li>
                                                                        @endforeach
                                                                    </ul>
                                                                </div>
                                                            </div>

                                                            <!-- Price Range -->
                                                            <div class="col-lg-2 col-md-3">
                                                                <div class="dropdown">
                                                                    <button class="btn {{ $maxPrice != 10000 ? 'btn-primary' : 'btn-white' }} dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                                        Price Range
                                                                    </button>
                                                                    <div class="dropdown-menu p-3">
                                                                        <input type="range" class="form-range" id="priceRange" wire:model.live="maxPrice" min="100" max="10000" step="50">
                                                                        <div class="d-flex justify-content-between mt-2">
                                                                            <span class="badge bg-light text-dark">$100</span>
                                                                            <span class="badge bg-light text-dark">$<span wire:model="maxPrice">{{ $maxPrice }}</span></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- Sort By -->
                                                            <div class="col-lg-2 col-md-3">
                                                                <div class="dropdown">
                                                                    <button class="btn {{ $sortBy == '' ? 'btn-white' : 'btn-primary' }} dropdown-toggle" type="button" data-bs-toggle="dropdown" data-td="">
                                                                        Sort By
                                                                    </button>
                                                                    <ul class="dropdown-menu">
                                                                        <li><a class="dropdown-item {{ $sortBy == 'newest' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('newest')">Newest</a></li>
                                                                        <li><a class="dropdown-item {{ $sortBy == 'price_low_high' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('price_low_high')">Price Low to High</a></li>
                                                                        <li><a class="dropdown-item {{ $sortBy == 'price_high_low' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('price_high_low')">Price High to Low</a></li>
                                                                        <li><a class="dropdown-item {{ $sortBy == 'most_popular' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('most_popular')">Most Popular</a></li>
                                                                        <li><a class="dropdown-item {{ $sortBy == 'best_rating' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('best_rating')">Best Rating</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>

                                                            <!-- Dynamic Attributes -->
                                                            @php //dd($productAttributes); @endphp
                                                            @foreach ($productAttributes as $attribute)
                                                                @if ($attribute->productAttributeOptions->isNotEmpty())
                                                                    <div class="col-lg-2 col-md-3">
                                                                        <div class="dropdown">
                                                                            <button class="btn {{ !empty($selectedAttributes[$attribute->id]) ? 'btn-primary' : 'btn-white' }} dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                                                {{ $attribute->attribute_name }}
                                                                            </button>
                                                                            <ul class="dropdown-menu p-3">
                                                                                @foreach ($attribute->productAttributeOptions as $atributeOption)
                                                                                    <li>
                                                                                        <div class="form-check">
                                                                                            <input class="form-check-input" type="checkbox" wire:model.live="selectedAttributes.{{ $attribute->id }}" value="{{ $atributeOption->id }}" id="attr-{{ $attribute->id }}-{{ $atributeOption->id }}">
                                                                                            <label class="form-check-label" for="attr-{{ $attribute->id }}-{{ $atributeOption->id }}">
                                                                                                {{ $atributeOption->option }}
                                                                                            </label>
                                                                                        </div>
                                                                                    </li>
                                                                                @endforeach
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            @endforeach
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    @if (session()->has('message') || session()->has('error_message'))
                                        <div class="card">
                                            <div class="card-body p-4">
                                                @if (session()->has('message'))
                                                    <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                                        {{ session('message') }}
                                                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                                    </div>
                                                @endif

                                                @if (session()->has('error_message'))
                                                    <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                                        {{ session('error_message') }}
                                                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 row-cols-xxl-5 product-grid">
                    @if ($productDetails->isNotEmpty())
                        @foreach ($productDetails as $product)
                            @php
                                $productImages = $product->images;
                                $productImagePath = '';
                                if ($productImages) {
                                    foreach ($productImages as $productImg) {
                                        $productImagePath = $productImg->image_path;
                                        break;
                                    }
                                }

                                $discountPercentage = '';
                                if ($product->discounted_price) {
                                    $productPrice = (float)($product->price);
                                    $productDiscountPrice = (float)($product->discounted_price);
                                    $discountPercentage = (($productPrice - $productDiscountPrice) / $productPrice) * 100;
                                    $discountPercentage = number_format((float)$discountPercentage, 0);
                                }
                            @endphp
                            <div class="col">
                                <div class="card">
                                    <a href="{{ route('product.detail', ['productId' => $product->id]) }}">
                                        <img src="{{ ($productImagePath != '') ? asset('storage/' . $productImagePath) : '' }}" class="card-img-top" alt="{{ $product->name }}" width="302px" height="302px">
                                    </a>
                                    @if ($discountPercentage != '')
                                        <div class="">
                                            <div class="position-absolute top-0 end-0 m-3 bg-primary text-white p-2 rounded-circle"><span class="">{{ '-'.$discountPercentage.'%' }}</span></div>
                                        </div>
                                    @endif
                                    <div class="card-body">
                                        <h6 class="card-title cursor-pointer">
                                            <a href="{{ route('product.detail', ['productId' => $product->id]) }}" class="text-decoration-none text-dark">
                                                {{ $product->name }}
                                            </a>
                                        </h6>
                                        <div class="clearfix">
                                            <p class="mb-0 float-start"><strong>134</strong> Sales</p>
                                            <p class="mb-0 float-end fw-bold">
                                                @if ($discountPercentage != '')
                                                    <span class="me-2 text-decoration-line-through text-secondary">{{ '$'.$product->price }}</span>
                                                    <span>{{ '$'.(number_format($product->discounted_price, 2, '.', '')) ?? '' }}</span>
                                                @else
                                                    <span>{{ '$'.(number_format($product->price, 2, '.', '')) }}</span>
                                                @endif
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-center mt-3 fs-6">
                                            <div class="cursor-pointer">
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-secondary'></i>
                                            </div>	
                                            <p class="mb-0 ms-auto">4.2(182)</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @else
                    <div class="col-lg-12 col-md-12">
                        <div class="col">
                            <div class="card">
                                <div class="card-body p-4">
                                    <h5 class="card-title text-center">There is no products available, if you have selected any filter then please change filter and try again.</h5>
                                    <hr />
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                </div><!--end row-->
                <div wire:ignore.self class="d-flex justify-content-end mt-3 me-3">
                    {{ $productDetails->links('livewire::bootstrap-5') }}
                </div>
            </div>
        </div>
        <!--end page wrapper -->
