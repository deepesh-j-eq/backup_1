<?php $__env->startPush('meta_tags'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>
<?php $productName = $productDetail->name ?? ''; ?>
<?php $__env->startSection('title', 'Product Detail | ' . $productName); ?>
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">

                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Products Details</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->


                <!--[if BLOCK]><![endif]--><?php if($productDetail): ?>
                    <?php $ik = 1; ?>
                    <?php $productImagesArray = []; ?>
                    <?php $productMainImagePath = ''; ?>
                    <?php $productAttributesArray = []; ?>
                    <?php $productAttributeOtionsArray = []; ?>

                    <!--[if BLOCK]><![endif]--><?php if($productDetail->attributeOptions): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productDetail->attributeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productAttributeOptionsDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--[if BLOCK]><![endif]--><?php if($productAttributeOptionsDetail): ?>
                                <?php
                                    $productAttributeName = $productAttributeOptionsDetail->productAttribute->attribute_name;
                                    $productAttributeId = $productAttributeOptionsDetail->product_attribute_id;

                                    $productAttributeOtionsArray[$productAttributeName][$productAttributeOptionsDetail->id] = $productAttributeOptionsDetail->option;
                                ?>
                                <!--[if BLOCK]><![endif]--><?php if(!in_array($productAttributeName, $productAttributesArray, true)): ?>
                                    <?php
                                        $productAttributesArray[$productAttributeId] = ($productAttributeName) ?? '';
                                    ?>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productDetail->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if ($productImg && $ik == 1) {
                                $productMainImagePath = $productImg->image_path;
                            }

                            $productImagesArray[] = $productImg->image_path;
                            $ik++;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php
                        $discountPercentage = '';
                        if ($productDetail->discounted_price) {
                            $productPrice = (float)($productDetail->price);
                            $productDiscountPrice = (float)($productDetail->discounted_price);
                            $discountPercentage = (($productPrice - $productDiscountPrice) / $productPrice) * 100;
                            $discountPercentage = number_format((float)$discountPercentage, 0);
                        }
                    ?>
                <?php else: ?>
                    <script>
                        window.location.href = "<?php echo e(route('all.products')); ?>?error_message=<?php echo e(urlencode('Product not found.')); ?>";
                    </script>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <?php /*<!--[if BLOCK]><![endif]-->@if($errors->any())
                    {{ implode('', $errors->all('<div>:message</div>')) }}
                @endif<!--[if ENDBLOCK]><![endif]--> */ ?>

                <div class="card">
                    <div class="d-flex align-items-center justify-content-center my-3 my-lg-0">
                        <div class="row">
                            <div id="general-message"></div>
                            <div id="general-error"></div>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                            <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                <?php echo e(session('message')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <?php if(session()->has('error_message')): ?>
                            <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                <?php echo e(session('error_message')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="row g-0">
                        <div class="col-md-4 border-end">
                            <img src="<?php echo e(($productMainImagePath != '') ? asset('storage/' . $productMainImagePath) : ''); ?>" class="img-fluid <?php echo e(($productMainImagePath != '') ? 'product-detail-main-image' : ''); ?>" alt="<?php echo e($productName); ?>">
                            <!--[if BLOCK]><![endif]--><?php if($discountPercentage != ''): ?>
                                <div class="">
                                    <div class="position-absolute top-0 end-0 m-3 product-discount"><span class=""><?php echo e('-'.$discountPercentage.'%'); ?></span></div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if(isset($productImagesArray) && !empty($productImagesArray)): ?>
                                <?php $a = 1; ?>
                                <div class="row mb-3 row-cols-auto g-2 justify-content-center mt-3">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productImagesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col">
                                            <img src="<?php echo e(asset('storage/' . $productImages)); ?>" width="70" height="70" class="border rounded cursor-pointer <?php echo e('product-detail-sub-image-'.$a); ?>" alt="<?php echo e($productImages); ?>">
                                        </div>
                                        <?php $a++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo e($productName); ?></h4>
                                <div class="d-flex gap-3 py-3">
                                    <div class="cursor-pointer">
                                        <i class='bx bxs-star text-warning'></i>
                                        <i class='bx bxs-star text-warning'></i>
                                        <i class='bx bxs-star text-warning'></i>
                                        <i class='bx bxs-star text-warning'></i>
                                        <i class='bx bxs-star text-secondary'></i>
                                    </div>
                                    <div>142 reviews</div>
                                    <div class="text-success"><i class='bx bxs-cart-alt align-middle'></i> 134 orders</div>
                                </div>
                                <div class="mb-3">
                                    <span class="price h4">
                                        <p class="mb-0 fw-bold">
                                            <!--[if BLOCK]><![endif]--><?php if($discountPercentage != ''): ?>
                                                <span class="me-2 text-decoration-line-through text-secondary"><?php echo e('$'.$productDetail->price); ?></span>
                                                <span><?php echo e('$'.($productDetail->discounted_price) ?? ''); ?></span>
                                            <?php else: ?>
                                                <span><?php echo e('$'.$productDetail->price); ?></span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </p>
                                    </span>
                                    <!-- <span class="text-muted">/per kg</span> -->
                                </div>
                                <p class="card-text fs-6"><?php echo e($productDetail->description); ?></p>
                                <dl class="row">
                                    <dt class="col-sm-3">Model#</dt>
                                    <dd class="col-sm-9">Odsy-1000</dd>

                                    <dt class="col-sm-3">Color</dt>
                                    <dd class="col-sm-9">Brown</dd>

                                    <dt class="col-sm-3">Delivery</dt>
                                    <dd class="col-sm-9">Russia, USA, and Europe </dd>
                                </dl>
                                <hr>
                                <form id="add-to-cart-form" wire:submit.prevent="addToCart">
                                    <div class="row row-cols-auto row-cols-1 row-cols-md-3 align-items-center pr-quantity">
                                        <div class="col">
                                            <label class="form-label">Quantity</label>
                                            <div class="input-group input-spinner">
                                                <button class="btn btn-white" type="button" id="button-plus"> + </button>
                                                <input type="text" id="quantity" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" min="1" maxlength="9" wire:model="quantity">
                                                <button class="btn btn-white" type="button" id="button-minus"> − </button>
                                            </div>
                                        </div>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                        <!--[if BLOCK]><![endif]--><?php if(!empty($productDetail->attributeOptions)): ?>
                                            <?php $groupedAttributes = $productDetail->attributeOptions->groupBy('product_attribute_id')->toArray(); ?>
                                            <?php ksort($groupedAttributes); ?>

                                            <?php //dd($groupedAttributes); ?>

                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $groupedAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeId => $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $attributeName = $options[0]['product_attribute']['attribute_name'];
                                                    $modelKey = 'selectedOptions.' . $attributeId;
                                                ?>

                                                <div class="col">
                                                    <div class="form-group">
                                                        <label class="form-label"><?php echo e($attributeName); ?></label>
    
                                                        <!--[if BLOCK]><![endif]--><?php if(strtolower($attributeName) === 'color'): ?>
                                                            <div class="d-flex">
                                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $attrColor =  ($option['option']) ?? 'transparent'; ?>
                                                                    <?php $backgroundColor = "background-color: $attrColor"; ?>
                                                                    <label class="mr-3">
                                                                        <input type="radio"
                                                                            wire:model="<?php echo e($modelKey); ?>"
                                                                            class="form-check-input custom-control-input product-attribute-option <?php $__errorArgs = [$modelKey];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            style="display:inline-block;width:20px;margin-right:10px;height:20px;<?php echo e($backgroundColor); ?>;"
                                                                            value="<?php echo e($option['id']); ?>">
                                                                        <!--[if BLOCK]><![endif]--><?php if($attrColor && $attrColor == 'transparent'): ?> transparent <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                    </label>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$modelKey];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="bb">
                                                                <select class="form-select product-attribute-option <?php $__errorArgs = [$modelKey];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="<?php echo e($modelKey); ?>">
                                                                    <option value="">Select <?php echo e($attributeName); ?></option>
                                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($option['id']); ?>"><?php echo e($option['option']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                                </select>
                                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$modelKey];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                            </div>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                        <?php /*<!--[if BLOCK]><![endif]-->@if (!empty($productAttributeOtionsArray))
                                            <?php ksort($productAttributeOtionsArray) ?>
                                            <!--[if BLOCK]><![endif]-->@foreach($productAttributeOtionsArray as $attributeName => $attributeOptions)
                                                <?php $inputAttrbuteOptionName = strtolower($attributeName) . '_attribute_option';  ?>
                                                <!--[if BLOCK]><![endif]-->@if (strcmp($attributeName, 'Color') == 0)
                                                    <div class="col mt-3">
                                                        <div class="color-attribute-options-div">
                                                            <label class="form-label">{{ $attributeName }}</label>
                                                            <!--[if BLOCK]><![endif]-->@if ($attributeOptions && !empty($attributeOptions))
                                                                <!--[if BLOCK]><![endif]-->@foreach($attributeOptions as $attrOptId => $attrOpt)
                                                                    <?php $attrColor =  ($attrOpt) ?? 'transparent'; ?>
                                                                    <?php $backgroundColor = "background-color: $attrColor;"; ?>
                                                                    <input type="radio" name="{{ $inputAttrbuteOptionName }}" id="{{ $inputAttrbuteOptionName }}" class="form-check-input custom-control-input product-attribute-option @error($inputAttrbuteOptionName) is-invalid @enderror" style="{{ $backgroundColor }}" value="{{ $attrOptId }}"><!--[if BLOCK]><![endif]-->@if ($attrColor && $attrColor == 'transparent') transparent @endif<!--[if ENDBLOCK]><![endif]-->
                                                                @endforeach<!--[if ENDBLOCK]><![endif]-->
                                                                <!--[if BLOCK]><![endif]-->@error($inputAttrbuteOptionName) <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror<!--[if ENDBLOCK]><![endif]-->
                                                            @endif<!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                    </div>
                                                @else
                                                    <div class="col">
                                                        <label class="form-label">{{ $attributeName }}</label>
                                                        <!--[if BLOCK]><![endif]-->@if ($attributeOptions && !empty($attributeOptions))
                                                            <select name="{{ $inputAttrbuteOptionName }}" id="{{ $inputAttrbuteOptionName }}" class="form-select product-attribute-option @error($inputAttrbuteOptionName) is-invalid @enderror">
                                                                <option value="">Select {{ $attributeName }}</option>
                                                                <!--[if BLOCK]><![endif]-->@foreach($attributeOptions as $attrOptId => $attrOpt)
                                                                    <option value="{{ $attrOptId }}">{{ $attrOpt }}</option>
                                                                @endforeach<!--[if ENDBLOCK]><![endif]-->
                                                            </select>
                                                            <!--[if BLOCK]><![endif]-->@error($inputAttrbuteOptionName) <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror<!--[if ENDBLOCK]><![endif]-->
                                                        @endif<!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                @endif<!--[if ENDBLOCK]><![endif]-->
                                            @endforeach<!--[if ENDBLOCK]><![endif]-->
                                        @endif<!--[if ENDBLOCK]><![endif]--> */ ?>
                                    </div>
                                    <!-- <div class="row row-cols-auto row-cols-1 row-cols-md-3 align-items-center">
                                        <div class="col">
                                            <label class="form-label">Quantity</label>
                                            <div class="input-group input-spinner">
                                                <button class="btn btn-white" type="button" id="button-plus"> + </button>
                                                <input type="text" class="form-control" value="1">
                                                <button class="btn btn-white" type="button" id="button-minus"> − </button>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <label class="form-label">Select size</label>
                                            <div class="">
                                                <label class="form-check form-check-inline">
                                                    <input type="radio" class="form-check-input" name="select_size" checked="" class="custom-control-input">
                                                    <div class="form-check-label">Small</div>
                                                </label>
                                                <label class="form-check form-check-inline">
                                                    <input type="radio" class="form-check-input" name="select_size" checked="" class="custom-control-input">
                                                    <div class="form-check-label">Medium</div>
                                                </label>
            
                                                <label class="form-check form-check-inline">
                                                    <input type="radio" class="form-check-input" name="select_size" checked="" class="custom-control-input">
                                                    <div class="form-check-label">Large</div>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <label class="form-label">Select Color</label>
                                            <div class="color-indigators d-flex align-items-center gap-2">
                                                <div class="color-indigator-item bg-primary"></div>
                                                <div class="color-indigator-item bg-danger"></div>
                                                <div class="color-indigator-item bg-success"></div>
                                                <div class="color-indigator-item bg-warning"></div>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="d-flex gap-3 mt-3">
                                        <a href="#" class="btn btn-primary">Buy Now</a>
                                        <button class="btn btn-outline-primary"><span class="text">Add to cart</span> <i class='bx bxs-cart-alt'></i></button>
                                    </div>
                                    <input type="hidden" name="product_id" id="product_id" value="<?php echo e($productDetail->id); ?>">
                                    <input type="hidden" name="product_add_to_cart_url" id="product_add_to_cart_url" value="<?php echo e(route('add.to.cart')); ?>">
                                    <input type="hidden" name="update_cart_icon_quantity_url" id="update_cart_icon_quantity_url" value="<?php echo e(route('update.cart.icon.quantity')); ?>">
                                </form>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="card-body">
                        <ul class="nav nav-tabs nav-primary mb-0" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" data-bs-toggle="tab" href="#primaryhome" role="tab" aria-selected="true">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-icon"><i class='bx bx-comment-detail font-18 me-1'></i>
                                        </div>
                                        <div class="tab-title"> Product Description </div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="tab" href="#primaryprofile" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-icon"><i class='bx bx-bookmark-alt font-18 me-1'></i>
                                        </div>
                                        <div class="tab-title">Tags</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="tab" href="#primarycontact" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-icon"><i class='bx bx-star font-18 me-1'></i>
                                        </div>
                                        <div class="tab-title">Reviews</div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content pt-3">
                            <div class="tab-pane fade show active" id="primaryhome" role="tabpanel">
                                <p><?php echo e($productDetail->description); ?></p>
                            </div>
                            <div class="tab-pane fade" id="primaryprofile" role="tabpanel">
                                <p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. Exercitation +1 labore velit, blog sartorial PBR leggings next level wes anderson artisan four loko farm-to-table craft beer twee. Qui photo booth letterpress, commodo enim craft beer mlkshk aliquip jean shorts ullamco ad vinyl cillum PBR. Homo nostrud organic, assumenda labore aesthetic magna delectus mollit. Keytar helvetica VHS salvia yr, vero magna velit sapiente labore stumptown. Vegan fanny pack odio cillum wes anderson 8-bit, sustainable jean shorts beard ut DIY ethical culpa terry richardson biodiesel. Art party scenester stumptown, tumblr butcher vero sint qui sapiente accusamus tattooed echo park.</p>
                            </div>
                            <div class="tab-pane fade" id="primarycontact" role="tabpanel">
                                <p>Etsy mixtape wayfarers, ethical wes anderson tofu before they sold out mcsweeney's organic lomo retro fanny pack lo-fi farm-to-table readymade. Messenger bag gentrify pitchfork tattooed craft beer, iphone skateboard locavore carles etsy salvia banksy hoodie helvetica. DIY synth PBR banksy irony. Leggings gentrify squid 8-bit cred pitchfork. Williamsburg banh mi whatever gluten-free, carles pitchfork biodiesel fixie etsy retro mlkshk vice blog. Scenester cred you probably haven't heard of them, vinyl craft beer blog stumptown. Pitchfork sustainable tofu synth chambray yr.</p>
                            </div>
                        </div>
                    </div>

                </div>


                <h6 class="text-uppercase mb-0">Related Product</h6>
                <hr />
                <div class="row row-cols-1 row-cols-lg-3">
                    <div class="col">
                        <div class="card">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?php echo e(asset('assets/images/products/16.png')); ?>" class="img-fluid" alt="...">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h6 class="card-title">Light Grey Headphone</h6>
                                        <div class="cursor-pointer my-2">
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-secondary"></i>
                                        </div>
                                        <div class="clearfix">
                                            <p class="mb-0 float-start fw-bold"><span class="me-2 text-decoration-line-through text-secondary">$240</span><span>$199</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?php echo e(asset('assets/images/products/17.png')); ?>" class="img-fluid" alt="...">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h6 class="card-title">Black Cover iPhone 8</h6>
                                        <div class="cursor-pointer my-2">
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                        </div>
                                        <div class="clearfix">
                                            <p class="mb-0 float-start fw-bold"><span class="me-2 text-decoration-line-through text-secondary">$179</span><span>$110</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?php echo e(asset('assets/images/products/19.png')); ?>" class="img-fluid" alt="...">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h6 class="card-title">Men Hand Watch</h6>
                                        <div class="cursor-pointer my-2">
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-warning"></i>
                                            <i class="bx bxs-star text-secondary"></i>
                                            <i class="bx bxs-star text-secondary"></i>
                                        </div>
                                        <div class="clearfix">
                                            <p class="mb-0 float-start fw-bold"><span class="me-2 text-decoration-line-through text-secondary">$150</span><span>$120</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <!--end page wrapper -->

        <?php $__env->startPush('clientSideValidationScript'); ?>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.21.0/jquery.validate.min.js"></script>
                <script>
                    /* console.log('test4');
                    document.addEventListener("livewire:load", function () {
                        console.log('test6');
                        $(document).ready(function () {
                            console.log('test6');
                            $("#productForm").validate({
                                rules: {
                                    name: { required: true, minlength: 3 },
                                    price: { required: true, number: true }
                                },
                                messages: {
                                    name: { required: "Product name is required", minlength: "At least 3 characters" },
                                    price: { required: "Price is required", number: "Enter a valid number" }
                                },
                                errorElement: "span",
                                errorClass: "text-danger",
                                submitHandler: function (form) {
                                    console.log("Valid form submitted");
                                    Livewire.emit('store');
                                }
                            });
                        });
                    }); */
                    $(document).ready(function() {
                        $('#button-plus').click(function () {
                            let quantity = parseInt($('#quantity').val()) || 0;
                            let new_quantity = quantity + 1;

                            const maxQuantity = 214748360;

                            if (new_quantity > maxQuantity) {
                                new_quantity = maxQuantity;
                            }

                            $('#quantity').val(new_quantity).attr('value', new_quantity);
                        });

                        $('#button-minus').click(function () {
                            let quantity = parseInt($('#quantity').val()) || 0;
                            if (quantity > 1) {
                                $('#quantity').val(quantity - 1).attr('value', quantity - 1);
                            }
                        });

                        $('#quantity').on('input', function () {
                            let sanitized = $(this).val().replace(/[^0-9]/g, '');
                            if (sanitized === '' || parseInt(sanitized) < 1) {
                                sanitized = '1';
                            }

                            if (sanitized !== '' && parseInt(sanitized) > 214748360) {
                                sanitized = '214748360';
                            }

                            $(this).val(sanitized).attr('value', sanitized);
                        });

                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                                'Accept': 'application/json'
                            }
                        });

                        /* $("#add-to-cart-form").validate({
                            rules: {
                                quantity: {
                                    required: true
                                }
                            },
                            errorPlacement: function(error, element) {
                                element.addClass('is-invalid');
                                if (element.attr('id') == 'quantity' || element.attr('id') == 'color_attribute_option') {
                                    var closest_div = element.closest('div');
                                    error.insertAfter(closest_div);
                                } else {
                                    error.insertAfter(element);
                                }
                                error.addClass('text-danger').wrap('<strong></strong>');
                            },
                            messages: {
                                quantity: 'Please enter quantity'
                            },
                            submitHandler: function(form) {
                                var formData = new FormData(form);
                                var addToCartUrl = $('#product_add_to_cart_url').val();

                                $.ajax({
                                    url:addToCartUrl,
                                    type: 'POST',
                                    data: formData,
                                    processData: false,
                                    contentType: false,
                                    datatype: 'json',
                                    success: function(response) {
                                        if (response.status == true) {
                                            updateCartIconQuantity();
                                            if ($('.invalid-feedback').length) {
                                                $('.invalid-feedback').remove();
                                            }
                                            if ($('.form-control').hasClass('is-invalid')) {
                                                $('.form-control').removeClass('is-invalid');
                                            }
                                            if (response.message) {
                                                showGeneralMessage(response.message);
                                            }
                                        } else if (response.status == 'error') {
                                            console.log('Error message ' + response.message);
                                        }
                                    },
                                    error: function(xhr) {
                                        var response = xhr.responseJSON;
                                        console.log(response);
                                        if (response && response.custom_error) {
                                            showGeneralError(response.message);
                                        }

                                        if (response && response.errors) {
                                            displayErrors(response.errors);
                                        }
                                    }
                                });
                            }
                        }); */

                        if ($(".product-attribute-option").length > 0) {
                            $(".product-attribute-option").each(function() {
                                var attrName = $(this).attr("name");
                                if (attrName) {
                                    $("#add-to-cart-form").validate().settings.rules[attrName] = {
                                        required: true
                                    };
                                    $("#add-to-cart-form").validate().settings.messages[attrName] = {
                                        required: 'Please select an option'
                                    };
                                }
                            });
                        }

                        $('#add-to-cart-form').on('input change', 'input, select, textarea', function() {
                            if ($(this).valid()) {
                                $(this).removeClass('is-invalid');
                            }
                        });

                        function showGeneralError(message) {
                            $("#general-error").html('');

                            var errorHtml = `
                                <div class="alert alert-danger alert-dismissible fade show p-1" role="alert">
                                    ${message}
                                    <button type="button" class="btn-close p-2" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            `;

                            $("#general-error").html(errorHtml);
                        }

                        function displayErrors(errors) {
                            $('.invalid-feedback').remove();
                            $('.form-control').removeClass('is-invalid');
                            $('.product-attribute-option').removeClass('is-invalid');

                            $.each(errors, function(field, messages) {
                                var input = $('[name="' + field + '"]');
                                input.addClass('is-invalid');

                                $.each(messages, function(index, message) {
                                    if (input.closest('.input-group').length) {
                                        if (input.closest('.pr-quantity').length) {
                                            input.closest('.pr-quantity').append('<span class="invalid-feedback d-block"><strong>' + message + '</strong></span>');
                                        } else {
                                            input.closest('.input-group').append('<span class="invalid-feedback d-block"><strong>' + message + '</strong></span>');
                                        }
                                        //input.closest('.input-group').append('<span class="invalid-feedback d-block"><strong>' + message + '</strong></span>');
                                    } else {
                                        input.after('<span class="invalid-feedback d-block"><strong>' + message + '</strong></span>');
                                    }
                                });
                            });
                        }

                        function updateCartIconQuantity() {
                            var updateCartIconQtyUrl = $('#update_cart_icon_quantity_url').val();
                            $.ajax({
                                url: updateCartIconQtyUrl,
                                method: 'GET',
                                success: function(response) {
                                    if (response.status === true) {
                                        if($('.cart-item-quantity').length) {
                                            $('.cart-item-quantity').text(response.total_quantity);
                                        }
                                    }
                                },
                                error: function() {
                                    console.log('Failed to update cart icon quantity');
                                }
                            });
                        }

                        function showGeneralMessage(message) {
                            $("#general-message").html('');

                            var generalMessageHtml = `
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    ${message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            `;

                            $("#general-message").html(generalMessageHtml);
                        }
                    });
                </script>
        <?php $__env->stopPush(); ?>

        <?php $__env->startPush('scripts'); ?>
            <script>
                $(document).ready(function() {
                    $('[class*="product-detail-sub-image-"]').on('click', function() {
                        var newImageSrc = $(this).attr('src');
                        $('.product-detail-main-image').attr('src', newImageSrc);
                    });
                });

                function showAlert(message) {
                    setTimeout(hideAlert, 5000);
                }

                function hideAlert() {
                    let alertBox = document.getElementById('sessionAlert');
                    if (alertBox) {
                        alertBox.style.display = 'none';
                    }
                }

                Livewire.on('showAlert', (message) => {
                    showAlert(message);
                });

                window.addEventListener('cart-icon-quantity-update', function () {
                    updateCartIconQuantity();
                });
            </script>
        <?php $__env->stopPush(); ?><?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\shopping_kart\resources\views/livewire/product-detail.blade.php ENDPATH**/ ?>