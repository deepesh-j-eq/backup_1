<script>
    $(document).ready(function() {
        updateCartIconQuantity();
    });

    function updateCartIconQuantity() {
        var updateCartIconQtyUrl = "{{ route('update.cart.icon.quantity') }}";
        var csrfToken = "{{ csrf_token() }}";

        $.ajax({
            url: updateCartIconQtyUrl,
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': csrfToken
            },
            success: function(response) {
                if (response.status === true) {
                    if($('.cart-item-quantity').length) {
                        $('.cart-item-quantity').text(response.total_quantity);
                    }
                }
            },
            error: function() {
                console.log('Failed to fetch cart quantity');
            }
        });
    }
</script>
