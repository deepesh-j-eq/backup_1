@section('title', 'Dashboard')

        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                @if($message = session()->pull('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ $message }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                @if (session()->has('message'))
                    <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                        {{ session('message') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif
                <h4>User dashboard</h4>
            </div>
        </div>

    @push('scripts')
        <script>
            function showAlert(message) {
                setTimeout(hideAlert, 5000);
            }

            function hideAlert() {
                let alertBox = document.getElementById('sessionAlert');
                if (alertBox) {
                    alertBox.style.display = 'none';
                }
            }

            Livewire.on('showAlert', (message) => {
                showAlert(message);
            });
        </script>
    @endpush
