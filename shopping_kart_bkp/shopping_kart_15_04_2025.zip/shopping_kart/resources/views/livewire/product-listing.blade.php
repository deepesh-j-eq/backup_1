@section('title', 'Products')
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    @if (userRole() && userRole() == 'admin')
                                        <div class="col-lg-3 col-xl-2">
                                            <a href="{{ route('admin.products') }}" class="btn btn-primary mb-3 mb-lg-0"><i class='bx bxs-plus-square'></i>New Product</a>
                                        </div>
                                    @endif
                                    <div class="col-lg-9 col-xl-10">
                                        <form class="float-lg-end">
                                            <div class="row row-cols-lg-auto g-2">
                                                <div class="col-12">
                                                    <div class="position-relative">
                                                        <input type="text" class="form-control ps-5" wire:model.live.debounce.300ms="searchTerm" placeholder="Search Product..."> <span class="position-absolute top-50 product-show translate-middle-y"><i class="bx bx-search"></i></span>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                                                        <button type="button" class="btn btn-white">Sort By</button>
                                                        <div class="btn-group" role="group">
                                                          <button id="btnGroupDrop1" type="button" class="btn btn-white dropdown-toggle dropdown-toggle-nocaret px-1" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <i class='bx bx-chevron-down'></i>
                                                          </button>
                                                          <ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                            <!-- <li><a class="dropdown-item" data-shortby="most_popular" href="#">Most Popular</a>
                                                            <li><a class="dropdown-item" data-shortby="ratings" href="#">Ratings</a></li> -->
                                                            <li><a class="dropdown-item" href="#" wire:click.prevent="setSortBy('newest')">Newest</a></li>
                                                            <li><a class="dropdown-item" href="#" wire:click.prevent="setSortBy('price_low_high')">Price Low To High</a></li>
                                                            <li><a class="dropdown-item" href="#" wire:click.prevent="setSortBy('price_high_low')">Price High To Low</a></li>
                                                          </ul>
                                                        </div>
                                                      </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                                                        <button type="button" class="btn btn-white">Collection Type</button>
                                                        <div class="btn-group" role="group">
                                                          <button id="btnGroupDrop1" type="button" class="btn btn-white dropdown-toggle dropdown-toggle-nocaret px-1" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <i class='bx bxs-category'></i>
                                                          </button>
                                                          <ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                            <li><a class="dropdown-item" href="#">Dropdown link</a></li>
                                                            <li><a class="dropdown-item" href="#">Dropdown link</a></li>
                                                          </ul>
                                                        </div>
                                                      </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="btn-group" role="group">
                                                        <button type="button" class="btn btn-white">Price Range</button>
                                                        <div class="btn-group" role="group">
                                                          <button id="btnGroupDrop1" type="button" class="btn btn-white dropdown-toggle dropdown-toggle-nocaret px-1" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <i class='bx bx-slider'></i>
                                                          </button>
                                                          <ul class="dropdown-menu dropdown-menu-start" aria-labelledby="btnGroupDrop1">
                                                            <li><a class="dropdown-item" href="#">Dropdown link</a></li>
                                                            <li><a class="dropdown-item" href="#">Dropdown link</a></li>
                                                          </ul>
                                                        </div>
                                                      </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body p-4">
                        @if (session()->has('message'))
                            <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        @if (session()->has('error_message'))
                            <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('error_message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif
                    </div>
                </div>

                <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 row-cols-xxl-5 product-grid">
                    @if ($productDetails->isNotEmpty())
                        @foreach ($productDetails as $product)
                            @php
                                $productImages = $product->images;
                                $productImagePath = '';
                                if ($productImages) {
                                    foreach ($productImages as $productImg) {
                                        $productImagePath = $productImg->image_path;
                                        break;
                                    }
                                }

                                $discountPercentage = '';
                                if ($product->discounted_price) {
                                    $productPrice = (float)($product->price);
                                    $productDiscountPrice = (float)($product->discounted_price);
                                    $discountPercentage = (($productPrice - $productDiscountPrice) / $productPrice) * 100;
                                    $discountPercentage = number_format((float)$discountPercentage, 0);
                                }
                            @endphp
                            <div class="col">
                                <div class="card">
                                    <a href="#" onclick="event.preventDefault(); document.querySelector('#product_page_redirect_form_{{ $product->id }}').submit();">
                                        <img src="{{ ($productImagePath != '') ? asset('storage/' . $productImagePath) : '' }}" class="card-img-top" alt="{{ $product->name }}" width="302px" height="302px">
                                    </a>
                                    <form id="product_page_redirect_form_{{ $product->id }}" action="{{ route('product.detail.redirect') }}" method="POST" style="display: none;">
                                        @csrf
                                        <input type="hidden" name="hidden_product_id" value="{{ $product->id }}">
                                    </form>
                                    <!-- <a href="{{ route('product.detail', ['productId' => $product->id]) }}">
                                        <img src="{{ ($productImagePath != '') ? asset('storage/' . $productImagePath) : '' }}" class="card-img-top" alt="{{ $product->name }}" width="302px" height="302px">
                                    </a> -->
                                    @if ($discountPercentage != '')
                                        <div class="">
                                            <div class="position-absolute top-0 end-0 m-3 product-discount"><span class="">{{ '-'.$discountPercentage.'%' }}</span></div>
                                        </div>
                                    @endif
                                    <div class="card-body">
                                        <h6 class="card-title cursor-pointer">
                                            <a href="{{ route('product.detail', ['productId' => $product->id]) }}" class="text-decoration-none text-dark">
                                                {{ $product->name }}
                                            </a>
                                        </h6>
                                        <div class="clearfix">
                                            <p class="mb-0 float-start"><strong>134</strong> Sales</p>
                                            <p class="mb-0 float-end fw-bold">
                                                @if ($discountPercentage != '')
                                                    <span class="me-2 text-decoration-line-through text-secondary">{{ '$'.$product->price }}</span>
                                                    <span>{{ '$'.(number_format($product->discounted_price, 2, '.', '')) ?? '' }}</span>
                                                @else
                                                    <span>{{ '$'.(number_format($product->price, 2, '.', '')) }}</span>
                                                @endif
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-center mt-3 fs-6">
                                            <div class="cursor-pointer">
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-secondary'></i>
                                            </div>	
                                            <p class="mb-0 ms-auto">4.2(182)</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div class="col">
                            <h5 class="card-title">There is no products available</h5>
                            <hr />
                        </div>
                    @endif
                </div><!--end row-->
                <div class="mt-3">
                    {{ $productDetails->links() }}
                </div>

            </div>
        </div>
        <!--end page wrapper -->
