<?php $__env->startSection('title', 'Dashboard'); ?>

        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--[if BLOCK]><![endif]--><?php if($message = session()->pull('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e($message); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                    <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <h4>User dashboard</h4>
            </div>
        </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            function showAlert(message) {
                setTimeout(hideAlert, 5000);
            }

            function hideAlert() {
                let alertBox = document.getElementById('sessionAlert');
                if (alertBox) {
                    alertBox.style.display = 'none';
                }
            }

            Livewire.on('showAlert', (message) => {
                showAlert(message);
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\shopping_kart\resources\views/livewire/user/dashboard.blade.php ENDPATH**/ ?>