<?php

namespace App\Livewire;

use App\Models\Cart;
use App\Models\Product;
use App\Services\CartService;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithPagination;

class CartDetails extends Component
{
    use WithPagination;

    public $cartId;
    public $cart_quantity = [];

    public $specificCartItemRemoveConfirmation = false;
    public $removeAllCartItemfirmation = false;

    public $searchTerm  = '';

    protected $cartService;

    public function mount()
    {
        $this->resetFields();

        $user = loggedinUserDetail();
        if ($user && !empty($user)) {
            $this->cart_quantity = Cart::where('user_id', $user->id)
                ->pluck('quantity', 'id')
                ->toArray();
        }

        $this->cartService = new CartService;
    }

    public function resetFields()
    {
        $this->cartId = '';
        $this->specificCartItemRemoveConfirmation = false;
        $this->removeAllCartItemfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function render()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try{
                $cartItems = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->where(function ($query) {
                    $query->whereHas('product', function ($q) {
                        $q->where('name', 'like', '%' . $this->searchTerm . '%');
                    })
                    ->orWhereHas('product.attributeOptions', function ($q) {
                        $q->where('option', 'like', '%' . $this->searchTerm . '%');
                    })
                    ->orWhereHas('product.attributeOptions.productAttribute', function ($q) {
                        $q->where('name', 'like', '%' . $this->searchTerm . '%');
                    });
                })
                ->latest()->paginate(5);

                if (is_null($this->cartService)) {
                    $this->cartService = new CartService;
                }

                foreach ($cartItems as $item) {
                    $item->sub_total = $this->cartService->calculateSubTotal($item);
                }

                return view('livewire.cart-details', compact('cartItems'));
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while fetching your cart. Error : ' . $e->getMessage());
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while fetching the cart'
            ], 401);
        }
    }

    public function confirmDelete($id)
    {
        $this->cartId = $id;
        $this->specificCartItemRemoveConfirmation = true;
    }

    public function confirmRemoveAllCartItem()
    {
        $this->removeAllCartItemfirmation = true;
    }

    public function updatedCartQuantity($value, $key)
    {
        dd($value, $key);
        $value = intval($value);
        $value = max(1, min($value, 214748360));

        $this->cart_quantity[$key] = $value;

        $user = loggedinUserDetail();

        if ($user) {
            try {
                $cartItem = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->find($key);

                dd($cartItem);

                if (!$cartItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart item is not available for update');
                    $this->dispatch('showAlert', session('message'));
                    return;
                }

                $checkProductStockResponse = [];

                if (!is_null($cartItem->product_attribute_option_id)) {
                    $selectedAttributeOptions = json_decode($cartItem->product_attribute_option_id, true);
                    $checkProductStockResponse = $this->checkProductStock($cartItem, $value, $selectedAttributeOptions);
                } else {
                    $checkProductStockResponse = $this->checkProductStock($cartItem, $value);
                }

                $cartItem->update(['quantity' => $value]);
                session()->flash('message', 'Cart quantity updated.');
                $this->dispatch('cart-icon-quantity-update');
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while updating specific cart item using text box. Error : ' . $e->getMessage());
            }
        }
    }

    public function updateCartQuantity($cartId, $action)
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $cartItem = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->find($cartId);

                if (!$cartItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart item is not available for update');
                    $this->dispatch('showAlert', session('message'));
                    return;
                }

                //dd('uiutrutrutr', "cartId ".$cartId, "this->cart_quantity ".$this->cart_quantity, "this->cart_quantity[$cartId] ".$this->cart_quantity[$cartId]);

                $currentQuantity = $this->cart_quantity[$cartId] ?? 1;
                $newQuantity = $action == 'increment' ? $currentQuantity + 1 : max(1, $currentQuantity - 1);

                if ($cartItem->quantity == 1 && $newQuantity == 1 && $action == 'decrement') {
                    return;
                }

                //dd('yreyreyrer', "currentQuantity ".$currentQuantity, "newQuantity ".$newQuantity);

                //$requestedCartQuantity = $this->cart_quantity[$cartId] ?? null;

                $stockValidationResponse = [];

                if (!is_null($cartItem->product_attribute_option_id)) {
                    $selectedAttributeOptions = json_decode($cartItem->product_attribute_option_id, true);
                    $stockValidationResponse = $this->validateCartQuantityChange($cartItem, $newQuantity, $action, $selectedAttributeOptions);
                } else {
                    $stockValidationResponse = $this->validateCartQuantityChange($cartItem, $newQuantity, $action);
                }

                //dd($stockValidationResponse);

                if (!empty($stockValidationResponse)) {
                    $message = isset($stockValidationResponse['message']) 
                        ? $stockValidationResponse['message'] 
                        : 'Something went wrong while updating cart quantity.';

                    $this->cart_quantity[$cartId] = $currentQuantity;
                    session()->flash('error_message', $message);
                    return;
                }

                //dd('test22', "cartItem->id ".$cartItem->id, "cartItem->quantity ".$cartItem->quantity, "cartItem->product_id ".$cartItem->product_id, "cartItem->product->quantity ".$cartItem->product->quantity, "currentQuantity ".$currentQuantity, "newQuantity ".$newQuantity);

                $cartItem->update(['quantity' => $newQuantity]);
                $this->cart_quantity[$cartId] = $newQuantity;

                $this->resetFields();
                session()->flash('message', 'Cart item quantity updated successfully.');
                $this->dispatch('showAlert', session('message'));

                $this->dispatch('cart-icon-quantity-update');
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while updating specific cart item. Error : ' . $e->getMessage());
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while fetching the cart'
            ], 401);
        }
    }

    public function removeSpecificCartItem()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $cartItem = Cart::where('user_id', $user->id)->find($this->cartId)->delete();

                if (!$cartItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart item is not available');
                    $this->dispatch('showAlert', session('message'));
                }

                $this->resetFields();
                session()->flash('message', 'Cart item removed successfully.');
                $this->dispatch('showAlert', session('message'));
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while removing specific cart item. Error : ' . $e->getMessage());
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while fetching the cart'
            ], 401);
        }
    }

    protected function checkProductStock($cartItem, $newQuantity, $selectedAttributeOptions = [])
    {
        $user = loggedinUserDetail();

        $availableQuantity = $cartItem->product->quantity !== null ? $cartItem->product->quantity : 0;

        dd("checkProductStock ", "cart_id ".$cartItem->id, "cartItem->quantity ".$cartItem->quantity, "newQuantity ".$newQuantity, $selectedAttributeOptions);
        if (!empty($selectedAttributeOptions) && $cartItem !== null && $user !== null) {
            $productQuantityForAttributeOptions = Cart::where([
                'product_id' => $cartItem->product_id,
                'user_id' => $user->id
            ])->sum('quantity');

            $availableQuantity -= $productQuantityForAttributeOptions;
        } elseif ($cartItem !== null) {
            $availableQuantity -= $cartItem->quantity;
        }

        if ($newQuantity > $availableQuantity) {
            return [
                'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Maximum available quantity is ' . $availableQuantity
            ];
        }

        if ($newQuantity < 1) {
            return [
                'message' => 'Quantity must be at least 1.'
            ];
        }

        return [];
    }

    protected function validateCartQuantityChange($cartItem, $newQuantity, $action, $selectedAttributeOptions = [])
    {
        $user = loggedinUserDetail();

        $availableQuantity = $cartItem->product->quantity !== null ? $cartItem->product->quantity : 0;

        dd("validateCartQuantityChange  ", "cart_id ".$cartItem->id, "cartItem->quantity ".$cartItem->quantity, "newQuantity ".$newQuantity, "action ".$action, $selectedAttributeOptions);
        if (!empty($selectedAttributeOptions) && $cartItem !== null && $user !== null) {
            $productQuantityForAttributeOptions = Cart::where([
                'product_id' => $cartItem->product_id,
                'user_id' => $user->id
            ])->sum('quantity');
    
            $currentCartQuantity = $productQuantityForAttributeOptions;
            $availableQuantity -= $productQuantityForAttributeOptions;
        } elseif ($cartItem !== null) {
            $currentCartQuantity = $cartItem->quantity;
            $availableQuantity -= $cartItem->quantity;
        }

        //dd("validateCartQuantityChange ", "cart_id ".$cartItem->id, "currentCartQuantity ".$currentCartQuantity, "newQuantity ".$newQuantity, "availableQuantity ".$availableQuantity, "action ".$action, "selectedAttributeOptions ".$selectedAttributeOptions);

        if ($action === 'decrement' && $newQuantity < 1) {
            return [
                'message' => 'Please remove correct quantity for product ' . ($cartItem->product->name ?? '') . '. ' . $currentCartQuantity . ' in your cart.'
            ];
        }

        if ($action === 'increment' && $newQuantity > $availableQuantity) {
            return [
                'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Maximum available quantity is ' . $availableQuantity
            ];
        }

        if ($newQuantity < 1) {
            return [
                'message' => 'Quantity must be at least 1.'
            ];
        }

        return [];
    }
}
