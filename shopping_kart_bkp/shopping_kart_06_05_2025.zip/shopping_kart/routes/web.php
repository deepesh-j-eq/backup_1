<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\GoogleController;
use App\Livewire\Admin\Category;
use App\Livewire\Admin\Dashboard as AdminDashboard;
use App\Livewire\Admin\ProductAttributeOptions;
use App\Livewire\Admin\ProductAttributes;
use App\Livewire\Admin\Products;
use App\Livewire\CartDetails;
use App\Livewire\ProductDetail;
use App\Livewire\ProductListing;
use App\Livewire\User\Dashboard as UserDashboard;
use App\Livewire\UserProfile;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::controller(AuthController::class)->group(Function() {
    Route::get('login', 'showLoginForm')->name('login');
    Route::post('login', 'login')->name('login.authentication');

    Route::get('register', 'showRegisterForm')->name('register');
    Route::post('register', 'register')->name('register.authentication');
});

Route::controller(GoogleController::class)
    ->prefix('auth/google')
    ->group(Function() {
        Route::get('/', 'redirectToGoogle')->name('auth.google');
        Route::get('/callback', 'handleGoogleCallback')->name('handle.google.callback');
});

Route::middleware('auth')->group(function() {
    Route::post('logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('products', ProductListing::class)->name('all.products');
    Route::get('product-detail/{productId}', ProductDetail::class)->name('product.detail');

    Route::get('cart', CartDetails::class)->name('view.cart');

    Route::get('update-cart-icon-quantity', [CartController::class, 'updateCartIconQuantity'])->name('update.cart.icon.quantity');

    Route::get('user-profile', UserProfile::class)->name('user.profile');

    Route::middleware('role:admin')->prefix('admin')->group(function () {
        Route::name('admin.')->group(function () {
            Route::get('dashboard', AdminDashboard::class)->name('dashboard');
            Route::get('categories', Category::class)->name('categories');
            Route::get('product-attributes', ProductAttributes::class)->name('product.attributes');
            Route::get('product-attribute-options', ProductAttributeOptions::class)->name('product.attribute.options');
            Route::get('products', Products::class)->name('products');

            Route::get('google-login-details', [GoogleController::class, 'googleLoginDetails'])->name('google.login.details');
        });
    });

    Route::middleware('role:user')->group(function () {
        Route::get('dashboard', UserDashboard::class)->name('user.dashboard');
    });
});
