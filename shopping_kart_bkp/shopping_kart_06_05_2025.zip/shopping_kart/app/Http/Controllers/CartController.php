<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function updateCartIconQuantity()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            $totalCartQuantity = Cart::where('user_id', $user->id)->sum('quantity');

            return response()->json([
                'status' => true,
                'total_quantity' => $totalCartQuantity
            ]);
        }

        return response()->json([
            'status' => false,
            'message' => 'User not logged in'
        ], 401);
    }
}
