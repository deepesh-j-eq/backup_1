<?php

namespace App\Http\Controllers;

use App\Http\Requests\AuthValidationRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        try{
            if (Auth::check()) {
                return redirect()->route('admin.dashboard')->with('success', 'You have already logged in.');
            }
    
            return view('authentication.signin');
        } catch (\Exception $e) {
            return response()->json([
                'status'=>false,
                'custom_error' => true,
                'message' => 'Opps! While fetching login form an error occurred: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function showRegisterForm()
    {
        try{
            if (Auth::check()) {
                return redirect()->route('admin.dashboard')->with('success', 'You have already logged in.');
            }

            return view('authentication.signup');
        } catch (\Exception $e) {
            return response()->json([
                'status'=>false,
                'custom_error' => true,
                'message' => 'Opps! While fetching registration form an error occurred: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function register(AuthValidationRequest $request)
    {
        try{    
            if ($request->hasFile('image')) {
                $path = $request->image->store('user_images', 'public');
            }
    
            $user = User::updateOrCreate([
                'email' => $request->email,
            ], [
                'name' => trim($request->first_name . ' ' . $request->last_name),
                'password' => $request->password,
                'image' => $path ?? '',
                'role_id' => 2
            ]);
    
            if ($user) {
                session()->flash('success', 'Registration successfully, please login');
    
                return response()->json([
                    'status' => true,
                    'message' => 'Registration successfully, please login',
                    'redirect_url' => route('login')
                ], 200);
            }
    
            return response()->json([
                'status' => false,
                'custom_error' => true,
                'message' => 'User registration failed, Something went wrong!'
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'status'=>false,
                'custom_error' => true,
                'message' => 'Opps! While register user an error occurred: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function login(AuthValidationRequest $request)
    {
        try{
            if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
                $authUser = Auth::user();
                $user_id = $authUser->id;

                $user = User::with('role')->whereNull('deleted_at')->find($user_id);

                if (!$user) {
                    return response()->json([
                        'status' => false,
                        'custom_error' => true,
                        'message' => 'User account is deleted (inactive)'
                    ], 403);
                }

                //session()->flash('success', 'Login successful');

                $userName = '';
                if (Auth::check() && Auth::user()->name) {
                    $userName = Auth::user()->name;
                }

                if (userRole() && userRole() == 'admin') {
                    return response()->json([
                        'status' => true,
                        'message' => ($userName != '') ? 'Hello ' . $userName . ' loggedin successfully' : 'Loggedin successfully',
                        'redirect_url' => route('admin.dashboard')
                    ], 200);
                } else if (userRole() && userRole() == 'user') {
                    return response()->json([
                        'status' => true,
                        'message' => ($userName != '') ? 'Hello ' . $userName . ' loggedin successfully' : 'Loggedin successfully',
                        'redirect_url' => route('user.dashboard')
                    ], 200);
                } else {
                    return response()->json([
                        'status' => false,
                        'custom_error' => true,
                        'message' => 'Somthing went wrong! role related issue'
                    ], 200);
                }
            } else {
                return response()->json([
                    'status' => false,
                    'custom_error' => true,
                    'message' => 'Email and Password do not match'
                ], 401);
            }
        } catch (\Exception $e) {
            return response()->json([
                'status'=>false,
                'custom_error' => true,
                'message' => 'Opps! While login an error occurred: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function logout(Request $request)
    {
        try{
            Auth::logout();

            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('login')->with('success', 'You have logged out successfully.');
        } catch (\Exception $e) {
            return response()->json([
                'status'=>false,
                'custom_error' => true,
                'message' => 'Opps! While logout an error occurred: ' . $e->getMessage(),
            ], 500);
        }
    }
}
