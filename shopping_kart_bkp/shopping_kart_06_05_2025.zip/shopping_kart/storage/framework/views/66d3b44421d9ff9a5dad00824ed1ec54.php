<?php $__env->startPush('meta_tags'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title', 'Cart Detail'); ?>
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">

                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Your cart</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="container-fluid ny-4">
                        <div class="row">   
                            <div class="col-md-12">
                                <div class="card-body">
                                    <input type="text" class="form-control" wire:model.live.debounce.300ms="searchTerm" placeholder="Search cart items...">
                                    <h4 class="card-title">Your cart detail</h4>
                                    <hr />
                                    <!--[if BLOCK]><![endif]--><?php if($cartItems->isNotEmpty()): ?>
                                        <div class="d-flex">
                                            <button class="btn btn-danger mb-3 ms-auto" id="remove_all_cart_items_btn" wire:click="confirmRemoveAllCartItem">Remove all cart items</button>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                                    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                                        <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                            <?php echo e(session('message')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                                    <?php if(session()->has('error_message')): ?>
                                        <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                            <?php echo e(session('error_message')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                                    <div class="table-responsive">
                                        <table id="cart_table" class="table table-bordered table-hover align-middle">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Sr. no.</th>
                                                    <th>Name</th>
                                                    <th>Price</th>
                                                    <th>Discounted Price</th>
                                                    <th>Quantity</th>
                                                    <th>Sub Total</th>
                                                    <th>Product Attribute Options</th>
                                                    <th>Image</th>
                                                    <th></th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!--[if BLOCK]><![endif]--><?php if($cartItems->isNotEmpty()): ?>
                                                    <?php $a = 1; ?>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $prdocutWithAttributes = []; ?>
                                                        <?php $prdocutWithAttributeOptions = []; ?>
                                                        <?php $selectedPrdocutAttributeOptions = []; ?>
                                                        <?php $selectedPrdocutAttributeOptionsToDisplay = []; ?>
                                                        <?php $cartSubTotal = ''; ?>
    
                                                        <!--[if BLOCK]><![endif]--><?php if($item->product->attributeOptions): ?>
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $item->product->attributeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeOpt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <!--[if BLOCK]><![endif]--><?php if($attributeOpt->productAttribute): ?>
                                                                    <?php
                                                                        $attr_name = $attributeOpt->productAttribute->attribute_name;
                                                                    ?>
    
                                                                    <!--[if BLOCK]><![endif]--><?php if(!in_array($attr_name, $prdocutWithAttributes)): ?>
                                                                        <?php
                                                                            $prdocutWithAttributes[] = $attr_name ?? '';
                                                                        ?>
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                                                                    <?php
                                                                        $prdocutWithAttributeOptions[strtolower($attr_name)][$attributeOpt->id] = $attributeOpt->option;
                                                                    ?>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                                                        <!--[if BLOCK]><![endif]--><?php if(!is_null($item->product_attribute_option_id)): ?>
                                                            <?php $selectedPrdocutAttributeOptionsOriginal = json_decode($item->product_attribute_option_id, true); ?>
                                                            <?php $selectedPrdocutAttributeOptions = []; ?>
    
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedPrdocutAttributeOptionsOriginal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $newKey = strtolower(str_replace('_attribute_option', '', $key));
                                                                    $selectedPrdocutAttributeOptions[$newKey] = $value;
                                                                ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                                                        <!--[if BLOCK]><![endif]--><?php if(!empty($prdocutWithAttributeOptions) && !empty($selectedPrdocutAttributeOptions)): ?>
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedPrdocutAttributeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <!--[if BLOCK]><![endif]--><?php if(array_key_exists($key, $prdocutWithAttributeOptions)): ?>
                                                                    <!--[if BLOCK]><![endif]--><?php if(array_key_exists($value, $prdocutWithAttributeOptions[$key])): ?>
                                                                        <?php
                                                                            $selectedPrdocutAttributeOptionsToDisplay[$key] = $prdocutWithAttributeOptions[$key][$value]; 
                                                                        ?>
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        <tr>
                                                            <td><?php echo e($a); ?></td>
                                                            <td><?php echo e($item->product->name); ?></td>
                                                            <td><?php echo e('$'.(number_format($item->product->price, 2, '.', '')) ?? ''); ?></td>
                                                            <td><?php echo e(($item->product->discounted_price) ? "$".number_format($item->product->discounted_price, 2, '.', '') : '-'); ?></td>
                                                            <td><?php echo e($item->quantity); ?></td>
                                                            <td><?php echo e('$'.(number_format($item->sub_total, 2, '.', '')) ?? ''); ?></td>
                                                            <td>
                                                                <!--[if BLOCK]><![endif]--><?php if(!empty($selectedPrdocutAttributeOptionsToDisplay)): ?>
                                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedPrdocutAttributeOptionsToDisplay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectedPrdocutAttrNameToDisplay => $selectedPrdocutAttrOptToDisplay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <p><?php echo e($selectedPrdocutAttrNameToDisplay . ' -> ' . $selectedPrdocutAttrOptToDisplay); ?></p>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php else: ?>
                                                                    <?php echo e('-'); ?>

                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            </td>
                                                            <td>
                                                                <?php
                                                                    $image = DB::table('product_images')
                                                                        ->select('image_path')
                                                                        ->where('product_id', $item->product_id)
                                                                        ->first();
                                                                ?>
                                                                <!--[if BLOCK]><![endif]--><?php if($image): ?>
                                                                    <div class="col">
                                                                        <div class="card">
                                                                            <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>" alt="<?php echo e($item->product->name); ?>" style="width: 200px; height: 100px; object-fit: contain;">
                                                                        </div>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <?php echo e('-'); ?>

                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            </td>
                                                            <td class="text-center">
                                                                <div class="input-group input-group-sm justify-content-center">
                                                                    <button class="btn btn-outline-secondary" type="button" id="button-plus-<?php echo e($item->id); ?>" data-cart-id="<?php echo e($item->id); ?>" wire:click="updateCartQuantity(<?php echo e($item->id); ?>, 'increment')"> + </button>

                                                                        <input
                                                                            type="text"
                                                                            id="quantity_for_<?php echo e($item->id); ?>"
                                                                            class="form-control form-control-sm text-center w-auto px-1 <?php $__errorArgs = ['cart_quantity.' . $item->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            maxlength="9"
                                                                            data-product-id="<?php echo e($item->product_id); ?>"
                                                                            wire:model.lazy="cart_quantity.<?php echo e($item->id); ?>">

                                                                    <button class="btn btn-outline-secondary" type="button" id="button-minus-<?php echo e($item->id); ?>" data-cart-id="<?php echo e($item->id); ?>" wire:click="updateCartQuantity(<?php echo e($item->id); ?>, 'decrement')"> − </button>

                                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['cart_quantity.' . $item->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="invalid-feedback small mt-1" role="alert"><strong><?php echo e($message); ?></strong></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="d-flex gap-2">
                                                                    <button class="btn btn-danger btn-sm" wire:click="confirmDelete(<?php echo e($item->id); ?>)">Remove item</button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <?php $a++; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="10" class="text-center">
                                                            Your cart is empty, Keep shopping!
                                                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('all.products')); ?>" role="button">All Products</a>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </tbody>
                                        </table>
                                    </div>

                                    <!--[if BLOCK]><![endif]--><?php if($cartItems->isNotEmpty()): ?>
                                        <div class="d-flex justify-content-end gap-2 mb-3">
                                            <span class="badge rounded-pill bg-info text-dark p-2 px-3 fs-6 align-self-center" id="cart-total-span">
                                                Cart Total: $<?php echo e(number_format($cartTotal, 2, '.', '')); ?>

                                            </span>
                                            <button class="btn btn-primary" id="proceed-to-checkout-btn">Proceed To Checkout</button>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
                                    <!--[if BLOCK]><![endif]--><?php if($specificCartItemRemoveConfirmation || $removeAllCartItemfirmation): ?>
                                        <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title"><?php echo e($specificCartItemRemoveConfirmation ? 'Remove cart item' : 'Remove all items from cart'); ?></h5>
                                                        <button type="button" class="close" wire:click="$set('specificCartItemRemoveConfirmation', false), $set('removeAllCartItemfirmation', false)">
                                                            &times;
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>
                                                            <?php echo e($specificCartItemRemoveConfirmation ? 'Are you sure you want to delete this cart item ?' : 'Are you sure you want to remove all cart items ?'); ?>

                                                        </p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <!--[if BLOCK]><![endif]--><?php if($specificCartItemRemoveConfirmation): ?>
                                                            <button class="btn btn-secondary" wire:click="$set('specificCartItemRemoveConfirmation', false)">Cancel</button>
                                                        <?php elseif($removeAllCartItemfirmation): ?>
                                                            <button class="btn btn-secondary" wire:click="$set('removeAllCartItemfirmation', false)">Cancel</button>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                                                        <button class="btn btn-danger" id="remove-cart-items" wire:click="<?php echo e($specificCartItemRemoveConfirmation ? 'removeSpecificCartItem' : 'removeAllCartItems'); ?>">Delete</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                                    <div wire:ignore.self>
                                        <?php echo e($cartItems->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->

        <?php $__env->startPush('clientSideValidationScript'); ?>
            <script>
                $(document).ready(function() {
                    $(document).on('input', 'input[id^="quantity_for_"]', function () {
                        let sanitized = $(this).val().replace(/[^0-9]/g, '');
                        if (sanitized !== '') {
                            sanitized = String(parseInt(sanitized));
                        }

                        if (sanitized === 'NaN' || sanitized === '' || parseInt(sanitized) < 1) {
                            sanitized = '1';
                        }
    
                        if (sanitized !== '' && parseInt(sanitized) > 214748360) {
                            sanitized = '214748360';
                        }
    
                        $(this).val(sanitized).attr('value', sanitized);
                    });

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                            'Accept': 'application/json'
                        }
                    });
                });
            </script>
        <?php $__env->stopPush(); ?>

        <?php $__env->startPush('scripts'); ?>
            <script>
                function showAlert(message) {
                    setTimeout(hideAlert, 5000);
                }

                function hideAlert() {
                    let alertBox = document.getElementById('sessionAlert');
                    if (alertBox) {
                        alertBox.style.display = 'none';
                    }
                }

                Livewire.on('showAlert', (message) => {
                    showAlert(message);
                });

                Livewire.on('scrollToMessage', () => {
                    const messageContainer = document.querySelector('#sessionAlert');
                    if (messageContainer) {
                        messageContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                });

                window.addEventListener('cart-icon-quantity-update', function () {
                    updateCartIconQuantity();
                });
            </script>
        <?php $__env->stopPush(); ?><?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\shopping_kart\resources\views/livewire/cart-details.blade.php ENDPATH**/ ?>