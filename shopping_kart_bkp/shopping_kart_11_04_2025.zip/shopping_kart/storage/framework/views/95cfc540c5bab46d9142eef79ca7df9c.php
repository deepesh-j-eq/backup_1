<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('cart-details');

$__html = app('livewire')->mount($__name, $__params, 'lw-2876456051-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\shopping_kart\resources\views/cart.blade.php ENDPATH**/ ?>