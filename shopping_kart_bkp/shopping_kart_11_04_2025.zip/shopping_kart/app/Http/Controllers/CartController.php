<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddToCartRequest;
use App\Livewire\CartDetails;
use App\Models\Cart;
use App\Models\Product;
use App\Services\CartService;
use Illuminate\Http\Request;
use Livewire\Livewire;

class CartController extends Controller
{
    protected $cartService;

    public function __construct(CartService $cartService)
    {
        $this->cartService = $cartService;
    }

    public function addToCart(AddToCartRequest $request)
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $productId = $request->product_id;
                $quantity = $request->quantity;

                if ($request->filled('product_attributes_detail')) {
                    $attributes = $request->input('product_attributes_detail');
                    $attributesArray = json_decode($attributes, true);
                }

                $selectedAttributeOptions = [];
                $selectedAttributeOptions = collect($request->all())
                    ->filter(fn($value, $key) => str_ends_with($key, '_attribute_option'))
                    ->all();

                if (!empty($selectedAttributeOptions)) {
                    $product = Product::whereHas('attributeOptions', function ($query) use ($selectedAttributeOptions) {
                            $query->whereIn('product_attribute_options.id', $selectedAttributeOptions);
                        })
                        ->with(['attributeOptions' => function ($query) use ($selectedAttributeOptions) {
                            $query->whereIn('product_attribute_options.id', $selectedAttributeOptions);
                        }])
                        ->find($productId);
                    /* $product = Product::with('attributeOptions')
                            ->whereHas('attribute_options', function ($query) use ($selectedAttributeOptions) {
                                $query->whereIn('product_attribute_option_id', $selectedAttributeOptions);
                            })
                            ->find($productId); */
                } else {
                    $product = Product::find($productId);
                }

                if (!$product) {
                    return response()->json([
                        'status' => false,
                        'custom_error' => false,
                        'message' => 'Something went wrong! Requested product is not available while add to cart'
                    ], 404);
                }

                if ($quantity > $product->quantity) {
                    if (!empty($selectedAttributeOptions)) {
                        return $this->cartService->handleStockError($product, $selectedAttributeOptions);
                    }
                    return $this->cartService->handleStockError($product);
                }

                if (!empty($selectedAttributeOptions)) {
                    $cartItem = Cart::where('user_id', $user->id)
                                ->where('product_id', $productId)
                                ->whereIn('product_attribute_option_id', array_values($selectedAttributeOptions))
                                ->get();
                } else {
                    $cartItem = Cart::where('user_id', $user->id)
                                ->where('product_id', $productId)
                                ->first();
                }
    
                if ($cartItem) {
                    if (!empty($selectedAttributeOptions)) {

                    } else {
                        $newQuantity = $cartItem->quantity + $quantity;
    
                        if ($newQuantity > $product->quantity) {
                            return $this->cartService->handleStockError($product, $selectedAttributeOptions, $cartItem);
                        }

                        $cartItem->update(['quantity' => $newQuantity]);
                    }
                } else {
                    if (!empty($selectedAttributeOptions)) {
                        foreach ($selectedAttributeOptions as $selectedAttrOption) {
                            $cartItem = Cart::create([
                                'quantity' => $quantity,
                                'product_id' => $productId,
                                'product_attribute_option_id' => $selectedAttrOption,
                                'user_id' => $user->id
                            ]);

                            if (!$cartItem) {
                                return response()->json([
                                    'status' => false,
                                    'custom_error' => true,
                                    'message' => 'Something went wrong! Product add to cart failed'
                                ], 500);
                            }
                        }
                    } else {
                        $cartItem = Cart::create([
                            'quantity' => $quantity,
                            'product_id' => $productId,
                            'product_attribute_option_id' => null,
                            'user_id' => $user->id
                        ]);

                        if (!$cartItem) {
                            return response()->json([
                                'status' => false,
                                'custom_error' => true,
                                'message' => 'Something went wrong! Product add to cart failed'
                            ], 500);
                        }
                    }
                }

                return response()->json([
                    'status' => true,
                    'message' => 'Product added to cart successfully'
                ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    'status' => false,
                    'custom_error' => false,
                    'message' => 'While add to cart an error occurred: ' . $e->getMessage()
                ], 500);
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while add to cart'
            ], 401);
        }
    }

    /* public function viewCart()
    {
        //return Livewire::mount('cart-details')->view();

        $livewireComponent = new CartDetails();

        $livewireComponent->mount();

        return $livewireComponent->render();
    } */

    public function updateCartIconQuantity()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            $totalCartQuantity = Cart::where('user_id', $user->id)->sum('quantity');

            return response()->json([
                'status' => true,
                'total_quantity' => $totalCartQuantity
            ]);
        }

        return response()->json([
            'status' => false,
            'message' => 'User not logged in'
        ], 401);
    }
}
