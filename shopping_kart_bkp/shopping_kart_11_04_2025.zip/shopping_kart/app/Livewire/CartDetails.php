<?php

namespace App\Livewire;

use App\Models\Cart;
use Livewire\Component;
use Livewire\WithPagination;

class CartDetails extends Component
{
    use WithPagination;

    public $cartId;

    public $specificCartItemRemoveConfirmation = false;

    public $searchTerm  = '';

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->cartId = '';
        $this->specificCartItemRemoveConfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function render()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try{
                $cartItems = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->where(function ($query) {
                    $query->whereHas('product', function ($q) {
                        $q->where('name', 'like', '%' . $this->searchTerm . '%');
                    })
                    ->orWhereHas('product.attributeOptions', function ($q) {
                        $q->where('option', 'like', '%' . $this->searchTerm . '%');
                    })
                    ->orWhereHas('product.attributeOptions.productAttribute', function ($q) {
                        $q->where('name', 'like', '%' . $this->searchTerm . '%');
                    });
                })
                ->latest()->paginate(5);

                return view('livewire.cart-details', compact('cartItems'));
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while fetching your cart. Error : ' . $e->getMessage());
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while fetching the cart'
            ], 401);
        }
    }

    public function confirmDelete($id)
    {
        $this->cartId = $id;
        $this->specificCartItemRemoveConfirmation = true;
    }

    public function updateCartQuantity($id)
    {

    }

    public function removeSpecificCartItem()
    {
        try {
            $productAttribute = Cart::findOrFail($this->cartId)->delete();
    
            if (!$productAttribute) {
                $this->resetFields();
                session()->flash('message', 'Something went wrong! Requested cart item is not available');
                $this->dispatch('showAlert', session('message'));
            }
    
            $this->resetFields();
            session()->flash('message', 'Cart item removed successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while removing specific cart item. Error : ' . $e->getMessage());
        }
    }
}
