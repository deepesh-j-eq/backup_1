<?php

namespace App\Livewire;

use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use Livewire\WithPagination;

class ProductListing extends Component
{
    use WithPagination;
   
    public $priceRange, $productId, $productDetail;
    public $shortBy = 'newest';
    public $searchTerm  = '';

    protected $paginationTheme = 'bootstrap';

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->shortBy = '';
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function setSortBy($sortBy)
    {
        $this->shortBy = $sortBy;
        $this->resetPage();
    }

    public function render()
    {
        $query = Product::with([
            'images' => function ($query) {
                $query->select(['id', 'image_path', 'product_id'])->limit(4);
            },
        ]);

        if (isset($this->shortBy) && $this->shortBy != '') {
            switch ($this->shortBy) {
                case 'most_popular':
                    $query->orderBy('popularity', 'desc');
                    break;
                case 'best_rating':
                    $query->withAvg('ratings', 'rating')->orderByDesc('ratings_avg_rating');
                    break;
                case 'newest':
                    $query->orderBy('created_at', 'desc');
                    break;
                case 'price_low_high':
                    $query->orderBy(DB::raw("CASE WHEN discounted_price IS NOT NULL AND discounted_price > 0 THEN discounted_price ELSE price END"), 'asc');
                    /* $query->orderByRaw("
                        CASE 
                            WHEN discounted_price IS NOT NULL AND discounted_price > 0 THEN discounted_price 
                            ELSE price 
                        END ASC
                    "); */
                    break;
                case 'price_high_low':
                    $query->orderBy(DB::raw("CASE WHEN discounted_price IS NOT NULL AND discounted_price > 0 THEN discounted_price ELSE price END"), 'desc');
                    /* $query->orderByRaw("
                        CASE 
                            WHEN discounted_price IS NOT NULL AND discounted_price > 0 THEN discounted_price 
                            ELSE price 
                        END DESC
                    "); */
                    break;
                default:
                    $query->orderBy('created_at', 'desc');
            }
        }

        $productDetails = $query
            ->where(function ($query) {
                $query->where('name', 'like', '%' . $this->searchTerm . '%')
                    ->orWhere('price', 'like', '%' . $this->searchTerm . '%')
                    ->orWhereHas('category', function ($query) {
                        $query->where('name', 'like', '%' . $this->searchTerm . '%');
                    });
            })
            ->paginate(2);

        return view('livewire.product-listing', compact('productDetails'));
    }
}
