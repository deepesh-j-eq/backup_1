@push('meta_tags')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush
@section('title', 'Cart Detail')
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">

                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Your cart</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="d-flex align-items-center justify-content-center my-3 my-lg-0">
                        <div class="row">
                            <div id="general-error"></div>
                        </div>
                    </div>
                    <div class="row">
                        @if (session()->has('message'))
                            <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        @if (session()->has('error_message'))
                            <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('error_message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif
                        <div class="col-md-1"></div>

                        <div class="col-md-10">
                            <div class="card-body">
                                <input type="text" class="form-control" wire:model.live.debounce.300ms="searchTerm" placeholder="Search cart items...">
                                <h4 class="card-title">Your cart detail</h4>
                                <hr />

                                <div class="table-responsive">
                                    <table id="cart_table" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Sr. no.</th>
                                                <th>Name</th>
                                                <th>Price</th>
                                                <th>Discounted Price</th>
                                                <th>Quantity</th>
                                                <th>Product Attribute Options</th>
                                                <th>Image</th>
                                                <th></th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @if ($cartItems->isNotEmpty())
                                                @php $a = 1; @endphp
                                                @foreach ($cartItems as $item)
                                                    <tr>
                                                        <td>{{ $a }}</td>
                                                        <td>{{ $item->product->name }}</td>
                                                        <td>${{ number_format($item->product->price, 2, '.', ',') }}</td>
                                                        <td>{{ ($item->product->discounted_price) ? "$".number_format($item->product->discounted_price, 2, '.', ',') : '-' }}</td>
                                                        <td>{{ $item->quantity }}</td>
                                                        <td>{{ '-' }}</td>
                                                        <td>
                                                            @php
                                                                $image = DB::table('product_images')
                                                                    ->select('image_path')
                                                                    ->where('product_id', $item->product_id)
                                                                    ->first();
                                                            @endphp
                                                            @if ($image)
                                                                <div class="col">
                                                                    <div class="card">
                                                                        <img src="{{ asset('storage/' . $image->image_path) }}" alt="{{ $item->product->name }}" style="width: 200px; height: 100px; object-fit: contain;">
                                                                    </div>
                                                                </div>
                                                            @else
                                                                {{ '-' }}
                                                            @endif
                                                        </td>
                                                        <td>
                                                            <div class="col">
                                                                <div class="input-group input-spinner">
                                                                    <button class="btn btn-white" type="button" id="button-plus-{{$item->product_id}}" data-product-id="{{$item->product_id}}"> + </button>
                                                                        <input type="text" name="quantity_for_{{$item->product_id}}" id="quantity_for_{{$item->product_id}}" class="form-control @error('quantity_for_{{$item->product_id}}') is-invalid @enderror" value="1" maxlength="9" data-product-id="{{$item->product_id}}">
                                                                    <button class="btn btn-white" type="button" id="button-minus-{{$item->product_id}}" data-product-id="{{$item->product_id}}"> − </button>
                                                                    @error('quantity_for_{{$item->product_id}}') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <button class="btn btn-warning btn-sm" wire:click="updateCartQuantity({{ $item->id }})">Update quantity</button>
                                                            <button class="btn btn-danger btn-sm" wire:click="confirmDelete({{ $item->id }})">Remove item</button>
                                                        </td>
                                                    </tr>
                                                    @php $a++; @endphp
                                                @endforeach
                                            @else
                                                <tr>
                                                    <td colspan="9" class="text-center">Your cart is empty, Keep shopping!</td>
                                                </tr>
                                            @endif
                                        </tfoot>
                                    </table>
                                </div>

                                @if ($specificCartItemRemoveConfirmation)
                                    <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Remove cart item</h5>
                                                    <button type="button" class="close" wire:click="$set('specificCartItemRemoveConfirmation', false)">
                                                        &times;
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete this product attribute ?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" wire:click="$set('specificCartItemRemoveConfirmation', false)">Cancel</button>
                                                    <button class="btn btn-danger" wire:click="removeSpecificCartItem">Delete</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endif

                                <div wire:ignore.self>
                                    {{ $cartItems->links() }}
                                </div>
                            </div>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->


        @push('clientSideValidationScript')
            <script>
                $(document).ready(function() {
                    $(document).on('click', '[id^="button-plus-"]', function () {
                        var productId = $(this).data('product-id');
                        var input = $('#quantity_for_' + productId);
    
                        let quantity = parseInt(input.val()) || 0;
                        let new_quantity = quantity + 1;

                        const maxQuantity = 214748360;
    
                        if (new_quantity > maxQuantity) {
                            new_quantity = maxQuantity;
                        }
    
                        input.val(new_quantity).attr('value', new_quantity);
                    });
    
                    $(document).on('click', '[id^="button-minus-"]', function () {
                        var productId = $(this).data('product-id');
                        var input = $('#quantity_for_' + productId);
    
                        let quantity = parseInt(input.val()) || 0;
                        if (quantity > 1) {
                            input.val(quantity - 1).attr('value', quantity - 1);
                        }
                    });
    
                    $(document).on('input', 'input[id^="quantity_for_"]', function () {
                        let sanitized = $(this).val().replace(/[^0-9]/g, '');
                        if (sanitized === '' || parseInt(sanitized) < 1) {
                            sanitized = '1';
                        }
    
                        if (sanitized !== '' && parseInt(sanitized) > 214748360) {
                            sanitized = '214748360';
                        }
    
                        $(this).val(sanitized).attr('value', sanitized);
                    });
    
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                            'Accept': 'application/json'
                        }
                    });
                });
            </script>
        @endpush