<?php

namespace App\Livewire;

use App\Models\Product;
use Livewire\Component;

class ProductDetail extends Component
{
    public $productDetail, $productId;

    public function mount($productId)
    {
        $this->productId = $productId;
    }

    public function render()
    {
        try {
            $this->productDetail = Product::with([
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id'])->limit(4);
                },
                'category',
                'attributeOptions',
                'attributeOptions.productAttribute:id,attribute_name'
            ])
            ->find($this->productId);
    
            if (!$this->productDetail) {
                return redirect()->route('all.products')->with('error_message', 'Something went wrong! while feteching the product detail page');
            }
    
            return view('livewire.product-detail');
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching product detail page. Error : ' . $e->getMessage());
        }
    }
}
