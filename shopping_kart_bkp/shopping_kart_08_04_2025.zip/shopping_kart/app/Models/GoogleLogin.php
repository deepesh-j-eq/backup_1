<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GoogleLogin extends Model
{
    use HasFactory;

    protected $fillable = ['google_id', 'email', 'name', 'ip_address', 'user_agent', 'logged_in_at', 'user_id'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
