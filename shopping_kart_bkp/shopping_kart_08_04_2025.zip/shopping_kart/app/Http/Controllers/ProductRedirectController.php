<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductRedirectController extends Controller
{
    public function handle(Request $request)
    {
        $productId = $request->input('hidden_product_id');
        return redirect()->route('product.detail', ['productId' => $productId]);
    }
}
