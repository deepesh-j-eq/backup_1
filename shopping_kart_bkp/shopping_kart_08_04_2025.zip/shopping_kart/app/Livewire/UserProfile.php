<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;

class UserProfile extends Component
{
    public $loggedinUserDetail, $name, $email, $imagePath;

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->loggedinUserDetail = (object)[];
        $this->name = '';
        $this->email = '';
    }

    public function render()
    {
        $this->loggedinUserDetail = loggedinUserDetail();

        if (empty($this->loggedinUserDetail)) {
            session()->flash('error_message', 'User details not found.');
            redirect()->back()->send();
        }

        $this->name = $this->loggedinUserDetail->name;
        $this->email = $this->loggedinUserDetail->email;
        $this->imagePath = $this->loggedinUserDetail->image ?? '';

        $userRole = User::with(['role'])->where('id', $this->loggedinUserDetail->id)->first();

        $resultArray = [];
        $resultArray['userInformation'] = $this->loggedinUserDetail;

        if ($userRole) {
            $resultArray['userRole'] = ucfirst($userRole->role->role);
        }

        return view('livewire.user-profile', $resultArray);
    }
}
