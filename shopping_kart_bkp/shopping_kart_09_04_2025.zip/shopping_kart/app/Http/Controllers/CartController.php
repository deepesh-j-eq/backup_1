<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddToCartRequest;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function addToCart(AddToCartRequest $request)
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $productId = $request->product_id;
                $quantity = $request->quantity;

                if ($request->filled('product_attributes_detail')) {
                    $attributes = $request->input('product_attributes_detail');
                    $attributesArray = json_decode($attributes, true);
                }
    
                $selectedAttributeOptions = [];
                $selectedAttributeOptions = collect($request->all())
                    ->filter(fn($value, $key) => str_ends_with($key, '_attribute_option'))
                    ->all();

                if (!empty($selectedAttributeOptions)) {
                    $product = Product::whereHas('attributeOptions', function ($query) use ($selectedAttributeOptions) {
                            $query->whereIn('product_attribute_options.id', $selectedAttributeOptions);
                        })
                        ->with(['attributeOptions' => function ($query) use ($selectedAttributeOptions) {
                            $query->whereIn('product_attribute_options.id', $selectedAttributeOptions);
                        }])
                        ->find($productId);
                    /* $product = Product::with('attributeOptions')
                            ->whereHas('attribute_options', function ($query) use ($selectedAttributeOptions) {
                                $query->whereIn('product_attribute_option_id', $selectedAttributeOptions);
                            })
                            ->find($productId); */
                } else {
                    $product = Product::find($productId);
                }

                dd($product);
    
                if (!$product) {
                    return response()->json([
                        'status' => false,
                        'custom_error' => false,
                        'message' => 'Something went wrong! Requested product is not available while add to cart'
                    ], 404);
                }
    
                if ($quantity > $product->quantity) {
                    if (!empty($selectedAttributeOptions)) {
                        return $this->handleStockError($product, $selectedAttributeOptions);
                    }
                    return $this->handleStockError($product);
                }
    
                if (!empty($selectedAttributeOptions)) {
                    $cartItem = Cart::where('user_id', $user->id)
                                ->where('product_id', $productId)
                                ->whereIn('product_attribute_option_id', array_values($selectedAttributeOptions))
                                ->get();
                }
    
                $cartItem = Cart::where('user_id', $user->id)
                                ->where('product_id', $productId)
                                ->first();
    
                if ($cartItem) {
                    $newQuantity = $cartItem->quantity + $quantity;
    
                    if ($newQuantity > $product->quantity) {
                        return $this->handleStockError($product, $selectedAttributeOptions, $cartItem);
                    }
    
                    $cartItem->update(['quantity' => $newQuantity]);
                } else {
                    if (!empty($selectedAttributeOptions)) {
                        foreach ($selectedAttributeOptions as $selectedAttrOption) {
                            $cartItem = Cart::create([
                                'quantity' => $quantity,
                                'product_id' => $productId,
                                'product_attribute_option_id' => $selectedAttrOption,
                                'user_id' => $user->id
                            ]);
    
                            if (!$cartItem) {
                                return response()->json([
                                    'status' => false,
                                    'custom_error' => true,
                                    'message' => 'Something went wrong! Add to cart failed'
                                ], 500);
                            }
                        }
                    }
                }
    
                return response()->json([
                    'status' => true,
                    'message' => 'Product added to cart successfully'
                ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    'status' => false,
                    'custom_error' => false,
                    'message' => 'While add to cart an error occurred: ' . $e->getMessage()
                ], 500);
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while add to cart'
            ], 422);
        }
    }

    private function handleStockError($product, $selectedAttributeOptions = [], $cartItem = null)
    {
        $availableQuantity = $product ? $product->quantity : 0;

        if ($cartItem) {
            $availableQuantity -= $cartItem->quantity;
        }

        return response()->json([
            'status' => false,
            'custom_error' => true,
            'message' => 'Not enough stock available for selected product ' . ($product->name ?? '') . '. You can add only ' . max($availableQuantity, 0) . ' more.'
        ], 409);
    }
}
