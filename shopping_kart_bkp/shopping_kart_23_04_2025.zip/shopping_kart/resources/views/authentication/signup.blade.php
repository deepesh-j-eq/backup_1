<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!--favicon-->
    <link rel="icon" href="{{ asset('assets/images/favicon-32x32.png') }}" type="image/png" />
    <!--plugins-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/simplebar/6.2.3/simplebar.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/perfect-scrollbar/1.5.5/css/perfect-scrollbar.min.css" rel="stylesheet" />
    <link href="{{ asset('assets/plugins/metismenu/css/metisMenu.min.css') }}" rel="stylesheet" />
    <!-- loader-->
    <link href="{{ asset('assets/css/pace.min.css') }}" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pace/1.2.4/pace.min.js"></script>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{ asset('assets/css/bootstrap-extended.css') }}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link href="{{ asset('assets/css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/icons.css') }}" rel="stylesheet">
    <link href="https://parsleyjs.org/src/parsley.css" rel="stylesheet">
    <title>Register</title>
</head>

<body class="bg-login">
    <!--wrapper-->
    <div class="wrapper">
        <div class="d-flex align-items-center justify-content-center my-5 my-lg-0">
            <div class="container">
                <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-2">
                    <div class="col mx-auto">
                        <div class="my-4 text-center">
                            <img src="{{ asset('assets/images/logo-img.png') }}" width="180" alt="" />
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="border p-4 rounded">
                                    <div class="text-center">
                                        <h3 class="">Sign Up</h3>
                                        <p>Already have an account? <a href="{{ route('login') }}">Sign in here</a>
                                        </p>
                                    </div>
                                    @if(session('error'))
                                        <div class="alert alert-danger text-center">
                                            {{ session('error') }}
                                        </div>
                                    @endif
                                    @if($message = session()->pull('success'))
                                        <div class="alert alert-success alert-dismissible fade show p-1" role="alert">
                                            {{ $message }}
                                            <button type="button" class="btn-close p-2" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    @endif
                                    <div class="login-separater text-center mb-4"> <span>OR SIGN UP WITH EMAIL</span>
                                        <hr/>
                                    </div>
                                    <div class="form-body">
                                        <form class="row g-3" id="signupForm" method="post" enctype="multipart/form-data">
                                            @csrf
                                            <div class="col-sm-6">
                                                <label for="inputFirstName" class="form-label">First Name</label>
                                                <input type="text" name="first_name" class="form-control @error('first_name') is-invalid @enderror" id="inputFirstName" placeholder="Enter first name" value="{{ old('first_name') }}" data-parsley-required="true" data-parsley-required-message="The first name is required" data-parsley-maxlength="255">
                                                @error('first_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="inputLastName" class="form-label">Last Name</label>
                                                <input type="text" name="last_name" class="form-control @error('last_name') is-invalid @enderror" id="inputLastName" placeholder="Enter last name" value="{{ old('last_name') }}" data-parsley-maxlength="255">
                                                @error('last_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-12">
                                                <label for="inputEmailAddress" class="form-label">Email Address</label>
                                                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" id="inputEmailAddress" placeholder="Enter email address" value="{{ old('email') }}" data-parsley-required="true" data-parsley-required-message="The email is required" data-parsley-maxlength="255">
                                                @error('email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-12">
                                                <label for="inputChoosePassword" class="form-label">Password</label>
                                                <div class="input-group" id="show_hide_password">
                                                    <input type="password" name="password" class="form-control border-end-0 @error('password') is-invalid @enderror" id="inputChoosePassword" value="{{ old('password') }}" placeholder="Enter password" data-parsley-required="true" data-parsley-required-message="The password is required" data-parsley-minlength="5" data-parsley-maxlength="12"> <a href="javascript:;" class="input-group-text bg-transparent"><i class='bx bx-hide'></i></a>
                                                    @error('password')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <label for="inputConfirmPassword" class="form-label">Confirm Password</label>
                                                <div class="input-group" id="show_hide_password">
                                                    <input type="password" name="confirm_password" class="form-control border-end-0 @error('confirm_password') is-invalid @enderror" id="inputConfirmPassword" value="" placeholder="Enter confirm password" data-parsley-required="true" data-parsley-required-message="The confirm password is required" data-parsley-minlength="5" data-parsley-maxlength="12" data-parsley-equalto="#inputChoosePassword"
                                                    data-parsley-equalto-message="Passwords do not match"> <a href="javascript:;" class="input-group-text bg-transparent"><i class='bx bx-hide'></i></a>
                                                    @error('password')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <label for="inputImage">
                                                <input type="file" name="image" class="form-control @error('image') is-invalid @enderror" id="inputImage"  value="{{ old('image') }}" data-parsley-required="true" data-parsley-required-message="The image is required" data-parsley-filemaxmegabytes="2" data-parsley-filemimetypes="image/jpeg, image/png, image/jpg">
                                                @error('image')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="col-12">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked">
                                                    <label class="form-check-label" for="flexSwitchCheckChecked">I read and agree to Terms & Conditions</label>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-grid">
                                                    <button type="submit" class="btn btn-primary"><i class='bx bx-user'></i>Sign up</button>
                                                </div>
                                            </div>
                                            <input type="hidden" name="admin_signup_url" class="admin_signup_url" value="{{ route('register.authentication') }}">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end row-->
            </div>
        </div>
    </div>
    <!--end wrapper-->
    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <!--plugins-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/simplebar/5.1.0/simplebar.min.js"></script>
    <script src="{{ asset('assets/plugins/metismenu/js/metisMenu.min.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/perfect-scrollbar/1.4.0/perfect-scrollbar.min.js"></script>
    <script src="https://parsleyjs.org/dist/parsley.min.js"></script>
    <!--Password show & hide js -->
    <script>
        $(document).ready(function () {
            $("#show_hide_password a").on('click', function (event) {
                event.preventDefault();
                if ($('#show_hide_password input').attr("type") == "text") {
                    $('#show_hide_password input').attr('type', 'password');
                    $('#show_hide_password i').addClass("bx-hide");
                    $('#show_hide_password i').removeClass("bx-show");
                } else if ($('#show_hide_password input').attr("type") == "password") {
                    $('#show_hide_password input').attr('type', 'text');
                    $('#show_hide_password i').removeClass("bx-hide");
                    $('#show_hide_password i').addClass("bx-show");
                }
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            /* $('#signupForm').parsley({
                errorsContainer: function (ParsleyField) {
                    var field = ParsleyField.$element;

                    if (field.closest('.input-group').length) {
                        return field.closest('.input-group');
                    }

                    if (field.closest('div').length) {
                        return field.closest('div');
                    }

                    return field;
                }
            }); */

            $('#signupForm').parsley().on('field:error', function () {
                var field = $(this.$element);
                var errorList = field.next('.parsley-errors-list');

                if (field.hasClass('parsley-success')) {
                    field.removeClass('is-invalid');
                }

                if (field.nextAll('.invalid-feedback').length) {
                    field.nextAll('.invalid-feedback').remove();
                }

                if (field.closest('.input-group').length) {
                    field.closest('.input-group').append(errorList);
                }
            });

            $('#signupForm').parsley().on('field:success', function () {
                var field = $(this.$element);

                if (field.hasClass('parsley-success')) {
                    field.removeClass('is-invalid');
                }
            });

            $("#signupForm").submit(function(e) {
                e.preventDefault();
                if ($(this).parsley().validate()) {
                    var url = $('.admin_signup_url').val();
                    //url = url.replace('http://', 'https://');
                    var formData = new FormData(this);

                    $.ajax({
                        url: url,
                        data: formData,
                        type: 'POST',
                        dataType: 'json',
                        processData: false,
                        contentType: false,
                        cache: false,
                        success: function(result) {
                            if (result.status === true) {
                                window.location.href = result.redirect_url;
                            }
                        },
                        error: function(xhr) {
                            var response = xhr.responseJSON;
                            if (response && response.custom_error) {
                                showGeneralError(response.message);
                            }

                            if (response && response.errors) {
                                displayErrors(response.errors);
                            }
                        }
                    });
                }
            });

            window.Parsley.addValidator('filemaxmegabytes', {
                requirementType: 'integer',
                validateString: function(value, requirement, parsleyInstance) {
                    var file = parsleyInstance.$element[0].files[0];
                    return file ? file.size / 1024 / 1024 <= requirement : true;
                },
                messages: {
                    en: 'File size should not exceed %s MB.'
                }
            });

            window.Parsley.addValidator('filemimetypes', {
                requirementType: 'string',
                validateString: function(value, requirement, parsleyInstance) {
                    var file = parsleyInstance.$element[0].files[0];
                    return file ? requirement.split(',').includes(file.type) : true;
                },
                messages: {
                    en: 'Only JPG, JPEG, and PNG files are allowed.'
                }
            });

            function showGeneralError(message) {
                $("#general-error").html('');

                var errorHtml = `
                    <div class="alert alert-danger alert-dismissible fade show p-1" role="alert">
                        ${message}
                        <button type="button" class="btn-close p-2" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `;

                $("#general-error").html(errorHtml);
            }

            function displayErrors(errors) {
                $('.invalid-feedback').remove();
                $('.form-control').removeClass('is-invalid');

                $.each(errors, function(field, messages) {
                    var input = $('[name="' + field + '"]');
                    if (input.hasClass('parsley-success')) {
                        input.removeClass('parsley-success');
                    }
                    input.addClass('is-invalid');

                    $.each(messages, function(index, message) {
                        if (input.closest('.input-group').length) {
                            input.closest('.input-group').append('<span class="invalid-feedback d-block"><strong>' + message + '</strong></span>');
                        } else {
                            input.after('<span class="invalid-feedback d-block"><strong>' + message + '</strong></span>');
                        }
                    });
                });
            }
        });
    </script>
</body>

</html>
