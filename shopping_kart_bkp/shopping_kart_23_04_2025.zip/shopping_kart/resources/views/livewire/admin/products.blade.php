@section('title', 'Products')
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Products</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="card-body p-4">
                        <button class="btn btn-primary mb-3" id="add_new_product_attr_btn" wire:click="showCreateModal">Add New Product</button>
                        <input type="text" class="form-control" wire:model.live.debounce.300ms="searchTerm" placeholder="Search products...">
                        <h5 class="card-title">Products</h5>
                        <hr />

                        @if (session()->has('message'))
                            <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        @if (session()->has('error_message'))
                            <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('error_message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        {{-- @if ($productDetails->isNotEmpty())
                            @php $productAttributeOptionsArray = []; @endphp
                            @foreach ($productDetails as $product)
                                @if ($product->attributeOptions)
                                    @foreach ($product->attributeOptions as $attr)
                                        @php $productAttributeOptionsArray[$product->id][$attr->productAttribute->attribute_name][] = $attr->option; @endphp
                                    @endforeach
                                @endif
                            @endforeach
                        @endif --}}

                        <div class="table-responsive">
                            <table id="product_details_table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Sr. no.</th>
                                        <th>Name</th>
                                        <th style="word-wrap: break-word; max-width: 200px;">Description</th>
                                        <th>Price</th>
                                        <th>Discounted Price</th>
                                        <th>Quantity</th>
                                        <th>Category</th>
                                        <th>Product Attribute Options</th>
                                        <th>Images</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if ($productDetails->isNotEmpty())
                                        @php $srNo = 1; @endphp
                                        @foreach ($productDetails as $product)
                                            @php $productAttributeOptionsArray = []; @endphp
                                            @if ($product->attributeOptions)
                                                @foreach ($product->attributeOptions as $attr)
                                                    @php $productAttributeOptionsArray[$product->id][$attr->productAttribute->attribute_name][] = $attr->option; @endphp
                                                @endforeach
                                            @endif
                                            <tr>
                                                <td>{{ $srNo }}</td>
                                                <td>{{ $product->name }}</td>
                                                <td>
                                                    <span class="short-desc-{{ $product->id }}">
                                                        {{ Str::limit($product->description, 50, '...') }}
                                                    </span>
                                                    <span class="full-desc-{{ $product->id }}" style="display: none;">
                                                        {{ $product->description }}
                                                    </span>
                                                    @if (strlen($product->description) > 50)
                                                        <a href="javascript:void(0);" class="read-more-btn" data-id="{{ $product->id }}">Read More</a>
                                                        <a href="javascript:void(0);" class="read-less-btn" data-id="{{ $product->id }}" style="display: none;">Read Less</a>
                                                    @endif
                                                </td>
                                                <td>{{ number_format($product->price, 2, '.', ',') }}</td>
                                                <td>{{ ($product->discounted_price) ? number_format($product->discounted_price, 2, '.', ',') : '-' }}</td>
                                                <td>{{ $product->quantity }}</td>
                                                <td>{{ $product->category->name }}</td>
                                                <td>
                                                    @if (!empty($productAttributeOptionsArray))
                                                        @foreach ($productAttributeOptionsArray[$product->id] as $attributeName => $options)
                                                            <p>{{ $attributeName . " => " . implode(', ', $options) }}</p>
                                                        @endforeach
                                                    @else
                                                        {{ '-' }}
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($product->images)
                                                        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 row-cols-xxl-5 g-3">
                                                            @foreach ($product->images as $image)
                                                                <div class="col">
                                                                    <div class="card">
                                                                        <img src="{{ asset('storage/' . $image->image_path) }}" alt="{{ $product->name }}" class="img-thumbnail" style="width: 140px; height: 100px; object-fit: contain;">
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button class="btn btn-warning btn-sm" wire:click="showEditModal({{ $product->id }})">Edit</button>
                                                    <button class="btn btn-danger btn-sm" wire:click="confirmDelete({{ $product->id }})">Delete</button>
                                                </td>
                                            </tr>
                                            @php $srNo++; @endphp
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="10" class="text-center">No product details or no products created</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>

                        @if ($modalFormVisible)
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">{{ $productId ? 'Edit' : 'Create' }} Product</h5>
                                            <button type="button" class="close" wire:click="$set('modalFormVisible', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            @if (!empty($errorMessages))
                                                <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show p-1" onclick="hideAlert()" role="alert">
                                                    <ul>
                                                        @foreach ($errorMessages as $errorMsg)
                                                            <li>{{ $errorMsg }}</li>
                                                        @endforeach
                                                    </ul>
                                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                                </div>
                                            @endif
                                            <form id="product_form"
                                                x-data="{   name: @entangle('name'),
                                                            description: @entangle('description'),
                                                            images: @entangle('images'),
                                                            price: @entangle('price'),
                                                            discounted_price: @entangle('discounted_price'),
                                                            quantity: @entangle('quantity'),
                                                            category_id: @entangle('category_id'),
                                                            selectedProductAttributes: @entangle('selectedProductAttributes'),
                                                            selectedProductAttributeOptions: @entangle('selectedProductAttributeOptions'),
                                                            errors: { name: '', description: '', images: '', price: '', discounted_price: '', quantity: '', category_id: '', selectedProductAttributes: '', selectedProductAttributeOptions: '' }
                                                        }"
                                                x-on:submit.prevent="if (validateProductForm($el, $data, $wire, {{ $productId ? "'update'" : "'store'" }})) { $wire.call({{ $productId ? "'update'" : "'store'" }}); }">
                                                <div class="form-group">
                                                    <label for="inputProductTitle" class="form-label">Product Name</label>
                                                    <input type="text"
                                                        class="form-control @error('name') is-invalid @enderror"
                                                        id="inputProductTitle"
                                                        placeholder="Enter product name"
                                                        wire:model="name"
                                                        x-model="name">
                                                    @error('name') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                    <span x-show="errors.name" class="text-danger mt-1" x-text="errors.name"></span>
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputProductDescription" class="form-label">Description</label>
                                                    <textarea class="form-control @error('description') is-invalid @enderror"
                                                            id="inputProductDescription"
                                                            rows="3" wire:model="description"
                                                            x-model="description">
                                                        {{ old('description') }}
                                                    </textarea>
                                                    @error('description') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                    <span x-show="errors.description" class="text-danger mt-1" x-text="errors.description"></span>
                                                </div>
                                                <div class="form-group">
                                                    <label for="image-uploadify" class="form-label">Product Images</label>
                                                    <input class="form-control @error('images') is-invalid @enderror"
                                                        id="image-uploadify"
                                                        type="file" multiple
                                                        wire:model="images">
                                                    @error('images.*') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                    <span x-show="errors.images" class="text-danger mt-1" x-text="errors.images"></span>

                                                    @if ($productId && $existingImages)
                                                        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 row-cols-xxl-5 g-3 p-3 product-grid">
                                                            @foreach ($existingImages as $image)
                                                                <div class="col">
                                                                    <div class="card">
                                                                        <img src="{{ asset('storage/' . $image->image_path) }}" alt="{{ ($name) ?? '' }}" style="width: 140px; height: 100px; object-fit: contain;">
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    @endif
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <label for="inputPrice" class="form-label">Price</label>
                                                            <input type="text"
                                                                name="price"
                                                                class="form-control @error('price') is-invalid @enderror"
                                                                id="inputPrice"
                                                                placeholder="100.00"
                                                                wire:model="price"
                                                                x-model="price">
                                                            @error('price') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                            <span x-show="errors.price" class="text-danger mt-1" x-text="errors.price"></span>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label for="inputDiscountPrice" class="form-label">Discounted Price</label>
                                                            <input type="text"
                                                                name="discounted_price"
                                                                class="form-control @error('discounted_price') is-invalid @enderror"
                                                                id="inputDiscountPrice"
                                                                placeholder="50.00"
                                                                wire:model="discounted_price"
                                                                x-model="discounted_price">
                                                            @error('discounted_price') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                            <span x-show="errors.discounted_price" class="text-danger mt-1" x-text="errors.discounted_price"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputQuantity">Quantity</label>
                                                    <input type="text"
                                                        class="form-control @error('quantity') is-invalid @enderror"
                                                        id="inputQuantity"
                                                        wire:model="quantity"
                                                        x-model="quantity">
                                                    @error('quantity') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                    <span x-show="errors.quantity" class="text-danger mt-1" x-text="errors.quantity"></span>
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputCategory" class="form-label">Product Category</label>
                                                    <select name="category_id"
                                                        class="form-select @error('category_id') is-invalid @enderror"
                                                        id="inputCategory"
                                                        wire:model="category_id"
                                                        x-model="category_id">
                                                        <option>Select Category</option>
                                                        @if ($categoryDetails->isNotEmpty())
                                                            @foreach ($categoryDetails as $category)
                                                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                    @error('category_id') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                    <span x-show="errors.category_id" class="text-danger mt-1" x-text="errors.category_id"></span>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <label for="inputProductAttributes" class="form-label">Product Attributes</label>
                                                            <select multiple
                                                                name="product_attributes" 
                                                                class="form-select @error('selectedProductAttributes') is-invalid @enderror"
                                                                id="inputProductAttributes"
                                                                wire:model="selectedProductAttributes"
                                                                x-model="selectedProductAttributes">
                                                                @foreach ($productAttributeDetails as $productAttribute)
                                                                    <option value="{{ $productAttribute->id }}">{{ $productAttribute->attribute_name }}</option>
                                                                @endforeach
                                                            </select>
                                                            @error('selectedProductAttributes') <span class="invalid-feedback"><strong>{{ $message }}</strong></span> @enderror
                                                            <span x-show="errors.selectedProductAttributes" class="text-danger mt-1" x-text="errors.selectedProductAttributes"></span>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <label for="inputProductAttributeOptions" class="form-label">Product Attribute Options</label>
                                                            <select multiple name="product_attribute_options"
                                                                class="form-select @error('selectedProductAttributeOptions') is-invalid @enderror @if (!empty($errorMessages)) is-invalid @endif"
                                                                id="inputProductAttributeOptions"
                                                                wire:model="selectedProductAttributeOptions"
                                                                x-model="selectedProductAttributeOptions">
                                                                @foreach ($productAttributeOptionDetails as $productAttributeOption)
                                                                    <option value="{{ $productAttributeOption->id }}">{{ $productAttributeOption->option }}</option>
                                                                @endforeach
                                                            </select>
                                                            @error('selectedProductAttributeOptions') <span class="invalid-feedback"><strong>{{ $message }}</strong></span> @enderror
                                                            <span x-show="errors.selectedProductAttributeOptions" class="text-danger mt-1" x-text="errors.selectedProductAttributeOptions"></span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" wire:click="$set('modalFormVisible', false)">Close</button>
                                                    <button type="submit" class="btn btn-primary" id="submitLivewireForm">{{ $productId ? 'Update' : 'Create' }}</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if ($deleteConfirmation)
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Delete Product</h5>
                                            <button type="button" class="close" wire:click="$set('deleteConfirmation', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete this product ?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" wire:click="$set('deleteConfirmation', false)">Cancel</button>
                                            <button class="btn btn-danger" wire:click="delete">Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        <div wire:ignore.self class="d-flex justify-content-end mt-3 me-3">
                            {{ $productDetails->links('livewire::bootstrap-5') }}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @push('clientSideValidationScript')
            <script>
                //
            </script>
        @endpush

        @push('scripts')
            <script>
                $(document).ready(function () {
                    $(".read-more-btn").click(function () {
                        let productId = $(this).data("id");
                        $(".short-desc-" + productId).hide();
                        $(".full-desc-" + productId).show();
                        $(this).hide();
                        $(".read-less-btn[data-id='" + productId + "']").show();
                    });

                    $(".read-less-btn").click(function () {
                        let productId = $(this).data("id");
                        $(".short-desc-" + productId).show();
                        $(".full-desc-" + productId).hide();
                        $(this).hide();
                        $(".read-more-btn[data-id='" + productId + "']").show();
                    });
                });

                function showAlert(message) {
                    setTimeout(hideAlert, 5000);
                }

                function hideAlert() {
                    let alertBox = document.getElementById('sessionAlert');
                    if (alertBox) {
                        alertBox.style.display = 'none';
                    }
                }

                Livewire.on('showAlert', (message) => {
                    showAlert(message);
                });

                document.addEventListener("DOMContentLoaded", function () {
                    if (typeof Livewire !== "undefined") {
                        document.addEventListener("keydown", function (event) {
                            if (event.key === "Escape") {
                                Livewire.first().call('closeModal');
                            }
                        });
                    } else {
                        console.error("Livewire is not loaded. Ensure livewireScripts is included in your layout.");
                    }
                });

                function validateProductForm(element, data, wire, action) {
                    const productValidationRules = {
                        name: {
                            label: 'Product name',
                            required: true,
                            min: 3,
                            max: 255,
                            regex: /^[a-zA-Z0-9\s\-_']+$/,
                            regexMessage: 'Product name must contain only letters, numbers, spaces, hyphens, or underscores.'
                        },
                        description: {
                            label: 'Description',
                            required: true,
                            max: 255
                        },
                        images: {
                            label: 'Images',
                            required: action === 'store',
                            maxFiles: 5,
                            maxSize: 2 * 1024 * 1024,
                            allowedTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/jpg']
                        },
                        price: {
                            label: 'Price',
                            required: true,
                            numeric: true,
                            minValue: 1,
                            maxValue: 1000000,
                            regex: /^\d+(\.\d{1,2})?$/,
                            regexMessage: 'Price must have up to 2 decimal places.'
                        },
                        discounted_price: {
                            label: 'Discounted price',
                            required: false,
                            numeric: true,
                            minValue: 0,
                            maxValue: 1000000,
                            regex: /^\d+(\.\d{1,2})?$/,
                            regexMessage: 'Discounted price must have up to 2 decimal places.',
                            lessThanField: 'price',
                            lessThanMessage: 'Discounted price must be less than the regular price.'
                        },
                        quantity: {
                            label: 'Quantity',
                            required: true,
                            integer: true,
                            minValue: 0,
                            maxValue: 100000
                        },
                        category_id: {
                            label: 'Category',
                            required: true
                        },
                        selectedProductAttributes: {
                            label: 'Product attributes',
                            required: false,
                            minItems: 0
                        },
                        selectedProductAttributeOptions: {
                            label: 'Product attribute options',
                            required: false,
                            minItems: 0,
                            dependsOn: 'selectedProductAttributes'
                        }
                    };

                    data.errors = Object.keys(productValidationRules).reduce((acc, field) => ({ ...acc, [field]: '' }), {});
                    let isValid = true;

                    Object.keys(productValidationRules).forEach((field) => {
                        const value = data[field];
                        const fieldRules = productValidationRules[field];

                        if (fieldRules.required && !value) {
                            data.errors[field] = `${fieldRules.label} is required.`;
                            isValid = false;
                        }

                        if (value && typeof value === 'string') {
                            if (fieldRules.min && value.length < fieldRules.min) {
                                data.errors[field] = `${fieldRules.label} must be at least ${fieldRules.min} characters.`;
                                isValid = false;
                            }
                            if (fieldRules.max && value.length > fieldRules.max) {
                                data.errors[field] = `${fieldRules.label} must not exceed ${fieldRules.max} characters.`;
                                isValid = false;
                            }
                            if (fieldRules.regex && !fieldRules.regex.test(value)) {
                                data.errors[field] = fieldRules.regexMessage || `${fieldRules.label} is invalid.`;
                                isValid = false;
                            }
                        }

                        if (fieldRules.numeric && value) {
                            const numValue = parseFloat(value);
                            if (isNaN(numValue)) {
                                data.errors[field] = `${fieldRules.label} must be a number.`;
                                isValid = false;
                            } else {
                                if (fieldRules.minValue !== undefined && numValue < fieldRules.minValue) {
                                    data.errors[field] = `${fieldRules.label} must be at least ${fieldRules.minValue}.`;
                                    isValid = false;
                                }
                                if (fieldRules.maxValue !== undefined && numValue > fieldRules.maxValue) {
                                    data.errors[field] = `${fieldRules.label} must not exceed ${fieldRules.maxValue}.`;
                                    isValid = false;
                                }
                                if (fieldRules.regex && !fieldRules.regex.test(value)) {
                                    data.errors[field] = fieldRules.regexMessage || `${fieldRules.label} is invalid.`;
                                    isValid = false;
                                }
                            }
                        }

                        if (fieldRules.integer && value) {
                            const intValue = parseInt(value, 10);
                            if (isNaN(intValue) || intValue.toString() !== value.toString()) {
                                data.errors[field] = `${fieldRules.label} must be an integer.`;
                                isValid = false;
                            }
                        }

                        if (fieldRules.maxFiles && value && value.length > fieldRules.maxFiles) {
                            data.errors[field] = `${fieldRules.label} must not exceed ${fieldRules.maxFiles} files.`;
                            isValid = false;
                        }

                        if (fieldRules.maxSize && value) {
                            for (let i = 0; i < value.length; i++) {
                                if (value[i].size > fieldRules.maxSize) {
                                    data.errors[field] = `${fieldRules.label} must not exceed ${fieldRules.maxSize / (1024 * 1024)}MB per file.`;
                                    isValid = false;
                                    break;
                                }
                            }
                        }
                        if (fieldRules.allowedTypes && value) {
                            for (let i = 0; i < value.length; i++) {
                                console.log(value[i]);
                                if (!fieldRules.allowedTypes.includes(value[i].type)) {
                                    data.errors[field] = `${fieldRules.label} must be one of: ${fieldRules.allowedTypes.join(', ')}.`;
                                    isValid = false;
                                    break;
                                }
                            }
                        }

                        if (fieldRules.lessThanField && value && data[fieldRules.lessThanField]) {
                            const valueNum = parseFloat(value);
                            const compareNum = parseFloat(data[fieldRules.lessThanField]);
                            if (!isNaN(valueNum) && !isNaN(compareNum) && valueNum >= compareNum) {
                                data.errors[field] = fieldRules.lessThanMessage || `${fieldRules.label} must be less than ${fieldRules.lessThanField}.`;
                                isValid = false;
                            }
                        }

                        if (fieldRules.minItems && Array.isArray(value) && value.length < fieldRules.minItems) {
                            data.errors[field] = `${fieldRules.label} must have at least ${fieldRules.minItems} items.`;
                            isValid = false;
                        }
                    });

                    if (action === 'store' && productValidationRules.images.required && (!data.images || data.images.length === 0)) {
                        data.errors.images = `${productValidationRules.images.label} is required.`;
                        isValid = false;
                    }

                    const attributes = data.selectedProductAttributes || [];
                    const options = data.selectedProductAttributeOptions || [];

                    if (attributes.length > 0 && options.length === 0) {
                        data.errors.selectedProductAttributeOptions = 'At least one product attribute option is required when attributes are selected.';
                        isValid = false;
                    }

                    if (options.length > 0 && attributes.length === 0) {
                        data.errors.selectedProductAttributeOptions = 'Product attributes must be selected when attribute options are chosen.';
                        isValid = false;
                    }

                    return isValid;
                }
            </script>
        @endpush
