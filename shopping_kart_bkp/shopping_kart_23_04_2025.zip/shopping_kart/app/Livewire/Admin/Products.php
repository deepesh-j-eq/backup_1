<?php

namespace App\Livewire\Admin;

use App\Http\Requests\ProductManageRequest;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductAttributeOption;
use App\Models\ProductImage;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class Products extends Component
{
    use WithPagination, WithFileUploads;

    public $name, $description, $images, $price, $discounted_price, $quantity, $category_id, $existingImages, $product_attribute, $productId;
    public $modalFormVisible = false;
    public $deleteConfirmation = false;
    public $perPage = 2;
    public $searchTerm  = '';
    public $selectedProductAttributes = [];
    public $selectedProductAttributeOptions = [];
    public $productAttrOptions = [];
    public $productAttributeOptions = [];
    public $errorMessages = [];

    protected $listeners = ['closeModal'];
    protected $paginationTheme = 'bootstrap';

    public function rules()
    {
        return [
            'name' => ['required', 'string', 'min:3', 'max:255'],
            'description' => ['required', 'string', 'max:255'],
            'price' => ['required', 'numeric', 'min:1', 'regex:/^\d+(\.\d{1,2})?$/'],
            'discounted_price' => ['nullable', 'numeric', 'min:0', 'regex:/^\d+(\.\d{1,2})?$/', function ($attribute, $value, $fail) {
                if ($value !== null && $value >= $this->price) {
                    $fail('The discounted price must be less than the original price.');
                }
            }],
            'quantity' => ['required', 'integer', 'min:0'],
            'category_id' => ['required', 'exists:categories,id'],
            'images' => [$this->productId ? 'nullable' : 'required', 'array', 'max:5'],
            'images.*' => ['image', 'mimes:jpeg,png,jpg,gif', 'max:2048'],
            'selectedProductAttributes' => ['nullable', 'array'],
            'selectedProductAttributes.*' => ['exists:product_attributes,id'],
            'selectedProductAttributeOptions' => ['nullable', 'array'],
            'selectedProductAttributeOptions.*' => ['exists:product_attribute_options,id'],
        ];
    }

    protected $messages = [
        'name.required' => 'Product name is required.',
        'name.string' => 'Product name must be a valid string.',
        'name.min' => 'Product name must be at least 3 characters.',
        'name.max' => 'Product name cannot exceed 255 characters.',
        'description.required' => 'Description is required.',
        'description.string' => 'Description must be a valid string.',
        'description.max' => 'Description cannot exceed 255 characters.',
        'price.required' => 'Price is required.',
        'price.numeric' => 'Price must be a number.',
        'price.min' => 'Price must be at least 1.',
        'price.regex' => 'Price must have up to 2 decimal places.',
        'discounted_price.numeric' => 'Discounted price must be a number.',
        'discounted_price.min' => 'Discounted price cannot be negative.',
        'discounted_price.regex' => 'Discounted price must have up to 2 decimal places.',
        'quantity.required' => 'Quantity is required.',
        'quantity.integer' => 'Quantity must be an integer.',
        'quantity.min' => 'Quantity cannot be negative.',
        'category_id.required' => 'Please select a category.',
        'category_id.exists' => 'Selected category is invalid.',
        'images.required' => 'At least one image is required.',
        'images.max' => 'You can upload up to 5 images.',
        'images.*.image' => 'Each file must be an image.',
        'images.*.mimes' => 'Images must be JPEG, PNG, JPG, or GIF.',
        'images.*.max' => 'Each image must not exceed 2MB.',
        'selectedProductAttributes.array' => 'Product attributes must be valid.',
        'selectedProductAttributes.*.exists' => 'Selected product attributes are invalid.',
        'selectedProductAttributeOptions.array' => 'Product attribute options must be valid.',
        'selectedProductAttributeOptions.*.exists' => 'Selected product attribute options are invalid.',
    ];

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->name = '';
        $this->description = '';
        $this->images = [];
        $this->price = '';
        $this->discounted_price = null;
        $this->quantity = '';
        $this->category_id = '';
        $this->productId = null;

        $this->selectedProductAttributes = [];
        $this->selectedProductAttributeOptions = [];
        $this->productAttrOptions = [];
        $this->errorMessages = [];

        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
        $this->resetValidation();
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function updated($propertyName)
    {
        if (property_exists($this, $propertyName) && is_string($this->$propertyName)) {
            $this->$propertyName = trim($this->$propertyName);
        }
    }

    public function render()
    {
        try {
            $productDetails = Product::with([
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id'])->limit(4);
                },
                'category',
                'attributeOptions',
                'attributeOptions.productAttribute:id,attribute_name'
            ])
            ->where('name', 'like', '%' . $this->searchTerm . '%')
            ->orWhere('price', 'like', '%' . $this->searchTerm . '%')
            ->orWhereHas('category', function ($query) {
                $query->where('name', 'like', '%' . $this->searchTerm . '%');
            })
            ->orWhereHas('attributeOptions.productAttribute', function ($query) {
                $query->where('attribute_name', 'like', '%' . $this->searchTerm . '%');
            })
            ->orWhereHas('attributeOptions', function ($query) {
                $query->where('option', 'like', '%' . $this->searchTerm . '%');
            })
            ->latest()
            ->paginate($this->perPage);
    
            $categoryDetails = Category::all();
            $productAttributeDetails = ProductAttribute::all();
            $productAttributeOptionDetails = ProductAttributeOption::all();        
    
            return view('livewire.admin.products', compact('productDetails', 'categoryDetails', 'productAttributeDetails', 'productAttributeOptionDetails'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching products. Error : ' . $e->getMessage());
        }
    }

    public function showCreateModal()
    {
        $this->resetErrorBag();
        $this->resetFields();
        $this->dispatch('showProductModal');
        $this->modalFormVisible = true;
        $this->resetValidation();
    }

    public function store()
    {
        $this->validate();

        try {
            if (!empty($this->selectedProductAttributes)) {
                $this->validateProductAttributeOptions();               
                if (!empty($this->errorMessages)) {
                    return;
                }
            }

            $product = Product::create([
                'name' => $this->name,
                'description' => $this->description,
                'price' => $this->price,
                'discounted_price' => ($this->discounted_price) ? $this->discounted_price : null,
                'quantity' => $this->quantity,
                'category_id' => $this->category_id
            ]);
    
            if (!$product) {
                session()->flash('message', 'Product creation failed.');
                $this->dispatch('showAlert', session('message'));
            }
    
            if (!empty($this->images)) {
                foreach ($this->images as $image) {
                    $path = $image->store('product_images', 'public');
    
                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $product->id
                    ]);
                }
            }

            /* if (!empty($this->selectedProductAttributes) && !empty($this->selectedProductAttributeOptions)) {
                foreach ($this->selectedProductAttributeOptions as $selectedProductAttrOptionId) {
                    ProductAttributeOption::create([
                        'product_id' => $product->id,
                        'product_attribute_option_id' => $selectedProductAttrOptionId,
                    ]);
                }
            } */

            $product->attributeOptions()->syncWithPivotValues($this->selectedProductAttributeOptions, [
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ]);

            /* foreach ($this->attribute_options as $option_id) {
                AttributeOption::create([
                    'product_id' => $product->id,
                    'product_attribute_option_id' => $option_id
                ]);
            } */

            $this->handleSuccess('Product created successfully.');
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while creating product. Error : ' . $e->getMessage());
        }
    }

    public function showEditModal($id)
    {
        $product = Product::with([
            'images' => function ($query) {
                $query->select(['id', 'image_path', 'product_id']);
            },
            'attributeOptions'
        ])->findorFail($id);

        if (!$product) {
            $this->resetFields();
            session()->flash('message', 'Requrested product not available for update.');
            $this->dispatch('showAlert', session('message'));
        }

        $selectedProductAttributesForUpdate = [];
        $selectedProductAttributeOptionsForUpdate = [];
        if (!empty($product->attributeOptions)) {
            foreach ($product->attributeOptions as $attributeOptions) {
                $selectedProductAttributesForUpdate[] = $attributeOptions->product_attribute_id;
                $selectedProductAttributeOptionsForUpdate[] = $attributeOptions->id;
            }
        }

        $this->resetErrorBag();
        $this->name = $product->name;
        $this->description = $product->description;
        $this->existingImages = $product->images;
        $this->price = $product->price;
        $this->discounted_price = $product->discounted_price ?? '';
        $this->quantity = $product->quantity;
        $this->category_id = $product->category_id;
        $this->productId = $product->id;
        $this->selectedProductAttributes = (!empty($selectedProductAttributesForUpdate)) ? $selectedProductAttributesForUpdate : [];
        $this->selectedProductAttributeOptions = (!empty($selectedProductAttributeOptionsForUpdate)) ? $selectedProductAttributeOptionsForUpdate : [];

        $this->dispatch('showProductModal');
        $this->modalFormVisible = true;
    }

    public function update()
    {
        $this->validate();

        try {
            $productData = Product::find($this->productId);

            if (!$productData) {
                $this->resetFields();
                session()->flash('message', 'Requrested product not available for update.');
                $this->dispatch('showAlert', session('message'));
            }

            if (!empty($this->selectedProductAttributes)) {
                $this->validateProductAttributeOptions();               
                if (!empty($this->errorMessages)) {
                    return;
                }
            }

            $updateProductData = $productData->update([
                'name' => $this->name,
                'description' => $this->description,
                'price' => $this->price,
                'discounted_price' => ($this->discounted_price) ? $this->discounted_price : null,
                'quantity' => $this->quantity,
                'category_id' => $this->category_id
            ]);

            if (!$updateProductData) {
                $this->resetFields();
                session()->flash('message', 'Product is not available after update.');
                $this->dispatch('showAlert', session('message'));
            }

            if (!empty($this->images)) {
                foreach ($productData->images as $image) {
                    Storage::disk('public')->delete($image->image_path);
                    $image->delete();
                }

                foreach ($this->images as $image) {
                    $path = $image->store('product_images', 'public');

                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $productData->id
                    ]);
                }
            }

            $productData->attributeOptions()->syncWithPivotValues($this->selectedProductAttributeOptions, [
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ]);

            $this->handleSuccess('Product updated successfully.');
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while updating product. Error : ' . $e->getMessage());
        }
    }

    public function confirmDelete($id)
    {
        $this->productId = $id;
        $this->deleteConfirmation = true;
    }

    public function delete()
    {
        try {
            $productData = Product::find($this->productId);
    
            if (!$productData) {
                $this->resetFields();
                session()->flash('message', 'Requested product not available for delete');
            }
    
            foreach ($productData->images as $image) {
                Storage::disk('public')->delete($image->image_path);
                $image->delete();
            }

            $productData->attributeOptions()->detach();
            $productData->delete();

            $this->handleSuccess('Product deleted successfully.');
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while deleting product. Error : ' . $e->getMessage());
        }
    }

    public function closeModal()
    {
        $this->dispatch('hideProductModal');
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
        $this->resetValidation();
    }

    private function handleSuccess($message)
    {
        $this->resetFields();
        $this->resetPage();
        session()->flash('message', $message);
        $this->dispatch('showAlert', $message);
    }

    private function getPrdouctAttributeOptions($productAttribute)
    {
        return ProductAttributeOption::select(['id', 'option'])->where('product_attribute_id', $productAttribute)->get();
    }

    private function getPrdouctAttributeName($productAttribute)
    {
        return ProductAttribute::where('id', $productAttribute)->pluck('attribute_name')->first();
    }

    protected function getAllPrdouctAttributeOptions()
    {
        return ProductAttributeOption::with('productAttribute:id,attribute_name')->get();
    }

    protected function validateProductAttributeOptions()
    {
        try {
            $allowedProductAttrOption = [];
            $attributeOptionsMap = [];
            $allowedOptionsByAttribute = [];
            $allProductAttributeOptions = [];
            $allProductAttributeOptionsByAttribute = [];
            $this->errorMessages = [];

            $productAttributeOptions = $this->getAllPrdouctAttributeOptions();

            if ($productAttributeOptions->isNotEmpty()) {
                foreach ($productAttributeOptions as $productAttributeOption) {
                    $attributeName = $productAttributeOption->productAttribute->attribute_name;
                    $optionId = $productAttributeOption->id;

                    if (!isset($allProductAttributeOptions[$attributeName])) {
                        $allProductAttributeOptions[$attributeName] = [];
                    }
                    $allProductAttributeOptions[$attributeName][] = $optionId;

                    if (!isset($allProductAttributeOptionsByAttribute[$attributeName])) {
                        $allProductAttributeOptionsByAttribute[$attributeName] = [];
                    }
                    $allProductAttributeOptionsByAttribute[$attributeName][$optionId] = $productAttributeOption->option;
                }
            }

            foreach ($this->selectedProductAttributes as $selectedProductAttribute) {
                $allowedAttributeOptions = $this->getPrdouctAttributeOptions($selectedProductAttribute);
                $attributeName = $this->getPrdouctAttributeName($selectedProductAttribute);

                if ($allowedAttributeOptions->isNotEmpty()) {
                    if (!isset($allowedProductAttrOption[$attributeName])) {
                        $allowedProductAttrOption[$attributeName] = [];
                    }

                    foreach ($allowedAttributeOptions as $allowedOption) {
                        $allowedProductAttrOption[$attributeName][] = [
                            'id' => $allowedOption->id,
                            'option' => $allowedOption->option,
                        ];
                        $attributeOptionsMap[$allowedOption->id] = $attributeName;
                        $allowedOptionsByAttribute[$attributeName][$allowedOption->id] = $allowedOption->option;
                    }
                }
            }

            $selectedOptionsGroupedByAttribute = [];
            $wrongAttributeOptions = [];
            $wrongAttributeOptionsSelection = [];
            $missingAttributeOptions = [];

            if (!empty($this->selectedProductAttributeOptions)) {
                foreach ($this->selectedProductAttributeOptions as $optionId) {
                    if (isset($attributeOptionsMap[$optionId])) {
                        $attributeName = $attributeOptionsMap[$optionId];

                        if (!isset($selectedOptionsGroupedByAttribute[$attributeName])) {
                            $selectedOptionsGroupedByAttribute[$attributeName] = [];
                        }
                        $selectedOptionsGroupedByAttribute[$attributeName][] = $optionId;
                    } else {
                        $wrongAttributeOptions[] = $optionId;
                    }
                }
            }

            if (!empty($allowedProductAttrOption)) {
                foreach ($allowedProductAttrOption as $attributeName => $options) {
                    if (!isset($selectedOptionsGroupedByAttribute[$attributeName])) {
                        $missingAttributeOptions[$attributeName] = array_column($options, 'option');
                    }
                }
            }

            if (!empty($allProductAttributeOptions) && !empty($wrongAttributeOptions)) {
                foreach ($allProductAttributeOptions as $attributeName => $options) {
                    foreach ($options as $option) {
                        if (in_array($option, $wrongAttributeOptions)) {
                            if (!isset($wrongAttributeOptionsSelection[$attributeName])) {
                                $wrongAttributeOptionsSelection[$attributeName] = [];
                            }
                            $wrongAttributeOptionsSelection[$attributeName][] = $option;
                        }
                    }
                }
            }

            if (!empty($missingAttributeOptions)) {
                foreach ($missingAttributeOptions as $attributeName => $missingOptions) {
                    $this->errorMessages[] = sprintf(
                        'You have selected product attribute "%s", Please select available attribute options [%s]',
                        $attributeName,
                        implode(', ', $missingOptions)
                    );
                }
            }

            if (!empty($wrongAttributeOptionsSelection)) {
                foreach ($wrongAttributeOptionsSelection as $attributeName => $optionIds) {
                    $optionNames = array_map(function ($id) use ($allProductAttributeOptionsByAttribute, $attributeName) {
                        return isset($allProductAttributeOptionsByAttribute[$attributeName][$id])
                            ? $allProductAttributeOptionsByAttribute[$attributeName][$id]
                            : 'Unknown';
                    }, $optionIds);
        
                    $this->errorMessages[] = sprintf(
                        'You have selected wrong attribute options [%s] that belong to attribute "%s".',
                        implode(', ', $optionNames),
                        $attributeName
                    );
                }
            }
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while validating product attribute options. Error : ' . $e->getMessage());
        }
    }
}
