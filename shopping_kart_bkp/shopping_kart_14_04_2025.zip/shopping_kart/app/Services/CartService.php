<?php

namespace App\Services;

use App\Models\Cart;
use App\Models\Product;

class CartService
{
    public function handleStockError(Product $product, $selectedAttributeOptions = [], ?Cart $cartItem = null)
    {
        $availableQuantity = $product ? $product->quantity : 0;

        if ($cartItem) {
            $availableQuantity -= $cartItem->quantity;
        }

        $message = 'Not enough stock available for selected product ' . ($product->name ?? '');

        if ($availableQuantity > 0) {
            $message .= ', you can add only ' . max($availableQuantity, 0) . ' more.';
        }

        return response()->json([
            'status' => false,
            'custom_error' => true,
            'message' => $message
        ], 409);
    }
}
