<?php

namespace App\Livewire;

use App\Models\Cart;
use App\Models\Product;
use App\Services\CartService;
use Livewire\Component;
use Livewire\WithPagination;

class CartDetails extends Component
{
    use WithPagination;

    public $cartId;
    public $cart_quantity = [];

    public $specificCartItemRemoveConfirmation = false;
    public $removeAllCartItemfirmation = false;

    public $searchTerm  = '';

    public function __construct(public CartService $cartService) {

    }

    public function mount()
    {
        $this->resetFields();

        $user = loggedinUserDetail();
        if ($user && !empty($user)) {
            $this->cart_quantity = Cart::where('user_id', $user->id)
                ->pluck('quantity', 'id')
                ->toArray();
        }
    }

    public function resetFields()
    {
        $this->cartId = '';
        $this->specificCartItemRemoveConfirmation = false;
        $this->removeAllCartItemfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function render()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try{
                $cartItems = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->where(function ($query) {
                    $query->whereHas('product', function ($q) {
                        $q->where('name', 'like', '%' . $this->searchTerm . '%');
                    })
                    ->orWhereHas('product.attributeOptions', function ($q) {
                        $q->where('option', 'like', '%' . $this->searchTerm . '%');
                    })
                    ->orWhereHas('product.attributeOptions.productAttribute', function ($q) {
                        $q->where('name', 'like', '%' . $this->searchTerm . '%');
                    });
                })
                ->latest()->paginate(5);

                return view('livewire.cart-details', compact('cartItems'));
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while fetching your cart. Error : ' . $e->getMessage());
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while fetching the cart'
            ], 401);
        }
    }

    public function confirmDelete($id)
    {
        $this->cartId = $id;
        $this->specificCartItemRemoveConfirmation = true;
    }

    public function confirmRemoveAllCartItem()
    {
        $this->removeAllCartItemfirmation = true;
    }

    public function updateCartQuantity($id)
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $carItem = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)->find($id);

                if (!$carItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart item is not available for update');
                    $this->dispatch('showAlert', session('message'));
                    return;
                }

                $cartQuantity = $this->cart_quantity[$id] ?? null;

                if (!empty($carItem->product_attribute_option_id)) {
                    $selectedAttributeOptions = json_decode($carItem->product_attribute_option_id, true);

                    $product = Product::with(['attributeOptions'])
                            ->whereHas('attributeOptions', function ($query) use ($selectedAttributeOptions) {
                                $query->whereIn('product_attribute_options.id', array_values($selectedAttributeOptions));
                            })
                            ->whereIn('products.id', [$carItem->product_id])
                            ->first();
                } else {
                    $product = Product::find($carItem->product_id);
                }

                if (!$product) {
                    session()->flash('message', 'Something went wrong! Requested product is not available while updaing cart quantity');
                    $this->dispatch('showAlert', session('message'));
                    return;
                }

                if (!is_null($carItem->product_attribute_option_id)) {
                    if ($cartQuantity > $product->quantity) {
                        return $this->cartService->handleStockError($product);
                    }
                } else {
                    if ($cartQuantity > $carItem->product->quantity) {
                        return $this->cartService->handleStockError($product);
                    }
                }

                $this->resetFields();
                session()->flash('message', 'Cart item quantity updated successfully.');
                $this->dispatch('showAlert', session('message'));
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while removing specific cart item. Error : ' . $e->getMessage());
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while fetching the cart'
            ], 401);
        }
    }

    public function removeSpecificCartItem()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $carItem = Cart::where('user_id', $user->id)->find($this->cartId)->delete();

                if (!$carItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart item is not available');
                    $this->dispatch('showAlert', session('message'));
                }

                $this->resetFields();
                session()->flash('message', 'Cart item removed successfully.');
                $this->dispatch('showAlert', session('message'));
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while removing specific cart item. Error : ' . $e->getMessage());
            }
        } else {
            return response()->json([
                'status' => false,
                'custom_error' => false,
                'message' => 'User not logged in, Something went wrong while fetching the cart'
            ], 401);
        }
    }
}
