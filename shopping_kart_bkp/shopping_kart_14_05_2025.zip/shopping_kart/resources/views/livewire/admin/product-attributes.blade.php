@section('title', 'Product Attributes')
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Product Attributes</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="card-body p-4">
                        <button class="btn btn-primary mb-3" id="add_new_product_attr_btn" wire:click="showCreateModal">Add New Product Attribute</button>
                        <input type="text" class="form-control" wire:model.live.debounce.300ms="searchTerm" placeholder="Search product attributes...">
                        <h5 class="card-title">Product Attributes</h5>
                        <hr />

                        @if (session()->has('message'))
                            <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        @if (session()->has('error_message'))
                            <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                {{ session('error_message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        <div class="table-responsive">
                            <table id="product_attribute_table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>Attribute Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if ($productAttributeDetails->isNotEmpty())
                                        @php $srNo = 1; @endphp
                                        @foreach ($productAttributeDetails as $productAttribute)
                                            <tr>
                                                <td>{{ $srNo }}</td>
                                                <td>{{ $productAttribute->attribute_name }}</td>
                                                <td>
                                                    <button class="btn btn-warning btn-sm" wire:click="showEditModal({{ $productAttribute->id }})">Edit</button>
                                                    <button class="btn btn-danger btn-sm" wire:click="confirmDelete({{ $productAttribute->id }})">Delete</button>
                                                </td>
                                            </tr>
                                            @php $srNo++; @endphp
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="3" class="text-center">No product attribute details or no product attributes created</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                        
                        @if ($modalFormVisible)
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">{{ $productAttributeId ? 'Edit' : 'Create' }} Product Attribute</h5>
                                            <button type="button" class="close" wire:click="$set('modalFormVisible', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                        <form id="product_attribute_form"
                                                x-data="{   attribute_name: @entangle('attribute_name'),
                                                            errors: { attribute_name: '' }
                                                        }"
                                                x-on:submit.prevent="if (validateProductAttributeForm($el, $data, $wire, {{ $productAttributeId ? "'update'" : "'store'" }})) { $wire.call({{ $productAttributeId ? "'update'" : "'store'" }}); }">
                                                <div class="form-group">
                                                    <label for="inputProductAttributeName" class="form-label">Product Attribute Name</label>
                                                    <input type="text"
                                                        class="form-control @error('attribute_name') is-invalid @enderror"
                                                        id="inputProductAttributeName"
                                                        placeholder="Enter product attribute"
                                                        wire:model="attribute_name"
                                                        x-model="attribute_name">
                                                    @error('attribute_name') <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span> @enderror
                                                    <span x-show="errors.attribute_name" class="text-danger mt-1" x-text="errors.attribute_name"></span>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" wire:click="$set('modalFormVisible', false)">Close</button>
                                                    <button type="submit" class="btn btn-primary">{{ $productAttributeId ? 'Update' : 'Create' }}</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if ($deleteConfirmation)
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Delete Product Attribute</h5>
                                            <button type="button" class="close" wire:click="$set('deleteConfirmation', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete this product attribute ?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" wire:click="$set('deleteConfirmation', false)">Cancel</button>
                                            <button class="btn btn-danger" wire:click="delete">Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        <div wire:ignore.self class="d-flex justify-content-end mt-3 me-3">
                            {{ $productAttributeDetails->links('livewire::bootstrap-5') }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->

        @push('scripts')
            <script>
                function showAlert(message) {
                    setTimeout(hideAlert, 5000);
                }

                function hideAlert() {
                    let alertBox = document.getElementById('sessionAlert');
                    if (alertBox) {
                        alertBox.style.display = 'none';
                    }
                }

                Livewire.on('showAlert', (message) => {
                    showAlert(message);
                });

                document.addEventListener("DOMContentLoaded", function () {
                    if (typeof Livewire !== "undefined") {
                        document.addEventListener("keydown", function (event) {
                            if (event.key === "Escape") {
                                Livewire.first().call('closeModal');
                            }
                        });
                    } else {
                        console.error("Livewire is not loaded. Ensure livewireScripts is included in your layout.");
                    }
                });

                function validateProductAttributeForm(element, data, wire, action) {
                    data.errors = { attribute_name: '' };
                    let isValid = true;

                    if (!data.attribute_name.trim()) {
                        data.errors.attribute_name = 'Please enter product attribute.';
                        isValid = false;
                    } else if (data.attribute_name.length > 255) {
                        data.errors.attribute_name = 'Product attribute must not exceed 255 characters.';
                        isValid = false;
                    } else if (!/^[a-zA-Z0-9\s\-_']+$/.test(data.attribute_name)) {
                        data.errors.attribute_name = 'Product attribute must be a valid string (letters, numbers, spaces, hyphens, underscores or single quote only).';
                        isValid = false;
                    }

                    return isValid;
                }
            </script>
        @endpush
