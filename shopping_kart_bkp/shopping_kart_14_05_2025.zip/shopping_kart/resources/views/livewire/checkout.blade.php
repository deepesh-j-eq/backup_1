@section('title', 'Checkout')
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i class="bx bx-home-alt"></i></a></li>
                                <li class="breadcrumb-item"><a href="{{ route('view.cart') }}">Cart</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="d-flex align-items-center justify-content-center my-3 my-lg-0">
                        <div class="row">
                            <div id="general-error"></div>
                        </div>
                    </div>
                    <div class="container-fluid my-4">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h4 class="card-title">Checkout</h4>
                                    <hr />

                                    @if (session()->has('message'))
                                        <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                            {{ session('message') }}
                                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                        </div>
                                    @endif

                                    @if (session()->has('error_message'))
                                        <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                            {{ session('error_message') }}
                                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                        </div>
                                    @endif

                                    <form wire:submit.prevent="placeOrder">
                                        <!-- Contact Info -->
                                        <div class="mb-4">
                                            <h5>Contact Info</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="contactInfo.email">Email Address</label>
                                                        <input type="email" class="form-control @error('contactInfo.email') is-invalid @enderror" wire:model="contactInfo.email">
                                                        @error('contactInfo.email')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="contactInfo.phone">Phone Number</label>
                                                        <input type="text" class="form-control @error('contactInfo.phone') is-invalid @enderror" wire:model="contactInfo.phone">
                                                        @error('contactInfo.phone')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Shipping Address -->
                                        <div class="mb-4">
                                            <h5>Shipping Address</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.first_name">First Name</label>
                                                        <input type="text" class="form-control @error('shippingAddress.first_name') is-invalid @enderror" wire:model="shippingAddress.first_name">
                                                        @error('shippingAddress.first_name')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.last_name">Last Name</label>
                                                        <input type="text" class="form-control @error('shippingAddress.last_name') is-invalid @enderror" wire:model="shippingAddress.last_name">
                                                        @error('shippingAddress.last_name')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.address_1">Address Line 1</label>
                                                        <input type="text" class="form-control @error('shippingAddress.address_1') is-invalid @enderror" wire:model="shippingAddress.address_1">
                                                        @error('shippingAddress.address_1')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.address_2">Address Line 2</label>
                                                        <input type="text" class="form-control @error('shippingAddress.address_2') is-invalid @enderror" wire:model="shippingAddress.address_2">
                                                        @error('shippingAddress.address_2')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.city">City</label>
                                                        <input type="text" class="form-control @error('shippingAddress.city') is-invalid @enderror" wire:model="shippingAddress.city">
                                                        @error('shippingAddress.city')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.country">Country</label>
                                                        <input type="text" class="form-control @error('shippingAddress.country') is-invalid @enderror" wire:model="shippingAddress.country">
                                                        @error('shippingAddress.country')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="shippingAddress.postal_code">Postal Code</label>
                                                        <input type="text" class="form-control @error('shippingAddress.postal_code') is-invalid @enderror" wire:model="shippingAddress.postal_code">
                                                        @error('shippingAddress.postal_code')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Shipping Method -->
                                        <div class="mb-4">
                                            <h5>Shipping Method</h5>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="shippingMethod" id="standardShipping" value="standard" wire:model.live="shippingMethod">
                                                <label class="form-check-label" for="standardShipping">
                                                    Standard - 4 days delivery for $10
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="shippingMethod" id="expressShipping" value="express" wire:model.live="shippingMethod">
                                                <label class="form-check-label" for="expressShipping">
                                                    Express - 2 days delivery for $20
                                                </label>
                                            </div>
                                        </div>

                                        <!-- Payment Info -->
                                        <div class="mb-4">
                                            <h5>Payment</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.card_number">Card Number</label>
                                                        <input type="text" class="form-control @error('paymentInfo.card_number') is-invalid @enderror" wire:model="paymentInfo.card_number" maxlength="16">
                                                        @error('paymentInfo.card_number')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.expiry_date">Expiry Date (MM/YY)</label>
                                                        <input type="text" class="form-control @error('paymentInfo.expiry_date') is-invalid @enderror" wire:model="paymentInfo.expiry_date" placeholder="MM/YY">
                                                        @error('paymentInfo.expiry_date')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="paymentInfo.cvc">CVC</label>
                                                        <input type="text" class="form-control @error('paymentInfo.cvc') is-invalid @enderror" wire:model="paymentInfo.cvc" maxlength="3">
                                                        @error('paymentInfo.cvc')
                                                            <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                                        @enderror
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-primary">Confirm Order</button>
                                    </form>
                                </div>
                            </div>

                            <!-- Order Summary -->
                            <div class="col-md-4">
                                <div class="card-body">
                                    <h5>Order Summary</h5>
                                    @if ($cartItems->isNotEmpty())
                                        @foreach ($cartItems as $item)
                                            <div class="d-flex align-items-center mb-3">
                                                <img src="{{ asset('storage/' . $item->product->images->first()->image_path) }}" alt="{{ $item->product->name }}" style="width: 50px; height: 50px; object-fit: contain;">
                                                <div class="ms-3">
                                                    <p class="mb-0">{{ $item->product->name }}</p>
                                                    <small>Quantity: {{ $item->quantity }}</small>
                                                </div>
                                                <div class="ms-auto">
                                                    <p class="mb-0">${{ number_format($item->sub_total, 2) }}</p>
                                                </div>
                                            </div>
                                        @endforeach
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <p>Subtotal</p>
                                            <p>${{ number_format($subTotal, 2) }}</p>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <p>Shipping Estimate</p>
                                            <p>${{ number_format($shippingCost, 2) }}</p>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <p>Tax Estimate</p>
                                            <p>${{ number_format($tax, 2) }}</p>
                                        </div>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <h6>Order Total</h6>
                                            <h6>${{ number_format($cartTotal, 2) }}</h6>
                                        </div>
                                    @else
                                        <p>Your cart is empty.</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->

@push('clientSideValidationScript')
    <script>
        $(document).ready(function() {
            // Card number validation
            $('input[wire\\:model="paymentInfo.card_number"]').on('input', function() {
                let sanitized = $(this).val().replace(/[^0-9]/g, '');
                if (sanitized.length > 16) {
                    sanitized = sanitized.substring(0, 16);
                }
                $(this).val(sanitized);
            });

            // Expiry date validation
            $('input[wire\\:model="paymentInfo.expiry_date"]').on('input', function() {
                let sanitized = $(this).val().replace(/[^0-9\/]/g, '');
                if (sanitized.length === 2 && !sanitized.includes('/')) {
                    sanitized += '/';
                }
                if (sanitized.length > 5) {
                    sanitized = sanitized.substring(0, 5);
                }
                $(this).val(sanitized);
            });

            // CVC validation
            $('input[wire\\:model="paymentInfo.cvc"]').on('input', function() {
                let sanitized = $(this).val().replace(/[^0-9]/g, '');
                if (sanitized.length > 3) {
                    sanitized = sanitized.substring(0, 3);
                }
                $(this).val(sanitized);
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json'
                }
            });
        });
    </script>
@endpush

@push('scripts')
    <script>
        function showAlert(message) {
            setTimeout(hideAlert, 5000);
        }

        function hideAlert() {
            let alertBox = document.getElementById('sessionAlert');
            if (alertBox) {
                alertBox.style.display = 'none';
            }
        }

        Livewire.on('showAlert', (message) => {
            showAlert(message);
        });
    </script>
@endpush
