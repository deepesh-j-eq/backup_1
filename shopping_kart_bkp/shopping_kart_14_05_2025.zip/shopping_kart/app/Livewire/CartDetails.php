<?php

namespace App\Livewire;

use App\Models\Cart;
use App\Services\CartService;
use Livewire\Component;
use Livewire\WithPagination;

class CartDetails extends Component
{
    use WithPagination;

    public $cartId;
    public float $cartTotal = 0;
    public $cart_quantity = [];

    public $specificCartItemRemoveConfirmation = false;
    public $removeAllCartItemfirmation = false;

    public $searchTerm  = '';

    protected $cartService;

    protected $listeners = [
        'cart-icon-quantity-update' => 'updateCartIconQuantity',
    ];

    public function mount()
    {
        $this->resetFields();

        $user = loggedinUserDetail();
        if ($user && !empty($user)) {
            $this->cart_quantity = Cart::where('user_id', $user->id)
                ->pluck('quantity', 'id')
                ->toArray();
        }

        $this->cartService = new CartService;
    }

    public function resetFields()
    {
        $this->searchTerm = '';
        $this->cartId = '';
        $this->specificCartItemRemoveConfirmation = false;
        $this->removeAllCartItemfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function render()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try{
                $cartItems = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->where(function ($query) {
                    $query->whereHas('product', function ($q) {
                        $q->where('name', 'like', '%' . $this->searchTerm . '%');
                    })
                    ->orWhereHas('product.attributeOptions', function ($q) {
                        $q->where('option', 'like', '%' . $this->searchTerm . '%');
                    })
                    ->orWhereHas('product.attributeOptions.productAttribute', function ($q) {
                        $q->where('attribute_name', 'like', '%' . $this->searchTerm . '%');
                    });
                })
                ->latest()->paginate(5);

                if (is_null($this->cartService)) {
                    $this->cartService = new CartService;
                }

                $this->cartTotal = 0;
                foreach ($cartItems as $item) {
                    $item->sub_total = $this->cartService->calculateSubTotal($item);
                    $this->cartTotal += $item->sub_total;
                }

                return view('livewire.cart-details', compact('cartItems'));
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while fetching your cart. Error : ' . $e->getMessage());
                $this->dispatch('scrollToMessage');
            }
        } else {
            session()->flash('error_message', 'User not logged in, Something went wrong while fetching the cart');
            $this->dispatch('scrollToMessage');
        }
    }

    public function updatedCartQuantity($value, $key)
    {
        $value = intval($value);
        $value = max(1, min($value, 214748360));

        $this->cart_quantity[$key] = $value;

        $user = loggedinUserDetail();

        if ($user) {
            try {
                $cartItem = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->find($key);

                if (!$cartItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart item is not available for update');
                    $this->dispatch('showAlert', session('message'));
                    $this->dispatch('scrollToMessage');
                    return;
                }

                $checkProductStockResponse = [];

                if (!is_null($cartItem->product_attribute_option_id)) {
                    $selectedAttributeOptions = json_decode($cartItem->product_attribute_option_id, true);
                    $checkProductStockResponse = $this->checkProductStock($cartItem, $value, $selectedAttributeOptions);
                } else {
                    $checkProductStockResponse = $this->checkProductStock($cartItem, $value);
                }

                if (!empty($checkProductStockResponse)) {
                    $message = isset($checkProductStockResponse['message']) 
                        ? $checkProductStockResponse['message'] 
                        : 'Something went wrong while updating cart quantity.';

                    $this->cart_quantity[$key] = $cartItem->quantity;
                    session()->flash('error_message', $message);
                    $this->dispatch('scrollToMessage');
                    return;
                }

                $cartItem->update(['quantity' => $value]);
                $this->cart_quantity[$key] = $value;

                $this->recalculateCartTotal();

                $this->resetFields();
                session()->flash('message', 'Cart quantity updated.');
                $this->dispatch('showAlert', session('message'));
                $this->dispatch('scrollToMessage');

                $this->dispatch('cart-icon-quantity-update');
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while updating specific cart item using text box. Error : ' . $e->getMessage());
                $this->dispatch('scrollToMessage');
            }
        } else {
            session()->flash('error_message', 'User not logged in, Something went wrong while fetching the cart');
            $this->dispatch('scrollToMessage');
        }
    }

    public function updateCartQuantity($cartId, $action)
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $cartItem = Cart::with([
                    'product.attributeOptions',
                    'product.attributeOptions.productAttribute'
                ])
                ->where('user_id', $user->id)
                ->find($cartId);

                if (!$cartItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart item is not available for update');
                    $this->dispatch('showAlert', session('message'));
                    $this->dispatch('scrollToMessage');
                    return;
                }

                $currentQuantity = $this->cart_quantity[$cartId] ?? 1;
                $newQuantity = $action == 'increment' ? $currentQuantity + 1 : max(1, $currentQuantity - 1);

                if ($cartItem->quantity == 1 && $newQuantity == 1 && $action == 'decrement') {
                    return;
                }

                $stockValidationResponse = [];

                if (!is_null($cartItem->product_attribute_option_id)) {
                    $selectedAttributeOptions = json_decode($cartItem->product_attribute_option_id, true);
                    $stockValidationResponse = $this->validateCartQuantityChange($cartItem, $newQuantity, $action, $selectedAttributeOptions);
                } else {
                    $stockValidationResponse = $this->validateCartQuantityChange($cartItem, $newQuantity, $action);
                }

                if (!empty($stockValidationResponse)) {
                    $message = isset($stockValidationResponse['message']) 
                        ? $stockValidationResponse['message'] 
                        : 'Something went wrong while updating cart quantity.';

                    $this->cart_quantity[$cartId] = $currentQuantity;
                    session()->flash('error_message', $message);
                    $this->dispatch('scrollToMessage');
                    return;
                }

                $cartItem->update(['quantity' => $newQuantity]);
                $this->cart_quantity[$cartId] = $newQuantity;

                $this->recalculateCartTotal();

                $this->resetFields();
                session()->flash('message', 'Cart item quantity updated successfully.');
                $this->dispatch('showAlert', session('message'));
                $this->dispatch('scrollToMessage');

                $this->dispatch('cart-icon-quantity-update');
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while updating specific cart item. Error : ' . $e->getMessage());
                $this->dispatch('scrollToMessage');
            }
        } else {
            session()->flash('error_message', 'User not logged in, Something went wrong while fetching the cart');
            $this->dispatch('scrollToMessage');
        }
    }

    public function confirmDelete($id)
    {
        $this->cartId = $id;
        $this->specificCartItemRemoveConfirmation = true;
    }

    public function removeSpecificCartItem()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $cartItem = Cart::where('user_id', $user->id)->find($this->cartId);

                if (!$cartItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart item is not available for delete');
                    $this->dispatch('showAlert', session('message'));
                    $this->dispatch('scrollToMessage');
                }

                $cartItem->delete();

                $this->resetFields();
                session()->flash('message', 'Cart item removed successfully.');
                $this->dispatch('showAlert', session('message'));
                $this->dispatch('scrollToMessage');

                $this->dispatch('cart-icon-quantity-update');
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while removing specific cart item. Error : ' . $e->getMessage());
                $this->dispatch('scrollToMessage');
            }
        } else {
            session()->flash('error_message', 'User not logged in, Something went wrong while fetching the cart');
            $this->dispatch('scrollToMessage');
        }
    }

    public function confirmRemoveAllCartItem()
    {
        $this->removeAllCartItemfirmation = true;
    }

    public function removeAllCartItems()
    {
        $user = loggedinUserDetail();

        if($user && !empty($user)) {
            try {
                $cartItem = Cart::where('user_id', $user->id);

                if (!$cartItem) {
                    $this->resetFields();
                    session()->flash('message', 'Something went wrong! Requested cart details is not available for delete');
                    $this->dispatch('showAlert', session('message'));
                    $this->dispatch('scrollToMessage');
                }

                $cartItem->delete();

                $this->resetFields();
                session()->flash('message', 'Cart item removed successfully.');
                $this->dispatch('showAlert', session('message'));
                $this->dispatch('scrollToMessage');

                $this->dispatch('cart-icon-quantity-update');
            } catch (\Exception $e) {
                $this->resetFields();
                session()->flash('error_message', 'Error occured while removing specific cart item. Error : ' . $e->getMessage());
                $this->dispatch('scrollToMessage');
            }
        } else {
            session()->flash('error_message', 'User not logged in, Something went wrong while fetching the cart');
            $this->dispatch('scrollToMessage');
        }
    }

    public function recalculateCartTotal(): void
    {
        $user = loggedinUserDetail();

        try {
            if (!$user || empty($user->id)) {
                $this->cartTotal = 0;
                return;
            }

            if (is_null($this->cartService)) {
                $this->cartService = new CartService;
            }

            $cartItems = Cart::with('product')
                ->where('user_id', $user->id)
                ->get();

            $this->cartTotal = $cartItems->sum(function ($item) {
                if (!$item->product) {
                    return 0;
                }

                return $this->cartService->calculateSubTotal($item);
            });
        } catch (\Exception $e) {
            session()->flash('error_message', 'Error occured while recalculate cart item total. Error : ' . $e->getMessage());
            $this->dispatch('scrollToMessage');
        }
    }

    public function updateCartIconQuantity()
    {
        $user = loggedinUserDetail();

        try {
            if($user && !empty($user)) {
                $totalCartQuantity = Cart::where('user_id', $user->id)->sum('quantity');

                return response()->json([
                    'status' => true,
                    'total_quantity' => $totalCartQuantity
                ]);
            }

            return response()->json([
                'status' => false,
                'message' => 'User not logged in'
            ], 401);
        } catch (\Exception $e) {
            session()->flash('error_message', 'Error occured while checking cart item stock. Error : ' . $e->getMessage());
            $this->dispatch('scrollToMessage');
        }
    }

    protected function checkProductStock($cartItem, $newQuantity, $selectedAttributeOptions = [])
    {
        try {
            $user = loggedinUserDetail();
    
            $availableQuantity = $cartItem->product->quantity !== null ? $cartItem->product->quantity : 0;
    
            $action = 'nothing';
            $cartCurrentQuantity = $cartItem->quantity;
            if ($newQuantity < $cartCurrentQuantity) {
                $action = 'decrement';
            } else if ($newQuantity > $cartCurrentQuantity) {
                $action = 'increment';
            }
    
            if (!empty($selectedAttributeOptions) && $cartItem !== null && $user !== null) {
    
                $getHandleStockMessage = $this->getHandleStockMessage($cartItem, $user);
    
                if (!empty($getHandleStockMessage)) {
                    if (isset($getHandleStockMessage['current_cart_quantity'])){
                        $currentCartQuantity = $getHandleStockMessage['current_cart_quantity'];
                    }
    
                    if (isset($getHandleStockMessage['validated_cart_items_message'])){
                        $validatedCartItemsMessage = $getHandleStockMessage['validated_cart_items_message'];
                    }
                } else {
                    $currentCartQuantity = $availableQuantity;
                    $validatedCartItemsMessage = '';
                }

            } else if ($cartItem !== null) {
                $currentCartQuantity = $cartItem->quantity;
            }

            $updatedAvailableQuantity = $availableQuantity - $currentCartQuantity;

            if (!empty($selectedAttributeOptions) && $currentCartQuantity > 0) {
                if ($newQuantity > $updatedAvailableQuantity) {
                    if (isset($validatedCartItemsMessage) && $validatedCartItemsMessage !== '') {
                        return [
                            'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Available quantity is ' . $availableQuantity . '. ' .$validatedCartItemsMessage
                        ];
                    } else {
                        return [
                            'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Available quantity is ' . $availableQuantity . '. And ' . $currentCartQuantity . ' already in your cart.'
                        ];
                    }
                }
            } else {
                if ($newQuantity > $availableQuantity) {
                    return [
                        'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Maximum available## quantity is ' . $availableQuantity
                    ];
                }
            }
    
            if ($newQuantity < 1) {
                return [
                    'message' => 'Quantity must be at least 1.'
                ];
            }
    
            return [];
        } catch (\Exception $e) {
            session()->flash('error_message', 'Error occured while checking cart item stock. Error : ' . $e->getMessage());
        }
    }

    protected function validateCartQuantityChange($cartItem, $newQuantity, $action, $selectedAttributeOptions = [])
    {
        try {
            $user = loggedinUserDetail();
            $availableQuantity = $cartItem->product->quantity !== null ? $cartItem->product->quantity : 0;
    
            if (!empty($selectedAttributeOptions) && $cartItem !== null && $user !== null) {
    
                $getHandleStockMessage = $this->getHandleStockMessage($cartItem, $user);
    
                if (!empty($getHandleStockMessage)) {
                    if (isset($getHandleStockMessage['current_cart_quantity'])){
                        $currentCartQuantity = $getHandleStockMessage['current_cart_quantity'];
                    }
    
                    if (isset($getHandleStockMessage['validated_cart_items_message'])){
                        $validatedCartItemsMessage = $getHandleStockMessage['validated_cart_items_message'];
                    }
                } else {
                    $currentCartQuantity = $availableQuantity;
                    $validatedCartItemsMessage = '';
                }

            } else if ($cartItem !== null) {
                $currentCartQuantity = $cartItem->quantity;
            }
    
            if ($action === 'decrement' && $newQuantity < 1) {
                return [
                    'message' => 'Please remove correct quantity for product ' . ($cartItem->product->name ?? '') . '. ' . $currentCartQuantity . ' in your cart.'
                ];
            }
    
            if (!empty($selectedAttributeOptions) && $currentCartQuantity > 0) {
                if ($action === 'increment' && $currentCartQuantity >= $availableQuantity) {
                    if (isset($validatedCartItemsMessage) && $validatedCartItemsMessage !== '') {
                        return [
                            'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Available quantity is ' . $availableQuantity . ' ' . $validatedCartItemsMessage
                        ];
                    } else {
                        return [
                            'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Available quantity is ' . $availableQuantity . ' And ' . $currentCartQuantity . ' already in your cart.'
                        ];
                    }
                }
            } else {
                if ($action === 'increment' && $newQuantity > $availableQuantity) {
                    return [
                        'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. Maximum available quantity is ' . $availableQuantity
                    ];
                }
            }
    
            if ($newQuantity < 1) {
                return [
                    'message' => 'Quantity must be at least 1.'
                ];
            }
    
            return [];
        } catch (\Exception $e) {
            session()->flash('error_message', 'Error occured while validate cart quantity on change. Error : ' . $e->getMessage());
        }
    }

    protected function getHandleStockMessage($cartItem, $user)
    {
        try {
            $productQuantityForAttributeOptions = Cart::where([
                'product_id' => $cartItem->product_id,
                'user_id' => $user->id
            ])->sum('quantity');
    
            $cartItemsWithProdAttrOpt = Cart::with([
                'product.attributeOptions',
                'product.attributeOptions.productAttribute'
            ])
            ->where([
                'product_id' => $cartItem->product_id,
                'user_id' => $user->id
            ])->get();

            $cartItemHasAttributeOptions = [];
            $productHasAttributes = [];
            $productHasAttributeOptions = [];
            $attributeOptionsMap = [];
            $transformCartItemHasAttributeOptions = [];
    
            if ($cartItemsWithProdAttrOpt->isNotEmpty()) {
                foreach ($cartItemsWithProdAttrOpt as $itemDetails) {
                    $cartItemHasAttributeOptions[$itemDetails->id] = [
                        "cart_attribute_options" => $itemDetails->product_attribute_option_id,
                        "cart_quantity" => $itemDetails->quantity
                    ];
    
                    if ($itemDetails->product->attributeOptions) {
                        foreach ($itemDetails->product->attributeOptions as $itemAttributeOption) {
                            $productAttrName = $itemAttributeOption->productAttribute->attribute_name ?? '';
                            $optionId = $itemAttributeOption->id;
                            $optionValue = $itemAttributeOption->option;
    
                            if (!in_array($productAttrName, $productHasAttributes)) {
                                $productHasAttributes[] = $productAttrName;
                            }
    
                            $attributeOptionsMap[strtolower($productAttrName)][$optionId] = $optionValue;
                        }
                    }
                }
            }
    
            $productHasAttributeOptions = [];
            if (!empty($attributeOptionsMap)) {
                foreach ($attributeOptionsMap as $attrName => $attrOptions) {
                    $productHasAttributeOptions[] = [$attrName => $attrOptions];
                }
            }
    
            if (!empty($cartItemHasAttributeOptions)) {
                foreach ($cartItemHasAttributeOptions as $key => $item) {
                    $decodedOptions = json_decode($item['cart_attribute_options'], true);
                    $final = [];
    
                    foreach ($decodedOptions as $attributeKey => $value) {
                        $cleanKey = str_replace('_attribute_option', '', $attributeKey);
                        $final[$cleanKey] = (int) $value;
                    }
    
                    $final['cart_quantity'] = (int) $item['cart_quantity'];
                    $transformCartItemHasAttributeOptions[$key] = $final;
                }
            }
    
            $validatedCartItems = [];
            $nonValidatedCartItems = [];

            if (!empty($transformCartItemHasAttributeOptions)) {
                foreach ($transformCartItemHasAttributeOptions as $index => $attributes) {
                    $isCorrectAttributeOption = true;
                    $transformedProductAttributeOpts = [];
        
                    foreach ($attributes as $attributeKey => $optionId) {
                        if ($attributeKey === 'cart_quantity') {
                            $transformedProductAttributeOpts['cart_quantity'] = $optionId;
                            continue;
                        }
        
                        $found = false;
        
                        foreach ($productHasAttributeOptions as $attributeGroup) {
                            if (isset($attributeGroup[$attributeKey]) && isset($attributeGroup[$attributeKey][$optionId])) {
                                $transformedProductAttributeOpts[$attributeKey] = $attributeGroup[$attributeKey][$optionId];
                                $found = true;
                            }
                        }
        
                        if (!$found) {
                            $transformedProductAttributeOpts[$attributeKey] = $optionId;
                            $isCorrectAttributeOption = false;
                        }
                    }
        
                    if ($isCorrectAttributeOption) {
                        $validatedCartItems[$index] = $transformedProductAttributeOpts;
                    } else {
                        $nonValidatedCartItems[$index] = $transformedProductAttributeOpts;
                    }
                }
            }
    
            $currentCartQuantityProductAttributeWise = '';
            $validatedCartItemsMessage = '';
    
            if (!empty($validatedCartItems)) {
                $currentCartQuantityProductAttributeWise = 0;

                $ik = 1;
                foreach ($validatedCartItems as $cartIdKey => $cartQuantityDetails) {
                    if ($ik == 1) {
                        $validatedCartItemsMessage .= 'You have added ' . $cartQuantityDetails['cart_quantity'] . ' for attribute ';
                    } else {
                        $validatedCartItemsMessage .= 'and ' . $cartQuantityDetails['cart_quantity'] . ' for attribute ';
                    }
    
                    foreach ($cartQuantityDetails as $attribute_name => $attribute_option) {
                        if ($attribute_name == 'cart_quantity') {
                            continue;
                        }
    
                        $validatedCartItemsMessage .= '"' . (ucfirst(str_replace('_', ' ', $attribute_name))) . '"' . ' => ' . $attribute_option . ' ';
                    }
    
                    if (isset($cartQuantityDetails['cart_quantity'])) {
                        $currentCartQuantityProductAttributeWise = $currentCartQuantityProductAttributeWise + $cartQuantityDetails['cart_quantity'];
                    }
                    $ik++;
                }
            }
    
            if (isset($currentCartQuantityProductAttributeWise) && $currentCartQuantityProductAttributeWise !== '') {
                $currentCartQuantity = $currentCartQuantityProductAttributeWise;
            } else {
                $currentCartQuantity = $productQuantityForAttributeOptions;
            }
    
            return [
                'current_cart_quantity' => $currentCartQuantity,
                'validated_cart_items_message' => $validatedCartItemsMessage
            ];
        } catch (\Exception $e) {
            session()->flash('error_message', 'Error occured while get handle stock message. Error : ' . $e->getMessage());
        }
    }
}
