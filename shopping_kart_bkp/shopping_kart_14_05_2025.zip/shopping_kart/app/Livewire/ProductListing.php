<?php

namespace App\Livewire;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductAttribute;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use Livewire\WithPagination;

class ProductListing extends Component
{
    use WithPagination;
   
    public $priceRange, $productId, $productDetail, $categories, $productAttributes;
    public $sortBy = 'default';
    public $perPage = 2;
    public $maxPrice = 10000;
    public $searchTerm  = '';

    public $selectedCategories = [];
    public $selectedAttributes = [];
    public $hasActiveFilters = false;

    protected $paginationTheme = 'bootstrap';

    public function mount()
    {
        $this->resetFields();
        $this->categories = Category::all();
        $this->productAttributes = ProductAttribute::with('productAttributeOptions')->get();

        foreach ($this->productAttributes as $attribute) {
            $this->selectedAttributes[$attribute->id] = [];
        }

        $this->updateHasActiveFilters();
    }

    public function resetFields()
    {
        $this->sortBy = 'default';
        $this->searchTerm = '';
        $this->selectedCategories = [];
        $this->maxPrice = 10000;
        $this->selectedAttributes = [];
        $this->hasActiveFilters = false;
    }

    public function clearFilters()
    {
        $this->sortBy = 'default';
        $this->searchTerm = '';
        $this->selectedCategories = [];
        $this->maxPrice = 10000;
        $this->selectedAttributes = array_fill_keys(array_keys($this->selectedAttributes), []);
        $this->hasActiveFilters = false;
    }

    public function updateHasActiveFilters()
    {
        //dd($this->sortBy);
        //dd($this->selectedCategories);
        
        /* dd(!empty($this->selectedCategories),
        !empty(array_filter($this->selectedAttributes, fn($options) => !empty($options))),
        $this->maxPrice != 10000,
        $this->sortBy != 'default',
        !empty($this->searchTerm)
        ); */

        $abc = !empty($this->selectedCategories) ||
               !empty(array_filter($this->selectedAttributes, fn($options) => !empty($options))) ||
               $this->maxPrice != 10000 ||
               $this->sortBy != 'default' ||
               !empty($this->searchTerm);

        //dd($abc);
        //dd($this->hasActiveFilters);

        $this->hasActiveFilters = !empty($this->selectedCategories) ||
               !empty(array_filter($this->selectedAttributes, fn($options) => !empty($options))) ||
               $this->maxPrice != 10000 ||
               $this->sortBy != 'default' ||
               !empty($this->searchTerm);

        //dd($this->hasActiveFilters);
    }

    public function updatedSearchTerm($value)
    {
        $this->resetPage();
        $this->updateHasActiveFilters();
    }

    public function updatedSelectedCategories($value)
    {
        $this->resetPage();
        $this->updateHasActiveFilters();
    }

    public function updatedMaxPrice($value)
    {
        $this->resetPage();
        $this->updateHasActiveFilters();
    }

    public function updatedSelectedAttributes($value)
    {
        $this->resetPage();
        $this->updateHasActiveFilters();
    }

    public function updatedSortBy()
    {
        $this->resetPage();
        $this->updateHasActiveFilters();
    }

    /* public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
        $this->resetPage();
        $this->updateHasActiveFilters();
    } */

    public function render()
    {
        try {
            $query = Product::with([
                'images' => function ($query) {
                    $query->select(['id', 'image_path', 'product_id'])->limit(4);
                },
            ]);

            if (!empty($this->selectedCategories)) {
                $query->whereIn('category_id', $this->selectedCategories);
            }

            $query->where(function ($query) {
                $query->where('price', '<=', $this->maxPrice)
                    ->orWhere('discounted_price', '<=', $this->maxPrice);
            });

            if (!empty($this->selectedAttributes)) {
                //dd($this->selectedAttributes);
                foreach ($this->selectedAttributes as $attributeId => $optionIds) {
                    if (is_array($optionIds) && !empty($optionIds)) {
                        $query->whereHas('attributeOptions', function ($q) use ($optionIds) {
                            $q->whereIn('product_attribute_option_id', $optionIds);
                        });
                    }
                }
            }

            if (isset($this->sortBy) && $this->sortBy != 'default') {
                switch ($this->sortBy) {
                    case 'most_popular':
                        // Future implementation: Order by completed orders count
                        // $query->withCount(['orders' => function($q) {
                        //     $q->where('status', 'completed');
                        // }])->orderByDesc('orders_count');
                        $query->orderBy('created_at', 'desc');
                        break;
                    case 'best_rating':
                        // Future implementation: Order by average rating
                        // $query->withAvg('ratings', 'rating')->orderByDesc('ratings_avg_rating');
                        $query->orderBy('created_at', 'desc');
                        break;
                    case 'most_popular':
                        $query->orderBy('popularity', 'desc');
                        break;
                    case 'best_rating':
                        $query->withAvg('ratings', 'rating')->orderByDesc('ratings_avg_rating');
                        break;
                    case 'newest':
                        $query->orderBy('created_at', 'desc');
                        break;
                    case 'price_low_high':
                        $query->orderBy(DB::raw("CASE WHEN discounted_price IS NOT NULL AND discounted_price > 0 THEN discounted_price ELSE price END"), 'asc');
                        /* $query->orderByRaw("
                            CASE 
                                WHEN discounted_price IS NOT NULL AND discounted_price > 0 THEN discounted_price 
                                ELSE price 
                            END ASC
                        "); */
                        break;
                    case 'price_high_low':
                        $query->orderBy(DB::raw("CASE WHEN discounted_price IS NOT NULL AND discounted_price > 0 THEN discounted_price ELSE price END"), 'desc');
                        /* $query->orderByRaw("
                            CASE 
                                WHEN discounted_price IS NOT NULL AND discounted_price > 0 THEN discounted_price 
                                ELSE price 
                            END DESC
                        "); */
                        break;
                    default:
                        $query->orderBy('created_at', 'desc');
                }
            } else {
                $query->orderBy('created_at', 'desc');
            }

            $productDetails = $query
                ->where(function ($query) {
                    $query->where('name', 'like', '%' . $this->searchTerm . '%')
                        ->orWhere('price', 'like', '%' . $this->searchTerm . '%')
                        ->orWhereHas('category', function ($query) {
                            $query->where('name', 'like', '%' . $this->searchTerm . '%');
                        });
                })
                ->paginate($this->perPage);

            return view('livewire.product-listing', [
                'productDetails' => $productDetails,
                'categories' => $this->categories,
                'productAttributes' => $this->productAttributes
            ]);
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching product listing. Error : ' . $e->getMessage());
        }
    }
}
