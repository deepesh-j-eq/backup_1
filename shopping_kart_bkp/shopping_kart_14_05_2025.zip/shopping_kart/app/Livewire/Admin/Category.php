<?php

namespace App\Livewire\Admin;

use App\Http\Requests\CategoryRequest;
use App\Models\Category as ModelsCategory;
use Livewire\Component;
use Livewire\WithPagination;

class Category extends Component
{
    use WithPagination;

    public $name, $categoryId;
    public $modalFormVisible = false;
    public $deleteConfirmation = false;
    public $perPage = 5;
    public $searchTerm  = '';

    protected $listeners = ['closeModal'];
    protected $paginationTheme = 'bootstrap';

    public function rules()
    {
        return [
            'name' => 'required|string|min:3|max:255|unique:categories,name,' . $this->categoryId,
        ];
    }

    protected $messages = [
        'name.required' => 'Please enter category name.',
        'name.string' => 'Category name must be a valid string.',
        'name.min' => 'Category name must be at least 3 characters.',
        'name.max' => 'Category name cannot exceed 255 characters.',
        'name.unique' => 'This category name is already taken.'
    ];

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->searchTerm = '';
        $this->name = '';
        $this->categoryId = null;
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
        $this->resetValidation();
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function render()
    {
        try{
            $categoryDetails = ModelsCategory::where('name', 'like', '%' . $this->searchTerm . '%')
                ->latest()
                ->paginate($this->perPage);
    
            return view('livewire.admin.category', compact('categoryDetails'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while fetching category. Error : ' . $e->getMessage());
        }
    }

    public function showCreateModal()
    {
        $this->resetErrorBag();
        $this->resetFields();
        $this->modalFormVisible = true;
    }

    public function store()
    {
        $this->validate();

        try {
            $category = ModelsCategory::create([
                'name' => $this->name,
            ]);

            if (!$category) {
                session()->flash('message', 'Category creation failed.');
                $this->dispatch('showAlert', session('message'));
            }

            $this->handleSuccess('Category created successfully.');
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while creating category. Error : ' . $e->getMessage());
        }
    }

    public function showEditModal($id)
    {
        $category = ModelsCategory::findorFail($id);

        if (!$category) {
            $this->resetFields();
            session()->flash('message', 'Requrested category not available for update.');
            $this->dispatch('showAlert', session('message'));
        }

        $this->resetErrorBag();
        $this->name = $category->name;
        $this->categoryId = $category->id;
        
        $this->modalFormVisible = true;
    }

    public function update()
    {
        $this->validate();

        try {
            $categoryData = ModelsCategory::find($this->categoryId);

            if (!$categoryData) {
                $this->resetFields();
                session()->flash('message', 'Requrested category not available for update.');
                $this->dispatch('showAlert', session('message'));
            }

            $updateCategory = $categoryData->update([
                'name' => $this->name
            ]);

            if (!$updateCategory) {
                $this->resetFields();
                session()->flash('message', 'Category is not available after update.');
                $this->dispatch('showAlert', session('message'));
            }

            $this->handleSuccess('Category updated successfully.');
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while updating category. Error : ' . $e->getMessage());
        }
    }

    public function confirmDelete($id)
    {
        $this->categoryId = $id;
        $this->deleteConfirmation = true;
    }

    public function delete()
    {
        try {
            $category = ModelsCategory::findOrFail($this->categoryId)->delete();

            if (!$category) {
                $this->resetFields();
                session()->flash('message', 'Requested category is not available for delete');
                $this->dispatch('showAlert', session('message'));
            }

            $this->handleSuccess('Category deleted successfully.');
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while deleting category. Error : ' . $e->getMessage());
        }
    }

    public function closeModal()
    {
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
        $this->resetValidation();
    }

    private function handleSuccess($message)
    {
        $this->resetFields();
        $this->resetPage();
        session()->flash('message', $message);
        $this->dispatch('showAlert', $message);
    }
}
