<?php

namespace App\Livewire;

use App\Models\Cart;
use App\Models\ProductAttributeOption;
use Illuminate\Support\Facades\Log;
use Livewire\Component;

class MiniCart extends Component
{
    public $cartItems = [];
    public $cartItemsCount = 0;
    public $cartId;
    public $specificCartItemRemoveConfirmation = false;

    protected $listeners = [
        'cart-icon-quantity-update' => 'refreshCart',
        'keepDropdownOpen' => '$refresh',
    ];

    public function mount()
    {
        $this->refreshCart();
    }

    public function refreshCart()
    {
        $user = loggedinUserDetail();
        //Log::info('refreshCart started', ['user_id' => $user ? $user->id : null]);

        if ($user && !empty($user)) {
            try {
                $this->cartItems = Cart::with(['product.images'])
                    ->where('user_id', $user->id)
                    ->orderBy('created_at', 'desc')
                    ->take(5)
                    ->get()
                    ->map(function ($cart) {
                        $cart->cart_id = $cart->id;
                        $cart->cart_quantity = $cart->quantity;

                        $product = $cart->product;
                        $cart->name = $product->name ?? '';
                        $cart->price = $product->price ?? 0;
                        $cart->discounted_price = $product->discounted_price ?? 0;
                        $cart->category_id = $product->category_id ?? null;

                        $cart->image_paths = $product->images->pluck('image_path')->toArray();

                        $cart->attributes = [];

                        if (!is_null($cart->product_attribute_option_id) && is_string($cart->product_attribute_option_id)) {
                            try {
                                $attributeOptions = json_decode($cart->product_attribute_option_id, true);

                                if (is_array($attributeOptions)) {
                                    $cart->attributes = collect($attributeOptions)->map(function ($optionId, $attributeKey) {
                                        $option = ProductAttributeOption::with('productAttribute')
                                            ->where('id', $optionId)
                                            ->first();
    
                                        return $option ? [
                                            'attribute_name' => $option->productAttribute->attribute_name ?? $attributeKey,
                                            'attribute_option' => $option->option ?? 'Unknown',
                                        ] : null;
                                    })->filter()->values()->toArray();
                                }
                            } catch (\Exception $e) {
                                Log::error('Failed to parse product_attribute_option_id', [
                                    'cart_id' => $cart->id,
                                    'error' => $e->getMessage(),
                                ]);
                            }
                        }

                        return $cart;
                    });

                //Log::info('this->cartItems', ['this->cartItems' => $this->cartItems]);

                $this->cartItemsCount = Cart::where('user_id', $user->id)->count();
            } catch (\Exception $e) {
                Log::error('Failed to refresh cart', ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
                session()->flash('error_message', 'Error occurred while fetching mini cart items. Error: ' . $e->getMessage());
                $this->dispatch('scrollToMessage');
            }
        }
    }

    public function confirmDelete($cartId)
    {
        $this->cartId = $cartId;
        $this->specificCartItemRemoveConfirmation = true;
        $this->dispatch('showRemoveModal');
        $this->dispatch('keepDropdownOpen');
    }

    public function cancelDelete()
    {
        $this->specificCartItemRemoveConfirmation = false;
        $this->cartId = null;
        $this->dispatch('keepDropdownOpen');
    }

    public function removeSpecificCartItem()
    {
        $user = loggedinUserDetail();

        if ($user && !empty($user)) {
            try {
                $cartItem = Cart::where('user_id', $user->id)->find($this->cartId);

                if (!$cartItem) {
                    session()->flash('error_message', 'Requested cart item is not available for deletion.');
                    $this->dispatch('scrollToMessage');
                    return;
                }

                $cartItem->delete();

                $this->specificCartItemRemoveConfirmation = false;
                $this->cartId = null;
                session()->flash('message', 'Cart item removed successfully.');
                $this->dispatch('showAlert', session('message'));
                $this->dispatch('scrollToMessage');
                $this->dispatch('cart-icon-quantity-update');
                $this->dispatch('keepDropdownOpen');
                $this->refreshCart();
            } catch (\Exception $e) {
                session()->flash('error_message', 'Error occurred while removing cart item. Error: ' . $e->getMessage());
                $this->dispatch('scrollToMessage');
            }
        } else {
            session()->flash('error_message', 'User not logged in. Unable to remove cart item.');
            $this->dispatch('scrollToMessage');
        }
    }

    public function render()
    {
        return view('livewire.mini-cart', [
            'cartItems' => $this->cartItems,
            'cartItemsCount' => $this->cartItemsCount,
        ]);
    }
}
