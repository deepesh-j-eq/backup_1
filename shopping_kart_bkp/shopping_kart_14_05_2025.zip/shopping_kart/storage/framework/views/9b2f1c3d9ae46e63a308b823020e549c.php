<?php $__env->startSection('title', 'Products'); ?>
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <!--[if BLOCK]><![endif]--><?php if(userRole() && userRole() == 'admin'): ?>
                                        <div class="col-lg-3 col-xl-2 ms-5">
                                            <a href="<?php echo e(route('admin.products')); ?>" class="btn btn-primary mb-3 mb-lg-0"><i class='bx bxs-plus-square'></i>New Product</a>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="card p-4 mb-4 shadow-sm">
                                                <!-- <form> -->
                                                    <div class="row g-3 mb-4">
                                                        <!-- Search -->
                                                        <div class="col-lg-6 col-md-12">
                                                            <div class="position-relative">
                                                                <input type="text" class="form-control ps-5" wire:model.live.debounce.300ms="searchTerm" placeholder="Search Product...">
                                                                <span class="position-absolute top-50 product-show translate-middle-y"><i class="bx bx-search"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-md-12"></div>
                                                    </div>
                                                    
                                                    <div class="row g-3 mb-4">
                                                        <h4 class="mb-3">Filters</h4>
                                                        <div class="row g-3">
                                                            <div class="mb-3">
                                                                <button type="button"class="btn btn-danger" wire:click="clearFilters" <?php echo e($hasActiveFilters ? '' : 'disabled'); ?>>Clear All Filters</button>
                                                            </div>

                                                            <!-- Category Filter -->
                                                            <div class="col-lg-2 col-md-3">
                                                                <div class="dropdown">
                                                                    <button class="btn <?php echo e(!empty($selectedCategories) ? 'btn-primary' : 'btn-white'); ?> dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                                        Categories
                                                                    </button>
                                                                    <ul class="dropdown-menu p-3">
                                                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <li>
                                                                                <div class="form-check">
                                                                                    <input class="form-check-input" type="checkbox" wire:model.live="selectedCategories" value="<?php echo e($category->id); ?>" id="category-<?php echo e($category->id); ?>">
                                                                                    <label class="form-check-label" for="category-<?php echo e($category->id); ?>">
                                                                                        <?php echo e($category->name); ?>

                                                                                    </label>
                                                                                </div>
                                                                            </li>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                                    </ul>
                                                                </div>
                                                            </div>

                                                            <!-- Price Range -->
                                                            <div class="col-lg-2 col-md-3">
                                                                <div class="mb-3">
                                                                    <h5>
                                                                        <label class="form-label <?php echo e($maxPrice != 10000 ? 'badge bg-primary' : 'badge bg-light text-dark'); ?>">Price Range</label>
                                                                    </h5>
                                                                    <input type="range" class="form-range" id="priceRange" wire:model.live="maxPrice" min="100" max="10000" step="50" style="width: 100%;">
                                                                    <div class="d-flex justify-content-between mt-2">
                                                                        <span class="badge bg-light text-dark">$100</span>
                                                                        <span class="badge bg-light text-dark">$<span wire:model="maxPrice"><?php echo e($maxPrice); ?></span></span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- Sort By -->
                                                            <div class="col-lg-2 col-md-3">
                                                                <div class="dropdown">
                                                                    <button class="btn <?php echo e($sortBy == 'default' ? 'btn-white' : 'btn-primary'); ?> dropdown-toggle" type="button" data-bs-toggle="dropdown" data-td="">
                                                                        Sort By
                                                                    </button>
                                                                    <ul class="dropdown-menu p-3">
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio" wire:model.live="sortBy" value="newest" id="sort-newest" <?php echo e($sortBy == 'newest' ? 'checked' : ''); ?>>
                                                                                <label class="form-check-label" for="sort-newest">
                                                                                    Newest
                                                                                </label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio" wire:model.live="sortBy" value="price_low_high" id="sort-price-low-high" <?php echo e($sortBy == 'price_low_high' ? 'checked' : ''); ?>>
                                                                                <label class="form-check-label" for="sort-price-low-high">
                                                                                    Price Low to High
                                                                                </label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio" wire:model.live="sortBy" value="price_high_low" id="sort-price-high-low" <?php echo e($sortBy == 'price_high_low' ? 'checked' : ''); ?>>
                                                                                <label class="form-check-label" for="sort-price-high-low">
                                                                                    Price High to Low
                                                                                </label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio" wire:model.live="sortBy" value="most_popular" id="sort-most-popular" <?php echo e($sortBy == 'most_popular' ? 'checked' : ''); ?>>
                                                                                <label class="form-check-label" for="sort-most-popular">
                                                                                    Most Popular
                                                                                </label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio" wire:model.live="sortBy" value="best_rating" id="sort-best-rating" <?php echo e($sortBy == 'best_rating' ? 'checked' : ''); ?>>
                                                                                <label class="form-check-label" for="sort-best-rating">
                                                                                    Best Rating
                                                                                </label>
                                                                            </div>
                                                                        </li>
                                                                        
                                                                        <?php /* <li><a class="dropdown-item {{ $sortBy == 'newest' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('newest')">Newest</a></li>
                                                                        <li><a class="dropdown-item {{ $sortBy == 'price_low_high' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('price_low_high')">Price Low to High</a></li>
                                                                        <li><a class="dropdown-item {{ $sortBy == 'price_high_low' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('price_high_low')">Price High to Low</a></li>
                                                                        <li><a class="dropdown-item {{ $sortBy == 'most_popular' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('most_popular')">Most Popular</a></li>
                                                                        <li><a class="dropdown-item {{ $sortBy == 'best_rating' ? 'bg-primary text-white' : '' }}" href="#" wire:click.prevent="setSortBy('best_rating')">Best Rating</a></li> */ ?>
                                                                    </ul>
                                                                </div>
                                                            </div>

                                                            <!-- Dynamic Attributes -->
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <!--[if BLOCK]><![endif]--><?php if($attribute->productAttributeOptions->isNotEmpty()): ?>
                                                                    <div class="col-lg-2 col-md-3">
                                                                        <div class="dropdown">
                                                                            <button class="btn <?php echo e(!empty($selectedAttributes[$attribute->id]) ? 'btn-primary' : 'btn-white'); ?> dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                                                <?php echo e($attribute->attribute_name); ?>

                                                                            </button>
                                                                            <ul class="dropdown-menu p-3">
                                                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $attribute->productAttributeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atributeOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <li>
                                                                                        <div class="form-check">
                                                                                            <input class="form-check-input" type="checkbox" wire:model.live="selectedAttributes.<?php echo e($attribute->id); ?>" value="<?php echo e($atributeOption->id); ?>" id="attr-<?php echo e($attribute->id); ?>-<?php echo e($atributeOption->id); ?>">
                                                                                            <label class="form-check-label" for="attr-<?php echo e($attribute->id); ?>-<?php echo e($atributeOption->id); ?>">
                                                                                                <?php echo e($atributeOption->option); ?>

                                                                                            </label>
                                                                                        </div>
                                                                                    </li>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                    </div>
                                                <!-- </form> -->
                                            </div>
                                        </div>
                                    </div>

                                    <!--[if BLOCK]><![endif]--><?php if(session()->has('message') || session()->has('error_message')): ?>
                                        <div class="card">
                                            <div class="card-body p-4">
                                                <?php if(session()->has('message')): ?>
                                                    <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                                        <?php echo e(session('message')); ?>

                                                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                                <?php if(session()->has('error_message')): ?>
                                                    <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                                        <?php echo e(session('error_message')); ?>

                                                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 row-cols-xxl-5 product-grid">
                    <!--[if BLOCK]><![endif]--><?php if($productDetails->isNotEmpty()): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $productImages = $product->images;
                                $productImagePath = '';
                                if ($productImages) {
                                    foreach ($productImages as $productImg) {
                                        $productImagePath = $productImg->image_path;
                                        break;
                                    }
                                }

                                $discountPercentage = '';
                                if ($product->discounted_price) {
                                    $productPrice = (float)($product->price);
                                    $productDiscountPrice = (float)($product->discounted_price);
                                    $discountPercentage = (($productPrice - $productDiscountPrice) / $productPrice) * 100;
                                    $discountPercentage = number_format((float)$discountPercentage, 0);
                                }
                            ?>
                            <div class="col">
                                <div class="card">
                                    <a href="<?php echo e(route('product.detail', ['productId' => $product->id])); ?>">
                                        <img src="<?php echo e(($productImagePath != '') ? asset('storage/' . $productImagePath) : ''); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>" width="302px" height="302px">
                                    </a>
                                    <!--[if BLOCK]><![endif]--><?php if($discountPercentage != ''): ?>
                                        <div class="">
                                            <div class="position-absolute top-0 end-0 m-3 bg-primary text-white p-2 rounded-circle"><span class=""><?php echo e('-'.$discountPercentage.'%'); ?></span></div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <div class="card-body">
                                        <h6 class="card-title cursor-pointer">
                                            <a href="<?php echo e(route('product.detail', ['productId' => $product->id])); ?>" class="text-decoration-none text-dark">
                                                <?php echo e($product->name); ?>

                                            </a>
                                        </h6>
                                        <div class="clearfix">
                                            <p class="mb-0 float-start"><strong>134</strong> Sales</p>
                                            <p class="mb-0 float-end fw-bold">
                                                <!--[if BLOCK]><![endif]--><?php if($discountPercentage != ''): ?>
                                                    <span class="me-2 text-decoration-line-through text-secondary"><?php echo e('$'.$product->price); ?></span>
                                                    <span><?php echo e('$'.(number_format($product->discounted_price, 2, '.', '')) ?? ''); ?></span>
                                                <?php else: ?>
                                                    <span><?php echo e('$'.(number_format($product->price, 2, '.', ''))); ?></span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-center mt-3 fs-6">
                                            <div class="cursor-pointer">
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-warning'></i>
                                                <i class='bx bxs-star text-secondary'></i>
                                            </div>	
                                            <p class="mb-0 ms-auto">4.2(182)</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                    <div class="col-lg-12 col-md-12">
                        <div class="col">
                            <div class="card">
                                <div class="card-body p-4">
                                    <h5 class="card-title text-center">There is no products available, if you have selected any filter then please change filter or "clear all filters" and try again.</h5>
                                    <hr />
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div><!--end row-->
                <div wire:ignore.self class="d-flex justify-content-end mt-3 me-3">
                    <?php echo e($productDetails->links('livewire::bootstrap-5')); ?>

                </div>
            </div>
        </div>
        <!--end page wrapper -->
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\git_repo\trainee-milestones-laravel\shopping_kart\resources\views/livewire/product-listing.blade.php ENDPATH**/ ?>