<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!--favicon-->
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon-32x32.png')); ?>" type="image/png" />
    <!--plugins-->
    <link href="<?php echo e(asset('assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet" />
    <!-- loader-->
    <link href="<?php echo e(asset('assets/css/pace.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(asset('assets/js/pace.min.js')); ?>"></script>
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/bootstrap-extended.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet">
    <link href="https://parsleyjs.org/src/parsley.css" rel="stylesheet">
    <title>Signin</title>
</head>

<body class="bg-login">
    <!--wrapper-->
    <div class="wrapper">
        <div class="section-authentication-signin d-flex align-items-center justify-content-center my-5 my-lg-0">
            <div class="container-fluid">
                <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">
                    <div class="col mx-auto">
                        <div class="mb-4 text-center">
                            <img src="<?php echo e(asset('assets/images/logo-img.png')); ?>" width="180" alt="" />
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="border p-4 rounded">
                                    <div class="text-center">
                                        <h3 class="">Sign in</h3>
                                        <p>Don't have an account yet? <a href="<?php echo e(route('register')); ?>">Sign up here</a>
                                        </p>
                                    </div>
                                    <?php if(session('error')): ?>
                                        <div class="alert alert-danger text-center">
                                            <?php echo e(session('error')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($message = session()->pull('success')): ?>
                                        <div class="alert alert-success alert-dismissible fade show p-1" role="alert">
                                            <?php echo e($message); ?>

                                            <button type="button" class="btn-close p-2" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php endif; ?>
                                    <div class="d-grid">
                                        <a class="btn my-4 shadow-sm btn-white" href="<?php echo e(route('auth.google')); ?>"> <span class="d-flex justify-content-center align-items-center">
                          <img class="me-2" src="<?php echo e(asset('assets/images/icons/search.svg')); ?>" width="16" alt="Image Description">
                          <span>Sign in with Google</span>
                                            </span>
                                        </a> 
                                    </div>
                                    <div class="login-separater text-center mb-4"> <span>OR SIGN IN WITH EMAIL</span>
                                        <hr/>
                                    </div>
                                    <div class="form-body">
                                        <div id="general-error"></div>
                                        <form class="row g-3" id="siginForm" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="col-12">
                                                <label for="inputEmailAddress" class="form-label">Email Address</label>
                                                <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputEmailAddress" placeholder="Email address" value="<?php echo e(old('email')); ?>" data-parsley-required="true" data-parsley-required-message="The email is required">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-12">
                                                <label for="inputChoosePassword" class="form-label">Enter Password</label>
                                                <div class="input-group" id="show_hide_password">
                                                    <input type="password" name="password" class="form-control border-end-0 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputChoosePassword" value="<?php echo e(old('password')); ?>" placeholder="Enter password" data-parsley-required="true" data-parsley-required-message="The password is required"> <a href="javascript:;" class="input-group-text bg-transparent"><i class='bx bx-hide'></i></a>
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-grid">
                                                    <button type="submit" class="btn btn-primary"><i class="bx bxs-lock-open"></i>Sign in</button>
                                                </div>
                                            </div>
                                            <input type="hidden" name="admin_signin_url" class="admin_signin_url" value="<?php echo e(route('login.authentication')); ?>">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end row-->
            </div>
        </div>
    </div>
    <!--end wrapper-->
    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <!--plugins-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/simplebar/5.1.0/simplebar.min.js"></script>
    <script src="<?php echo e(asset('assets/plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/perfect-scrollbar/1.4.0/perfect-scrollbar.min.js"></script>
    <script src="https://parsleyjs.org/dist/parsley.min.js"></script>
    <!--Password show & hide js -->
    <script>
        $(document).ready(function () {
            $("#show_hide_password a").on('click', function (event) {
                event.preventDefault();
                if ($('#show_hide_password input').attr("type") == "text") {
                    $('#show_hide_password input').attr('type', 'password');
                    $('#show_hide_password i').addClass("bx-hide");
                    $('#show_hide_password i').removeClass("bx-show");
                } else if ($('#show_hide_password input').attr("type") == "password") {
                    $('#show_hide_password input').attr('type', 'text');
                    $('#show_hide_password i').removeClass("bx-hide");
                    $('#show_hide_password i').addClass("bx-show");
                }
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json'
                }
            });

            $('#siginForm').parsley().on('field:error', function () {
                var field = $(this.$element);
                var errorList = field.next('.parsley-errors-list');

                if (field.hasClass('parsley-success')) {
                    field.removeClass('is-invalid');
                }

                if (field.nextAll('.invalid-feedback').length) {
                    field.nextAll('.invalid-feedback').remove();
                }

                //field.closest('.input-group').find('.parsley-errors-list').remove();

                if (field.closest('.input-group').length) {
                    field.closest('.input-group').append(errorList);
                }
            });

            $('#siginForm').parsley().on('field:success', function () {
                var field = $(this.$element);

                if (field.hasClass('parsley-success')) {
                    field.removeClass('is-invalid');
                }
            });

            $("#siginForm").submit(function(e) {
                e.preventDefault();
                if ($(this).parsley().validate()) {
                    var url = $('.admin_signin_url').val();
                    //url = url.replace('http://', 'https://');

                    $.ajax({
                        url: url,
                        data: $('#siginForm').serialize(),
                        type: 'POST',
                        dataType: 'json',
                        success: function(result) {
                            if (result.status === true) {
                                window.location.href = result.redirect_url;
                            }
                        },
                        error: function(xhr) {
                            var response = xhr.responseJSON;
                            if (response && response.custom_error) {
                                showGeneralError(response.message);
                            }

                            if (response && response.errors) {
                                displayErrors(response.errors);
                            }
                        }
                    });
                }
            });

            function showGeneralError(message) {
                $("#general-error").html('');

                var errorHtml = `
                    <div class="alert alert-danger alert-dismissible fade show p-1" role="alert">
                        ${message}
                        <button type="button" class="btn-close p-2" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `;

                $("#general-error").html(errorHtml);
            }

            function displayErrors(errors) {
                $('.invalid-feedback').remove();
                $('.form-control').removeClass('is-invalid');

                $.each(errors, function(field, messages) {
                    var input = $('[name="' + field + '"]');
                    if (input.hasClass('parsley-success')) {
                        input.removeClass('parsley-success');
                    }
                    input.addClass('is-invalid');

                    $.each(messages, function(index, message) {
                        if (input.closest('.input-group').length) {
                            input.closest('.input-group').append('<span class="invalid-feedback d-block"><strong>' + message + '</strong></span>');
                        } else {
                            input.after('<span class="invalid-feedback d-block"><strong>' + message + '</strong></span>');
                        }
                    });
                });
            }
        });
    </script>
</body>

</html>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\git_repo\trainee-milestones-laravel\shopping_kart\resources\views/authentication/signin.blade.php ENDPATH**/ ?>