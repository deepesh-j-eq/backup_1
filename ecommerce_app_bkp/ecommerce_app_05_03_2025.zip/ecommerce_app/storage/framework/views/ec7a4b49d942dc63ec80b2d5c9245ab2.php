<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Payment</title>
</head>
<body>
    <h2>Product: Keyboard</h2>
    <h4>Price: $5</h4>

    <?php
    function fetchImage($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Bypass SSL verification
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        $data = curl_exec($ch);
        if (curl_errno($ch)) {
            return "cURL Error: " . curl_error($ch);
        }
        
        curl_close($ch);
        return $data;
    }
    
    $imageData = fetchImage("https://source.unsplash.com/640x480/?fashion");

    var_dump($imageData);

    exit;
    
    //var_dump(file_get_contents("https://www.google.com")); exit;
    ?>

    <form action="<?php echo e(route('stripe')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="price" value="5">
        <input type="hidden" name="product_name" value="Keyboard">
        <input type="hidden" name="quantity" value="2">
        <button type="submit">Pay with stripe</button>
    </form>
</body>
</html><?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\git_repo\trainee-milestones-laravel\ecommerce_app\resources\views/prdouct_detail.blade.php ENDPATH**/ ?>