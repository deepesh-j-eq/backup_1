<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\OrderMail;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderAddress;
use App\Models\OrderItem;
use App\Models\OrderStatus;
use App\Models\Payment;
use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class CartController extends Controller
{
    protected $stripePaymentController;

    public function __construct(StripePaymentController $stripePaymentController)
    {
        $this->stripePaymentController = $stripePaymentController;
    }

    /**
    * @OA\Get(
    *     path="/api/cart",
    *     summary="View your cart",
    *     description="Display your cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="view.cart.items",
    *     @OA\Response(
    *         response=200,
    *         description="Display your cart or No product in your cart, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your cart | No product in your cart, keep shoppping!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                           @OA\Property(
    *                             property="cart_items",
    *                             type="array",
    *                                   @OA\Items(
    *                                       type="object",
    *                                       @OA\Property(property="id", type="integer", example=3),
    *                                       @OA\Property(property="quantity", type="integer", example=2),
    *                                       @OA\Property(property="product_id", type="integer", example=1),
    *                                       @OA\Property(property="created_at", type="string", example="2025-02-24T12:36:29.000000Z"),
    *                                       @OA\Property(property="updated_at", type="string", example="2025-02-25T11:03:47.000000Z"),
    *                                       @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                           @OA\Property(
    *                                               property="product",
    *                                               type="object",
    *                                                   @OA\Property(property="name", type="string", example="Product 1"),
    *                                                   @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                                   @OA\Property(property="price", type="string", example="50.00")
    *                                           )
    *                                   ),
    *                           ),
    *                      @OA\Property(property="total_price", type="string", example="715.00")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function viewCart(Request $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItems = Cart::with(['product' => function ($query) {
                            $query->select(['id', 'name', 'description', 'price']);
                        }])
                ->where('user_id', $authenticatedUserId)
                ->get()
                ->makeHidden(['user_id']);

            if ($cartItems->isEmpty()) {
                return helperJSONResponse(true, 'No product in your cart, keep shoppping!', [], 200);
            }

            $data = array();
            $totalPrice = 0;

            $cartItems->transform(function ($item) use (&$totalPrice) {
                $item->product->makeHidden(['id']);

                $price = (float) $item->product->price;
                $quantity = (int) $item->quantity;

                $item->sub_total = $price * $quantity;
                $totalPrice += $item->sub_total;

                $item->sub_total = number_format($item->sub_total, 2);

                return $item;
            });

            $data['cart_items'] = $cartItems;
            $data['total_price'] = number_format($totalPrice, 2);

            if ($data['cart_items']->isNotEmpty()) {
                return helperJSONResponse(true, 'Your cart', ['cart' => $data], 200);
            }
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/cart/add",
    *     summary="Add to cart",
    *     description="Add to cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="add.to.cart",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"product_id", "quantity"},
    *                   @OA\Property(
    *                       property="product_id",
    *                       type="integer",
    *                       example=6
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=2
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"product_id", "quantity"},
    *                   @OA\Property(
    *                       property="product_id",
    *                       type="integer",
    *                       example=6
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=2
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product added to cart successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product added to cart successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                         @OA\Property(property="product_id", type="string", example="6"),
    *                         @OA\Property(property="quantity", type="string", example="2"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-04T08:20:17.000000Z"),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-04T08:20:17.000000Z"),
    *                         @OA\Property(property="id", type="integer", example=13),
    *                         @OA\Property(property="sub_total", type="string", example="410.00"),
    *                         @OA\Property(
    *                             property="product",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Product 3"),
    *                             @OA\Property(property="description", type="string", example="Product 3 description"),
    *                             @OA\Property(property="price", type="string", example="205.00"),
    *                             @OA\Property(property="quantity", type="integer", example=12)
    *                        )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "product_id": {"The product_id field is required.", "The selected product id is invalid.", "The product id field must be an integer."},
    *                   "quantity": {"The quantity field is required.", "The quantity field must be at least 1.", "The quantity field must be an integer."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=405,
    *         description="Not enough stock available for selected product",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Not enough stock available for selected product")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function addToCart(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'product_id' => 'required|integer|exists:products,id',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;
            $productId = $request->product_id;
            $quantity = $request->quantity;

            $product = Product::find($productId);

            if (!$product || $quantity > $product->quantity) {
                return helperJSONResponse(false, 'Not enough stock available for selected product ' . ($product->name ?? ''), [], 405);
            }

            $cartItem = Cart::with([
                'product' => function ($query) {
                    $query->select('id', 'name', 'description', 'price', 'quantity');
                }])->where('user_id', $authenticatedUserId)
                    ->where('product_id', $productId)
                    ->first();

            if ($cartItem) {
                $newQuantity = $cartItem->quantity + $quantity;

                if ($newQuantity > $product->quantity) {
                    $availableQuantity = $product->quantity - $cartItem->quantity;

                    return helperJSONResponse(
                        false,
                        'Not enough stock available for selected product ' . ($product->name ?? '') . '. You can able to add only avalaible ' . $availableQuantity . ' quantity',
                        [],
                        400
                    );
                }

                $cartItem->update(['quantity' => $newQuantity]);
            } else {
                $cartItem = Cart::create([
                    'user_id' => $authenticatedUserId,
                    'product_id' => $productId,
                    'quantity' => $quantity
                ]);
            }

            $cartItem->sub_total = number_format($cartItem->quantity * $product->price, 2);
            $cartItem->product->makeHidden(['id', 'category_id', 'created_at', 'updated_at']);
            $cartItem->makeHidden(['user_id']);

            return helperJSONResponse(true, 'Product added to cart successfully', ['cart' => $cartItem], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }
    
    /**
    * @OA\Post(
    *     path="/api/cart/changeQty/{id}",
    *     summary="Change product quantity from cart",
    *     description="Change product quantity from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="change.cart.qty",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Cart id to change product quantity",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"change_to", "quantity"},
    *                   @OA\Property(
    *                       property="change_to",
    *                       type="string",
    *                       enum={"up", "down"},
    *                       example="down",
    *                       description="Change (increase or decrease) product quantity which already added to cart"
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=1
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"change_to", "quantity"},
    *                   @OA\Property(
    *                       property="change_to",
    *                       type="string",
    *                       enum={"up", "down"},
    *                       example="down",
    *                       description="Change (increase or decrease) product quantity which already added to cart"
    *                   ),
    *                   @OA\Property(
    *                       property="quantity",
    *                       type="integer",
    *                       example=1
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Product qunatity has been changed successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Product qunatity has been changed successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                         @OA\Property(
    *                             property="cart_item",
    *                             type="object",
    *                                   @OA\Property(property="id", type="integer", example=12),
    *                                   @OA\Property(property="quantity", type="integer", example=2),
    *                                   @OA\Property(property="product_id", type="integer", example=6),
    *                                   @OA\Property(property="updated_at", type="string", example="2025-03-04T08:31:20.000000Z"),
    *                                   @OA\Property(property="created_at", type="string", example="2025-03-04T09:12:07.000000Z"),
    *                                   @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                   @OA\Property(
    *                                       property="product",
    *                                       type="object",
    *                                           @OA\Property(property="name", type="string", example="Product 1"),
    *                                           @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                           @OA\Property(property="price", type="string", example="50.00")
    *                                   )
    *                          )
    *                   )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error or Please choose correct cart item for update quantity",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error | Please choose correct cart item for update quantity"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "change_to": {"The change to field is required.", "The selected change to is invalid."},
    *                   "quantity": {"The quantity field is required.", "The quantity field must be at least 1.", "The quantity field must be an integer."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=405,
    *         description="Please add correct qunatity of product",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Please add correct qunatity of product")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function changeCartQuantity(Request $request, $id)
    {
        try {
            $validate = Validator::make($request->all(), [
                'change_to' => 'required|string|in:up,down',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItem = Cart::with(['product'])
                ->where('user_id', $authenticatedUserId)
                ->find($id);

            if (!$cartItem) {
                return helperJSONResponse(false, 'Please choose correct cart item for update quantity', [], 400);
            }

            $changeTo = $request->change_to;
            $quantity = $request->quantity;
            
            if ($changeTo == 'up') {
                $newQuantity = $cartItem->quantity + $quantity;
            } else if ($changeTo == 'down') {
                $newQuantity = $cartItem->quantity - $quantity;
            }

            if ($newQuantity < 1) {
                return helperJSONResponse(false, 'Please add correct qunatity of product, its not more than or eqal to ' . $cartItem->quantity, [], 405);
            }

            if ($changeTo == 'up' && $cartItem->quantity == $cartItem->product->quantity) {
                return helperJSONResponse(
                    false,
                    'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. You have already added avalaible ' . $cartItem->product->quantity . ' quantity',
                    [],
                    405
                );
            }

            if ($newQuantity > $cartItem->product->quantity) {
                return helperJSONResponse(
                    false,
                    'Please add correct qunatity of product, its not more than ' . ($cartItem->product->quantity - $cartItem->quantity),
                    [],
                    405
                );
            }

            $cartItem->update(['quantity' => $newQuantity]);

            $cart_item = Cart::with([
                'product' => function ($query) {
                    $query->select(['id', 'name', 'description', 'price']);
                }])
                ->where('user_id', $authenticatedUserId)
                ->find($id);

            $cart_item_price = (float) $cart_item->product->price;
            $cart_item_quantity = (int) $cartItem->quantity;
            $cart_item->sub_total = number_format($cart_item_price * $cart_item_quantity, 2);

            $cart_item->product->makeHidden(['id']);
            $cart_item->makeHidden(['user_id']);

            $data = array();
            $data['cart_item'] = $cart_item;

            return helperJSONResponse(true, $cart_item->product->name . ' qunatity has been changed successfully', ['cart' => $data], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Delete(
    *     path="/api/cart/{id}",
    *     summary="Remove item from cart",
    *     description="Remove item from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="remove.cart.item",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Cart id to delete the specific cart item",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Cart item removed successfully or No product in your cart, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Cart item removed successfully | No product in your cart, keep shoppping!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="cart",
    *                     type="object",
    *                           @OA\Property(
    *                             property="cart_items",
    *                             type="array",
    *                                   @OA\Items(
    *                                       type="object",
    *                                       @OA\Property(property="id", type="integer", example=3),
    *                                       @OA\Property(property="quantity", type="integer", example=2),
    *                                       @OA\Property(property="product_id", type="integer", example=1),
    *                                       @OA\Property(property="created_at", type="string", example="2025-02-24T12:36:29.000000Z"),
    *                                       @OA\Property(property="updated_at", type="string", example="2025-02-25T11:03:47.000000Z"),
    *                                       @OA\Property(property="sub_total", type="string", example="100.00"),
    *                                           @OA\Property(
    *                                               property="product",
    *                                               type="object",
    *                                                   @OA\Property(property="name", type="string", example="Product 1"),
    *                                                   @OA\Property(property="description", type="string", example="Product 1 description"),
    *                                                   @OA\Property(property="price", type="string", example="50.00")
    *                                           )
    *                                   ),
    *                           ),
    *                      @OA\Property(property="total_price", type="string", example="715.00")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested cart item not available for remove",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested cart item not available for remove"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function removeFromCart(Request $request, $id)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItem = Cart::where('user_id', $authenticatedUserId)
                            ->find($id);

            if (!$cartItem) {
                return helperJSONResponse(false, 'Requested cart item not available for remove', [], 400);
            }

            $cartItem->delete();

            $RemainingCartItems = Cart::with(['product' => function ($query) {
                            $query->select(['id', 'name', 'description', 'price']);
                        }])
                ->where('user_id', $authenticatedUserId)
                ->get()
                ->makeHidden(['user_id']);

            if ($RemainingCartItems->isEmpty()) {
                return helperJSONResponse(true, 'Cart item removed successfully, No product in your cart, keep shoppping!', [], 200);
            }

            $data = array();
            $totalPrice = 0;

            $RemainingCartItems->transform(function ($item) use (&$totalPrice) {
                $item->product->makeHidden(['id']);

                $price = (float) $item->product->price;
                $quantity = (int) $item->quantity;

                $item->sub_total = $price * $quantity;
                $totalPrice += $item->sub_total;

                $item->sub_total = number_format($item->sub_total, 2);

                return $item;
            });

            $data['cart_items'] = $RemainingCartItems;
            $data['total_price'] = number_format($totalPrice, 2);

            return helperJSONResponse(true, 'Cart item removed successfully', ['cart' => $data], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/cart/removeCart",
    *     summary="Remove all items from cart",
    *     description="Remove all items from cart",
    *     tags={"Cart"},
    *     security={{"bearerAuth": {}}},
    *     operationId="remove.all.cart.items",
    *     @OA\Response(
    *         response=200,
    *         description="All products are removed from cart successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All products are removed from cart successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="No cart item available for remove, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="No cart item available for remove, keep shoppping!"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function removeAllProductsFromCart(Request $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItems = Cart::where('user_id', $authenticatedUserId)->get();

            if ($cartItems->isEmpty()) {
                return helperJSONResponse(false, 'No cart item available for remove, keep shoppping!', [], 400);
            }

            $cartProducts = array();

            foreach ($cartItems as $cartItem) {
                $product = Product::find($cartItem->product_id);

                $cartProducts[] = $product->name;

                $cartItem->delete();
            }

            return helperJSONResponse(true, 'All products ('.implode(", ", $cartProducts).') are removed from cart successfully', [], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
    * @OA\Post(
    *     path="/api/cart/checkout",
    *     summary="Checkout",
    *     description="Checkout",
    *     tags={"Checkout"},
    *     security={{"bearerAuth": {}}},
    *     operationId="checkout",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"first_name", "last_name", "address_line_1", "city", "state", "country", "postal_code", "email", "card_number", "phone"},
    *                   @OA\Property(
    *                       property="first_name",
    *                       type="string",
    *                       example="Test1 First Name"
    *                   ),
    *                   @OA\Property(
    *                       property="last_name",
    *                       type="string",
    *                       example="Test1 Last Name"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_1",
    *                       type="string",
    *                       example="Test1 Address Line 1"
    *                   ),
    *                   @OA\Property(
    *                       property="apartment",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Apartment"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_2",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Address Line 2"
    *                   ),
    *                   @OA\Property(
    *                       property="city",
    *                       type="string",
    *                       example="Ahmedabad"
    *                   ),
    *                   @OA\Property(
    *                       property="state",
    *                       type="string",
    *                       example="Gujarat"
    *                   ),
    *                   @OA\Property(
    *                       property="country",
    *                       type="string",
    *                       example="India"
    *                   ),
    *                   @OA\Property(
    *                       property="postal_code",
    *                       type="integer",
    *                       example=441122
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="card_number",
    *                       type="integer",
    *                       example=8855229966337744
    *                   ),
    *                   @OA\Property(
    *                       property="phone",
    *                       type="integer",
    *                       example=4411441188
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"first_name", "last_name", "address_line_1", "city", "state", "country", "postal_code", "email", "card_number", "phone"},
    *                   @OA\Property(
    *                       property="first_name",
    *                       type="string",
    *                       example="Test1 First Name"
    *                   ),
    *                   @OA\Property(
    *                       property="last_name",
    *                       type="string",
    *                       example="Test1 Last Name"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_1",
    *                       type="string",
    *                       example="Test1 Address Line 1"
    *                   ),
    *                   @OA\Property(
    *                       property="apartment",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Apartment"
    *                   ),
    *                   @OA\Property(
    *                       property="address_line_2",
    *                       type="string",
    *                       nullable=true,
    *                       example="Test1 Address Line 2"
    *                   ),
    *                   @OA\Property(
    *                       property="city",
    *                       type="string",
    *                       example="Ahmedabad"
    *                   ),
    *                   @OA\Property(
    *                       property="state",
    *                       type="string",
    *                       example="Gujarat"
    *                   ),
    *                   @OA\Property(
    *                       property="country",
    *                       type="string",
    *                       example="India"
    *                   ),
    *                   @OA\Property(
    *                       property="postal_code",
    *                       type="integer",
    *                       example=441122
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="card_number",
    *                       type="integer",
    *                       example=8855229966337744
    *                   ),
    *                   @OA\Property(
    *                       property="phone",
    *                       type="integer",
    *                       example=4411441188
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Order placed successfully or Your cart is empty, keep shoppping!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Order placed successfully | Your cart is empty, keep shoppping!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="order_details",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="total_amount", type="string", example="460.00"),
    *                         @OA\Property(property="order_status_id", type="integer", example=1),
    *                         @OA\Property(property="payment_id", type="integer", example=5),
    *                         @OA\Property(property="updated_by", type="string", example=null),
    *                         @OA\Property(property="created_at", type="string", example="2025-03-04T10:40:08.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-03-04T10:40:08.000000Z"),
    *                         @OA\Property(
    *                             property="order_status",
    *                             type="object",
    *                             @OA\Property(property="status", type="string", example="Placed")
    *                         ),
    *                         @OA\Property(
    *                             property="payment",
    *                             type="object",
    *                             @OA\Property(property="payment_gateway", type="string", example="paypal"),
    *                             @OA\Property(property="transaction_id", type="string", example="ojsMiGIkg50MrLG"),
    *                             @OA\Property(property="status", type="string", example="successful")
    *                         ),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Test 2")
    *                         ),
    *                         @OA\Property(
    *                             property="address",
    *                             type="object",
    *                             @OA\Property(property="id", type="integer", example=1),
    *                             @OA\Property(property="order_id", type="integer", example=1),
    *                             @OA\Property(property="first_name", type="string", example="Test2 First Name"),
    *                             @OA\Property(property="last_name", type="string", example="Test2 Last Name"),
    *                             @OA\Property(property="address_line_1", type="string", example="Test2 Address Line 1"),
    *                             @OA\Property(property="apartment", type="string", example="Test2 Apartment"),
    *                             @OA\Property(property="address_line_2", type="string", example="Test2 Address Line 2"),
    *                             @OA\Property(property="city", type="string", example="Ahmedabad"),
    *                             @OA\Property(property="country", type="string", example="India"),
    *                             @OA\Property(property="state", type="string", example="Gujarat"),
    *                             @OA\Property(property="postal_code", type="integer", example=441122),
    *                             @OA\Property(property="phone", type="integer", example=4411441188),
    *                             @OA\Property(property="email", type="string", example="test2@gmail.com")
    *                         ),
    *                         @OA\Property(
    *                             property="order_items",
    *                             type="array",
    *                             @OA\Items(
    *                                 type="object",
    *                                 @OA\Property(property="quantity", type="integer", example=2),
    *                                 @OA\Property(property="price", type="string", example="205.00"),
    *                                 @OA\Property(property="order_id", type="integer", example=1),
    *                                 @OA\Property(property="created_at", type="string", example="2025-03-04T10:40:08.000000Z"),
    *                                 @OA\Property(property="updated_at", type="string", example="2025-03-04T10:40:08.000000Z"),
    *                                 @OA\Property(property="sub_total", type="string", example="410.00"),
    *                                 @OA\Property(
    *                                     property="product",
    *                                     type="object",
    *                                     @OA\Property(property="name", type="string", example="Product 1")
    *                                 )
    *                             )
    *                         )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error or Payment processing failed. Try again later.",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error | Payment processing failed. Try again later."
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                       "first_name": {"The first_name field is required.", "The first name field must be at least 2 characters."},
    *                       "last_name": {"The last_name field is required.", "The last name field must be at least 2 characters."},
    *                       "address_line_1": {"The address_line_1 field is required.", "The address line 1 field must be at least 10 characters."},
    *                       "city": {"The city field is required."},
    *                       "state": {"The state field is required."},
    *                       "country": {"The country field is required."},
    *                       "postal_code": {"The postal code field is required.", "Postal code should be minimum 6 digits."},
    *                       "email": {"The email field is required.", "Please enter a valid email address."},
    *                       "card_number": {"The card number field is required.", "The card number field must be 16 digits."},
    *                       "phone": {"The phone field is required.", "The phone field must be 10 digits."},
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="An error occurred")
    *         )
    *     )
    * )
    */
    public function checkout(Request $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItems = Cart::with(['product'])->where('user_id', $authenticatedUserId)->get();

            if ($cartItems->isEmpty()) {
                return helperJSONResponse(true, 'Your cart is empty, keep shoppping!', [], 200);
            }

            Validator::extend('valid_domain', function ($attribute, $value, $parameters, $validator) {
                $domain = substr(strrchr($value, "@"), 1);
                return !empty(dns_get_record($domain, DNS_MX));
            });

            $validate = Validator::make($request->all(), [
                'first_name' => 'required|string|min:2|max:191',
                'last_name' => 'required|string|min:2|max:191',
                'address_line_1' => 'required|string|min:10|max:191',
                'apartment' => 'nullable|string|max:191',
                'address_line_2' => 'nullable|string|max:191',
                'city' => 'required|string|max:191',
                'state' => 'required|string|max:191',
                'country' => 'required|string|max:191',
                'postal_code' => 'required|regex:/^\d{6,}$/',
                'email' => 'required|email:rfc,dns|valid_domain',
                'payment_method' => 'required|string|in:pm_card_visa,pm_card_mastercard,pm_card_chargeDeclined,pm_card_chargeDeclinedInsufficientFunds',
                'phone' => 'required|integer|digits:10'
                /*'exp_month' => 'required|between:1,12',
                'exp_year' => 'required|integer|digits:4',
                'cvc' => 'required|integer|digits:3',
                'phone' => 'required|integer|regex:/^\d{10}$/',*/
            ], [
                'valid_domain' => 'Please enter a valid email address.',
                'email.email' => 'Please enter a valid email address.',
                'postal_code.regex' => 'Postal code should be minimum 6 digits.'
            ]);

            /* $validate->after(function ($validator) use ($request) {
                $currentYear = Carbon::now()->year;
                $currentMonth = Carbon::now()->month;
                $expYear = $request->exp_year;
                $expMonth = $request->exp_month;
        
                if ($expYear < $currentYear) {
                    $validator->errors()->add('exp_year', 'The expiration year must be the current year or a future year.');
                }

                if ($expYear == $currentYear && $expMonth < $currentMonth) {
                    $validator->errors()->add('exp_month', 'The expiration month must be the current month or a future month if the year is the current year.');
                }
            }); */

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $products = array();
            $totalAmount = 0;

            foreach ($cartItems as $item) {
                $products[] = [
                    'name' => $item->product->name,
                    'price' => $item->product->price,
                    'quantity' => $item->quantity
                ];
                $totalAmount += $item->product->price * $item->quantity;
            }

            $order = Order::create([
                'total_amount' => $totalAmount,
                'user_id' => $authenticatedUserId
            ]);

            $shippingAddress = OrderAddress::create([
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'address_line_1' => $request->address_line_1,
                'apartment' => $request->apartment,
                'address_line_2' => $request->address_line_2,
                'city' => $request->city,
                'state' => $request->state,
                'country' => $request->country,
                'postal_code' => $request->postal_code,
                'phone' => $request->phone,
                'email' => $request->email,
                'order_id' => $order->id
            ]);

            foreach ($cartItems as $item) {
                OrderItem::create([
                    'quantity' => $item->quantity,
                    'price' => $item->product->price,
                    'order_id' => $order->id,
                    'product_id' => $item->product_id
                ]);
            }

            $paymentResponse = $this->stripePaymentController->processPayment($request, $products);

            //dd("test");

            if (!empty($paymentResponse)) {
                if (isset($paymentResponse['status']) && $paymentResponse['status']) {
                    $orderItems = OrderItem::with(['product'])->where('order_id', $order->id)->get();

                    if (isset($paymentResponse['paymentDetails']) && $paymentResponse['paymentDetails'] != '') {
                        $payment = Payment::create([
                            'transaction_id' => $paymentResponse['paymentDetails']['payment_id'],
                            'currency' => $paymentResponse['paymentDetails']['currency'],
                            'amount' => $paymentResponse['paymentDetails']['amount'],
                            'payer_name' => $request->first_name,
                            'payer_email' => $request->email,
                            'payment_gateway' => $paymentResponse['paymentDetails']['payment_gateway'],
                            'payment_method' => $paymentResponse['paymentDetails']['payment_method'],
                            'status' => $paymentResponse['paymentDetails']['status']
                        ]);

                        $paymentId = $payment->id;

                        if ($paymentResponse['paymentDetails']['status'] != 'succeeded') {
                            $failedStatusId = OrderStatus::where('status', 'Payment Failed')->pluck('id')->first();
                            $order->update(['payment_id' => $paymentId, 'order_status_id' => $failedStatusId]);

                            if (isset($paymentResponse['message']) && $paymentResponse['message'] != '') {
                                $paymentResponseMessage = $paymentResponse['message'];
                            }

                            $request->email = "deepesh.jain-t@equestsolutions.net";
                            Mail::to($request->email)->queue(new OrderMail($order, $payment, $orderItems, $shippingAddress, 'Payment Failed'));

                            return $this->orderResponse($order, $paymentResponseMessage, false, 400);
                        }

                        $placedStatusId = OrderStatus::where('status', 'Placed')->pluck('id')->first();
                        $order->update(['payment_id' => $paymentId, 'order_status_id' => $placedStatusId]);
                        
                        foreach ($cartItems as $cartItem) {
                            $product = $cartItem->product;
                            $product->update(['quantity' => ($product->quantity - $cartItem->quantity)]);
                        }

                        Cart::where('user_id', $order->user_id)->delete();

                        $request->email = "deepesh.jain-t@equestsolutions.net";
                        Mail::to($request->email)->queue(new OrderMail($order, $payment, $orderItems, $shippingAddress, 'Order Placed Successfully'));

                        return $this->orderResponse($order, 'Order placed successfully', true, 200);
                    }
                } else {
                    return helperJSONResponse(false, 'Something went wrong ' . $paymentResponse['message'], [], 400);
                }
            } else {
                return helperJSONResponse(false, 'Something went wrong while attempting stripe payment!', [], 400);
            }




            // $payment = Payment::create([
            //     'transaction_id' => null,
            //     'status' => 'pending'
            // ]);

            // $paymentId = $payment->id;

            // // Payment success $paypalResponse['id'] = 1 and fail $paypalResponse['id'] = 0
            // $paypalResponse = array();
            // $paypalResponse['id'] = 0;
            // //$paypalResponse['id'] = 1;

            // if (/*!isset($paypalResponse['id'])*/ $paypalResponse['id'] == 0) {
            //     $payment->update([
            //         'transaction_id' => 'failed_'.Str::random(5),
            //         'status' => 'failed'
            //     ]);

            //     $failedStatusId = OrderStatus::where('status', 'Payment Failed')->pluck('id')->first();
            //     $order->update(['payment_id' => $paymentId, 'order_status_id' => $failedStatusId]);
            //     //viral.sonagra-t@equestsolutions.net
            //     Mail::to($request->email)->queue(new OrderMail($order, null, $cartItems, $shippingAddress, 'Payment Failed'));

            //     return $this->orderResponse($order, 'Payment processing failed. Try again later.', false, 400);
            // }

            // $payment->update([
            //     'status' => 'successful',
            //     'transaction_id' => Str::random(15),
            //     //'transaction_id' => $request->token,
            // ]);

            // $placedStatusId = OrderStatus::where('status', 'Placed')->pluck('id')->first();
            // $order->update(['payment_id' => $paymentId, 'order_status_id' => $placedStatusId]);
            
            // foreach ($cartItems as $cartItem) {
            //     $product = $cartItem->product;
            //     $product->update(['quantity' => ($product->quantity - $cartItem->quantity)]);
            // }

            // Cart::where('user_id', $order->user_id)->delete();

            // Mail::to($request->email)->queue(new OrderMail($order, $payment, $cartItems, $shippingAddress, 'Order Placed Successfully'));

            // return $this->orderResponse($order, 'Order placed successfully', true, 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    private function orderResponse($order, $message, $status, $httpCode)
    {
        $orderDetails = Order::with([
            'orderStatus:id,status',
            'payment:id,payment_gateway,transaction_id,status',
            'user:id,name',
            'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
            'orderItems.product:id,name'
        ])->find($order->id);

        $orderDetails->makeHidden(['user_id']);
        $orderDetails->payment->makeHidden(['id']);
        $orderDetails->orderStatus->makeHidden(['id']);
        $orderDetails->user->makeHidden(['id']);

        $orderDetails->orderItems->each(function ($orderItem) {
            $orderItem->makeHidden(['id', 'product_id']);
            $price = (float) $orderItem->price;
            $quantity = (int) $orderItem->quantity;

            $orderItem->sub_total = number_format($price * $quantity, 2);

            if ($orderItem->product) {
                $orderItem->product->makeHidden(['id']);
            }
        });

        return response()->json([
            'status' => $status,
            'message' => $message,
            'order_id' => $order->id,
            'data' => ['order_details' => $orderDetails]
        ], $httpCode);
    }

    public function paymentSuccess(Request $request, Order $order)
    {
        //$isSuccessful = $this->paypalService->capturePayment($request->token);
        /* $isSuccessful = true;

        if ($isSuccessful) {
            $order->update(['payment_status' => 'successful']);

            Payment::where('order_id', $order->id)->update([
                'transaction_id' => $request->token,
                'status' => 'successful',
                'transaction_id' => Str::random(12)
                //'transaction_id' => $request->token
            ]);

            Cart::where('user_id', $order->user_id)->delete();

            return true;
        } else {
            $order->update(['payment_status' => 'failed']);

            Payment::where('order_id', $order->id)->update([
                'status' => 'failed'
            ]);

            return false;
        } */
    }
}
