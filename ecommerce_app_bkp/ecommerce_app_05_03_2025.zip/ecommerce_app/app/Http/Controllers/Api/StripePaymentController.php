<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Stripe\Exception\ApiErrorException;
use Stripe\StripeClient;

class StripePaymentController extends Controller
{
    protected $stripe;

    public function __construct(StripeClient $stripe)
    {
        $this->stripe = new StripeClient(config('stripe.stripe_sk'));
    }

    public function processPayment(Request $request, array $products)
    {
        if (!$products || !is_array($products) || empty($products)) {
            return [
                'status' => 'error',
                'message' => 'Invalid product data.'
            ];
        }

        try {
            $lineItems = [];
            $totalAmount = 0;

            foreach ($products as $product) {
                $lineItems[] = [
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => ['name' => $product['name']],
                        'unit_amount' => $product['price'] * 100
                    ],
                    'quantity' => $product['quantity'],
                ];
                $totalAmount += $product['price'] * $product['quantity'];
            }

            /* $successCardNumber = "4242424242424242";
            $failCardNumber = "4000000000000002";

            $paymentMethod = $this->stripe->paymentMethods->create([
                'type' => 'card',
                'card' => [
                    'number' => $request->card_number,
                    'exp_month' => $request->exp_month,
                    'exp_year' => $request->exp_year,
                    'cvc' => $request->cvc
                ]
            ]);

            $paymentIntent = $this->stripe->paymentIntents->create([
                'amount' => $totalAmount * 100,
                'currency' => 'usd',
                'payment_method' => $paymentMethod->id,
                'confirm' => true
            ]); */

            $paymentIntent = $this->stripe->paymentIntents->create([
                'amount' => $totalAmount * 100,
                'currency' => 'usd',
                'payment_method' => $request->payment_method,
                'confirm' => true,
                'automatic_payment_methods' => [
                    'enabled' => true,
                    'allow_redirects' => 'never'
                ]
            ]);

            $paymentDetails = [
                'payment_id' => $paymentIntent->id,
                'status' => $paymentIntent->status,
                'amount' => $paymentIntent->amount / 100,
                'currency' => $paymentIntent->currency,
                'payment_method' => $paymentIntent->payment_method ?? $request->payment_method,
                'payment_gateway' => 'Stripe'
            ];

            return [
                'status' => 'true',
                'paymentDetails' => $paymentDetails
            ];

        } catch (ApiErrorException $e) {
            $errorResponse = $e->getJsonBody();
            $errorData = $errorResponse['error'] ?? [];

            $paymentIntentId = $errorData['payment_intent']['id'] ?? null;
            $paymentStatus = $errorData['payment_intent']['decline_code'] ?? 'failed';
            $currency = $errorData['payment_intent']['currency'] ?? 'usd';
            $amount = isset($errorData['payment_intent']['amount']) ? ($errorData['payment_intent']['amount'] / 100) : 0;

            return [
                'status' => 'error',
                'message' => 'Payment not prossesed: ' . ($errorData['message'] ?? 'Unknown error'),
                'paymentDetails' => [
                    'payment_id' => $paymentIntentId,
                    'status' => $paymentStatus,
                    'amount' => $amount,
                    'currency' => $currency,
                    'payment_method' => $request->payment_method,
                    'payment_gateway' => 'Stripe'
                ]
            ];
            /* return [
                'status' => 'error',
                'message' => 'Payment failed: ' . $e->getMessage()
            ]; */
        }
    }
}
