<?php

namespace App\Http\Controllers;

use App\Services\PayPalService;
use Illuminate\Http\Request;

class PayPalController extends Controller
{
    protected $paypalService;

    public function __construct(PayPalService $paypalService)
    {
        $this->paypalService = $paypalService;
    }

    public function index()
    {
        return view('paypal');
    }

    public function payment(Request $request)
    {
        $redirectUrl = $this->paypalService->createOrder(100.00);

        if ($redirectUrl) {
            return redirect()->away($redirectUrl);
        }

        return redirect()
            ->route('paypal')
            ->with('error', 'Something went wrong.');
    }

    public function paymentCancel()
    {
        return redirect()
            ->route('paypal')
            ->with('error', 'You have canceled the transaction.');
    }

    public function paymentSuccess(Request $request)
    {
        $isSuccessful = $this->paypalService->capturePayment($request->token);

        if ($isSuccessful) {
            return redirect()
                ->route('paypal')
                ->with('success', 'Transaction complete.');
        } else {
            return redirect()
                ->route('paypal')
                ->with('error', 'Something went wrong.');
        }
    }
}
