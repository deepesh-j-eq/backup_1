<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            $ordersQuery = Order::with([
                'orderStatus:id,status',
                'payment:id,order_id,transaction_id,status',
                'user:id,name',
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderItems.product:id,name'
            ]);

            if($user->isUser()) {
                $ordersQuery->where('user_id', $authenticatedUserId);
            }

            $orders = $ordersQuery->get();

            $formattedOrders = [];

            foreach ($orders as $order) {
                $formattedOrder = [
                    'id' => $order->id,
                    'total_amount' => $order->total_amount,
                    'payment_status' => $order->payment_status,
                    'user_id' => $order->user_id,
                    'updated_by' => $order->updated_by,
                    'created_at' => $order->created_at,
                    'updated_at' => $order->updated_at,
                    'payment' => [
                        'transaction_id' => $order->payment->transaction_id,
                        'status' => $order->payment->status,
                    ],
                    'order_status' => [
                        'status' => $order->orderStatus->status,
                    ],
                    'user' => [
                        'name' => $order->user->name,
                    ],
                    'address' => $order->address,
                    'order_items' => []
                ];

                if($user->isUser()) {
                    unset($formattedOrder['user_id']);
                    unset($formattedOrder['updated_by']);
                    unset($formattedOrder['address']['id']);
                }
    
                foreach ($order->orderItems as $item) {
                    $orderItem = [
                        'quantity' => $item->quantity,
                        'price' => $item->price,
                        'order_id' => $item->order_id,
                        'sub_total' => number_format(($item->quantity * $item->price), 2),
                        'product' => [
                            'name' => $item->product->name,
                        ]
                    ];

                    if (!$user->isUser()) {
                        $orderItem['product_id'] = $item->product_id;
                        $orderItem['created_at'] = $item->created_at;
                        $orderItem['updated_at'] = $item->updated_at;
                    }

                    $formattedOrder['order_items'][] = $orderItem;
                }
    
                $formattedOrders[] = $formattedOrder;
            }

            if (empty($formattedOrders)) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available'
                ], 400);
            }

            return response()->json([
                'status' => true,
                'message' => 'All orders',
                'data' => ['orders' => $formattedOrders],
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            $orderQuery = Order::with([
                'orderStatus:id,status',
                'payment:id,order_id,transaction_id,status',
                'user:id,name',
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderItems.product:id,name'
            ]);

            if($user->isUser()) {
                $orderQuery->where('user_id', $authenticatedUserId);
            }

            $orderDetails = $orderQuery->find($id);

            if (!$orderDetails) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available'
                ], 400);
            }

            if($user->isUser()) {
                $orderDetails->makeHidden(['user_id', 'order_status_id', 'updated_by']);
            }

            $orderDetails->orderStatus->makeHidden(['id']);
            $orderDetails->payment->makeHidden(['id', 'order_id']);
            $orderDetails->address->makeHidden(['id']);
            $orderDetails->user->makeHidden(['id']);

            foreach ($orderDetails->orderItems as $orderItem) {
                $orderItem->makeHidden(['id']);

                if($user->isUser()) {
                    $orderItem->makeHidden(['id', 'product_id', 'created_at', 'updated_at']);
                }
    
                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;
                $orderItem->sub_total = number_format($price * $quantity, 2);
    
                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            }

            return response()->json([
                'status' => true,
                'message' => 'Your single order',
                'data' => ['order_details' => $orderDetails]
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $adminUser = auth('sanctum')->user();
            $adminUserId = $adminUser->id;

            $adminCheck = User::find($adminUserId);

            if(!$adminCheck->isAdmin()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Unauthorize, admin has only access to update order'
                ], 403);
            }

            $validate = Validator::make($request->all(), [
                'order_status_id' => 'required|integer|exists:order_statuses,id',
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $order = Order::find($id);

            if (!$order) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available for update'
                ], 400);
            }

            $paymentDetails = Payment::where('order_id', $id)->first();

            if (!$paymentDetails) {
                return response()->json([
                    'status' => false,
                    'message' => 'Payment details not found for this order'
                ], 400);
            }

            $allowedOrderStatuses = [];

            if ($paymentDetails->status === 'successful') {
                $allowedOrderStatuses = [
                    "Placed" => 1, 
                    "In Transit" => 3, 
                    "Shipped" => 4, 
                    "Completed" => 8
                ];
            } elseif ($paymentDetails->status === 'pending' || $paymentDetails->status === 'failed') {
                $allowedOrderStatuses = [
                    "Canceled" => 5, 
                    "Payment Failed" => 6
                ];
            } elseif ($paymentDetails->status === 'refunded') {
                $allowedOrderStatuses = [
                    "Refunded" => 7
                ];
            }

            if (!in_array($request->order_status_id, $allowedOrderStatuses)) {
                return response()->json([
                    'status' => false,
                    'message' => "Invalid order_status_id. Allowed values for order payment status '{$paymentDetails->status}' are: " . json_encode($allowedOrderStatuses)
                ], 400);
            }

            $updateOrderData = array();

            if ($request->order_status_id != $order->order_status_id) {
                $updateOrderData['order_status_id'] = $request->order_status_id;
            }

            if ($order->payment_status != $paymentDetails->status) {
                $updateOrderData['payment_status'] = $paymentDetails->status;
            }

            if (!empty($updateOrderData)) {
                $updateOrderData['updated_by'] = $adminUserId;
                $order->update($updateOrderData);
            }

            if ($paymentDetails->status === 'refunded' ||  ($paymentDetails->status === 'successful' && $order->order_status_id == 5)) {
                foreach ($order->orderItems as $orderItem) {
                    $product = Product::find($orderItem->product_id);

                    if ($product) {
                        // $product->quantity += $orderItem->quantity;
                        // $product->save();
                    }
                }
            }

            $updatedOrderDetails = Order::with([
                'orderStatus:id,status',
                'payment:id,order_id,transaction_id,status',
                'user:id,name',
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderItems.product:id,name'
            ])->find($id);

            if (!$updatedOrderDetails) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available after update'
                ], 400);
            }

            $updatedOrderDetails->orderStatus->makeHidden(['id']);
            $updatedOrderDetails->payment->makeHidden(['id', 'order_id']);
            $updatedOrderDetails->address->makeHidden(['id']);
            $updatedOrderDetails->user->makeHidden(['id']);

            foreach ($updatedOrderDetails->orderItems as $orderItem) {
                $orderItem->makeHidden(['id']);
    
                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;
                $orderItem->sub_total = number_format($price * $quantity, 2);
    
                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            }

            return response()->json([
                'status' => true,
                'message' => 'Order updated successfully',
                'data' => ['order_details' => $updatedOrderDetails]
            ], 200);            
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function ordersByStatus(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'order_status_id' => 'nullable|integer|exists:order_statuses,id|required_without_all:payment_status',
                'payment_status' => 'nullable|string|in:pending,failed,successful,refunded|required_without_all:order_status_id'
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $orderQuery = Order::query();
        
            if ($request->has('order_status_id') && $request->order_status_id !== null) {
                $orderQuery->where('order_status_id', $request->order_status_id);
            }
        
            if ($request->has('payment_status') && $request->payment_status !== null) {
                $orderQuery->whereHas('payment', function ($query) use ($request) {
                    $query->where('status', $request->payment_status);
                });
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            if($user->isUser()) {
                $orderQuery->where('user_id', $authenticatedUserId);
            }

            $orderDetails = $orderQuery->with([
                'orderStatus:id,status',
                'payment:id,order_id,transaction_id,status',
                'user:id,name',
                'address:id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email,order_id',
                'orderItems.product:id,name'
            ])->get();

            if ($orderDetails->isEmpty()) {
                return response()->json([
                    'status' => true,
                    'message' => 'Sorry! No order available, please apply different filter'
                ], 200);
            }

            foreach ($orderDetails as $order) {
                if($user->isUser()) {
                    $order->makeHidden(['order_status_id', 'user_id', 'updated_by']);
                }

                $order->orderStatus->makeHidden(['id']);
                $order->payment->makeHidden(['id', 'order_id']);
                $order->user->makeHidden(['id']);
                $order->address->makeHidden(['id']);
    
                foreach ($order->orderItems as $orderItem) {
                    $orderItem->makeHidden(['id']);

                    if($user->isUser()) {
                        $orderItem->makeHidden(['id', 'product_id', 'created_at', 'updated_at']);
                    }
    
                    $price = (float) $orderItem->price;
                    $quantity = (int) $orderItem->quantity;
                    $orderItem->sub_total = number_format($price * $quantity, 2);
    
                    if ($orderItem->product) {
                        $orderItem->product->makeHidden(['id']);
                    }
                }
            }

            return response()->json([
                'status' => true,
                'message' => 'Orders after applying filters',
                'data' => ['order_details' => $orderDetails]
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }
}
