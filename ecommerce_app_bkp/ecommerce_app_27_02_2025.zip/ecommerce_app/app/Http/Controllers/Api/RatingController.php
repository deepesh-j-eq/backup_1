<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Rating;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RatingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $ratings = array();

        $user = auth('sanctum')->user();
        $userId = $user ? $user->id : null;

        $ratingsQuery = Rating::with([
            'product:id,name',
            'user:id,name',
        ]);

        if ($userId) {
            $ratingsQuery->where('user_id', $userId);
        }

        $ratings = $ratingsQuery->get();

        if($ratings->isEmpty()) {
            return response()->json([
                'status' => true,
                'message' => 'No ratings available'
            ], 200);
        }

        foreach ($ratings as $rating) {
            $rating->makeHidden(['id', 'user_id', 'created_at', 'updated_at']);
            $rating->product->makeHidden(['id']);
            $rating->user->makeHidden(['id']);
        }

        return response()->json([
            'status' => true,
            'message' => 'All ratings',
            'data' => ['ratings' => $ratings],
        ],200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'rating' => 'required|numeric|min:0.1|max:5|regex:/^\d+(\.\d{1,1})?$/',
            'review' => 'required|string|max:500',
            'product_id' => 'required|integer|exists:products,id'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }

        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $userRating = Rating::where(['user_id' => $authenticatedUserId, 'product_id' => $request->product_id])->first();

        if ($userRating) {
            $userRating->update([
                'rating' => number_format($request->rating, 1),
                'review' => $request->review,
                'product_id' => $request->product_id
            ]);
        } else {
            $userRating = Rating::create([
                'rating' => number_format($request->rating, 1),
                'review' => $request->review,
                'product_id' => $request->product_id,
                'user_id' => $authenticatedUserId
            ]);
        }

        if (!$userRating) {
            return response()->json([
                'status' => false,
                'message' => 'Rating create failed',
            ], 500);
        }

        $userRating->makeHidden(['id', 'user_id', 'created_at', 'updated_at']);

        return response()->json([
            'status' => true,
            'message' => 'Rating created successfully',
            'rating' => $userRating
        ], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $rating = array();

        $user = auth('sanctum')->user();
        $userId = $user ? $user->id : null;

        $ratingsQuery = Rating::with([
            'product:id,name',
            'user:id,name',
        ]);

        if ($userId) {
            $ratingsQuery->where('user_id', $userId);
        }

        $rating = $ratingsQuery->where('id', $id)->first();

        if (!$rating) {
            return response()->json([
                'status' => false,
                'message' => 'Requested rating is not available'
            ], 400);
        }

        $rating->makeHidden(['id', 'user_id', 'created_at', 'updated_at']);
        $rating->product->makeHidden(['id']);
        $rating->user->makeHidden(['id']);

        return response()->json([
            'status' => true,
            'message' => 'Your single rating',
            'data' => ['rating' => $rating]
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $rating = Rating::where('user_id', $authenticatedUserId)->find($id);

        if (!$rating) {
            return response()->json([
                'status' => false,
                'message' => 'Requested rating is not available for update',
            ], 400);
        }

        $validate = Validator::make($request->all(), [
            'rating' => 'required|numeric|min:0.1|max:5|regex:/^\d+(\.\d{1,1})?$/',
            'review' => 'required|string|max:500'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }

        $updateRating = $rating->update([
            'rating' => number_format($request->rating, 1),
            'review' => $request->review,
            'user_id' => $authenticatedUserId
        ]);

        if (!$updateRating) {
            return response()->json([
                'status' => false,
                'message' => 'Rating update failed',
            ], 500);
        }

        $updatedRatingData = array();
        $updatedRatingData = Rating::with([
            'product:id,name',
            'user:id,name',
        ])->find($id);

        $updatedRatingData->makeHidden(['id', 'user_id', 'created_at', 'updated_at']);
        $updatedRatingData->product->makeHidden(['id']);
        $updatedRatingData->user->makeHidden(['id']);

        return response()->json([
            'status' => true,
            'message' => 'Rating updated successfully',
            'data' => ['rating' => $updatedRatingData]
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $rating = Rating::find($id);

        if (!$rating) {
            return response()->json([
                'status' => false,
                'message' => 'Requested rating is not available for delete',
            ], 400);
        }

        $rating->delete();

        return response()->json([
            'status' => true,
            'message' => 'Rating deleted successfully',
        ], 200);
    }
}
