<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $users = User::with([
            'role' => function ($query) {
                $query->select('id', 'role');
            }
        ])->whereHas('role', function ($query) {
            $query->where('role', 'user');
        })->get();

        if($users->isEmpty()) {
            return response()->json([
                'status' => true,
                'message' => 'No user registered'
            ], 200);
        }

        $users->each(function ($user) {
            $user->role->makeHidden(['id']);
        });

        return response()->json([
            'status' => true,
            'message' => 'All users',
            'data' => ['users' => $users]
        ],200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $user = User::with([
            'role' => function ($query) {
                $query->select('id', 'role');
            }
        ])->whereHas('role', function ($query) {
            $query->where('role', 'user');
        })->find($id);
 
        if(!$user) {
            return response()->json([
                'status' => false,
                'message' => 'Requested user is not available'
            ], 400);
        }

        $user->role->makeHidden(['id']);

        return response()->json([
            'status' => true,
            'message' => 'Your single user data',
            'data' => ['user' => $user]
        ], 200);
    }

    /**
     * Display the specified resource.
     */
    public function showUserProfile()
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $user = User::select('name', 'email')->find($authenticatedUserId);
 
        if(!$user) {
            return response()->json([
                'status' => false,
                'message' => 'Something went wrong!'
            ], 400);
        }

        return response()->json([
            'status' => true,
            'message' => 'Your profile',
            'data' => ['profile' => $user]
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function updateUserProfile(Request $request)
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $user = User::find($authenticatedUserId);

        if (!$user) {
            return response()->json([
                'status' => false,
                'message' => 'Requested user is not available'
            ], 400);
        }

        $validate = Validator::make($request->all(), [
            'name'=>'nullable|string|min:2|max:191',
            'email' => 'nullable|email:rfc,dns|unique:users,email,' . $authenticatedUserId
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }

        $updateUser = $user->update([
            'name' => $request->name
        ]);

        if (!$updateUser) {
            return response()->json([
                'status' => false,
                'message' => 'Profile update failed'
            ], 500);
        }

        $updatedUserProfile = array();
        $updatedUserProfile = User::select('name', 'email')->find($authenticatedUserId);

        return response()->json([
            'status' => true,
            'message' => 'Your profile is updated successfully',
            'data' => ['profile' => $updatedUserProfile]
        ], 200);
    }
}
