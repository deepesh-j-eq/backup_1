<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderAddress;
use App\Models\OrderItem;
use App\Models\OrderStatus;
use App\Models\Payment;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class CartController extends Controller
{
    public function viewCart(Request $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $data = array();

            $cartItems = Cart::with(['product' => function ($query) {
                            $query->select(['id', 'name', 'description', 'price']);
                        }])
                ->where('user_id', $authenticatedUserId)
                ->get()
                ->makeHidden(['user_id']);

            $totalPrice = 0;

            $cartItems->transform(function ($item) use (&$totalPrice) {
                $item->product->makeHidden(['id']);

                $price = (float) $item->product->price;
                $quantity = (int) $item->quantity;

                $item->sub_total = $price * $quantity;
                $totalPrice += $item->sub_total;

                $item->sub_total = number_format($item->sub_total, 2);
                
                return $item;
            });

            $data['cart_items'] = $cartItems;
            $data['total_price'] = number_format($totalPrice, 2);

            if ($data['cart_items']->isNotEmpty()) {
                return response()->json([
                    'status' => true,
                    'message' => 'Your cart',
                    'cart' => $data
                ], 200);
            }

            return response()->json([
                'status' => true,
                'message' => 'No product in your cart, keep shoppping!'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function addToCart(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'product_id' => 'required|integer|exists:products,id',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;
            $productId = $request->product_id;
            $quantity = $request->quantity;

            $product = Product::find($productId);

            if (!$product || $quantity > $product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not enough stock available for product ' . ($product->name ?? '')
                ], 400);
            }

            $cartItem = Cart::with([
                'product' => function ($query) {
                    $query->select('id', 'name', 'description', 'price', 'quantity');
                }])->where('user_id', $authenticatedUserId)
                    ->where('product_id', $productId)
                    ->first();

            if ($cartItem) {
                $newQuantity = $cartItem->quantity + $quantity;

                if ($newQuantity > $product->quantity) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Not enough stock available for product ' . ($product->name ?? '') . 
                                        '. You have already added avalaible ' . $cartItem->product->quantity . ' quantity'
                    ], 400);
                }

                $cartItem->update(['quantity' => $newQuantity]);
            } else {
                $cartItem = Cart::create([
                    'user_id' => $authenticatedUserId,
                    'product_id' => $productId,
                    'quantity' => $quantity
                ]);
            }

            $cartItem->sub_total = number_format($cartItem->quantity * $product->price, 2);
            $cartItem->product->makeHidden(['id', 'category_id', 'created_at', 'updated_at']);
            $cartItem->makeHidden(['user_id']);

            return response()->json([
                'status' => true,
                'message' => 'Product added to cart successfully',
                'cart' => $cartItem
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function changeCartQuantity(Request $request, $id)
    {
        try {
            $validate = Validator::make($request->all(), [
                'change_to' => 'required|string|in:up,down',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItem = Cart::with(['product'])
                ->where('user_id', $authenticatedUserId)
                ->find($id);

            if (!$cartItem) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please choose correct product for update quantity'
                ], 400);
            }

            $changeTo = $request->change_to;
            $quantity = $request->quantity;
            
            if ($changeTo == 'up') {
                $newQuantity = $cartItem->quantity + $quantity;
            } else if ($changeTo == 'down') {
                $newQuantity = $cartItem->quantity - $quantity;
            }

            if ($newQuantity < 1) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please add correct qunatity of product, its not more than or eqal to ' . $cartItem->quantity
                ], 400);
            }

            if ($changeTo == 'up' && $cartItem->quantity == $cartItem->product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') .
                                '. You have already added avalaible ' . $cartItem->product->quantity . ' quantity'
                ], 400);
            }

            if ($newQuantity > $cartItem->product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please add correct qunatity of product, its not more than '
                                . ($cartItem->product->quantity - $cartItem->quantity)
                ], 400);
            }

            $cartItem->update(['quantity' => $newQuantity]);

            $cart_item = Cart::with([
                'product' => function ($query) {
                    $query->select(['id', 'name', 'description', 'price']);
                }])
                ->where('user_id', $authenticatedUserId)
                ->find($id);

            $cart_item_price = (float) $cart_item->product->price;
            $cart_item_quantity = (int) $cartItem->quantity;
            $cart_item->sub_total = number_format($cart_item_price * $cart_item_quantity, 2);

            $cart_item->product->makeHidden(['id']);
            $cart_item->makeHidden(['user_id']);

            $data = array();
            $data['cart_item'] = $cart_item;

            return response()->json([
                'status' => true,
                'message' => $cart_item->product->name . ' qunatity has been changed successfully',
                'cart' => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function removeFromCart(Request $request, $id)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItem = Cart::where('user_id', $authenticatedUserId)
                            ->find($id);

            if (!$cartItem) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested cart item not available for remove'
                ], 400);
            }

            $cartItem->delete();

            return response()->json([
                'status' => true,
                'message' => 'Cart item removed successfully',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function removeAllProductsFromCart(Request $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItems = Cart::where('user_id', $authenticatedUserId)->get();

            if ($cartItems->isEmpty()) {
                return response()->json([
                    'status' => false,
                    'message' => 'No cart item available for remove, keep shoppping!'
                ], 400);
            }

            $cartProducts = array();

            foreach ($cartItems as $cartItem) {
                $product = Product::find($cartItem->product_id);

                $cartProducts[] = $product->name;

                $cartItem->delete();
            }

            return response()->json([
                'status' => true,
                'message' => 'All products ('.implode(", ", $cartProducts).') are removed from cart successfully',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function checkout(Request $request)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $cartItems = Cart::with(['product'])->where('user_id', $authenticatedUserId)->get();

            if ($cartItems->isEmpty()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Your cart is empty, keep shoppping!'
                ], 400);
            }

            Validator::extend('valid_domain', function ($attribute, $value, $parameters, $validator) {
                $domain = substr(strrchr($value, "@"), 1);
                return !empty(dns_get_record($domain, DNS_MX));
            });

            $validate = Validator::make($request->all(), [
                'first_name' => 'required|string|min:2|max:191',
                'last_name' => 'required|string|min:2|max:191',
                'address_line_1' => 'required|string|min:10|max:191',
                'apartment' => 'nullable|string|max:191',
                'address_line_2' => 'nullable|string|max:191',
                'city' => 'required|string|max:191',
                'state' => 'required|string|max:191',
                'country' => 'required|string|max:191',
                'postal_code' => 'required|regex:/^\d{6,}$/',
                'email' => 'required|email:rfc,dns|valid_domain',
                'phone' => 'required|digits:10|regex:/^\d{10}$/',
                /*'phone' => 'required|integer|regex:/^\d{10}$/',*/
            ], [
                'valid_domain' => 'Please enter a valid email address.',
                'email.email' => 'Please enter a valid email address.',
                'postal_code.regex' => 'Postal code should be minimum 6 digits.'
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $totalAmount = 0;
            foreach ($cartItems as $item) {
                $totalAmount += $item->product->price * $item->quantity;
            }

            $order = Order::create([
                'total_amount' => $totalAmount,
                'user_id' => $authenticatedUserId
            ]);

            OrderAddress::create([
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'address_line_1' => $request->address_line_1,
                'apartment' => $request->apartment,
                'address_line_2' => $request->address_line_2,
                'city' => $request->city,
                'state' => $request->state,
                'country' => $request->country,
                'postal_code' => $request->postal_code,
                'phone' => $request->phone,
                'email' => $request->email,
                'order_id' => $order->id
            ]);

            foreach ($cartItems as $item) {
                OrderItem::create([
                    'quantity' => $item->quantity,
                    'price' => $item->product->price,
                    'order_id' => $order->id,
                    'product_id' => $item->product_id
                ]);
            }

            $payment = Payment::create([
                'payment_gateway' => 'paypal',
                'transaction_id' => null,
                'amount' => $totalAmount,
                'status' => 'pending',
                'order_id' => $order->id
            ]);

            $paymentId = $payment->id;

            // Payment success $paypalResponse['id'] = 1 and fail $paypalResponse['id'] = 0
            $paypalResponse = array();
            $paypalResponse['id'] = 0;
            //$paypalResponse['id'] = 1;

            if (/*!isset($paypalResponse['id'])*/ $paypalResponse['id'] == 0) {
                Payment::where('order_id', $order->id)->update([
                    'transaction_id' => 'failed_'.Str::random(5),
                    'status' => 'failed'
                ]);

                $failedStatusId = OrderStatus::where('status', 'Payment Failed')->pluck('id')->first();
                $order->update(['payment_id' => $payment->id, 'order_status_id' => $failedStatusId]);

                return $this->orderResponse($order, 'Payment processing failed. Try again later.', false, 400);
            }

            Payment::where('order_id', $order->id)->update([
                'status' => 'successful',
                'transaction_id' => Str::random(15),
                //'transaction_id' => $request->token,
            ]);

            $placedStatusId = OrderStatus::where('status', 'Placed')->pluck('id')->first();
            $order->update(['payment_id' => $payment->id, 'order_status_id' => $placedStatusId]);
            
            foreach ($cartItems as $cartItem) {
                $product = $cartItem->product;
                $product->update(['quantity' => ($product->quantity - $cartItem->quantity)]);
            }

            Cart::where('user_id', $order->user_id)->delete();

            return $this->orderResponse($order, 'Order placed successfully', true, 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    private function orderResponse($order, $message, $status, $httpCode)
    {
        $orderDetails = Order::with([
            'orderStatus:id,status',
            'payment:id,order_id,transaction_id,status',
            'user:id,name',
            'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
            'orderItems.product:id,name'
        ])->find($order->id);

        $orderDetails->makeHidden(['user_id']);
        $orderDetails->payment->makeHidden(['id','order_id']);
        $orderDetails->orderStatus->makeHidden(['id']);
        $orderDetails->user->makeHidden(['id']);

        $orderDetails->orderItems->each(function ($orderItem) {
            $orderItem->makeHidden(['id']);
            $price = (float) $orderItem->price;
            $quantity = (int) $orderItem->quantity;

            $orderItem->sub_total = number_format($price * $quantity, 2);

            if ($orderItem->product) {
                $orderItem->product->makeHidden(['id']);
            }
        });

        return response()->json([
            'status' => $status,
            'message' => $message,
            'order_id' => $order->id,
            'data' => ['order_details' => $orderDetails]
        ], $httpCode);
    }

    public function paymentSuccess(Request $request, Order $order)
    {
        //$isSuccessful = $this->paypalService->capturePayment($request->token);
        /* $isSuccessful = true;

        if ($isSuccessful) {
            $order->update(['payment_status' => 'successful']);

            Payment::where('order_id', $order->id)->update([
                'transaction_id' => $request->token,
                'status' => 'successful',
                'transaction_id' => Str::random(12)
                //'transaction_id' => $request->token
            ]);

            Cart::where('user_id', $order->user_id)->delete();

            return true;
        } else {
            $order->update(['payment_status' => 'failed']);

            Payment::where('order_id', $order->id)->update([
                'status' => 'failed'
            ]);

            return false;
        } */
    }
}
