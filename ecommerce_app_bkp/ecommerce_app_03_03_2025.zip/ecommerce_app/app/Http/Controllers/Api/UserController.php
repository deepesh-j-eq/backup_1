<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
* @OA\SecurityScheme(
*     securityScheme="bearerAuth",
*     type="http",
*     scheme="bearer"
* )
*/
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/users",
    *     summary="Get all users",
    *     description="Fetches all users data from the database",
    *     tags={"Users accessed by admin"},
    *     security={{"bearerAuth": {}}},
    *     operationId="getAllUsers",
    *     @OA\Response(
    *         response=200,
    *         description="All users data or No user registered",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All users or No user registered"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="users",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Test"),
    *                         @OA\Property(property="email", type="string", example="test@test.com"),
    *                         @OA\Property(property="email_verified_at", type="string", example=null),
    *                         @OA\Property(property="role_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(
    *                             property="role",
    *                             type="object",
    *                             @OA\Property(property="role", type="string", example="user")
    *                         )
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function index()
    {
        $users = User::with([
            'role' => function ($query) {
                $query->select('id', 'role');
            }
        ])->whereHas('role', function ($query) {
            $query->where('role', 'user');
        })->get();

        if($users->isEmpty()) {
            return helperJSONResponse(true, 'No user registered', [], 200);
        }

        $users->each(function ($user) {
            $user->role->makeHidden(['id']);
        });

        return helperJSONResponse(true, 'All users', ['users' => $users], 200);
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/users/{id}",
    *     summary="Get single user",
    *     description="Fetches all users data from the database",
    *     tags={"Users accessed by admin"},
    *     security={{"bearerAuth": {}}},
    *     operationId="getSingleUser",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="User id to show that user",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Your single user data",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single user data"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="user",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="name", type="string", example="Test"),
    *                         @OA\Property(property="email", type="string", example="test@test.com"),
    *                         @OA\Property(property="email_verified_at", type="string", example=null),
    *                         @OA\Property(property="role_id", type="integer", example=2),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T06:20:52.000000Z"),
    *                         @OA\Property(
    *                             property="role",
    *                             type="object",
    *                             @OA\Property(property="role", type="string", example="user")
    *                         )
    *                  )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested user is not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested user is not available")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {
        $user = User::with([
            'role' => function ($query) {
                $query->select('id', 'role');
            }
        ])->whereHas('role', function ($query) {
            $query->where('role', 'user');
        })->find($id);
 
        if(!$user) {
            return helperJSONResponse(false, 'Requested user is not available', [], 400);
        }

        $user->role->makeHidden(['id']);

        return helperJSONResponse(true, 'Your single user data', ['user' => $user], 200);
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/profile",
    *     summary="User profile",
    *     description="User profile",
    *     tags={"User"},
    *     security={{"bearerAuth": {}}},
    *     operationId="showUserProfile",
    *     @OA\Response(
    *         response=200,
    *         description="Your profile",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your profile"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="profile",
    *                     type="object",
    *                       @OA\Property(property="name", type="string", example="Test"),
    *                       @OA\Property(property="email", type="string", example="test@test.com")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Something went wrong!",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Something went wrong!")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function showUserProfile()
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $user = User::select('name', 'email')->find($authenticatedUserId);
 
        if(!$user) {
            return helperJSONResponse(false, 'Something went wrong!', [], 400);
        }

        return helperJSONResponse(true, 'Your profile', ['profile' => $user], 200);
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/updateUserProfile",
    *     summary="Update user profile",
    *     description="Update your profile",
    *     tags={"User"},
    *     security={{"bearerAuth": {}}},
    *     operationId="updateUserProfile",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name", "email"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Test 2"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "name", "email"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="name",
    *                       type="string",
    *                       example="Test 2"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="test@test.com"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Your profile is updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your profile is updated successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="profile",
    *                     type="object",
    *                       @OA\Property(property="name", type="string", example="Test"),
    *                       @OA\Property(property="email", type="string", example="test@test.com")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error or Requested user is not available",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error | Requested user is not available"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "name": {"The name field is required.", "The name field must be at least 3 characters."},
    *                   "email": {"The email field is required.", "The email must be a valid email address.", "The email has already been taken."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Profile update failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Profile update failed")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function updateUserProfile(Request $request)
    {
        $authenticatedUser = auth('sanctum')->user();
        $authenticatedUserId = $authenticatedUser->id;

        $user = User::find($authenticatedUserId);

        if (!$user) {
            return helperJSONResponse(false, 'Requested user is not available', [], 400);
        }

        $validate = Validator::make($request->all(), [
            'name'=>'required|string|min:3|max:191',
            'email' => 'nullable|email:rfc,dns|unique:users,email,' . $authenticatedUserId
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 401);
        }

        $updateUser = $user->update([
            'name' => $request->name,
            'email' => $request->email
        ]);

        if (!$updateUser) {
            return helperJSONResponse(false, 'Profile update failed', [], 500);
        }

        $updatedUserProfile = array();
        $updatedUserProfile = User::select('name', 'email')->find($authenticatedUserId);

        return helperJSONResponse(true, 'Your profile is updated successfully', ['profile' => $updatedUserProfile], 200);
    }
}
