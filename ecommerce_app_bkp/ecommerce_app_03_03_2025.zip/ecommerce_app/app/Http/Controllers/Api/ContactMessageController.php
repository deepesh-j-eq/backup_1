<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\ContactMessageMail;
use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class ContactMessageController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/contact_messages",
    *     summary="Get all contact messages",
    *     description="Fetches all contact messages from the database",
    *     tags={"Contact Message"},
    *     security={{"bearerAuth": {}}},
    *     operationId="all.contact.messages",
    *     @OA\Response(
    *         response=200,
    *         description="All contact messages or No contact messages available",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All contact messages or No contact messages available"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="contact_messages",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="full_name", type="string", example="Test1 contact"),
    *                         @OA\Property(property="email", type="string", example="test1@gmail.com"),
    *                         @OA\Property(property="message", type="string", example="Contact 1 Message"),
    *                         @OA\Property(property="user_id", type="integer", example=1),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T09:52:39.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T09:52:39.000000Z"),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="name", type="string", example="Test1"),
    *                             @OA\Property(property="email", type="string", example="test1@test.com"),
    *                             @OA\Property(property="email_verified_at", type="string", example=null),
    *                             @OA\Property(property="role_id", type="integer", example=2),
    *                             @OA\Property(
    *                               property="role",
    *                                type="object",
    *                                   @OA\Property(property="role", type="string", example="user"),
    *                             )
    *                         )
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function index()
    {
        $contactMessages = array();

        $contactMessages = ContactMessage::with(['user.role'])->get();

        if ($contactMessages->isEmpty()) {
            return helperJSONResponse(true, 'No contact messages available', [], 200);
        }

        foreach ($contactMessages as $contactMsg) {
            if ($contactMsg->user == null) {
                $contactMsg->makeHidden(['user']);
            } else {
                $contactMsg->user->makeHidden(['id', 'created_at', 'updated_at']);
                $contactMsg->user->role->makeHidden(['id', 'created_at', 'updated_at']);
            }
        }

        return helperJSONResponse(true, 'All contact messages', ['contact_messages' => $contactMessages], 200);
    }

    /**
     * Store a newly created resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/contact/authUser",
    *     summary="Create contact messages by authenticated user",
    *     description="Create contact messages by authenticated user",
    *     tags={"Contact Message"},
    *     security={{"bearerAuth": {}}},
    *     operationId="create.contact.message.auth.user",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"full_name", "email", "message"},
    *                   @OA\Property(
    *                       property="full_name",
    *                       type="string",
    *                       example="Test1 contact"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="te1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="message",
    *                       type="string",
    *                       example="Contact 1 Message"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"full_name", "email", "message"},
    *                   @OA\Property(
    *                       property="full_name",
    *                       type="string",
    *                       example="Test1 contact"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="te1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="message",
    *                       type="string",
    *                       example="Contact 1 Message"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Your message has been sent successfully!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your message has been sent successfully!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="contact_messages",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="full_name", type="string", example="Test1 contact"),
    *                         @OA\Property(property="email", type="string", example="test1@gmail.com"),
    *                         @OA\Property(property="message", type="string", example="Contact 1 Message")
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "full_name": {"The full_name field is required.", "The name field must be at least 3 characters."},
    *                   "email": {"The email field is required.", "The email must be a valid email address."},
    *                   "message": {"The message field is required.", "The name field must be at least 10 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Contact message create failed or An error occurred",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Contact message create failed or An error occurred")
    *         )
    *     )
    * )
    */
    public function store(Request $request)
    {
        try{
            $validate = Validator::make($request->all(), [
                'full_name' => 'required|string|min:3|max:191',
                'email' => 'required|email:rfc,dns|max:191',
                'message' => 'required|string|min:10|max:500'
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $user = auth('sanctum')->user();
            $userId = $user ? $user->id : null;

            $contact = ContactMessage::create([
                'full_name' => $request->full_name,
                'email' => $request->email,
                'message' => $request->message,
                'user_id' => $userId
            ]);

            if (!$contact) {
                return helperJSONResponse(false, 'Contact message create failed', [], 500);
            }

            Mail::to('test@example.com')->send(new ContactMessageMail($contact));

            $contact->makeHidden(['id', 'user_id', 'created_at', 'updated_at']);

            return helperJSONResponse(true, 'Your message has been sent successfully!', ['contact_message' => $contact], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/contact_messages/{id}",
    *     summary="Get single contact message",
    *     description="Display single contact message",
    *     tags={"Contact Message"},
    *     security={{"bearerAuth": {}}},
    *     operationId="single.contact.message",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Contact message id to show that contact message",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display single contact message",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single contact message"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="contact_message",
    *                     type="object",
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="full_name", type="string", example="Test8 contact"),
    *                         @OA\Property(property="email", type="string", example="te8@gmail.com"),
    *                         @OA\Property(property="message", type="string", example="Contact 8 Message"),
    *                         @OA\Property(
    *                             property="user",
    *                             type="object",
    *                             @OA\Property(property="id", type="integer", example=1),
    *                             @OA\Property(property="name", type="string", example="Test 2"),
    *                             @OA\Property(
    *                               property="role",
    *                                type="object",
    *                                   @OA\Property(property="role", type="string", example="user")
    *                             )
    *                         )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested contact message is not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested contact message is not available")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {

        $contactMessage = ContactMessage::with([
            'user' => function ($query) {
                $query->select('id', 'name', 'role_id')->with([
                    'role' => function ($roleQuery) {
                        $roleQuery->select('id', 'role');
                    }
                ]);
            }
        ])
        ->select('id', 'full_name', 'email', 'message', 'user_id')
        ->where('id', $id)
        ->first();

        if (!$contactMessage) {
            return helperJSONResponse(false, 'Requested contact message is not available', [], 400);
        }

        $contactMessage->makeHidden(['user_id']);
        
        if ($contactMessage->user) {
            $contactMessage->user->makeHidden(['role_id']);

            if ($contactMessage->user->role) {
                $contactMessage->user->role->makeHidden(['id']);
            }
        } else {
            $contactMessage->makeHidden(['user']);
        }

        return helperJSONResponse(true, 'Your single contact message', ['contact_message' => $contactMessage], 200);
    }

    /**
    * @OA\Post(
    *     path="/api/contact",
    *     summary="Create contact messages by guest user",
    *     description="Create contact messages by guest user",
    *     tags={"Contact Message"},
    *     operationId="create.contact.message",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"full_name", "email", "message"},
    *                   @OA\Property(
    *                       property="full_name",
    *                       type="string",
    *                       example="Test1 contact"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="te1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="message",
    *                       type="string",
    *                       example="Contact 1 Message"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"full_name", "email", "message"},
    *                   @OA\Property(
    *                       property="full_name",
    *                       type="string",
    *                       example="Test1 contact"
    *                   ),
    *                   @OA\Property(
    *                       property="email",
    *                       type="string",
    *                       example="te1@gmail.com"
    *                   ),
    *                   @OA\Property(
    *                       property="message",
    *                       type="string",
    *                       example="Contact 1 Message"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Your message has been sent successfully!",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your message has been sent successfully!"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="contact_messages",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="full_name", type="string", example="Test1 contact"),
    *                         @OA\Property(property="email", type="string", example="test1@gmail.com"),
    *                         @OA\Property(property="message", type="string", example="Contact 1 Message")
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "full_name": {"The full_name field is required.", "The name field must be at least 3 characters."},
    *                   "email": {"The email field is required.", "The email must be a valid email address."},
    *                   "message": {"The message field is required.", "The name field must be at least 10 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Contact message create failed or An error occurred",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Contact message create failed or An error occurred")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     )
    * )
    */
    public function guestUserstore(Request $request)
    {
        // This function is only created for swagger guest user contact message
        // The function store is used for both guest user and logged in user but URL's are different
    }
}
