<?php

use App\Http\Controllers\PayPalController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('testPaypal', function () {
    return view('prdouct_detail');
})->name('testPaypal');

Route::post('paypal', [PayPalController::class, 'payment'])->name('paypal');
Route::post('cancel', [PayPalController::class, 'paymentCancel'])->name('cancel.payment');
Route::post('success', [PayPalController::class, 'paymentSuccess'])->name('success.payment');