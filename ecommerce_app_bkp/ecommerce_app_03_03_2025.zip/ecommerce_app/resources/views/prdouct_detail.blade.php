<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Paypal</title>
</head>
<body>
    <h2>Product: Keyboard</h2>
    <h4>Price: $5</h4>

    <form action="{{ route('paypal') }}" method="post">
        @csrf
        <input type="hidden" name="price" value="5">
        <input type="hidden" name="product_name" value="Keyboard">
        <input type="hidden" name="quantity" value="2">
        <button type="submit">Pay with paypal</button>
    </form>
</body>
</html>