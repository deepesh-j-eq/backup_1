<?php

return [
    'stripe_pk' => env('STRIPE_TEST_PK'),
    'stripe_sk' => env('STRIPE_TEST_SK')
];
