<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Stripe\Exception\ApiErrorException;
use Stripe\StripeClient;

class StripePaymentController extends Controller
{
    protected $stripe;

    public function __construct(StripeClient $stripe)
    {
        $this->stripe = new StripeClient(config('stripe.stripe_sk'));
    }

    public function processPayment($newRequest)
    {
        try {
            if (!$newRequest || !is_array($newRequest) || empty($newRequest)) {
                return [
                    'status' => 'error',
                    'message' => 'Invalid request data.'
                ];
            }
    
            if (!isset($newRequest['order_id']) || $newRequest['order_id'] == '') {
                return [
                    'status' => 'error',
                    'message' => 'No order created, something went wrong!'
                ];
            }

            $orderData = Order::with([
                            'orderStatus:id,status',
                            'orderItems:id,order_id,product_id,quantity,price',
                            'orderItems.product:id,name'
                        ])->find($newRequest['order_id']);

            if (!$orderData) {
                return [
                    'status' => 'error',
                    'message' => 'No order available for process payment, something went wrong!'
                ];
            }

            return [
                'orderData' => $orderData
            ];



            if (!$products || !is_array($products) || empty($products)) {
                return [
                    'status' => 'error',
                    'message' => 'Invalid product data.'
                ];
            }

            $lineItems = [];
            $totalAmount = 0;

            foreach ($products as $product) {
                $lineItems[] = [
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => ['name' => $product['name']],
                        'unit_amount' => $product['price'] * 100
                    ],
                    'quantity' => $product['quantity'],
                ];
                $totalAmount += $product['price'] * $product['quantity'];
            }

            $customer = $this->stripe->customers->create([
                'name' => $newRequest->first_name,
                'email' => $newRequest->email
            ]);

            $paymentIntent = $this->stripe->paymentIntents->create([
                'amount' => $totalAmount * 100,
                'currency' => 'usd',
                'payment_method' => $newRequest->payment_method,
                'confirm' => true,
                'customer' => $customer->id,
                'automatic_payment_methods' => [
                    'enabled' => true,
                    'allow_redirects' => 'never'
                ]
            ]);

            $customerDetails = $this->stripe->customers->retrieve($paymentIntent->customer);

            $payment = Payment::create([
                'transaction_id' => $paymentIntent->id,
                'currency' => $paymentIntent->currency,
                'amount' => $paymentIntent->amount / 100,
                'payer_name' => $customerDetails->name ? $customerDetails->name : $request->first_name,
                'payer_email' => $customerDetails->email ? $customerDetails->email : $request->email,
                'payment_gateway' => 'Stripe',
                'payment_method' => $paymentIntent->payment_method ?? $request->payment_method
            ]);

            return [
                'status' => 'true',
                'paymentIntentId' => $paymentIntent->id,
                'paymentId' => $payment->id
            ];
        } catch (ApiErrorException $e) {
            $errorResponse = $e->getJsonBody();
            $errorData = $errorResponse['error'] ?? [];

            $paymentIntentId = $errorData['payment_intent']['id'] ?? null;
            $paymentStatus = $errorData['payment_intent']['decline_code'] ?? 'failed';
            $currency = $errorData['payment_intent']['currency'] ?? 'usd';
            $amount = isset($errorData['payment_intent']['amount']) ? ($errorData['payment_intent']['amount'] / 100) : 0;

            //$customerDetails = $errorData->customers->retrieve($paymentIntentId);

            $payment = Payment::create([
                'transaction_id' => $paymentIntentId,
                'currency' => $currency,
                'amount' => $amount,
                'payer_name' => $customerDetails->name ? $customerDetails->name : $request->first_name,
                'payer_email' => $customerDetails->email ? $customerDetails->email : $request->email,
                'payment_gateway' => 'Stripe',
                'payment_method' => $request->payment_method,
                'status' => $paymentStatus
            ]);

            return [
                'status' => 'error',
                'message' => 'Payment failed: ' . $e->getMessage()
            ];
        }
    }

    public function handleWebhook(Request $request)
    {
        try {
            $payload = $request->getContent();
            $event = json_decode($payload, true);

            $sigHeader = $request->header('Stripe-Signature');

            Log::info('Stripe Webhook Payload:', ['payload' => $payload]);
            Log::info('Stripe Webhook Event:', ['event' => $event]);
            Log::info('Stripe Webhook Signature:', ['signature' => $sigHeader]);

            $paymentIntentDetails = array();

            if (isset($event['type']) && isset($event['data']['object'])) {
                $paymentIntent = $event['data']['object'];
                if (!empty($paymentIntent['customer'])) {
                    try {
                        $customerDetails = $this->stripe->customers->retrieve($paymentIntent['customer']);
                    } catch (\Exception $e) {
                        Log::error('Failed to retrieve customer details: ' . $e->getMessage());
                    }
                }
                $customerDetails = $this->stripe->customers->retrieve($paymentIntent['customer']);

                /* $paymentIntentDetails = [
                    'payment_id' => $paymentIntent['id'],
                    'status' => $paymentIntent['status'],
                    'amount' => $paymentIntent['amount'] / 100,
                    'currency' => $paymentIntent['currency'],
                    'payment_method' => $paymentIntent['payment_method'] ?? $request->payment_method,
                    'payment_gateway' => 'Stripe',
                    'customer' => $customerDetails ? [
                        'id' => $customerDetails->id,
                        'name' => $customerDetails->name,
                        'email' => $customerDetails->email
                    ] : null
                ]; */

                $paymentDetails = Payment::find($paymentIntent['id']);
            }

            switch ($event['type'] ?? null) {
                case 'payment_intent.succeeded':
                    if (isset($paymentDetails) && $paymentDetails) {
                        $paymentDetails->update(['status' => $paymentIntent['status']]);
                    }

                    return [
                        'status' => 'true',
                        'paymentDetails' => $paymentDetails
                    ];
                case 'payment_intent.payment_failed':
                    if (isset($paymentDetails) && $paymentDetails) {
                        $paymentDetails->update(['status' => $paymentIntent['status']]);
                    }

                    return [
                        'status' => 'error',
                        'message' => 'Payment failed',
                        'paymentDetails' => $paymentDetails
                    ];
                default:
                    return [
                        'status' => 'error',
                        'message' => 'Invalid webhook event'
                    ];
            }
        } catch (ApiErrorException $e) {
            return [
                'status' => 'error',
                'message' => 'Payment failed: ' . $e->getMessage()
            ];
        }
    }
}
