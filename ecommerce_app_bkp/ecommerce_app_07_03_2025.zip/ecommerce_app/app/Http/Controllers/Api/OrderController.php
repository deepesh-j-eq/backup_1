<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            $ordersQuery = Order::with([
                'orderStatus:id,status',
                'payment:id,payment_gateway,transaction_id,status',
                'user:id,name',
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderItems.product:id,name'
            ]);

            if($user->isUser()) {
                $ordersQuery->where('user_id', $authenticatedUserId);
            }

            $orders = $ordersQuery->get();

            $formattedOrders = [];

            foreach ($orders as $order) {
                $formattedOrder = [
                    'id' => $order->id,
                    'total_amount' => $order->total_amount,
                    'payment_status' => $order->payment_status,
                    'user_id' => $order->user_id,
                    'updated_by' => $order->updated_by,
                    'created_at' => $order->created_at,
                    'updated_at' => $order->updated_at,
                    'payment' => [
                        'payment_gateway' => $order->payment->payment_gateway,
                        'transaction_id' => $order->payment->transaction_id,
                        'status' => $order->payment->status,
                    ],
                    'order_status' => [
                        'status' => $order->orderStatus->status,
                    ],
                    'user' => [
                        'name' => $order->user->name,
                    ],
                    'address' => $order->address,
                    'order_items' => []
                ];

                if($user->isUser()) {
                    unset($formattedOrder['user_id']);
                    unset($formattedOrder['updated_by']);
                    unset($formattedOrder['address']['id']);
                }
    
                foreach ($order->orderItems as $item) {
                    $orderItem = [
                        'quantity' => $item->quantity,
                        'price' => $item->price,
                        'order_id' => $item->order_id,
                        'sub_total' => number_format(($item->quantity * $item->price), 2),
                        'product' => [
                            'name' => $item->product->name,
                        ]
                    ];

                    if (!$user->isUser()) {
                        $orderItem['product_id'] = $item->product_id;
                        $orderItem['created_at'] = $item->created_at;
                        $orderItem['updated_at'] = $item->updated_at;
                    }

                    $formattedOrder['order_items'][] = $orderItem;
                }
    
                $formattedOrders[] = $formattedOrder;
            }

            if (empty($formattedOrders)) {
                return helperJSONResponse(false, 'Requested order is not available', [], 400);
            }

            return helperJSONResponse(true, 'All orders', ['orders' => $formattedOrders], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            $orderQuery = Order::with([
                            'orderStatus:id,status',
                            'payment:id,payment_gateway,transaction_id,status',
                            'user:id,name',
                            'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                            'orderItems.product:id,name'
                        ]);

            if($user->isUser()) {
                $orderQuery->where('user_id', $authenticatedUserId);
            }

            $orderDetails = $orderQuery->find($id);

            if (!$orderDetails) {
                return helperJSONResponse(false, 'Requested order is not available', [], 400);
            }

            if($user->isUser()) {
                $orderDetails->makeHidden(['user_id', 'order_status_id', 'updated_by']);
            }

            $orderDetails->orderStatus->makeHidden(['id']);
            $orderDetails->payment->makeHidden(['id']);
            $orderDetails->address->makeHidden(['id']);
            $orderDetails->user->makeHidden(['id']);

            foreach ($orderDetails->orderItems as $orderItem) {
                $orderItem->makeHidden(['id']);

                if($user->isUser()) {
                    $orderItem->makeHidden(['id', 'product_id', 'created_at', 'updated_at']);
                }
    
                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;
                $orderItem->sub_total = number_format($price * $quantity, 2);
    
                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            }

            return helperJSONResponse(true, 'Your single order', ['order_details' => $orderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $adminUser = auth('sanctum')->user();
            $adminUserId = $adminUser->id;

            $adminCheck = User::find($adminUserId);

            if(!$adminCheck->isAdmin()) {
                return helperJSONResponse(false, 'Unauthorize, admin has only access to update order', [], 403);
            }

            $validate = Validator::make($request->all(), [
                'order_status_id' => 'required|exists:order_statuses,id',
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $order = Order::find($id);

            if (!$order) {
                return helperJSONResponse(false, 'Requested order is not available for update', [], 400);
            }

            $paymentDetails = Payment::where('order_id', $id)->first();

            if (!$paymentDetails) {
                return helperJSONResponse(false, 'Payment details not found for this order', [], 400);
            }

            $allowedOrderStatuses = [];

            if ($paymentDetails->status === 'succeeded') {
                $allowedOrderStatuses = [
                    "Placed" => 1, 
                    "In Transit" => 3, 
                    "Shipped" => 4, 
                    "Completed" => 8
                ];
            } elseif ($paymentDetails->status === 'pending' || $paymentDetails->status === 'failed') {
                $allowedOrderStatuses = [
                    "Canceled" => 5, 
                    "Payment Failed" => 6
                ];
            } elseif ($paymentDetails->status === 'refunded') {
                $allowedOrderStatuses = [
                    "Refunded" => 7
                ];
            }

            if (!in_array($request->order_status_id, $allowedOrderStatuses)) {
                return helperJSONResponse(false, "Invalid order_status_id. Allowed values for order payment status '{$paymentDetails->status}' are: " . json_encode($allowedOrderStatuses), [], 400);
            }

            $updateOrderData = array();

            if ($request->order_status_id != $order->order_status_id) {
                $updateOrderData['order_status_id'] = $request->order_status_id;
            }

            if ($order->payment_status != $paymentDetails->status) {
                $updateOrderData['payment_status'] = $paymentDetails->status;
            }

            if (!empty($updateOrderData)) {
                $updateOrderData['updated_by'] = $adminUserId;
                $order->update($updateOrderData);
            }

            if ($paymentDetails->status === 'refunded' ||  ($paymentDetails->status === 'succeeded' && $order->order_status_id == 5)) {
                foreach ($order->orderItems as $orderItem) {
                    $product = Product::find($orderItem->product_id);

                    if ($product) {
                        // $product->quantity += $orderItem->quantity;
                        // $product->save();
                    }
                }
            }

            $updatedOrderDetails = Order::with([
                'orderStatus:id,status',
                'payment:id,payment_gateway,transaction_id,status',
                'user:id,name',
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderItems.product:id,name'
            ])->find($id);

            if (!$updatedOrderDetails) {
                return helperJSONResponse(false, 'Requested order is not available after update', [], 400);
            }

            $updatedOrderDetails->orderStatus->makeHidden(['id']);
            $updatedOrderDetails->payment->makeHidden(['id']);
            $updatedOrderDetails->address->makeHidden(['id']);
            $updatedOrderDetails->user->makeHidden(['id']);

            foreach ($updatedOrderDetails->orderItems as $orderItem) {
                $orderItem->makeHidden(['id']);
    
                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;
                $orderItem->sub_total = number_format($price * $quantity, 2);
    
                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            }

            return helperJSONResponse(true, 'Order updated successfully', ['order_details' => $updatedOrderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }

    public function ordersWithFilter(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                // 'order_status_id' => 'nullable|exists:order_statuses,id|required_without_all:payment_status',
                // 'payment_status' => 'nullable|string|in:pending,failed,successful,refunded|required_without_all:order_status_id',
                'order_status_id' => 'nullable|exists:order_statuses,id',
                'payment_status' => 'nullable|string|in:pending,failed,successful,refunded',
                'city' => 'nullable|string',
                'state' => 'nullable|string',
                'country' => 'nullable|string',
                'order_total_min' => 'nullable|integer|min:0',
                'order_total_max' => 'nullable|integer|min:0',
                'user_id' => 'nullable|exists:users,id'
            ]);

            if ($validate->fails()) {
                return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
            }

            $orderQuery = Order::query();
        
            if ($request->has('order_status_id') && $request->order_status_id !== null) {
                $orderQuery->where('order_status_id', $request->order_status_id);
            }
        
            if ($request->has('payment_status') && $request->payment_status !== null) {
                $orderQuery->whereHas('payment', function ($query) use ($request) {
                    $query->where('status', $request->payment_status);
                });
            }

            if ($request->has('city') && $request->city !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('city', 'LIKE', "%{$request->city}%");
                });
            }

            if ($request->has('state') && $request->state !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('state', 'LIKE', "%{$request->state}%");
                });
            }

            if ($request->has('country') && $request->country !== null) {
                $orderQuery->whereHas('address', function ($query) use ($request) {
                    $query->where('country', 'LIKE', "%{$request->country}%");
                });
            }

            if ($request->has('order_total_min') && $request->order_total_min !== null) {
                $orderQuery->where('total_amount', '>=', $request->order_total_min);
            }

            if ($request->has('order_total_max') && $request->order_total_max !== null) {
                $orderQuery->where('total_amount', '<=', $request->order_total_max);
            }

            $authenticatedUser = auth('sanctum')->user();
            $authenticatedUserId = $authenticatedUser->id;

            $user = User::find($authenticatedUserId);

            if($user->isUser()) {
                $orderQuery->where('user_id', $authenticatedUserId);
            }

            if($user->isAdmin()) {
                if ($request->has('user_id') && $request->user_id !== null) {
                    $orderQuery->where('user_id', $request->user_id);
                }
            }

            $orderDetails = $orderQuery->with([
                'orderStatus:id,status',
                'payment:id,payment_gateway,transaction_id,status',
                'user:id,name',
                'address:id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email,order_id',
                'orderItems.product:id,name'
            ])->get();

            if ($orderDetails->isEmpty()) {
                return helperJSONResponse(true, 'Sorry! No order available, please apply different filter', [], 200);
            }

            foreach ($orderDetails as $order) {
                if($user->isUser()) {
                    $order->makeHidden(['order_status_id', 'user_id', 'updated_by']);
                }

                $order->orderStatus->makeHidden(['id']);
                $order->payment->makeHidden(['id']);
                $order->user->makeHidden(['id']);
                $order->address->makeHidden(['id']);
    
                foreach ($order->orderItems as $orderItem) {
                    $orderItem->makeHidden(['id']);

                    if($user->isUser()) {
                        $orderItem->makeHidden(['id', 'product_id', 'created_at', 'updated_at']);
                    }
    
                    $price = (float) $orderItem->price;
                    $quantity = (int) $orderItem->quantity;
                    $orderItem->sub_total = number_format($price * $quantity, 2);
    
                    if ($orderItem->product) {
                        $orderItem->product->makeHidden(['id']);
                    }
                }
            }

            return helperJSONResponse(true, 'Orders after applying filters', ['order_details' => $orderDetails], 200);
        } catch (\Exception $e) {
            return helperJSONResponse(false, 'An error occurred: ' . $e->getMessage(), [], 500);
        }
    }
}
