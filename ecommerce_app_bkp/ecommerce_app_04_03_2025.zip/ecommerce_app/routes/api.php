<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\ColorController;
use App\Http\Controllers\Api\ContactMessageController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\OrderStatusController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\RatingController;
use App\Http\Controllers\Api\SizeController;
use App\Http\Controllers\Api\UserController;
use Illuminate\Support\Facades\Route;

Route::post('signup',[AuthController::class,'signup'])->name('signup');
Route::post('login', [AuthController::class, 'login'])->name('login');

Route::controller(RatingController::class)->group(function(){
    Route::get('ratings', 'index')->name('get.all.ratings');
    Route::get('ratings/{id}', 'show')->name('get.single.rating');
});

Route::post('contact', [ContactMessageController::class, 'store'])->name('create.contact.message');

Route::middleware('auth:sanctum')->group(function() {
    Route::post('logout', [AuthController::class, 'logout'])->name('logout');

    Route::controller(ProductController::class)->group(function(){
        Route::get('products', 'index')->name('get.all.products');
        Route::get('products/{id}', 'show')->name('get.single.product');

        Route::post('products_with_filter', 'productsWithFilter')->name('products.with.filter');
    });

    Route::match(['PUT', 'PATCH'], 'ratings/{id}', [RatingController::class, 'update'])->name('update.rating');

    Route::controller(OrderController::class)->group(function(){
        Route::get('orders', 'index')->name('view.user.all.orders');
        Route::get('order/{id}', 'show')->name('view.user.single.order');
        Route::post('orders_with_filter', 'ordersWithFilter')->name('orders.with.filter');
    });

    Route::middleware('role:admin')->prefix('admin')->group(function () {
        Route::apiResource('category', CategoryController::class);
        Route::apiResource('sizes', SizeController::class);
        Route::apiResource('colors', ColorController::class);
        Route::apiResource('orderStatus', OrderStatusController::class);

        Route::controller(ProductController::class)->group(function(){
            Route::post('products', 'store')->name('store.product');
            Route::match(['PUT', 'PATCH'], 'products/{id}', 'update')->name('update.product');
            Route::delete('products/{id}', 'destroy')->name('delete.product');
        });

        Route::delete('ratings/{id}', [RatingController::class, 'destroy'])->name('delete.rating');

        Route::controller(OrderController::class)->group(function(){
            Route::match(['PUT', 'PATCH'], 'order/{id}', 'update')->name('update.order');
        });

        Route::controller(ContactMessageController::class)->group(function(){
            Route::get('contact_messages', 'index')->name('all.contact.messages');
            Route::get('contact_messages/{id}', 'show')->name('single.contact.message');
        });

        Route::controller(UserController::class)->group(function(){
            Route::get('users', 'index')->name('all.users');
            Route::get('users/{id}', 'show')->name('single.user');
        });
    });

    Route::middleware('role:user')->group(function () {
        Route::controller(CartController::class)->group(function(){
            Route::get('cart', 'viewCart')->name('view.cart.items');
            Route::post('cart/add', 'addToCart')->name('add.to.cart');
            Route::post('cart/changeQty/{id}', 'changeCartQuantity')->name('change.cart.qty');
            Route::delete('cart/{id}', 'removeFromCart')->name('remove.cart.item');
            Route::post('cart/removeCart', 'removeAllProductsFromCart')->name('remove.all.cart.items');
            Route::post('cart/checkout', 'checkout')->name('checkout');
        });

        Route::post('ratings', [RatingController::class, 'store'])->name('create.rating');

        Route::post('contact/authUser', [ContactMessageController::class, 'store'])->name('create.contact.message.auth.user');

        Route::controller(UserController::class)->group(function(){
            Route::get('profile', 'showUserProfile')->name('user.profile');
            Route::match(['PUT', 'PATCH'], 'updateUserProfile', 'updateUserProfile')->name('update.user.profile');
        });
    });
});
