<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = ['payment_gateway', 'transaction_id', 'amount', 'status', 'masked_card_number'];

    public function order()
    {
        return $this->hasOne(Order::class);
    }

    public function setMaskedCardNumberAttribute($value)
    {
        $lastFour = substr($value, -4);
        $this->attributes['masked_card_number'] = 'xxxx-xxxx-xxxx-' . $lastFour;
    }
}
