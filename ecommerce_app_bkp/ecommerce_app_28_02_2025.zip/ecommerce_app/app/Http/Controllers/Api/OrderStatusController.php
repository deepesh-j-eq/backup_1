<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\OrderStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderStatusController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $order_statuses = array();

        $order_statuses = OrderStatus::all();

        if($order_statuses->isEmpty()) {
            return helperJSONResponse(true, 'No order status created', [], 200);
        }

        return helperJSONResponse(true, 'All order status', ['order_statuses' => $order_statuses], 200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'status' => 'required|string|min:2|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
        }
        
        $orderStatus = OrderStatus::create([
            'status' => $request->status
        ]);

        if (!$orderStatus) {
            return helperJSONResponse(false, 'Order status create failed', [], 500);
        }

        return helperJSONResponse(true, 'Order status created successfully', ['order_status' => $orderStatus], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $order_status = array();

        $order_status['order_status'] = OrderStatus::select(
            'id',
            'status'
        )->where('id', $id)->first();

        if (!$order_status) {
            return helperJSONResponse(false, 'Requested order status is not available', [], 400);
        }

        return helperJSONResponse(true, 'Your single order status', ['order_status' => $order_status], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $orderStatus = OrderStatus::find($id);

        if (!$orderStatus) {
            return helperJSONResponse(false, 'Requested order status is not available for update', [], 400);
        }

        $validate = Validator::make($request->all(), [
            'status' => 'required|string|min:2|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
        }

        $updateOrderStatus = $orderStatus->update([
            'status' => $request->status
        ]);

        if (!$updateOrderStatus) {
            return helperJSONResponse(false, 'Order status update failed', [], 500);
        }

        $updatedOrderStatusData = array();
        $updatedOrderStatusData = OrderStatus::find($id);

        return helperJSONResponse(true, 'Order status updated successfully', ['order_status' => $updatedOrderStatusData], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $orderStatus = OrderStatus::find($id);

        if (!$orderStatus) {
            return helperJSONResponse(false, 'Requested order status is not available for delete', [], 400);
        }

        $orderStatus->delete();

        return helperJSONResponse(true, 'Order status deleted successfully', [], 200);
    }
}
