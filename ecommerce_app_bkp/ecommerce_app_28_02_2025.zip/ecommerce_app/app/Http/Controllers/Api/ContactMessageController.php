<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\ContactMessageMail;
use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class ContactMessageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $contact_messages = array();

        $contact_messages = ContactMessage::with(['user'])->get();

        if($contact_messages->isEmpty()) {
            return helperJSONResponse(true, 'No contact messages available', [], 200);
        }

        $contact_messages->transform(function ($contactMsg) {
            if($contactMsg->user == null) {
                $contactMsg->makeHidden(['user']);
            }
        
            return $contactMsg;
        });

        return helperJSONResponse(true, 'All contact messages', ['contact_messages' => $contact_messages], 200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'full_name' => 'required|string|max:191',
            'email' => 'required|email:rfc,dns|max:191',
            'message' => 'required|string|min:10|max:500'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
        }

        $user = auth('sanctum')->user();
        $userId = $user ? $user->id : null;

        $contact = ContactMessage::create([
            'full_name' => $request->full_name,
            'email' => $request->email,
            'message' => $request->message,
            'user_id' => $userId
        ]);

        if (!$contact) {
            return helperJSONResponse(false, 'Contact message create failed', [], 500);
        }

        Mail::to('test@example.com')->send(new ContactMessageMail($contact));

        return helperJSONResponse(true, 'Your message has been sent successfully!', ['contact_message' => $contact], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $contact_message = array();

        $contact_message = ContactMessage::with('user')
            ->select('id', 'full_name', 'email', 'message', 'user_id')
            ->where('id', $id)
            ->first();

        if (!$contact_message) {
            return helperJSONResponse(false, 'Requested contact message is not available', [], 400);
        }

        return helperJSONResponse(true, 'Your single contact message', ['contact_message' => $contact_message], 200);
    }
}
