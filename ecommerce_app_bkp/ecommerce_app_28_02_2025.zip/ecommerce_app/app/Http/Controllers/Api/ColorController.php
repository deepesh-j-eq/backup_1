<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Color;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ColorController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/colors",
    *     summary="Get all color attributes",
    *     description="Fetches all color attributes from the database",
    *     tags={"Color Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="colors.index",
    *     @OA\Response(
    *         response=200,
    *         description="All color attributes or No color attribute created",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="All color attributes or No color attribute created"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="color",
    *                     type="array",
    *                     @OA\Items(
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="color", type="string", example="Blue"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T08:19:36.000000Z")
    *                     )
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function index()
    {
        $color_attribute = array();
        $color_attribute = Color::all();

        if($color_attribute->isEmpty()) {
            return helperJSONResponse(true, 'No color attribute created', [], 200);
        }

        return helperJSONResponse(true, 'All color attributes', ['color' => $color_attribute], 200);
    }

    /**
     * Store a newly created resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/colors",
    *     summary="Create color attribute",
    *     description="Create color attribute",
    *     tags={"Color Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="colors.store",
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"color"},
    *                   @OA\Property(
    *                       property="color",
    *                       type="string",
    *                       example="Light Blue"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"color"},
    *                   @OA\Property(
    *                       property="color",
    *                       type="string",
    *                       example="Light Blue"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Color attribute created successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Color attribute created successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="color",
    *                     type="object",
    *                         @OA\Property(property="color", type="string", example="Light Blue"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-21T08:19:36.000000Z"),
    *                         @OA\Property(property="id", type="integer", example=1)
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "color": {"The color field is required.", "The color field must be at least 2 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Color attribute create failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Color create failed")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'color' => 'required|string|min:2|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
        }
        
        $colorAttribute = Color::firstOrCreate([
            'color' => $request->color
        ]);

        if (!$colorAttribute) {
            return helperJSONResponse(false, 'Color create failed', [], 500);
        }

        return helperJSONResponse(true, 'Color attribute created successfully', ['color' => $colorAttribute], 200);
    }

    /**
     * Display the specified resource.
     */

    /**
    * @OA\Get(
    *     path="/api/admin/colors/{id}",
    *     summary="Get single color attribute",
    *     description="Display single color attribute",
    *     tags={"Color Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="colors.show",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Color attribute id to show that color",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Display single color attribute",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Your single color attribute"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 nullable=true,
    *                 @OA\Property(
    *                     property="color",
    *                     type="object",
    *                         type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="color", type="string", example="Blue")
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested color attribute is not available",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Requested color attribute is not available")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function show(string $id)
    {
        $color_attribute = array();

        $color_attribute = Color::select(
            'id',
            'color'
        )->where('id', $id)->first();

        if (!$color_attribute) {
            return helperJSONResponse(false, 'Requested color attribute is not available', [], 400);
        }

        return helperJSONResponse(true, 'Your single color attribute', ['color' => $color_attribute], 200);
    }

    /**
     * Update the specified resource in storage.
     */

    /**
    * @OA\Post(
    *     path="/api/admin/colors/{id}",
    *     summary="Update color attribute",
    *     description="Update color attribute",
    *     tags={"Color Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="colors.update",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Color attribute id to update that color",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\RequestBody(
    *           required=true,
    *           @OA\MediaType(
    *               mediaType="multipart/form-data",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "color"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="color",
    *                       type="string",
    *                       example="Light Blue"
    *                   )
    *               )
    *           ),
    *           @OA\MediaType(
    *               mediaType="application/json",
    *               @OA\Schema(
    *                   type="object",
    *                   required={"_method", "color"},
    *                   @OA\Property(
    *                       property="_method",
    *                       type="string",
    *                       enum={"PUT", "PATCH"},
    *                       example="PUT",
    *                       description="Override HTTP method (Add method PUT or PATCH only)"
    *                   ),
    *                   @OA\Property(
    *                       property="color",
    *                       type="string",
    *                       example="Light Blue"
    *                   )
    *               )
    *           )
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Color attribute updated successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Color attribute updated successfully"),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="color",
    *                     type="object",
    *                         @OA\Property(property="id", type="integer", example=1),
    *                         @OA\Property(property="color", type="string", example="Light Blue"),
    *                         @OA\Property(property="created_at", type="string", example="2025-02-28T11:37:13.000000Z"),
    *                         @OA\Property(property="updated_at", type="string", example="2025-02-28T11:59:52.000000Z"),
    *                 )
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Validation error or Requested color attribute is not available for update",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Validation error | Requested color attribute is not available for update"
    *             ),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 nullable=true,
    *                 additionalProperties=true,
    *                 example={
    *                   "color": {"The color field is required.", "The color field must be at least 2 characters."}
    *                 }
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=500,
    *         description="Color attribute update failed",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(property="message", type="string", example="Color attribute update failed")
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function update(Request $request, string $id)
    {
        $colorAttribute = Color::find($id);

        if (!$colorAttribute) {
            return helperJSONResponse(false, 'Requested color attribute is not available for update', [], 400);
        }

        $validate = Validator::make($request->all(), [
            'color' => 'required|string|min:2|max:191'
        ]);

        if ($validate->fails()) {
            return helperJSONResponse(false, 'Validation error', $validate->errors(), 400);
        }

        $updateColor = $colorAttribute->update([
            'color' => $request->color
        ]);

        if (!$updateColor) {
            return helperJSONResponse(false, 'Color attribute update failed', [], 500);
        }

        $updatedColorAttribute = array();
        $updatedColorAttribute = Color::find($id);

        return helperJSONResponse(true, 'Color attribute updated successfully', ['color' => $updatedColorAttribute], 200);
    }

    /**
     * Remove the specified resource from storage.
     */

    /**
    * @OA\Delete(
    *     path="/api/admin/colors/{id}",
    *     summary="Delete color attribute",
    *     description="Delete color attribute",
    *     tags={"Color Attribute"},
    *     security={{"bearerAuth": {}}},
    *     operationId="colors.destroy",
    *     @OA\Parameter(
    *         name="id",
    *         in="path",
    *         required=true,
    *         description="Color attribute id to delete that color",
    *         @OA\Schema(type="integer")
    *     ),
    *     @OA\Response(
    *         response=200,
    *         description="Color attribute deleted successfully",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=true),
    *             @OA\Property(property="message", type="string", example="Color attribute deleted successfully")
    *         )
    *     ),
    *     @OA\Response(
    *         response=400,
    *         description="Requested color attribute is not available for delete",
    *         @OA\JsonContent(
    *             type="object",
    *             @OA\Property(property="status", type="boolean", example=false),
    *             @OA\Property(
    *                 property="message",
    *                 type="string",
    *                 example="Requested color attribute is not available for delete"
    *             )
    *         )
    *     ),
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *     @OA\Response(
    *         response=403,
    *         description="Forbidden",
    *         @OA\JsonContent(
    *             @OA\Property(property="message", type="string", example="Forbidden. Insufficient permissions.")
    *         )
    *     )
    * )
    */
    public function destroy(string $id)
    {
        $color = Color::find($id);

        if (!$color) {
            return helperJSONResponse(false, 'Requested color attribute is not available for delete', [], 400);
        }

        $color->delete();

        return helperJSONResponse(true, 'Color attribute deleted successfully', [], 200);
    }
}
