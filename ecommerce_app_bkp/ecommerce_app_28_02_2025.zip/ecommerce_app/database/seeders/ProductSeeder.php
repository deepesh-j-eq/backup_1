<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Color;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Size;
use Carbon\Carbon;
use Faker\Factory as Faker;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();
        $categories = Category::all();
        $sizes = Size::all()->pluck('id')->toArray();
        $colors = Color::all()->pluck('id')->toArray();
        
        foreach ($categories as $category) {
            for ($i = 0; $i < 3; $i++) {
                $product = Product::create([
                    'name' => substr($faker->sentence(3), 0, 150),
                    'description' => substr($faker->paragraph, 0, 150),
                    'price' => $faker->randomElement([100, 500, 600]),
                    'quantity' => $faker->numberBetween(1, 100),
                    'category_id' => $category->id
                ]);

                $product->sizes()->syncWithPivotValues(array_rand(array_flip($sizes), 2), ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
                $product->colors()->syncWithPivotValues(array_rand(array_flip($colors), 2), ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);

                for ($j = 0; $j < 2; $j++) {
                    $imageName = 'product_' . $product->id . '_' . ($j + 1) . '.jpg';
                    $imagePath = 'public/product_images/' . $imageName;

                    Storage::put($imagePath, file_get_contents($faker->imageUrl(640, 480, 'fashion')));
                    
                    ProductImage::create([
                        'product_id' => $product->id,
                        'image_path' => 'storage/product_images/' . $imageName
                    ]);
                }
            }
        }
    }
}
