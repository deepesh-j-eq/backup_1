<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Color;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Size;
use Carbon\Carbon;
use Faker\Factory as Faker;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();
        $categories = Category::all();
        $sizes = Size::all()->pluck('id')->toArray();
        $colors = Color::all()->pluck('id')->toArray();
        
        $k = 1;
        foreach ($categories as $category) {
            for ($i = 0; $i < 2; $i++) {
                $product = Product::create([
                    'name' => "Product_" . $this->formatCategoryName($category->name) . "_" . $k,
                    'description' => substr($faker->paragraph, 0, 100),
                    'price' => $faker->randomElement([100, 500, 600]),
                    'quantity' => $faker->numberBetween(1, 100),
                    'category_id' => $category->id
                ]);

                $product->sizes()->syncWithPivotValues(array_rand(array_flip($sizes), 2), ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);
                $product->colors()->syncWithPivotValues(array_rand(array_flip($colors), 2), ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);

                for ($j = 0; $j < 2; $j++) {
                    $imageName = 'product_' . $product->id . '_' . ($j + 1) . '.jpg';

                    Storage::disk('public')->put('product_images/' . $imageName, file_get_contents('https://picsum.photos/640/480'));

                    //Storage::put($imagePath, file_get_contents('https://picsum.photos/640/480'));
                    
                    ProductImage::create([
                        'product_id' => $product->id,
                        'image_path' => 'storage/product_images/' . $imageName
                    ]);
                }
                $k++;
            }
        }
    }

    public function formatCategoryName($name) {
        $name = preg_replace('/[\'"&$@!\-]/', '', $name);
    
        $name = str_replace(' ', '_', $name);
    
        return strtolower($name);
    }
}
