<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $orders = Order::with([
                'orderStatus:id,status',
                'user:id,name',
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderItems.product:id,name'
            ])->get();

            $formattedOrders = [];

            foreach ($orders as $order) {
                $formattedOrder = [
                    'id' => $order->id,
                    'total_amount' => $order->total_amount,
                    'payment_status' => $order->payment_status,
                    'user_id' => $order->user_id,
                    'created_at' => $order->created_at,
                    'updated_at' => $order->updated_at,
                    'order_status' => [
                        'status' => $order->orderStatus->status,
                    ],
                    'user' => [
                        'name' => $order->user->name,
                    ],
                    'address' => $order->address,
                    'order_items' => []
                ];
    
                foreach ($order->orderItems as $item) {
                    $formattedOrder['order_items'][] = [
                        'product_id' => $item->product_id,
                        'quantity' => $item->quantity,
                        'price' => $item->price,
                        'order_id' => $item->order_id,
                        'created_at' => $item->created_at,
                        'updated_at' => $item->updated_at,
                        'sub_total' => number_format(($item->quantity * $item->price), 2),
                        'product' => [
                            'name' => $item->product->name,
                        ],
                    ];
                }
    
                $formattedOrders[] = $formattedOrder;
            }

            if (empty($formattedOrders)) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available'
                ], 400);
            }

            return response()->json([
                'status' => true,
                'message' => 'All orders',
                'data' => ['orders' => $formattedOrders],
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $orderDetails = Order::with([
                'orderStatus:id,status',
                'user:id,name',
                'address' => function ($query) {
                    $query->select(
                        'first_name',
                        'last_name',
                        'address_line_1',
                        'apartment',
                        'address_line_2',
                        'city',
                        'country',
                        'state',
                        'postal_code',
                        'phone',
                        'email',
                        'order_id'
                    );
                },
                'orderItems' => function ($query) {
                    $query->with(['product:id,name']);
                }
            ])->find($id);

            if (!$orderDetails) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available'
                ], 400);
            }

            $orderDetails->orderStatus->makeHidden(['id']);
            $orderDetails->user->makeHidden(['id']);

            foreach ($orderDetails->orderItems as $orderItem) {
                $orderItem->makeHidden(['id']);
    
                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;
                $orderItem->sub_total = number_format($price * $quantity, 2);
    
                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            }

            return response()->json([
                'status' => true,
                'message' => 'Your single order',
                'data' => ['order_details' => $orderDetails]
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function ordersByStatus(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'order_status_id' => 'nullable|integer|exists:order_statuses,id|required_without_all:payment_status',
                'payment_status' => 'nullable|string|in:pending,failed,successful,refunded|required_without_all:order_status_id'
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $query = Order::query();
        
            if ($request->has('order_status_id') && $request->order_status_id !== null) {
                $query->where('order_status_id', $request->order_status_id);
            }
        
            if ($request->has('payment_status') && $request->payment_status !== null) {
                $query->where('payment_status', $request->payment_status);
            }

            $orderDetails = $query->with([
                'orderStatus:id,status',
                'user:id,name',
                'address' => function ($query) {
                    $query->select(
                        'first_name',
                        'last_name',
                        'address_line_1',
                        'apartment',
                        'address_line_2',
                        'city',
                        'country',
                        'state',
                        'postal_code',
                        'phone',
                        'email',
                        'order_id'
                    );
                },
                'orderItems' => function ($query) {
                    $query->with(['product:id,name']);
                }
            ])->get();

            if ($orderDetails->isEmpty()) {
                return response()->json([
                    'status' => true,
                    'message' => 'Sorry! No order available, please apply different filter'
                ], 200);
            }

            foreach ($orderDetails as $order) {
                $order->orderStatus->makeHidden(['id']);
                $order->user->makeHidden(['id']);
    
                foreach ($order->orderItems as $orderItem) {
                    $orderItem->makeHidden(['id']);
    
                    $price = (float) $orderItem->price;
                    $quantity = (int) $orderItem->quantity;
                    $orderItem->sub_total = number_format($price * $quantity, 2);
    
                    if ($orderItem->product) {
                        $orderItem->product->makeHidden(['id']);
                    }
                }
            }

            return response()->json([
                'status' => true,
                'message' => 'Orders after applying filters',
                'data' => ['order_details' => $orderDetails]
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $admin = auth('sanctum')->user();
            $admin_id = $admin->id;

            $checkAdmin = User::find($admin_id);

            if(!$checkAdmin->isAdmin()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Unauthorize, admin has only access to update order'
                ], 403);
            }

            $validate = Validator::make($request->all(), [
                'order_status_id' => 'required|integer|exists:order_statuses,id',
            ]);
            

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $order = Order::find($id);

            if (!$order) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available for update'
                ], 400);
            }

            $paymentDetails = Payment::where('order_id', $id)->first();

            if (!$paymentDetails) {
                return response()->json([
                    'status' => false,
                    'message' => 'Payment details not found for this order'
                ], 400);
            }

            $orderStatusAllowed = array();

            if ($paymentDetails->status === 'successful') {
                $orderStatusAllowed = ["Placed" => 1, "In Transit" => 3, "Shipped" => 4, "Completed" => 8]; // 1 - Placed, 3 - In Transit, 4 - Shipped, 8 - Completed
            } elseif ($paymentDetails->status === 'pending' || $paymentDetails->status === 'failed') {
                $orderStatusAllowed = ["Canceled" => 5, "Payment Failed" => 6]; // 5 - Canceled, 6 - Payment Failed
            } elseif ($paymentDetails->status === 'refunded') {
                $orderStatusAllowed = ["Refunded" => 7]; // 7 - Refunded
            }

            if (!in_array($request->order_status_id, $orderStatusAllowed)) {
                return response()->json([
                    'status' => false,
                    'message' => "Invalid order_status_id. Allowed values for order payment status '{$paymentDetails->status}' are: " . json_encode($orderStatusAllowed)
                ], 400);
            }

            $updateOrderData = array();

            if ($request->order_status_id != $order->order_status_id) {
                $updateOrderData['order_status_id'] = $request->order_status_id;
            }

            if ($order->payment_status != $paymentDetails->status) {
                $updateOrderData['payment_status'] = $paymentDetails->status;
            }

            if (!empty($updateOrderData)) {
                $updateOrderData['updated_by'] = $admin_id;
                $order->update($updateOrderData);
            }

            if ($paymentDetails->status === 'refunded' ||  ($paymentDetails->status === 'successful' && $order->order_status_id == 5)) {
                foreach ($order->orderItems as $orderItem) {
                    $product = Product::find($orderItem->product_id);

                    if ($product) {
                        // $product->quantity += $orderItem->quantity;
                        // $product->save();
                    }
                }
            }

            $updatedOrderDetails = Order::with([
                'orderStatus:id,status',
                'user:id,name',
                'address' => function ($query) {
                    $query->select(
                        'first_name',
                        'last_name',
                        'address_line_1',
                        'apartment',
                        'address_line_2',
                        'city',
                        'country',
                        'state',
                        'postal_code',
                        'phone',
                        'email',
                        'order_id'
                    );
                },
                'orderItems' => function ($query) {
                    $query->with(['product:id,name']);
                }
            ])->find($id);

            if (!$updatedOrderDetails) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available after update'
                ], 400);
            }

            $updatedOrderDetails->orderStatus->makeHidden(['id']);
            $updatedOrderDetails->user->makeHidden(['id']);

            foreach ($updatedOrderDetails->orderItems as $orderItem) {
                $orderItem->makeHidden(['id']);
    
                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;
                $orderItem->sub_total = number_format($price * $quantity, 2);
    
                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            }

            return response()->json([
                'status' => true,
                'message' => 'Order updated successfully',
                'data' => ['order_details' => $updatedOrderDetails]
            ], 200);            
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function viewAllOrder()
    {
        try {
            $user = auth('sanctum')->user();
            $user_id = $user->id;

            $orders = Order::with([
                'orderStatus:id,status',
                'address' => function ($query) {
                    $query->select(
                        'order_id',
                        'first_name',
                        'last_name',
                        'address_line_1',
                        'apartment',
                        'address_line_2',
                        'city',
                        'country',
                        'state',
                        'postal_code',
                        'phone',
                        'email'
                    );
                },
                'user:id,name',
                'orderItems' => function ($query) {
                    $query->with(['product:id,name']);
                }
            ])->where('user_id', $user_id)->get();

            if ($orders->isEmpty()) {
                return response()->json([
                    'status' => false,
                    'message' => 'No orders, keep shoppping!'
                ], 400);
            }

            $processedOrders = [];
            foreach ($orders as $order) {
                $processedOrder = [
                    'id' => $order->id,
                    'total_amount' => $order->total_amount,
                    'payment_status' => $order->payment_status,
                    'created_at' => $order->created_at,
                    'updated_at' => $order->updated_at,
                    'order_status' => [
                        'status' => $order->orderStatus->status
                    ],
                    'user' => [
                        'name' => $order->user->name
                    ],
                    'address' => $order->address,
                    'order_items' => []
                ];

                foreach ($order->orderItems as $item) {
                    $processedOrder['order_items'][] = [
                        'quantity' => $item->quantity,
                        'price' => $item->price,
                        'order_id' => $item->order_id,
                        'created_at' => $item->created_at,
                        'updated_at' => $item->updated_at,
                        'sub_total' => number_format(($item->quantity * $item->price), 2),
                        'product' => [
                            'name' => $item->product->name
                        ]
                    ];
                }

                $processedOrders[] = $processedOrder;
            }
            
            return response()->json([
                'status' => true,
                'message' => 'All orders',
                'data' => ['orders' => $processedOrders]
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function showSingleOrder(string $id)
    {
        try {
            $user = auth('sanctum')->user();
            $user_id = $user->id;

            $orderDetails = Order::with([
                'orderStatus:id,status',
                'user:id,name',
                'address' => function ($query) {
                    $query->select(
                        'order_id',
                        'first_name',
                        'last_name',
                        'address_line_1',
                        'apartment',
                        'address_line_2',
                        'city',
                        'country',
                        'state',
                        'postal_code',
                        'phone',
                        'email'
                    );
                },
                'orderItems' => function ($query) {
                    $query->with(['product:id,name']);
                }
            ])->where('user_id', $user_id)->find($id);

            if (!$orderDetails) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available'
                ], 400);
            }

            $orderDetails->makeHidden(['user_id']);
            $orderDetails->orderStatus->makeHidden(['id']);
            $orderDetails->user->makeHidden(['id']);
    
            $orderDetails->orderItems->each(function ($orderItem) {
                $orderItem->makeHidden(['id']);
                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;

                $orderItem->sub_total = $price * $quantity;

                $orderItem->sub_total = number_format($orderItem->sub_total, 2);

                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            });

            return response()->json([
                'status' => true,
                'message' => 'Your single order',
                'data' => ['order_details' => $orderDetails]
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }
}
