<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function signup(Request $request){
        $validateUser = Validator::make(
            $request->all(), 
            [
                'name'=>'required|max:191',
                'email' => 'required|email:rfc,dns|unique:users,email',
                'password'=>'required|min:5|max:50|same:confirm_password'
            ]);

            if ($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation Error',
                    'errors' => $validateUser->errors()
                ],401);
            }

            $userRoleId = Role::where('role', 'user')->pluck('id')->first();
           
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
                'role_id' => $userRoleId
            ]);

            $user->makeHidden(['id', 'role_id']);

            return response()->json([
                'status'=> true,
                'message'=>'User created successfully',
                'errors'=>$user
            ],200);
    }

    public function login (Request $request) {
        $validateUser = Validator::make($request->all(), [
            'email' => 'required|email:rfc,dns',
            'password' => 'required|min:5|max:50'
        ]);

        if ($validateUser->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validateUser->errors()
            ], 400);
        }

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $authUser = Auth::user();
            $user_id = $authUser->id;

            $user = User::with('role')->find($user_id);
            $userRole = $user->role->role ?? null;

            return response()->json([
                'status' => true,
                'message' => $userRole . ' Logged in successfully',
                'token' => $authUser->createToken("API Token")->plainTextToken,
                'token_type' => 'bearer',
                'user_type' => $userRole
            ], 200);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'Email and Password does not matched'
            ], 401);
        }
    }

    public function logout (Request $request) {
        $authUser = Auth::user();

        if ($authUser) {
            $authUser->tokens()->delete();

            return response()->json([
                'status' => true,
                'message' => 'Logged out successfully'
            ], 200);
        }

        return response()->json([
            'status' => false,
            'message' => 'User not authenticated'
        ], 401);
    }
}
