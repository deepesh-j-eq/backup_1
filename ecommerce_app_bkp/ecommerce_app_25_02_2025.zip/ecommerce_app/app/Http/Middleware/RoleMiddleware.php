<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, $role): Response
    {
        if (!Auth::check()) {
            return response()->json(['message' => 'Unauthorized. Please log in.'], Response::HTTP_UNAUTHORIZED);
        }

        if ($request->user()->role->role !== $role) {
            return response()->json(['message' => 'Forbidden. Insufficient permissions.'], Response::HTTP_FORBIDDEN);
        }

        return $next($request);
    }
}
