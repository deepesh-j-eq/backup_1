<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $orders = Order::with([
                'order_statuses',
                'users'
            ])->get();

            $data['orders'] = $orders;
            
            return response()->json([
                'status' => true,
                'message' => 'All orders',
                'data' => $data,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'phone' => 'required|string|max:191',
            'email' => 'required|email:rfc,dns|max:191',
            'first_name' => 'required|string|max:191',
            'last_name' => 'required|string|max:191',
            'address_line_1' => 'required|string|max:191',
            'apartment' => 'nullable|string|max:191',
            'address_line_2' => 'nullable|string|max:191',
            'city' => 'required|string|max:191',
            'country' => 'required|string|max:191',
            'state' => 'required|string|max:191',
            'postal_code' => 'required|integer'
        ]);

        /* if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }
        
        $sizeAttribute = Size::create([
            'size' => $request->size
        ]);

        if (!$sizeAttribute) {
            return response()->json([
                'status' => false,
                'message' => 'Size create failed'
            ], 500);
        }

        return response()->json([
            'status' => true,
            'message' => 'Size attribute created successfully',
            'size' => $sizeAttribute
        ], 200);
        $validate = Validator::make($request->all(), [
            'size' => 'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }
        
        $sizeAttribute = Size::create([
            'size' => $request->size
        ]);

        if (!$sizeAttribute) {
            return response()->json([
                'status' => false,
                'message' => 'Size create failed'
            ], 500);
        }

        return response()->json([
            'status' => true,
            'message' => 'Size attribute created successfully',
            'size' => $sizeAttribute
        ], 200);

        $validated = $request->validate([
            'phone' => 'required|string',
            'email' => 'required|email',
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'address_line_1' => 'required|string',
            'apartment' => 'nullable|string',
            'address_line_2' => 'nullable|string',
            'city' => 'required|string',
            'country' => 'required|string',
            'state' => 'required|string',
            'postal_code' => 'required|string',
        ]);

        $order = Order::create([
            'phone' => $validated['phone'],
            'email' => $validated['email'],
        ]);

        OrderAddress::create([
            'order_id' => $order->id,
            'first_name' => $validated['first_name'],
            'last_name' => $validated['last_name'],
            'address_line_1' => $validated['address_line_1'],
            'apartment' => $validated['apartment'],
            'address_line_2' => $validated['address_line_2'],
            'city' => $validated['city'],
            'country' => $validated['country'],
            'state' => $validated['state'],
            'postal_code' => $validated['postal_code'],
        ]); */
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
