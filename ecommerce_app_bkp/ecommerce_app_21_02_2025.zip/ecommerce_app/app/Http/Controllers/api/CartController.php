<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    public function viewCart(Request $request)
    {
        try {
            $user = auth('sanctum')->user();
            $data = array();

            $cartItems = Cart::with(['product' => function ($query) {
                                    $query->select(['id', 'name', 'description', 'price']);
                                        }])
                                    ->where('user_id', $user->id)
                                    ->get()
                                    ->makeHidden(['user_id']);

            $totalPrice = 0;

            $cartItems->transform(function ($item) use (&$totalPrice) {
                $price = (float) $item->product->price;
                $quantity = (int) $item->quantity;
                
                $item->sub_total = $price * $quantity;
                $totalPrice += $item->sub_total;

                $item->sub_total = number_format($item->sub_total, 2);
                
                return $item;
            });

            $data['cart_items'] = $cartItems;
            $data['total_price'] = number_format($totalPrice, 2);

            if ($data['cart_items']->isNotEmpty()) {
                return response()->json([
                    'status' => true,
                    'message' => 'Your cart',
                    'cart' => $data
                ], 200);
            }

            return response()->json([
                'status' => true,
                'message' => 'No product added to cart, keep shoppping!'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function addToCart(Request $request)
    {
        try {
            $validate = Validator::make($request->all(), [
                'product_id' => 'required|integer|exists:products,id',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $user = auth('sanctum')->user();
            $productId = $request->product_id;
            $quantity = $request->quantity;

            $product = Product::find($productId);
            if (!$product || $quantity > $product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not enough stock available for product ' . ($product->name ?? '')
                ], 400);
            }

            $cartItem = Cart::with(['product'])
                            ->where('user_id', $user->id)
                            ->where('product_id', $productId)
                            ->first();

            if ($cartItem) {
                $newQuantity = $cartItem->quantity + $quantity;

                if ($newQuantity > $product->quantity) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Not enough stock available for product ' . ($product->name ?? '') . '. You have already added avalaible ' . $cartItem->product->quantity . ' quantity'
                    ], 400);
                }

                $cartItem->update(['quantity' => $newQuantity]);
            } else {
                $cartItem = Cart::create([
                    'user_id' => $user->id,
                    'product_id' => $productId,
                    'quantity' => $quantity
                ]);
            }

            $cartItem->sub_total = number_format($cartItem->quantity * $product->price, 2);
            $cartItem->makeHidden(['user_id']);

            return response()->json([
                'status' => true,
                'message' => 'Product added to cart successfully',
                'cart' => $cartItem
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function changeCartQuantity(Request $request, $id)
    {
        try {
            $validate = Validator::make($request->all(), [
                'change_to' => 'required|string|in:up,down',
                'quantity' => 'required|integer|min:1',
            ]);

            if ($validate->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validate->errors()
                ], 400);
            }

            $user = auth('sanctum')->user();
            $data = array();

            $cartItem = Cart::with(['product'])
                        ->where('user_id', $user->id)
                        ->find($id);

            if (!$cartItem) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please choose correct product for update quantity'
                ], 400);
            }

            $changeTo = $request->change_to;
            $quantity = $request->quantity;
            if ($changeTo == 'up') {
                $newQuantity = $cartItem->quantity + $quantity;
            } else if ($changeTo == 'down') {
                $newQuantity = $cartItem->quantity - $quantity;
            }

            if ($newQuantity < 1) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please add correct qunatity of product, its not more than or eqal to ' . $cartItem->quantity
                ], 400);
            }

            if ($changeTo == 'up' && $cartItem->quantity == $cartItem->product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not enough stock available for product ' . ($cartItem->product->name ?? '') . '. You have already added avalaible ' . $cartItem->product->quantity . ' quantity'
                ], 400);
            }

            if ($newQuantity > $cartItem->product->quantity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Please add correct qunatity of product, its not more than ' . ($cartItem->product->quantity - $cartItem->quantity)
                ], 400);
            }

            $cartItem->update(['quantity' => $newQuantity]);

            $cart_item = Cart::with(['product' => function ($query) {
                                            $query->select(['id', 'name', 'description', 'price']);
                                        }])
                                    ->where('user_id', $user->id)
                                    ->find($id);
            
            $cart_item_price = (float) $cart_item->product->price;
            $cart_item_quantity = (int) $cartItem->quantity;

            $cart_item->sub_total = number_format($cart_item_price * $cart_item_quantity, 2);

            $cart_item->makeHidden(['user_id']);

            $data['cart_items'] = $cart_item;

            return response()->json([
                'status' => true,
                'message' => 'Product qunatity has been changed successfully',
                'cart' => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function removeFromCart(Request $request, $id)
    {
        try {
            $user = auth('sanctum')->user();

            $cartItem = Cart::where('user_id', $user->id)
                            ->find($id);

            if (!$cartItem) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested cart item not available for remove'
                ], 400);
            }

            $cartItem->delete();

            return response()->json([
                'status' => true,
                'message' => 'Cart item removed successfully',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    public function removeAllProductsFromCart(Request $request, $id)
    {
        try {
            $user = auth('sanctum')->user();

            $cartItems = Cart::where('user_id', $user->id);

            if ($cartItems->count() === 0) {
                return response()->json([
                    'status' => false,
                    'message' => 'No cart item available for remove'
                ], 400);
            }

            $cartItems->delete();

            return response()->json([
                'status' => true,
                'message' => 'All products are removed from cart successfully',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }
}
