<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\OrderStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderStatusController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = array();

        $data['order_statuses'] = OrderStatus::all();

        return response()->json([
            'staus' => true,
            'message' => 'All order status',
            'data' => $data,
        ],200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'status' => 'required|string|min:2|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }
        
        $orderStatus = OrderStatus::create([
            'status' => $request->status
        ]);

        if (!$orderStatus) {
            return response()->json([
                'status' => false,
                'message' => 'Order status create failed'
            ], 500);
        }

        return response()->json([
            'status' => true,
            'message' => 'Order status created successfully',
            'order_status' => $orderStatus
        ], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $data = array();

        $data['order_status'] = OrderStatus::select(
            'id',
            'status'
        )->where('id', $id)->first();

        if ($data['order_status'] == null) {
            return response()->json([
                'status' => false,
                'message' => 'Requested order status is not available'
            ], 400);
        }

        return response()->json([
            'status' => true,
            'message' => 'Your single order status',
            'data' => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $orderStatus = OrderStatus::find($id);

        if (!$orderStatus) {
            return response()->json([
                'status' => false,
                'message' => 'Requested order status is not available for update'
            ], 400);
        }

        $validate = Validator::make($request->all(), [
            'status' => 'required|string|min:2|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }

        $updateOrderStatus = OrderStatus::where('id', $id)->update([
            'status' => $request->status
        ]);

        if (!$updateOrderStatus) {
            return response()->json([
                'status' => false,
                'message' => 'Order status update failed'
            ], 500);
        }

        $data = array();
        $data['order_status'] = OrderStatus::find($id);

        return response()->json([
            'status' => true,
            'message' => 'Order status updated successfully',
            'data' => $data
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $orderStatus = OrderStatus::find($id);

        if (!$orderStatus) {
            return response()->json([
                'status' => false,
                'message' => 'Requested order status is not available for delete',
            ], 400);
        }

        $orderStatus->delete();

        return response()->json([
            'status' => true,
            'message' => 'Order status deleted successfully',
        ], 200);
    }
}
