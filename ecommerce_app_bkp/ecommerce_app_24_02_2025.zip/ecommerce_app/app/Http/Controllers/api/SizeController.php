<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Size;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SizeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = array();
        $data['size_attributes'] = Size::all();

        return response()->json([
            'staus' => true,
            'message' => 'All size attributes',
            'data' => $data,
        ],200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'size' => 'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }
        
        $sizeAttribute = Size::create([
            'size' => $request->size
        ]);

        if (!$sizeAttribute) {
            return response()->json([
                'status' => false,
                'message' => 'Size create failed'
            ], 500);
        }

        return response()->json([
            'status' => true,
            'message' => 'Size attribute created successfully',
            'size' => $sizeAttribute
        ], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $data = array();

        $data['size_attribute'] = Size::select(
            'id',
            'size'
        )->where('id', $id)->first();

        if ($data['size_attribute'] == null) {
            return response()->json([
                'status' => false,
                'message' => 'Requested size attribute is not available'
            ], 400);
        }

        return response()->json([
            'status' => true,
            'message' => 'Your single size attribute',
            'data' => $data
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $sizeAttribute = Size::find($id);

        if (!$sizeAttribute) {
            return response()->json([
                'status' => false,
                'message' => 'Requested size attribute is not available for update'
            ], 400);
        }

        $validate = Validator::make($request->all(), [
            'size' => 'required|string|max:191'
        ]);

        if ($validate->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validate->errors()
            ], 400);
        }          

        $updateSize = Size::where('id', $id)->update([
            'size' => $request->size
        ]);

        if (!$updateSize) {
            return response()->json([
                'status' => false,
                'message' => 'Size update failed'
            ], 500);
        }

        $data = array();
        $data['size_attribute'] = Size::find($id);

        return response()->json([
            'status' => true,
            'message' => 'Size attribute updated successfully',
            'data' => $data
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $size = Size::find($id);

        if (!$size) {
            return response()->json([
                'status' => false,
                'message' => 'Requested size attribute is not available for delete',
            ], 400);
        }

        $size->delete();

        return response()->json([
            'status' => true,
            'message' => 'Size attribute deleted successfully',
        ], 200);
    }
}
