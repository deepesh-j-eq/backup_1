<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $orders = Order::with([
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderStatus:id,status',
                'orderItems.product:id,name',
                'user:id,name'
            ])->get();

            $orders = Order::with([
                'address:id,order_id,first_name,last_name,address_line_1,apartment,address_line_2,city,country,state,postal_code,phone,email',
                'orderStatus:id,status',
                'orderItems.product:id,name'
            ])->get()->transform(function ($order) {
                return [
                    'id' => $order->id,
                    'total_amount' => $order->total_amount,
                    'payment_status' => $order->payment_status,
                    'user_id' => $order->user_id,
                    'created_at' => $order->created_at,
                    'updated_at' => $order->updated_at,
                    'address' => $order->address,
                    'order_status' => [
                        'status' => $order->orderStatus->status,
                    ],
                    'order_items' => $order->orderItems->transform(function ($item) {
                        return [
                            'quantity' => $item->quantity,
                            'price' => $item->price,
                            'order_id' => $item->order_id,
                            'created_at' => $item->created_at,
                            'updated_at' => $item->updated_at,
                            'sub_total' => number_format(($item->quantity * $item->price), 2),
                            'product' => [
                                'name' => $item->product->name,
                            ],
                        ];
                    }),
                ];
            });

            if (!$orders) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available'
                ], 400);
            }

            $data['orders'] = $orders;
            
            return response()->json([
                'status' => true,
                'message' => 'All orders',
                'data' => $data,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $data = array();

            $orderDetails = Order::with([
                'address' => function ($query) {
                    $query->select('first_name', 'last_name', 'address_line_1', 'apartment', 'address_line_2', 'city', 'country', 'state', 'postal_code', 'phone', 'email', 'order_id');
                },
                'orderStatus' => function ($query) {
                    $query->select('id', 'status');
                },
                'orderItems' => function ($query) {
                    $query->with(['product:id,name']);
                },
                'user:id,name'
            ])->find($id);

            if (!$orderDetails) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available'
                ], 400);
            }

            $orderDetails->orderStatus->makeHidden(['id']);
    
            $orderDetails->orderItems->each(function ($orderItem) {
                $orderItem->makeHidden(['id']);
                $price = (float) $orderItem->price;
                $quantity = (int) $orderItem->quantity;

                $orderItem->sub_total = $price * $quantity;

                $orderItem->sub_total = number_format($orderItem->sub_total, 2);

                if ($orderItem->product) {
                    $orderItem->product->makeHidden(['id']);
                }
            });

            $data['order_details'] = $orderDetails;

            if ($data['order_details'] == null) {
                return response()->json([
                    'status' => false,
                    'message' => 'Requested order is not available'
                ], 400);
            }

            return response()->json([
                'status' => true,
                'message' => 'Your single order',
                'data' => $data
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
