<?php

namespace Database\Seeders;

use App\Models\ProductAttribute;
use App\Models\ProductAttributeOption;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProductAttributeOptionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $attributeOptions = [
            'Color' => ['Red', 'Blue', 'Black'],
            'Size' => ['S', 'M', 'L']
        ];

        foreach ($attributeOptions as $attributeName => $options) {
            $productAttribute = ProductAttribute::where('attribute_name', $attributeName)->first();

            if ($productAttribute) {
                foreach ($options as $option) {
                    ProductAttributeOption::firstOrCreate([
                        'option' => $option,
                        'product_attribute_id' => $productAttribute->id
                    ]);
                }
            }
        }
    }
}
