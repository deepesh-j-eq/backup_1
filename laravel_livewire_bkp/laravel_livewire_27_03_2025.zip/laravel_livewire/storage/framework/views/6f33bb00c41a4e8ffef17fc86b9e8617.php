<!--favicon-->
<link rel="icon" href="<?php echo e(asset('assets/images/favicon-32x32.png')); ?>" type="image/png" />
<!--plugins-->
<link href="<?php echo e(asset('assets/plugins/vectormap/jquery-jvectormap-2.0.2.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet" />
<!-- loader-->
<link href="<?php echo e(asset('assets/css/pace.min.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(asset('assets/js/pace.min.js')); ?>"></script>
<!-- Bootstrap CSS -->
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/bootstrap-extended.css')); ?>" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet">
<!-- Theme Style CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dark-theme.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/semi-dark.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/header-colors.css')); ?>" /><?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\laravel_livewire\resources\views/components/layouts/linkcss.blade.php ENDPATH**/ ?>