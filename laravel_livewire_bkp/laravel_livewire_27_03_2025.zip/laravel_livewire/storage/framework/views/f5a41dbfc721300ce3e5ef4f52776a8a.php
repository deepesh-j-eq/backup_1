<?php $__env->startSection('title', 'Likes'); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col">
            <div class="input-group">
                <label for="like">Likes</label>
                <button class="btn btn-primary" wire:click="$set('var', <?php echo e($var - 1); ?>)">-</button>
                <input type="text" class="form-control" id="like" wire:model.live="var">
                <button class="btn btn-primary" wire:click="$set('var', <?php echo e($var + 1); ?>)">+</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\laravel_livewire\resources\views/livewire/likes.blade.php ENDPATH**/ ?>