<?php

namespace App\Livewire;

use App\Models\Product;
use Livewire\Component;
use Livewire\WithPagination;

class Products extends Component
{
    use WithPagination;

    public $priceRange;
    public $shortBy = 'newest';

    public $searchTerm  = '';

    protected $listeners = ['closeModal'];
    protected $paginationTheme = 'bootstrap';

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->shortBy = '';
        //$this->searchTerm = '';
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function setSortBy($sortBy)
    {
        $this->shortBy = $sortBy;
        $this->resetPage();
    }

    public function render()
    {
        $query = Product::with([
            'images' => function ($query) {
                $query->select(['id', 'image_path', 'product_id'])->limit(4);
            },
        ]);

        if (isset($this->shortBy) && $this->shortBy != '') {
            switch ($this->shortBy) {
                case 'most_popular':
                    $query->orderBy('popularity', 'desc');
                    break;
                case 'best_rating':
                    $query->withAvg('ratings', 'rating')->orderByDesc('ratings_avg_rating');
                    break;
                case 'newest':
                    $query->orderBy('created_at', 'desc');
                    break;
                case 'price_low_high':
                    $query->orderBy('price', 'asc');
                    break;
                case 'price_high_low':
                    $query->orderBy('price', 'desc');
                    break;
                default:
                    $query->orderBy('created_at', 'desc');
            }
        }

        $productDetails = $query
            ->where(function ($query) {
                $query->where('name', 'like', '%' . $this->searchTerm . '%')
                    ->orWhere('price', 'like', '%' . $this->searchTerm . '%')
                    ->orWhereHas('category', function ($query) {
                        $query->where('name', 'like', '%' . $this->searchTerm . '%');
                    });
            })
            ->latest()
            ->paginate(2);

        return view('livewire.products', compact('productDetails'));
    }
}
