<?php

namespace App\Livewire\Admin;

use App\Models\ProductAttribute;
use Livewire\Component;
use Livewire\WithPagination;

class ProductAttributesManager extends Component
{
    use WithPagination;

    public $attribute_name, $productAttributeId;
    public $modalFormVisible = false;
    public $deleteConfirmation = false;
    public $searchTerm  = '';

    protected $listeners = ['closeModal'];
    protected $paginationTheme = 'bootstrap';

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->attribute_name = '';
        $this->productAttributeId = null;

        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function updated($propertyName)
    {
        if (is_string($this->$propertyName)) {
            $this->$propertyName = trim($this->$propertyName);
        }
    }

    public function render()
    {
        $productAttributeDetails = ProductAttribute::where('attribute_name', 'like', '%' . $this->searchTerm . '%')
        ->latest()->paginate(5);

        return view('livewire.admin.product-attributes-manager', compact('productAttributeDetails'));
    }

    public function showCreateModal()
    {
        $this->resetFields();
        $this->modalFormVisible = true;
    }

    public function store()
    {
        $this->validate([
            'attribute_name' => 'required|string|max:255'
        ]);

        try {    
            $productAttribute = ProductAttribute::create([
                'attribute_name' => $this->attribute_name
            ]);
    
            if (!$productAttribute) {
                session()->flash('message', 'Product attribute creation failed.');
                $this->dispatch('showAlert', session('message'));
            }
    
            $this->resetFields();
            session()->flash('message', 'Product attribute created successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while creating product attribute. Error : ' . $e->getMessage());
        }
    }

    public function showEditModal($id)
    {
        $productAttribute = ProductAttribute::findorFail($id);
    
        if (!$productAttribute) {
            $this->resetFields();
            session()->flash('message', 'Requrested product attribute not available for update.');
            $this->dispatch('showAlert', session('message'));
        }

        $this->attribute_name = $productAttribute->attribute_name;
        $this->productAttributeId = $productAttribute->id;
        $this->modalFormVisible = true;
    }

    public function update()
    {
        $this->validate([
            'attribute_name' => 'required|string|max:255'
        ]);

        try {
            $productAttributeData = ProductAttribute::find($this->productAttributeId);
    
            if (!$productAttributeData) {
                $this->resetFields();
                session()->flash('message', 'Requrested product attribute not available for update.');
                $this->dispatch('showAlert', session('message'));
            }

            ProductAttribute::findOrFail($this->productAttributeId)->update([
                'attribute_name' => $this->attribute_name
            ]);
    
            $this->resetFields();
            session()->flash('message', 'Product attribute updated successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while updating product attribute. Error : ' . $e->getMessage());
        }
    }

    public function confirmDelete($id)
    {
        $this->productAttributeId = $id;
        $this->deleteConfirmation = true;
    }

    public function delete()
    {
        $productData = ProductAttribute::findOrFail($this->productAttributeId)->delete();

        if (!$productData) {
            $this->resetFields();
            session()->flash('message', 'Requested product attribute not available for delete');
        }

        $this->resetFields();
        session()->flash('message', 'Prpduct attribute deleted successfully.');
        $this->dispatch('showAlert', session('message'));
    }

    public function closeModal()
    {
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }
}
