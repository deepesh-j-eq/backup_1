@section('title', 'Products')

        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Products</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="card-body p-4">
                        <button class="btn btn-primary mb-3" wire:click="showProductCreateModal">Add Post</button>
                        <input type="text" wire:model.live.debounce.300ms="searchTerm" placeholder="Search products...">
                        <h5 class="card-title">Add New Product</h5>
                        <hr />
                        @if(session('error'))
                        <div class="alert alert-danger text-center">
                            {{ session('error') }}
                        </div>
                        @endif
                        @if(session('success'))
                        <div class="alert alert-success text-center">
                            {{ session('success') }}
                        </div>
                        @endif
                        {{-- @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif --}}
                        <div class="form-body mt-4">
                            <form action="{{ route('store.product') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="border border-3 p-4 rounded">
                                            <div class="mb-3">
                                                <label for="inputProductTitle" class="form-label">Product Name</label>
                                                <input type="text" class="form-control @error('name') is-invalid @enderror" id="inputProductTitle" placeholder="Enter product name" wire:model="name">
                                                @error('name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="mb-3">
                                                <label for="inputProductDescription" class="form-label">Description</label>
                                                <textarea class="form-control @error('description') is-invalid @enderror" id="inputProductDescription" rows="3" wire:model="description">{{ old('description') }}</textarea>
                                                @error('description')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="mb-3">
                                                <label for="image-uploadify" class="form-label">Product Images</label>
                                                <input class="form-control @error('images') is-invalid @enderror" id="image-uploadify" type="file" accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf" multiple wire:model="images">
                                                @error('images')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror

                                                @if ($images)
                                                    <div class="mt-2">
                                                        <h6>Preview:</h6>
                                                        @foreach ($images as $image)
                                                            <img src="{{ $image->temporaryUrl() }}" class="img-thumbnail" width="100">
                                                        @endforeach
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="border border-3 p-4 rounded">
                                            <div class="row g-3">
                                                <div class="col-md-6">
                                                    <label for="inputPrice" class="form-label">Price</label>
                                                    <input type="text" name="price" class="form-control @error('price') is-invalid @enderror" id="inputPrice" placeholder="100.00" wire:model="price">
                                                    @error('price')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="inputDiscountPrice" class="form-label">Discounted Price</label>
                                                    <input type="text" name="discounted_price" class="form-control @error('discounted_price') is-invalid @enderror" id="inputDiscountPrice" placeholder="50.00" wire:model="discounted_price">
                                                    @error('discounted_price')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                                <!-- <div class="col-md-6">
                                                <label for="inputCostPerPrice" class="form-label">Cost Per Price</label>
                                                <input type="email" class="form-control" id="inputCostPerPrice" placeholder="00.00">-->
                                            </div>
                                            <!-- <div class="col-md-6">
                                                <label for="inputStarPoints" class="form-label">Star Points</label>
                                                <input type="password" class="form-control" id="inputStarPoints" placeholder="00.00">
                                            </div> -->
                                                <div class="col-12">
                                                    <label for="inputQuantity" class="form-label">Quantity</label>
                                                    <input type="text" name="quantity" class="form-control @error('quantity') is-invalid @enderror" id="inputQuantity" placeholder="50.00" wire:model="quantity">
                                                    @error('quantity')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                                <div class="col-12">
                                                    <label for="inputCategory" class="form-label">Product Category</label>
                                                    <select name="category_id" class="form-select @error('category_id') is-invalid @enderror" id="inputCategory">
                                                        <option></option>
                                                        <option value="1">One</option>
                                                        <option value="2">Two</option>
                                                        <option value="3">Three</option>
                                                    </select>
                                                    @error('category_id')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                                <!-- <div class="col-12">
                                                <label for="inputProductType" class="form-label">Product Type</label>
                                                <select class="form-select" id="inputProductType">
                                                    <option></option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                            </div>
                                            <div class="col-12">
                                                <label for="inputVendor" class="form-label">Vendor</label>
                                                <select class="form-select" id="inputVendor">
                                                    <option></option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                            </div>
                                            <div class="col-12">
                                                <label for="inputCollection" class="form-label">Collection</label>
                                                <select class="form-select" id="inputCollection">
                                                    <option></option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                            </div>
                                            <div class="col-12">
                                                <label for="inputProductTags" class="form-label">Product Tags</label>
                                                <input type="text" class="form-control" id="inputProductTags" placeholder="Enter Product Tags">
                                            </div> -->
                                                <div class="col-12">
                                                    <div class="d-grid">
                                                        <button type="submit" class="btn btn-primary">Save Product</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end row-->
                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <!--end page wrapper -->