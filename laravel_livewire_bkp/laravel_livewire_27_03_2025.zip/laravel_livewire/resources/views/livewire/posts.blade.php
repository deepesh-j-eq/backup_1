@section('title', 'Posts')

    <div class="page-wrapper">
        <div class="page-content">
            <div class="container mt-5">
                <h2 class="mb-4">Posts</h2>
        
                @if (session()->has('message'))
                    <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                        {{ session('message') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif
        
                <button class="btn btn-primary mb-3" wire:click="showCreateModal">Add Post</button>
        
                <input type="text" wire:model.live.debounce.300ms="searchTerm" placeholder="Search posts...">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Title</th>
                            <th>Body</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($posts->isNotEmpty())
                            @foreach ($posts as $post)
                                <tr>
                                    <td>{{ $post->id }}</td>
                                    <td>{{ $post->title }}</td>
                                    <td>{{ $post->body }}</td>
                                    <td>
                                        <button class="btn btn-warning btn-sm" wire:click="showEditModal({{ $post->id }})">Edit</button>
                                        <button class="btn btn-danger btn-sm" wire:click="confirmDelete({{ $post->id }})">Delete</button>
                                    </td>
                                </tr>
                            @endforeach
                        @else
                        <tr>
                            <td colspan="4" style="text-align: center;">There is no post created, please create first</td>
                        </tr>
                        @endif
                    </tbody>
                </table>
        
                <div class="modal fade @if($modalFormVisible) show d-block @endif" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">{{ $postId ? 'Edit' : 'Create' }} Post</h5>
                                <button type="button" class="close" wire:click="$set('modalFormVisible', false)">&times;</button>
                            </div>
                            <div class="modal-body">
                                <input type="text" class="form-control mb-2" placeholder="Post Title" wire:model="title">
                                @error('title') <span class="alert alert-danger p-1" role="alert">{{ $message }}</span> @enderror
        
                                <textarea class="form-control mb-2" placeholder="Post Body" wire:model="body"></textarea>
                                @error('body') <span class="alert alert-danger p-1" role="alert">{{ $message }}</span> @enderror
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" wire:click="$set('modalFormVisible', false)">Cancel</button>
                                <button class="btn btn-primary" wire:click="{{ $postId ? 'update' : 'create' }}">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
        
                <div class="modal fade @if($deleteConfirmation) show d-block @endif" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Delete Post</h5>
                                <button type="button" class="close" wire:click="$set('deleteConfirmation', false)">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Are you sure you want to delete this post?</p>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" wire:click="$set('deleteConfirmation', false)">Cancel</button>
                                <button class="btn btn-danger" wire:click="delete">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
        
                <div class="mt-3">
                    {{ $posts->links() }}
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
        <script>
            function showAlert(message) {
                setTimeout(hideAlert, 3000);
            }

            function hideAlert() {
                let alertBox = document.getElementById('sessionAlert');
                if (alertBox) {
                    alertBox.style.display = 'none';
                }
            }

            Livewire.on('showAlert', (message) => {
                showAlert(message);
            });

            document.addEventListener("DOMContentLoaded", function () {
                if (typeof Livewire !== "undefined") {
                    document.addEventListener("keydown", function (event) {
                        if (event.key === "Escape") {
                            Livewire.first().call('closeModal');
                        }
                    });
                } else {
                    console.error("Livewire is not loaded. Ensure livewireScripts is included in your layout.");
                }
            });
        </script>
    @endpush
