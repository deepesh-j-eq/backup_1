<?php

namespace Database\Seeders;

use App\Models\ProductAttribute;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProductAttributesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $productAttributes = [
            ['attribute_name' => 'Color'],
            ['attribute_name' => 'Size'],
            ['attribute_name' => 'Brand']
        ];

        foreach($productAttributes as $productAttribute) {
            ProductAttribute::firstOrCreate($productAttribute);
        }
    }
}
