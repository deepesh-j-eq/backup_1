<?php

use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\HomeController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\GoogleController;
use App\Livewire\Admin\Category;
use App\Livewire\Admin\ProductAttributeOptionsManager;
use App\Livewire\Admin\ProductAttributesManager;
use App\Livewire\Admin\ProductManager;
use App\Livewire\Likes;
use App\Livewire\Posts;
use App\Livewire\ProductDetail;
use App\Livewire\Products;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('posts', Posts::class);
Route::get('likes', Likes::class);

Route::get('signin', [AuthController::class, 'signin'])->name('login');

Route::controller(GoogleController::class)->group(Function() {
    Route::get('auth/google', 'redirectToGoogle')->name('auth.google');
    Route::get('auth/google/callback', 'handleGoogleCallback');
});

Route::prefix('admin')->group(function() {
    Route::middleware('auth')->group(function() {
        Route::get('dashboard', [HomeController::class, 'index'])->name('admin.dashboard');

        Route::controller(GoogleController::class)->group(Function() {
            Route::get('google_login_details', 'googleLoginDetails')->name('admin.google.login.details');
            Route::get('auth/logout', 'googleLogout')->name('auth.logout');
        });

        Route::controller(UserController::class)->group(Function() {
            Route::get('yourProfile', 'yourProfile')->name('admin.your.profile');
        });

        Route::get('categories', Category::class)->name('admin.categories');
        Route::get('productAttributes', ProductAttributesManager::class)->name('admin.product.attributes');
        Route::get('productAttributeOptions', ProductAttributeOptionsManager::class)->name('admin.product.attribute.options');
        Route::get('manageProducts', ProductManager::class)->name('admin.products');

        Route::get('products', Products::class)->name('all.products');
        Route::get('productDetail/{productId}', ProductDetail::class)->name('product.detail');

        Route::controller(ProductController::class)->group(Function() {
            //Route::get('allProducts', 'index')->name('all.products');
            //Route::get('product', 'create')->name('create.product');
            //Route::post('product', 'store')->name('store.product');
        });
    });

    Route::controller(AuthController::class)->group(Function() {
        Route::get('signin', 'signin')->name('admin.signin');
        Route::post('login', 'login')->name('admin.login');

        Route::get('signup', 'signup')->name('admin.signup');
        Route::post('register', 'register')->name('admin.register');
    });
});