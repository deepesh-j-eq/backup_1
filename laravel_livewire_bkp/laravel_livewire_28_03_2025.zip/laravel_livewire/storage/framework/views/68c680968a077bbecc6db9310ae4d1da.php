<?php $__env->startSection('title', 'Product Attribute'); ?>
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Product Attribute Manager</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="card-body p-4">
                        <button class="btn btn-primary mb-3" wire:click="showCreateModal">Add Product Attribute</button>
                        <input type="text" class="form-control" wire:model.live.debounce.300ms="searchTerm" placeholder="Search product attributes...">
                        <h5 class="card-title">Product Attributes</h5>
                        <hr />
                        <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
                        <div class="alert alert-danger text-center">
                            <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
                        <div class="alert alert-success text-center">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                            <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                <?php echo e(session('message')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <?php if(session()->has('error_message')): ?>
                            <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                <?php echo e(session('error_message')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="table-responsive">
                            <table id="product_details_table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Attribute Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--[if BLOCK]><![endif]--><?php if($productAttributeDetails->isNotEmpty()): ?>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productAttributeDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productAttribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($productAttribute->id); ?></td>
                                                <td><?php echo e($productAttribute->attribute_name); ?></td>
                                                <td>
                                                    <button class="btn btn-warning btn-sm" wire:click="showEditModal(<?php echo e($productAttribute->id); ?>)">Edit</button>
                                                    <button class="btn btn-danger btn-sm" wire:click="confirmDelete(<?php echo e($productAttribute->id); ?>)">Delete</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="3" class="text-center">No product attribute details or no product attributes created</td>
                                        </tr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </tfoot>
                            </table>
                        </div>
                        
                        <!--[if BLOCK]><![endif]--><?php if($modalFormVisible): ?>
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title"><?php echo e($productAttributeId ? 'Edit' : 'Create'); ?> Product Attribute</h5>
                                            <button type="button" class="close" wire:click="$set('modalFormVisible', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form wire:submit.prevent="<?php echo e($productAttributeId ? 'update' : 'store'); ?>">
                                                <div class="form-group">
                                                    <label for="inputProductAttributeName" class="form-label">Product Attribute Name</label>
                                                    <input type="text" class="form-control <?php $__errorArgs = ['attribute_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputProductAttributeName" placeholder="Enter product attribute" wire:model="attribute_name">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['attribute_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" wire:click="$set('modalFormVisible', false)">Close</button>
                                                    <button type="submit" class="btn btn-primary"><?php echo e($productAttributeId ? 'Update' : 'Create'); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if($deleteConfirmation): ?>
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Delete Product Attribute</h5>
                                            <button type="button" class="close" wire:click="$set('deleteConfirmation', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete this product attribute?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" wire:click="$set('deleteConfirmation', false)">Cancel</button>
                                            <button class="btn btn-danger" wire:click="delete">Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div wire:ignore.self>
                            <?php echo e($productAttributeDetails->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->

        <?php $__env->startPush('scripts'); ?>
            <script>
                function showAlert(message) {
                    setTimeout(hideAlert, 5000);
                }

                function hideAlert() {
                    let alertBox = document.getElementById('sessionAlert');
                    if (alertBox) {
                        alertBox.style.display = 'none';
                    }
                }

                Livewire.on('showAlert', (message) => {
                    showAlert(message);
                });

                document.addEventListener("DOMContentLoaded", function () {
                    if (typeof Livewire !== "undefined") {
                        document.addEventListener("keydown", function (event) {
                            if (event.key === "Escape") {
                                Livewire.first().call('closeModal');
                            }
                        });
                    } else {
                        console.error("Livewire is not loaded. Ensure livewireScripts is included in your layout.");
                    }
                });
            </script>
        <?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\laravel_livewire\resources\views/livewire/admin/product-attributes-manager.blade.php ENDPATH**/ ?>