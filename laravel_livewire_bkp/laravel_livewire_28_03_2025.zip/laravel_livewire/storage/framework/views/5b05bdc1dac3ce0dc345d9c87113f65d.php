<?php $__env->startSection('title', 'Posts'); ?>

    <div class="page-wrapper">
        <div class="page-content">
            <div class="container mt-5">
                <h2 class="mb-4">Posts</h2>
        
                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                    <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        
                <button class="btn btn-primary mb-3" wire:click="showCreateModal">Add Post</button>
        
                <input type="text" wire:model.live.debounce.300ms="searchTerm" placeholder="Search posts...">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Title</th>
                            <th>Body</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php if($posts->isNotEmpty()): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($post->id); ?></td>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo e($post->body); ?></td>
                                    <td>
                                        <button class="btn btn-warning btn-sm" wire:click="showEditModal(<?php echo e($post->id); ?>)">Edit</button>
                                        <button class="btn btn-danger btn-sm" wire:click="confirmDelete(<?php echo e($post->id); ?>)">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center;">There is no post created, please create first</td>
                        </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
        
                <div class="modal fade <?php if($modalFormVisible): ?> show d-block <?php endif; ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title"><?php echo e($postId ? 'Edit' : 'Create'); ?> Post</h5>
                                <button type="button" class="close" wire:click="$set('modalFormVisible', false)">&times;</button>
                            </div>
                            <div class="modal-body">
                                <input type="text" class="form-control mb-2" placeholder="Post Title" wire:model="title">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="alert alert-danger p-1" role="alert"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        
                                <textarea class="form-control mb-2" placeholder="Post Body" wire:model="body"></textarea>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="alert alert-danger p-1" role="alert"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" wire:click="$set('modalFormVisible', false)">Cancel</button>
                                <button class="btn btn-primary" wire:click="<?php echo e($postId ? 'update' : 'create'); ?>">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
        
                <div class="modal fade <?php if($deleteConfirmation): ?> show d-block <?php endif; ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Delete Post</h5>
                                <button type="button" class="close" wire:click="$set('deleteConfirmation', false)">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Are you sure you want to delete this post?</p>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" wire:click="$set('deleteConfirmation', false)">Cancel</button>
                                <button class="btn btn-danger" wire:click="delete">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
        
                <div class="mt-3">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            /* function showAlert(message) {
                setTimeout(hideAlert, 3000);
            }

            function hideAlert() {
                let alertBox = document.getElementById('sessionAlert');
                if (alertBox) {
                    alertBox.style.display = 'none';
                }
            } */

            Livewire.on('showAlert', (message) => {
                showAlert(message);
            });

            document.addEventListener("DOMContentLoaded", function () {
                if (typeof Livewire !== "undefined") {
                    document.addEventListener("keydown", function (event) {
                        if (event.key === "Escape") {
                            Livewire.first().call('closeModal');
                        }
                    });
                } else {
                    console.error("Livewire is not loaded. Ensure livewireScripts is included in your layout.");
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\laravel_livewire\resources\views/livewire/posts.blade.php ENDPATH**/ ?>