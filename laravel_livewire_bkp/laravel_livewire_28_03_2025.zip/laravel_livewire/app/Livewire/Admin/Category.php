<?php

namespace App\Livewire\Admin;

use App\Models\Category as ModelsCategory;
use Livewire\Component;
use Livewire\WithPagination;

class Category extends Component
{
    use WithPagination;

    public $name, $categoryId;
    public $modalFormVisible = false;
    public $deleteConfirmation = false;
    public $searchTerm  = '';

    protected $listeners = ['closeModal'];
    protected $paginationTheme = 'bootstrap';

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->name = '';
        $this->categoryId = null;
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function render()
    {
        $categoryDetails = ModelsCategory::where('name', 'like', '%' . $this->searchTerm . '%')->latest()->paginate(5);

        return view('livewire.admin.category', compact('categoryDetails'));
    }

    public function showCreateModal()
    {
        $this->resetFields();
        $this->modalFormVisible = true;
    }

    public function store()
    {
        $this->validate([
            'name' => 'required|string|min:3|max:255'
        ]);

        try {
            $category = ModelsCategory::create([
                'name' => $this->name,
            ]);
    
            if (!$category) {
                session()->flash('message', 'Category creation failed.');
                $this->dispatch('showAlert', session('message'));
            }

            $this->resetFields();
            session()->flash('message', 'Category created successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while creating category. Error : ' . $e->getMessage());
        }
    }

    public function showEditModal($id)
    {
        $category = ModelsCategory::findorFail($id);

        $this->name = $category->name;
        $this->categoryId = $category->id;
        
        $this->modalFormVisible = true;
    }

    public function update()
    {
        $this->validate([
            'name' => 'required|string|min:3|max:255'
        ]);

        try {
            $categoryData = ModelsCategory::find($this->categoryId);

            if (!$categoryData) {
                $this->resetFields();
                session()->flash('message', 'Requrested category not available for update.');
            }

            ModelsCategory::findOrFail($this->categoryId)->update([
                'name' => $this->name
            ]);

            $this->resetFields();
            session()->flash('message', 'Category updated successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while updating category. Error : ' . $e->getMessage());
        }
    }

    public function confirmDelete($id)
    {
        $this->categoryId = $id;
        $this->deleteConfirmation = true;
    }

    public function delete()
    {
        ModelsCategory::findOrFail($this->categoryId)->delete();
        
        $this->resetFields();
        session()->flash('message', 'Category deleted successfully.');
        $this->dispatch('showAlert', session('message'));
    }

    public function closeModal()
    {
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }
}
