<?php

namespace App\Livewire;

use Livewire\Component;

class Likes extends Component
{
    public $var = 100;

    public function render()
    {
        return view('livewire.likes');
    }
}
