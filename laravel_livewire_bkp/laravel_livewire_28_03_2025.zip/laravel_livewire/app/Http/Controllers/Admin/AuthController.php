<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function signin()
    {
        return view('authentication.signin');
    }

    public function signup()
    {
        return view('authentication.signup');
    }

    public function register(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'nullable|string|max:255',
            'email' => 'required|email:rfc,dns|unique:users|max:255',
            'password' => 'required|min:3|max:12',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        if ($request->hasFile('image')) {
            $path = $request->image->store('user_images', 'public');
        }

        $user = User::updateOrCreate([
            'email' => $request->email,
        ], [
            'name' => trim($request->first_name . ' ' . $request->last_name),
            'password' => $request->password,
            'image' => $path ?? ''
        ]);

        if ($user) {
            session()->flash('success', 'Registration successfully, please login');

            //return redirect()->route('admin.signin')->with('success', 'Registration successfully, please login');
            return response()->json([
                'status' => 200,
                'message' => 'Registration successfully, please login',
                'redirect_url' => route('admin.signin')
            ]);
        }

        //return redirect()->route('admin.signin')->with('error', 'User registration failed, Something went wrong!');
        return response()->json([
            'status' => 422,
            'custom_error' => true,
            'message' => 'User registration failed, Something went wrong!'
        ], 422);
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email:rfc,dns|min:3|max:255',
            'password' => 'required|min:3|max:12'
        ]);

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            session()->flash('success', 'Login successful');

            //return redirect()->route('admin.dashboard')->with('success', 'Login successful');
            return response()->json([
                'status' => 200,
                'message' => 'Login successful',
                'redirect_url' => route('admin.dashboard')
            ]);
        } else {
            //return redirect()->route('admin.signin')->with('error', 'Email and Password do not match');
            return response()->json([
                'status' => 401,
                'custom_error' => true,
                'message' => 'Email and Password do not match'
            ], 401);
        }
    }
}
