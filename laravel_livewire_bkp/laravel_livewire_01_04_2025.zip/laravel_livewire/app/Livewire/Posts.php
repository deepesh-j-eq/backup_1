<?php

namespace App\Livewire;

use App\Models\Post;
use Livewire\Component;
use Livewire\WithPagination;

class Posts extends Component
{
    use WithPagination;

    public $title, $body, $postId;
    public $modalFormVisible = false;
    public $deleteConfirmation = false;
    public $searchTerm  = '';

    protected $listeners = ['closeModal'];
    protected $paginationTheme = 'bootstrap';

    protected $rules = [
        'title' => 'required|string|max:255',
        'body' => 'required|string'
    ];

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->title = '';
        $this->body = '';
        $this->postId = null;

        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function render()
    {
        return view('livewire.posts', [
            'posts' => Post::where('title', 'like', '%' . $this->searchTerm . '%')
                            ->orWhere('body', 'like', '%' . $this->searchTerm . '%')
                            ->latest()
                            ->paginate(5)
        ]);
    }

    public function showCreateModal()
    {
        $this->resetFields();
        $this->modalFormVisible = true;
    }

    public function create()
    {
        $this->validate();

        Post::create([
            'title' => $this->title,
            'body' => $this->body
        ]);
        //$this->modalFormVisible = false;
        $this->resetFields();
        session()->flash('message', 'Post created successfully.');
        $this->dispatch('showAlert', session('message'));
    }

    public function showEditModal($id)
    {
        $post = Post::findorFail($id);
        $this->title = $post->title;
        $this->body = $post->body;
        $this->postId = $post->id;
        $this->modalFormVisible = true;
    }

    public function update()
    {
        $this->validate([
            'title' => 'required|string|max:255',
            'body' => 'required|string'
        ]);

        Post::findOrFail($this->postId)->update([
            'title' => $this->title,
            'body' => $this->body
        ]);
        $this->resetFields();
        session()->flash('message', 'Post updated successfully.');
        $this->dispatch('showAlert', session('message'));
    }

    public function confirmDelete($id)
    {
        $this->postId = $id;
        $this->deleteConfirmation = true;
    }

    public function delete()
    {
        Post::findOrFail($this->postId)->delete();
        $this->resetFields();
        session()->flash('message', 'Post deleted successfully.');
        $this->dispatch('showAlert', session('message'));
    }

    public function closeModal()
    {
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }
}
