<?php

namespace App\Livewire\Admin;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductAttributeOption;
use App\Models\ProductImage;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class ProductManager extends Component
{
    use WithPagination, WithFileUploads;

    public $name, $description, $images, $price, $discounted_price, $quantity, $category_id, $existingImages, $product_attribute, $productId;
    public $modalFormVisible = false;
    public $deleteConfirmation = false;
    public $searchTerm  = '';
    public $selectedProductAttributes = [];
    public $selectedProductAttributeOptions = [];
    public $productAttrOptions = [];
    public $productAttributeOptions = [];
    public $errorMessages = [];

    protected $listeners = ['closeModal'];
    protected $paginationTheme = 'bootstrap';

    public function mount()
    {
        $this->resetFields();
        //$this->dispatch('refreshComponent');
    }

    public function resetFields()
    {
        $this->name = '';
        $this->description = '';
        $this->images = [];
        $this->price = '';
        $this->discounted_price = null;
        $this->quantity = '';
        $this->category_id = '';
        $this->productId = null;

        $this->selectedProductAttributes = [];
        $this->selectedProductAttributeOptions = [];
        $this->productAttrOptions = [];
        $this->errorMessages = [];

        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function updated($propertyName)
    {
        if (property_exists($this, $propertyName) && is_string($this->$propertyName)) {
            $this->$propertyName = trim($this->$propertyName);
        }
    }

    public function render()
    {
        $productDetails = Product::with([
            'images' => function ($query) {
                $query->select(['id', 'image_path', 'product_id'])->limit(4);
            },
            'category',
            'attributeOptions',
            'attributeOptions.productAttribute:id,attribute_name'
        ])
        ->where('name', 'like', '%' . $this->searchTerm . '%')
        ->orWhere('price', 'like', '%' . $this->searchTerm . '%')
        ->orWhereHas('category', function ($query) {
            $query->where('name', 'like', '%' . $this->searchTerm . '%');
        })
        ->orWhereHas('attributeOptions.productAttribute', function ($query) {
            $query->where('attribute_name', 'like', '%' . $this->searchTerm . '%');
        })
        ->orWhereHas('attributeOptions', function ($query) {
            $query->where('option', 'like', '%' . $this->searchTerm . '%');
        })
        ->latest()
        ->paginate(5);

        $categoryDetails = Category::all();
        $productAttributeDetails = ProductAttribute::all();
        $productAttributeOptionDetails = ProductAttributeOption::all();        

        return view('livewire.admin.product-manager', compact('productDetails', 'categoryDetails', 'productAttributeDetails', 'productAttributeOptionDetails'));
    }

    /* public function updatedSelectedProductAttributes()
    {
        $this->productAttrOptions = ProductAttributeOption::whereIn('product_attribute_id', $this->selectedProductAttributes)->get();
        //$this->dispatch('refreshDropdown');

        $this->selectedProductAttributeOptions = [];
    } */

    public function showCreateModal()
    {
        $this->resetFields();
        $this->modalFormVisible = true;
    }

    public function store()
    {
        $this->validate([
            'name' => 'required|string|min:3|max:255',
            'description' => 'required|string|max:255',
            'price' => 'required|numeric|min:1|regex:/^\d+(\.\d{1,2})?$/',
            'discounted_price' => [
                'nullable',
                'numeric',
                'min:0',
                'regex:/^\d+(\.\d{1,2})?$/',
                function ($attribute, $value, $fail) {
                    if ($value !== null && $value >= $this->price) {
                        $fail('The discounted price must be less than the original price.');
                    }
                }
            ],
            'quantity' => 'required|integer|min:0',
            'category_id' => 'required|exists:categories,id',
            'images' => 'required',
            'images.*' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'selectedProductAttributes' => 'required|array|min:1',
            'selectedProductAttributes.*' => 'exists:product_attributes,id',
            'selectedProductAttributeOptions' => 'required|array|min:1',
            'selectedProductAttributeOptions.*' => 'exists:product_attribute_options,id'

            /* 'attribute_options' => 'required|array',
            'attribute_options.*' => 'exists:product_attribute_options,id' */
        ], [
            'category_id.required' => 'Please select category.',
            'category_id.exists' => 'Selected category is invalid.'
        ]);

        try {
            if (!empty($this->selectedProductAttributes)) {
                $this->validateProductAttributeOptions();               
            }

            //dd($this->errorMessages);

            if (!empty($this->errorMessages)) {
                return;
            }

            //dd('test');

            $product = Product::create([
                'name' => $this->name,
                'description' => $this->description,
                'price' => $this->price,
                'discounted_price' => ($this->discounted_price) ? $this->discounted_price : null,
                'quantity' => $this->quantity,
                'category_id' => $this->category_id
            ]);
    
            if (!$product) {
                session()->flash('message', 'Product creation failed.');
                $this->dispatch('showAlert', session('message'));
            }
    
            if (!empty($this->images)) {
                foreach ($this->images as $image) {
                    $path = $image->store('product_images', 'public');
    
                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $product->id
                    ]);
                }
            }

            //dd($this->selectedProductAttributeOptions);

            /* if (!empty($this->selectedProductAttributes) && !empty($this->selectedProductAttributeOptions)) {
                foreach ($this->selectedProductAttributeOptions as $selectedProductAttrOptionId) {
                    ProductAttributeOption::create([
                        'product_id' => $product->id,
                        'product_attribute_option_id' => $selectedProductAttrOptionId,
                    ]);
                }
            } */

            /* if (!empty($this->selectedProductAttributes) && !empty($this->selectedProductAttributeOptions)) {
                foreach ($this->selectedProductAttributeOptions as $selectedProductAttrOptionId) {
                    ProductAttributeOption::create([
                        'product_id' => $product->id,
                        'product_attribute_option_id' => $selectedProductAttrOptionId,
                    ]);
                }
            } */

            $product->attributeOptions()->syncWithPivotValues($this->selectedProductAttributeOptions, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);

            /* foreach ($this->attribute_options as $option_id) {
                AttributeOption::create([
                    'product_id' => $product->id,
                    'product_attribute_option_id' => $option_id
                ]);
            } */

            $this->resetFields();
            session()->flash('message', 'Product created successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            dd($e->getMessage());
            $this->resetFields();
            session()->flash('error_message', 'Error occured while creating product. Error : ' . $e->getMessage());
        }
    }

    public function showEditModal($id)
    {
        $product = Product::with([
            'images' => function ($query) {
                $query->select(['id', 'image_path', 'product_id']);
            },
            'attributeOptions'
        ])->findorFail($id);

        $selectedProductAttributesForUpdate = [];
        $selectedProductAttributeOptionsForUpdate = [];
        if (!empty($product->attributeOptions)) {
            foreach ($product->attributeOptions as $attributeOptions) {
                $selectedProductAttributesForUpdate[] = $attributeOptions->product_attribute_id;
                $selectedProductAttributeOptionsForUpdate[] = $attributeOptions->id;
            }
        }

        if (!$product) {
            $this->resetFields();
            session()->flash('message', 'Requrested product not available for update.');
            $this->dispatch('showAlert', session('message'));
        }

        $this->name = $product->name;
        $this->description = $product->description;
        $this->existingImages = $product->images;
        $this->price = $product->price;
        $this->discounted_price = $product->discounted_price ?? '';
        $this->quantity = $product->quantity;
        $this->category_id = $product->category_id;
        $this->productId = $product->id;
        $this->selectedProductAttributes = (!empty($selectedProductAttributesForUpdate)) ? $selectedProductAttributesForUpdate : [];
        $this->selectedProductAttributeOptions = (!empty($selectedProductAttributeOptionsForUpdate)) ? $selectedProductAttributeOptionsForUpdate : [];
        
        $this->modalFormVisible = true;
    }

    public function update()
    {
        $this->validate([
            'name' => 'required|string|min:3|max:255',
            'description' => 'required|string|max:255',
            'price' => 'required|numeric|min:1|regex:/^\d+(\.\d{1,2})?$/',
            'discounted_price' => [
                'nullable',
                'numeric',
                'min:0',
                'regex:/^\d+(\.\d{1,2})?$/',
                function ($attribute, $value, $fail) {
                    if ($value !== null && $value >= $this->price) {
                        $fail('The discounted price must be less than the original price.');
                    }
                }
            ],
            'quantity' => 'required|integer|min:0',
            'category_id' => 'required|exists:categories,id',
            'images' => 'nullable|array',
            'images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'selectedProductAttributes' => 'required|array|min:1',
            'selectedProductAttributes.*' => 'exists:product_attributes,id',
            'selectedProductAttributeOptions' => 'required|array|min:1',
            'selectedProductAttributeOptions.*' => 'exists:product_attribute_options,id'
        ], [
            'category_id.required' => 'Please select category.',
            'category_id.exists' => 'Selected category is invalid.'
        ]);

        try {
            $productData = Product::find($this->productId);

            if (!$productData) {
                $this->resetFields();
                session()->flash('message', 'Requrested product not available for update.');
                $this->dispatch('showAlert', session('message'));
            }

            if (!empty($this->selectedProductAttributes)) {
                $this->validateProductAttributeOptions();               
            }

            if (!empty($this->errorMessages)) {
                return;
            }

            Product::findOrFail($this->productId)->update([
                'name' => $this->name,
                'description' => $this->description,
                'price' => $this->price,
                'discounted_price' => ($this->discounted_price) ? $this->discounted_price : null,
                'quantity' => $this->quantity,
                'category_id' => $this->category_id
            ]);

            if (!empty($this->images)) {
                foreach ($productData->images as $image) {
                    Storage::disk('public')->delete($image->image_path);
                    $image->delete();
                }

                foreach ($this->images as $image) {
                    $path = $image->store('product_images', 'public');

                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $productData->id
                    ]);
                }
            }

            $productData->attributeOptions()->syncWithPivotValues($this->selectedProductAttributeOptions, ['created_at' => Carbon::now(), 'updated_at' => Carbon::now()]);

            $this->resetFields();
            session()->flash('message', 'Product updated successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            dd($e->getMessage());
            $this->resetFields();
            session()->flash('error_message', 'Error occured while updating product. Error : ' . $e->getMessage());
        }
    }

    public function confirmDelete($id)
    {
        $this->productId = $id;
        $this->deleteConfirmation = true;
    }

    public function delete()
    {
        $productData = Product::find($this->productId);

        if (!$productData) {
            $this->resetFields();
            session()->flash('message', 'Requested product not available for delete');
        }

        foreach ($productData->images as $image) {
            Storage::disk('public')->delete($image->image_path);
            $image->delete();
        }

        $productData->delete();

        $this->resetFields();
        session()->flash('message', 'Prpduct deleted successfully.');
        $this->dispatch('showAlert', session('message'));
    }

    public function closeModal()
    {
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }

    private function getPrdouctAttributeOptions($productAttribute)
    {
        return ProductAttributeOption::select(['id', 'option'])->where('product_attribute_id', $productAttribute)->get();
    }

    private function getPrdouctAttributeName($productAttribute)
    {
        return ProductAttribute::where('id', $productAttribute)->pluck('attribute_name')->first();
    }

    protected function getAllPrdouctAttributeOptions()
    {
        return ProductAttributeOption::with('productAttribute:id,attribute_name')->get();
    }

    protected function validateProductAttributeOptions()
    {
        try {
            $allowedProductAttrOption = [];
            $attributeOptionsMap = [];
            $allowedOptionsByAttribute = [];
            $allProductAttributeOptions = [];
            $allProductAttributeOptionsByAttribute = [];
            $this->errorMessages = [];

            $productAttributeOptions = $this->getAllPrdouctAttributeOptions();

            if ($productAttributeOptions->isNotEmpty()) {
                foreach ($productAttributeOptions as $productAttributeOption) {
                    $attributeName = $productAttributeOption->productAttribute->attribute_name;
                    $optionId = $productAttributeOption->id;

                    if (!isset($allProductAttributeOptions[$attributeName])) {
                        $allProductAttributeOptions[$attributeName] = [];
                    }
                    $allProductAttributeOptions[$attributeName][] = $optionId;

                    if (!isset($allProductAttributeOptionsByAttribute[$attributeName])) {
                        $allProductAttributeOptionsByAttribute[$attributeName] = [];
                    }
                    $allProductAttributeOptionsByAttribute[$attributeName][$optionId] = $productAttributeOption->option;
                }
            }

            foreach ($this->selectedProductAttributes as $selectedProductAttribute) {
                $allowedAttributeOptions = $this->getPrdouctAttributeOptions($selectedProductAttribute);
                $attributeName = $this->getPrdouctAttributeName($selectedProductAttribute);

                if (!isset($allowedProductAttrOption[$attributeName])) {
                    $allowedProductAttrOption[$attributeName] = [];
                }

                foreach ($allowedAttributeOptions as $allowedOption) {
                    $allowedProductAttrOption[$attributeName][] = [
                        'id' => $allowedOption->id,
                        'option' => $allowedOption->option,
                    ];
                    $attributeOptionsMap[$allowedOption->id] = $attributeName;
                    $allowedOptionsByAttribute[$attributeName][$allowedOption->id] = $allowedOption->option;
                }
            }

            $selectedOptionsGroupedByAttribute = [];
            $wrongAttributeOptions = [];
            $wrongAttributeOptionsSelection = [];
            $missingAttributeOptions = [];

            if (!empty($this->selectedProductAttributeOptions)) {
                foreach ($this->selectedProductAttributeOptions as $optionId) {
                    if (isset($attributeOptionsMap[$optionId])) {
                        $attributeName = $attributeOptionsMap[$optionId];

                        if (!isset($selectedOptionsGroupedByAttribute[$attributeName])) {
                            $selectedOptionsGroupedByAttribute[$attributeName] = [];
                        }
                        $selectedOptionsGroupedByAttribute[$attributeName][] = $optionId;
                    } else {
                        $wrongAttributeOptions[] = $optionId;
                    }
                }
            }

            if (!empty($allowedProductAttrOption)) {
                foreach ($allowedProductAttrOption as $attributeName => $options) {
                    if (!isset($selectedOptionsGroupedByAttribute[$attributeName])) {
                        $missingAttributeOptions[$attributeName] = array_column($options, 'option');
                    }
                }
            }

            if (!empty($allProductAttributeOptions) && !empty($wrongAttributeOptions)) {
                foreach ($allProductAttributeOptions as $attributeName => $options) {
                    foreach ($options as $option) {
                        if (in_array($option, $wrongAttributeOptions)) {
                            if (!isset($wrongAttributeOptionsSelection[$attributeName])) {
                                $wrongAttributeOptionsSelection[$attributeName] = [];
                            }
                            $wrongAttributeOptionsSelection[$attributeName][] = $option;
                        }
                    }
                }
            }

            if (!empty($missingAttributeOptions)) {
                foreach ($missingAttributeOptions as $attributeName => $missingOptions) {
                    $this->errorMessages[] = sprintf(
                        'You have selected product attribute "%s", Please select available attribute options [%s]',
                        $attributeName,
                        implode(', ', $missingOptions)
                    );
                }
            }

            if (!empty($wrongAttributeOptionsSelection)) {
                foreach ($wrongAttributeOptionsSelection as $attributeName => $optionIds) {
                    $optionNames = array_map(function ($id) use ($allProductAttributeOptionsByAttribute, $attributeName) {
                        return isset($allProductAttributeOptionsByAttribute[$attributeName][$id])
                            ? $allProductAttributeOptionsByAttribute[$attributeName][$id]
                            : 'Unknown';
                    }, $optionIds);
        
                    $this->errorMessages[] = sprintf(
                        'You have selected wrong attribute options [%s] that belong to attribute "%s".',
                        implode(', ', $optionNames),
                        $attributeName
                    );
                }
            }
        } catch (\Exception $e) {
            dd($e->getMessage());
            $this->resetFields();
            session()->flash('error_message', 'Error occured while validating product attribute options. Error : ' . $e->getMessage());
        }
    }
}
