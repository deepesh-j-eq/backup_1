<?php

namespace App\Livewire\Admin;

use App\Models\ProductAttribute;
use App\Models\ProductAttributeOption;
use Livewire\Component;
use Livewire\WithPagination;

class ProductAttributeOptionsManager extends Component
{
    use WithPagination;

    public $option, $product_attribute_id, $productAttributeOptionId;
    public $modalFormVisible = false;
    public $deleteConfirmation = false;
    public $searchTerm  = '';

    protected $listeners = ['closeModal'];
    protected $paginationTheme = 'bootstrap';

    public function mount()
    {
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->option = '';
        $this->product_attribute_id = '';
        $this->productAttributeOptionId = null;

        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }

    public function updatingSearchTerm()
    {
        $this->resetPage();
    }

    public function updated($propertyName)
    {
        if (is_string($this->$propertyName)) {
            $this->$propertyName = trim($this->$propertyName);
        }
    }

    public function render()
    {
        $productAttributeOptionDetails = ProductAttributeOption::with([
            'productAttribute'
        ])
        ->where('option', 'like', '%' . $this->searchTerm . '%')
        ->orWhereHas('productAttribute', function ($query) {
            $query->where('attribute_name', 'like', '%' . $this->searchTerm . '%');
        })
        ->latest()
        ->paginate(5);

        $productAttributeDetails = ProductAttribute::all();

        return view('livewire.admin.product-attribute-options-manager', compact('productAttributeOptionDetails', 'productAttributeDetails'));
    }

    public function showCreateModal()
    {
        $this->resetFields();
        $this->modalFormVisible = true;
    }

    public function store()
    {
        $this->validate([
            'option' => 'required|string|max:255',
            'product_attribute_id' => 'required|exists:product_attributes,id'
        ], [
            'product_attribute_id.required' => 'Please select product attribute.',
            'product_attribute_id.exists' => 'Selected product attribute is invalid.'
        ]);

        try {
            $productAttributeOption = ProductAttributeOption::create([
                'option' => $this->option,
                'product_attribute_id' => $this->product_attribute_id
            ]);
    
            if (!$productAttributeOption) {
                session()->flash('message', 'Product attribute option creation failed.');
                $this->dispatch('showAlert', session('message'));
            }

            $this->resetFields();
            session()->flash('message', 'Product attribute option created successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while creating product attribute option. Error : ' . $e->getMessage());
        }
    }

    public function showEditModal($id)
    {
        $productAttributeOption = ProductAttributeOption::findorFail($id);

        if (!$productAttributeOption) {
            $this->resetFields();
            session()->flash('message', 'Requrested product attribute option not available for update.');
            $this->dispatch('showAlert', session('message'));
        }

        $this->option = $productAttributeOption->option;
        $this->product_attribute_id = $productAttributeOption->product_attribute_id;
        $this->productAttributeOptionId = $productAttributeOption->id;
        $this->modalFormVisible = true;
    }

    public function update()
    {
        $this->validate([
            'option' => 'required|string|max:255',
            'product_attribute_id' => 'required|exists:product_attributes,id'
        ], [
            'product_attribute_id.required' => 'Please select product attribute.',
            'product_attribute_id.exists' => 'Selected product attribute is invalid.'
        ]);

        try {
            $productAttributeOptionData = ProductAttributeOption::find($this->productAttributeOptionId);

            if (!$productAttributeOptionData) {
                $this->resetFields();
                session()->flash('message', 'Requrested product attribute option not available for update.');
                $this->dispatch('showAlert', session('message'));
            }

            ProductAttributeOption::findOrFail($this->productAttributeOptionId)->update([
                'option' => $this->option,
                'product_attribute_id' => $this->product_attribute_id
            ]);
    
            $this->resetFields();
            session()->flash('message', 'Product attribute option updated successfully.');
            $this->dispatch('showAlert', session('message'));
        } catch (\Exception $e) {
            $this->resetFields();
            session()->flash('error_message', 'Error occured while updating product attribute option. Error : ' . $e->getMessage());
        }
    }

    public function confirmDelete($id)
    {
        $this->productAttributeOptionId = $id;
        $this->deleteConfirmation = true;
    }

    public function delete()
    {
        $productAttributeOptionData = ProductAttributeOption::findOrFail($this->productAttributeOptionId)->delete();

        if (!$productAttributeOptionData) {
            $this->resetFields();
            session()->flash('message', 'Requested product attribute option not available for delete');
            $this->dispatch('showAlert', session('message'));
        }

        $this->resetFields();
        session()->flash('message', 'Prpduct attribute option deleted successfully.');
        $this->dispatch('showAlert', session('message'));
    }

    public function closeModal()
    {
        $this->modalFormVisible = false;
        $this->deleteConfirmation = false;
    }
}
