<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class AttributeOption extends Pivot
{
    protected $table = 'attribute_options';

    /* protected $fillable = ['product_id', 'product_attribute_option_id'];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function productAttributeOption()
    {
        return $this->belongsTo(ProductAttributeOption::class, 'product_attribute_option_id');
    } */
}
