<?php

namespace App\Http\Requests;

use App\Models\ProductAttributeOption;
use Illuminate\Foundation\Http\FormRequest;

class AddToCartRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $rules = [
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1'
        ];

        $product_attributes_detail = '';

        if ($this->product_attributes_detail && $this->product_attributes_detail != '') {
            $product_attributes_detail = json_decode($this->product_attributes_detail, true);
            $product_attributes_detail = (array_keys($product_attributes_detail));
        }

        $productAttributes = ProductAttributeOption::whereIn('product_attribute_id', $product_attributes_detail)
            ->whereHas('products', function ($query) {
                $query->where('products.id', $this->product_id);
            })
            ->pluck('id')
            ->toArray();

        if (!isset($rules['quantity']) || !is_array($rules['quantity'])) {
            $rules['quantity'] = ['required', 'integer', 'min:1'];
        }

        foreach ($this->all() as $key => $value) {
            if (str_ends_with($key, '_attribute_option')) {
                $rules[$key] = [
                    'nullable',
                    'integer',
                    function ($attribute, $value, $fail) use ($productAttributes) {
                        if (!in_array($value, $productAttributes)) {
                            $formattedAttribute = str_replace('_', ' ', $attribute);
                            $fail("The selected {$formattedAttribute} is invalid.");
                        }
                    }
                ];
            }
        }

        $rules['quantity'][] = function ($attribute, $value, $fail) {
            $productAttributeOptions = json_decode(json_encode([]));
            $productQuanity = [];

            foreach ($this->all() as $key => $optionId) {
                if (str_ends_with($key, '_attribute_option')) {
                    $productAttributeOptions = ProductAttributeOption::with(['products:id,quantity','productAttribute:id,attribute_name'])
                        ->where('id', $optionId)
                        ->whereHas('products', function ($query) {
                            $query->where('products.id', $this->product_id);
                        })
                        ->get();

                    if ($productAttributeOptions->isNotEmpty()) {
                        foreach ($productAttributeOptions as $productAttrbuteOption) {
                            $tempProductAttributeName = $productAttrbuteOption->productAttribute->attribute_name;
                            $tempProductAttributeOption = $productAttrbuteOption->option;
                            foreach ($productAttrbuteOption->products as $produc) {
                                $productQuanity[$tempProductAttributeName] = [
                                    'product_attribute_option' => $tempProductAttributeOption,
                                    'product_quantity' => $produc->quantity,
                                ];
                            }
                        }
                    }
            
                    if (!empty($productQuanity)) {
                        foreach ($productQuanity as $prodAttrName => $productQty) {
                            if ($value > $productQty['product_quantity']) {
                                $fail("The requested quantity for '{$prodAttrName}' Option '{$productQty['product_attribute_option']}' is not available for sale.");
                            }
                        }
                    }
                }
            }
        };

        return $rules;
    }

    /* public function messages(): array
    {
        return [
            'product_id.required' => 'The product ID is required.',
            'product_id.exists' => 'The selected product does not exist.',
            'quantity.required' => 'Please specify the quantity.',
            'quantity.integer' => 'Quantity must be a valid number.',
            'quantity.min' => 'You must order at least 1 item.'
        ];
    } */
}
