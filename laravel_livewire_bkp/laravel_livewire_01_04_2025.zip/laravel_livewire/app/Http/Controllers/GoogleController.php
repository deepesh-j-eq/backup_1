<?php

namespace App\Http\Controllers;

use App\Models\GoogleLogin;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

class GoogleController extends Controller
{
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    public function handleGoogleCallback()
    {
        try {
            /* $googleUser = Socialite::driver('google')->user();
            $finduser = User::where('google_id', $googleUser->id)->first();

            if($finduser){
                Auth::login($finduser);
                return redirect()->intended('home');
            }else{
                $newUser = User::updateOrCreate(['email' => $googleUser->email],[
                        'name' => $googleUser->name,
                        'google_id'=> $googleUser->id,
                        'password' => encrypt('123456dummy')
                    ]);

                Auth::login($newUser);
                return redirect()->intended('home');
            } */

            /* $googleUser = Socialite::driver('google')->stateless()->setHttpOptions([
                'verify' => false
            ])->user(); */

            if (request()->has('error')) {
                return redirect()->route('login.view')->with('error', 'Google login was canceled.');
            }

            Socialite::driver('google')->setHttpClient(
                new \GuzzleHttp\Client(['verify' => false])
            );

            $googleUser = Socialite::driver('google')->stateless()->user();

            $user = User::updateOrCreate([
                'email' => $googleUser->getEmail(),
            ], [
                'name' => $googleUser->getName(),
                'password' => '12345'
            ]);

            Auth::login($user);

            GoogleLogin::create([
                'google_id' => $googleUser->getId(),
                'email'     => $googleUser->getEmail(),
                'name'      => $googleUser->getName(),
                'ip_address'=> request()->ip(),
                'user_agent'=> request()->header('User-Agent'),
                'user_id'   => $user->id
            ]);

            return redirect()->route('admin.dashboard');
        } catch (\Exception $e) {
            dd($e->getMessage());
        }
    }

    public function googleLogout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('success', 'You have logged out successfully.');
    }

    public function googleLoginDetails()
    {
        $googleLoginDetails = GoogleLogin::with(['user'])->get();
        
        return view('admin.google_login_details', compact('googleLoginDetails'));
    }
}
