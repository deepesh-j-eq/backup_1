<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function yourProfile()
    {
        $authUserId = Auth::user()->id;

        $userDetails = User::where('id', $authUserId)->first();
        
        return view('admin.profile', compact('userDetails'));
    }

    public function updateYourProfile(Request $request, $userId)
    {
        $userDetails = User::where('id', $userId)->first();

        if (!$userDetails) {
            return view('admin.profile', compact('userDetails'))->with('error', 'Something went wrong! Your profile is not available for updating');
        }

        $request->validate([
            'name' => 'required|min:3|max:255',
            'email' => 'required|email:rfc,dns|max:255|unique:users,email,' . $userId
        ]);
        
        return view('admin.profile', compact('userDetails'))->with('success', 'Your profile is updated successfully');
    }
}
