<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreProductRequest;
use App\Models\Product;
use App\Models\ProductImage;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $productDetails = Product::with([
            'images' => function ($query) {
                $query->select(['id', 'image_path', 'product_id'])->limit(1);
            },
            'category'
        ])->paginate(5);

        return view('admin.products', compact('productDetails'));
    }

    public function create()
    {
        return view('admin.create_products');
    }

    public function store(StoreProductRequest $request)
    {
        try{
            $product = Product::create([
                'name' => $request->name,
                'description' => $request->description,
                'price' => $request->price,
                'discounted_price' => !empty($request->discounted_price) ? $request->discounted_price : null,
                'quantity' => $request->quantity,
                'category_id' => $request->category_id
            ]);

            if (!$product) {
                return response()->json([
                    'status'=>false,
                    'message' => 'Product creation failed'
                ], 500);
            }

            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $image) {
                    $path = $image->store('product_images', 'public');

                    ProductImage::create([
                        'image_path' => $path,
                        'product_id' => $product->id
                    ]);
                }
            }

            return response()->json([
                'status'=>true,
                'message' => 'Product creation successfully',
                'product' => $product
            ], 201);
        } catch (\Exception $e) {
            dd("dfdfdsfsd");
            return response()->json([
                'status'=>false,
                'message' => 'Opps! while creating product an error occurred: ' . $e->getMessage(),
            ], 500);
        }
    }
}
