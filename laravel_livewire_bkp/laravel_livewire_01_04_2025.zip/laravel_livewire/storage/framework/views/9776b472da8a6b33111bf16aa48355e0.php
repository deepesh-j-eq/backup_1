<?php $__env->startSection('title', 'Product Manager'); ?>
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">eCommerce</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Product Manager</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-primary">Settings</button>
                            <button type="button" class="btn btn-primary split-bg-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown"> <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-end"> <a class="dropdown-item" href="javascript:;">Action</a>
                                <a class="dropdown-item" href="javascript:;">Another action</a>
                                <a class="dropdown-item" href="javascript:;">Something else here</a>
                                <div class="dropdown-divider"></div> <a class="dropdown-item" href="javascript:;">Separated link</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end breadcrumb-->

                <div class="card">
                    <div class="card-body p-4">
                        <button class="btn btn-primary mb-3" wire:click="showCreateModal">Add Product</button>
                        <input type="text" class="form-control" wire:model.live.debounce.300ms="searchTerm" placeholder="Search products...">
                        <h5 class="card-title">Products</h5>
                        <hr />
                        <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
                        <div class="alert alert-danger text-center">
                            <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
                        <div class="alert alert-success text-center">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        

                        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                            <div id="sessionAlert" class="alert alert-success alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                <?php echo e(session('message')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <?php if(session()->has('error_message')): ?>
                            <div id="sessionAlert" class="alert alert-danger alert-dismissible fade show" onclick="hideAlert()" role="alert">
                                <?php echo e(session('error_message')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if($productDetails->isNotEmpty()): ?>
                            <?php $productAttributeOptionsArray = []; ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!--[if BLOCK]><![endif]--><?php if($product->attributeOptions): ?>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $product->attributeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $productAttributeOptionsArray[$product->id][$attr->productAttribute->attribute_name][] = $attr->option; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="table-responsive">
                            <table id="product_details_table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th style="word-wrap: break-word; max-width: 200px;">Description</th>
                                        <th>Price</th>
                                        <th>Discounted Price</th>
                                        <th>Quantity</th>
                                        <th>Category</th>
                                        <th>Product Attribute Options</th>
                                        <th>Images</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--[if BLOCK]><![endif]--><?php if($productDetails->isNotEmpty()): ?>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($product->id); ?></td>
                                                <td><?php echo e($product->name); ?></td>
                                                <td>
                                                    <span class="short-desc-<?php echo e($product->id); ?>">
                                                        <?php echo e(Str::limit($product->description, 50, '...')); ?>

                                                    </span>
                                                    <span class="full-desc-<?php echo e($product->id); ?>" style="display: none;">
                                                        <?php echo e($product->description); ?>

                                                    </span>
                                                    <!--[if BLOCK]><![endif]--><?php if(strlen($product->description) > 50): ?>
                                                        <a href="javascript:void(0);" class="read-more-btn" data-id="<?php echo e($product->id); ?>">Read More</a>
                                                        <a href="javascript:void(0);" class="read-less-btn" data-id="<?php echo e($product->id); ?>" style="display: none;">Read Less</a>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td><?php echo e(number_format($product->price, 2, '.', ',')); ?></td>
                                                <td><?php echo e(($product->discounted_price) ? number_format($product->discounted_price, 2, '.', ',') : '-'); ?></td>
                                                <td><?php echo e($product->quantity); ?></td>
                                                <td><?php echo e($product->category->name); ?></td>
                                                <td>
                                                    <!--[if BLOCK]><![endif]--><?php if(!empty($productAttributeOptionsArray)): ?>
                                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productAttributeOptionsArray[$product->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeName => $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $attributeNameCount = count($options); ?>
                                                            <!--[if BLOCK]><![endif]--><?php if($attributeNameCount == 1): ?>
                                                                <?php echo e($attributeName . " => " . implode(', ', $options)); ?>

                                                            <?php else: ?>
                                                                <?php echo e($attributeName . " => " . implode(', ', $options)); ?> <br>
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php else: ?>
                                                        <?php echo e('-'); ?>

                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td>
                                                    <!--[if BLOCK]><![endif]--><?php if($product->images): ?>
                                                        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 row-cols-xxl-5 g-3">
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="col">
                                                                    <div class="card">
                                                                        <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>" alt="<?php echo e($product->name); ?>" class="img-thumbnail" style="width: 140px; height: 100px; object-fit: contain;">
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td>
                                                    <button class="btn btn-warning btn-sm" wire:click="showEditModal(<?php echo e($product->id); ?>)">Edit</button>
                                                    <button class="btn btn-danger btn-sm" wire:click="confirmDelete(<?php echo e($product->id); ?>)">Delete</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No product details or no products created</td>
                                        </tr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </tfoot>
                            </table>
                        </div>
                        
                        <!--[if BLOCK]><![endif]--><?php if($modalFormVisible): ?>
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title"><?php echo e($productId ? 'Edit' : 'Create'); ?> Product</h5>
                                            <button type="button" class="close" wire:click="$set('modalFormVisible', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <!--[if BLOCK]><![endif]--><?php if(!empty($errorMessages)): ?>
                                                <div class="alert alert-danger p-1">
                                                    <ul>
                                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errorMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($message); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </ul>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <form id='productForm' wire:submit.prevent="<?php echo e($productId ? 'update' : 'store'); ?>">
                                                <div class="form-group">
                                                    <label for="inputProductTitle" class="form-label">Product Name</label>
                                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputProductTitle" placeholder="Enter product name" wire:model.defer="name">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputProductDescription" class="form-label">Description</label>
                                                    <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputProductDescription" rows="3" wire:model="description"><?php echo e(old('description')); ?></textarea>
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                                <div class="form-group">
                                                    <label for="image-uploadify" class="form-label">Product Images</label>
                                                    <input name="images" class="form-control <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image-uploadify" type="file" multiple wire:model="images">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                                    <!--[if BLOCK]><![endif]--><?php if($productId && $existingImages): ?>
                                                        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 row-cols-xxl-5 g-3 p-3 product-grid">
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $existingImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="col">
                                                                    <div class="card">
                                                                        <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>" alt="<?php echo e(($name) ?? ''); ?>" style="width: 140px; height: 100px; object-fit: contain;">
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <label for="inputPrice" class="form-label">Price</label>
                                                            <input type="text" name="price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputPrice" placeholder="100.00" wire:model="price">
                                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label for="inputDiscountPrice" class="form-label">Discounted Price</label>
                                                            <input type="text" name="discounted_price" class="form-control <?php $__errorArgs = ['discounted_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputDiscountPrice" placeholder="50.00" wire:model="discounted_price">
                                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['discounted_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Quantity</label>
                                                    <input type="text" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="quantity">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputCategory" class="form-label">Product Category</label>
                                                    <select name="category_id" class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputCategory" wire:model="category_id">
                                                        <option>Select Category</option>
                                                        <!--[if BLOCK]><![endif]--><?php if($categoryDetails->isNotEmpty()): ?>
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categoryDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </select>
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <label for="inputProductAttributes" class="form-label">Product Attributes</label>
                                                            <select multiple name="product_attributes" 
                                                                class="form-select <?php $__errorArgs = ['selectedProductAttributes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="inputProductAttributes" wire:model="selectedProductAttributes">
                                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productAttributeDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productAttribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <p><?php print_r($selectedProductAttributes); ?></p>
                                                                    <option value="<?php echo e($productAttribute->id); ?>"><?php echo e($productAttribute->attribute_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                            </select>
                                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedProductAttributes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>

                                                        <div class="col-md-6">
                                                            <label for="inputProductAttributeOptions" class="form-label">Product Attribute Options</label>
                                                            <select multiple name="product_attribute_options"
                                                                class="form-select <?php $__errorArgs = ['selectedProductAttributeOptions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php if(!empty($errorMessages)): ?> is-invalid <?php endif; ?>"
                                                                id="inputProductAttributeOptions" wire:model="selectedProductAttributeOptions">
                                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productAttributeOptionDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productAttributeOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($productAttributeOption->id); ?>"><?php echo e($productAttributeOption->option); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                            </select>
                                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedProductAttributeOptions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback"><strong><?php echo e($message); ?></strong></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" wire:click="$set('modalFormVisible', false)">Close</button>
                                                    <button type="submit" class="btn btn-primary" id="submitLivewireForm"><?php echo e($productId ? 'Update' : 'Create'); ?></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if($deleteConfirmation): ?>
                            <div class="modal fade show d-block" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Delete Product</h5>
                                            <button type="button" class="close" wire:click="$set('deleteConfirmation', false)">
                                                &times;
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete this product?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" wire:click="$set('deleteConfirmation', false)">Cancel</button>
                                            <button class="btn btn-danger" wire:click="delete">Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div wire:ignore.self>
                            <?php echo e($productDetails->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end page wrapper -->

        <?php $__env->startPush('clientSideValidationScript'); ?>
            <!-- <script src="https://cdn.jsdelivr.net/jquery.validation/1.19.3/jquery.validate.min.js"></script> -->
            <script>
                /* console.log('test4');
                document.addEventListener("livewire:load", function () {
                    console.log('test6');
                    $(document).ready(function () {
                        console.log('test6');
                        $("#productForm").validate({
                            rules: {
                                name: { required: true, minlength: 3 },
                                price: { required: true, number: true }
                            },
                            messages: {
                                name: { required: "Product name is required", minlength: "At least 3 characters" },
                                price: { required: "Price is required", number: "Enter a valid number" }
                            },
                            errorElement: "span",
                            errorClass: "text-danger",
                            submitHandler: function (form) {
                                console.log("Valid form submitted");
                                Livewire.emit('store');
                            }
                        });
                    });
                }); */
            </script>
        <?php $__env->stopPush(); ?>

        <?php $__env->startPush('scripts'); ?>
            <script>
                $(document).ready(function () {
                    $(".read-more-btn").click(function () {
                        let productId = $(this).data("id");
                        $(".short-desc-" + productId).hide();
                        $(".full-desc-" + productId).show();
                        $(this).hide();
                        $(".read-less-btn[data-id='" + productId + "']").show();
                    });

                    $(".read-less-btn").click(function () {
                        let productId = $(this).data("id");
                        $(".short-desc-" + productId).show();
                        $(".full-desc-" + productId).hide();
                        $(this).hide();
                        $(".read-more-btn[data-id='" + productId + "']").show();
                    });
                });

                function showAlert(message) {
                    setTimeout(hideAlert, 5000);
                }

                function hideAlert() {
                    let alertBox = document.getElementById('sessionAlert');
                    if (alertBox) {
                        alertBox.style.display = 'none';
                    }
                }

                Livewire.on('showAlert', (message) => {
                    showAlert(message);
                });

                document.addEventListener("DOMContentLoaded", function () {
                    if (typeof Livewire !== "undefined") {
                        document.addEventListener("keydown", function (event) {
                            if (event.key === "Escape") {
                                Livewire.first().call('closeModal');
                            }
                        });
                    } else {
                        console.error("Livewire is not loaded. Ensure livewireScripts is included in your layout.");
                    }
                });

                Livewire.on('refreshDropdown', () => {
                    //$('#inputProductAttributeOptions').val([]).trigger('change');
                });
            </script>
        <?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\deepesh_laravel_trainee\laravel_livewire\resources\views/livewire/admin/product-manager.blade.php ENDPATH**/ ?>