<?php

use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\HomeController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\GoogleController;
use App\Livewire\Admin\Category;
use App\Livewire\Admin\ProductAttributeOptionsManager;
use App\Livewire\Admin\ProductAttributesManager;
use App\Livewire\Admin\ProductManager;
use App\Livewire\Likes;
use App\Livewire\Posts;
use App\Livewire\ProductDetail;
use App\Livewire\Products;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('posts', Posts::class);
Route::get('likes', Likes::class);


Route::controller(AuthController::class)->group(Function() {
    Route::get('login', 'showLoginForm')->name('login');
    Route::post('login', 'login')->name('login.authentication');

    Route::get('register', 'showRegisterForm')->name('register');
    Route::post('register', 'register')->name('register.authentication');
});

Route::controller(GoogleController::class)->group(Function() {
    Route::get('auth/google', 'redirectToGoogle')->name('auth.google');
    Route::get('auth/google/callback', 'handleGoogleCallback');
});

Route::middleware('auth')->group(function() {
    Route::get('products', Products::class)->name('all.products');
    Route::get('product-detail/{productId}', ProductDetail::class)->name('product.detail');

    Route::controller(CartController::class)->group(Function() {
        Route::post('add-to-cart', 'addToCart')->name('add.to.cart');
    });

    Route::post('logout', [AuthController::class, 'logout'])->name('logout');

    Route::prefix('admin')->group(function() {
        Route::get('dashboard', [HomeController::class, 'index'])->name('admin.dashboard');

        Route::controller(GoogleController::class)->group(Function() {
            Route::get('google-login-details', 'googleLoginDetails')->name('admin.google.login.details');
            //Route::get('auth/logout', 'googleLogout')->name('logout');
        });

        Route::controller(UserController::class)->group(Function() {
            Route::get('your-profile', 'yourProfile')->name('admin.your.profile');
        });

        Route::get('categories', Category::class)->name('admin.categories');
        Route::get('product-attributes', ProductAttributesManager::class)->name('admin.product.attributes');
        Route::get('product-attribute-options', ProductAttributeOptionsManager::class)->name('admin.product.attribute.options');
        Route::get('manage-products', ProductManager::class)->name('admin.products');

        Route::controller(ProductController::class)->group(Function() {
            //Route::get('all-products', 'index')->name('all.products');
            //Route::get('product', 'create')->name('create.product');
            //Route::post('product', 'store')->name('store.product');
        });
    });
});
